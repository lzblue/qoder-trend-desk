# Delivery sinks for BRIEF / SCAN / REPORT results — options and recommendation

**Task:** mailbox `20261120T115505Z-ca4b5d` (kind=spawn, priority=high, ready-by 14:30Z per requester).
**Written:** 2026-11-20, ~12:50Z. **Scope:** survey + proposal only. No cloud write, no config change,
no new third-party account or credential, no `GO=1`. The probe in §7 is GET-only.

Labels: **[observed]** = a response or file I read in this session (or an archived artifact, cited by
path); **[documented]** = Qoder/contest docs cached in this repo; **[inferred]** = my reasoning;
**[undiscoverable]** = not answerable from anything reachable here.

---

## 1. Answer in one line

The results are **already delivered** — every desk run's full text sits in the schedule-run object's
`result_payload`, readable today from `GET /schedule_runs` with the PAT the dashboard already holds — so
the lowest-effort real sink is a **read-only `/api/runs` route on the existing `server.js`**, not a
webhook, not an email, and not the cloud `sinks[]` field.

---

## 2. First, disambiguate the two things called "sink"

**2a. The cloud field.** `sinks: []` is a property of the Forward **schedule** object (`sched_*`), sitting
beside `resources`, `execution` and `trigger_policy`. Verified live at ~12:46Z: `GET /schedules` returns
7 rows (BRIEF, SCAN-1005/1100/1230/1400, FLAT, REPORT), all `active`, every one `sinks=[] resources=[]`
— so the requester's premise is correct and current **[observed]**. Its counterpart on the *run* row is
`push_sink` / `push_status` / `push_finished_at`, and across 21 live run rows: `push_status` is
`"skipped"` on **21/21** and `push_sink` is `null` on **21/21** **[observed]**.

That is worth reading carefully: the push machinery is not missing, it is **armed and skipping**,
because there is nothing in `sinks[]`.

**2b. What `sinks[]` would actually deliver to.** The platform's delivery targets are IM **Channels**.
**[documented]** `.scratch/premarket-3bd872/official-rules.md:216` — the template editor's *Channels* tab
"shows one card per messaging provider — DingTalk, Feishu, Lark, WeCom, WeChat, Slack and Microsoft
Teams — and each card can hold up to five console-created bots"; `:249-250` requires pasting an `xapp-`
App Token and an `xoxb-` Bot token for Slack; `:549` — "Tasks created through the API are not
automatically linked to a chat conversation. Query **Schedule Runs** to retrieve results; configure sinks
separately if IM delivery is required."

So **every admissible value of `sinks[]` needs a third-party account and a vendor-issued bot token.**
That is exactly what the request excludes. `sinks[]` is therefore **out of scope by the requester's own
constraint**, not by mine **[inferred from 2b + the ask]**.

**2c. Do not blind-write the field anyway.** The JSON shape of a *non-empty* `sinks` entry is
**[undiscoverable]** from this machine — there is no example of one anywhere in the repo, and no schema
page for it is cached (I searched: the string `sinks` appears in repo code and `docs/` **zero** times; the
only hits are schedule dumps and read-back checklists). Compounding it, `sinks` is one of the fields
`20261120T115505Z-ca4b5d`'s predecessors explicitly asserted "unchanged" on write-back
(`.scratch/changes/2026-11-20-scan-timeout-max/README.md:46`), and this project has already been bitten by
a merge-patch 200 that silently discarded an unknown field. A speculative `sinks` write risks the same
class of loss to buy a channel that needs a credential. **Recommendation: leave `sinks=[]` untouched.**

---

## 3. What is already reachable from this machine

| # | Candidate | Status on this machine | Verdict |
|---|---|---|---|
| S1 | `GET /schedule_runs` → `result_payload` | 200 live, 21 rows, payload non-null 21/21 | **USE — this is the sink** |
| S2 | Local file the dashboard already polls | pattern proven by `/api/mailbox`; needs a puller | optional optimisation of S1 |
| S3 | Awareness / memory-store ledger | live store, `desk-journal.md` **absent** until tonight | complement, not answer |
| S4 | Email via an existing mail relay | **no relay is configured anywhere in this project** | **NOT AVAILABLE** |
| S5 | Inbound webhook into `server.js` | no POST route, no body parser, no public ingress | rejected |
| S6 | Cloud `sinks[]` → IM channel | needs a third-party bot token | excluded by the ask (§2b) |

**S1 — the run payload is the content, and the auth already exists.**
`GET /schedule_runs?identity_id=<id>&limit=100` → 200 **[observed ~12:46Z]**. Envelope
`data / first_id / last_id / has_more`; pagination is `after_id`/`last_id` **[observed]**
`.scratch/cont-scan-1120/tools/pullall.mjs:16-27`. Row keys **[observed]**:
`initial_events_version, source, source_session_id, id, schedule_id, identity_id, template_id,
session_id, status, trigger_context, error, result_payload, error_message, push_sink, push_status,
push_finished_at, attempt, triggered_at, started_at, completed_at, duration_ms, created_at`.
`result_payload` is a plain string holding the coordinator's own final narrative for that leg — the
BRIEF/SCAN/REPORT text the owner wants to read. Sizes over 27 cached rows: 742–7,401 ch; live: 88–7,401
ch, median 2,554 **[observed]**. The `failed` row still carries 986 ch plus `error_message`
**[observed]**, so **failures arrive on the same path** — which is the property that makes this a real
delivery channel rather than a success-only ticker.
Cost: nothing new. `server.js` already authenticates against
`API_BASE = 'https://api.qoder.com/api/v1/forward'` with `QODER_PAT` via `qoderGet()`
([server.js:19-21](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L19-L21),
[:65-74](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L65-L74)), and `identity_id`
is resolvable from a session row **[observed]** rather than needing a new constant.

**S4 — stated plainly because the ask asked for it.** `.env.example` defines exactly five keys
(`QODER_PAT`, `TMPL_COORDINATOR/RESEARCHER/EXECUTOR/RISK_AUDITOR`, `PORT`,
`MAILBOX_NOMINAL_INTERVAL_MIN`) and `.env` six (`QODER_PAT`, four `TMPL_*`, `PORT`) — names only, values
not read out **[observed]**. **Neither file contains any SMTP host, port, from-address, relay or mail
credential**, and nothing in the repo mentions a webhook URL, tunnel or mail transport **[observed]**.
So: **there is no existing mail relay to reuse, and email is off the table without a new credential.**
Naming trap worth recording: "mailbox" in this project is `.scratch/mailbox/`, a **filesystem directory**
(`MAILBOX_DIR`, [server.js:22](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L22));
it has no relationship to email. If the ask's "existing mail relay" was inferred from the word *mailbox*,
that inference does not hold.

**S5 — the inbound webhook does not exist and cannot be made to work here.** `server.js` registers four
routes and all four are `app.get` — `/api/health` `:195`, `/api/mailbox` `:341`, `/api/sessions` `:345`,
`/api/overview` `:369` **[observed]**. There is no `app.post` and no `express.json()`/`urlencoded` body
parser mounted; only `express.static('public')` `:51` **[observed]**. More fundamentally, a cloud session
has nothing to call back *into*: this box is a home PC, the repo configures no tunnel or reverse proxy
**[observed — negative search]**, and the sandbox is not durable across runs — which is why that REPORT
payload's own text says `/data/desk` is "absent again at session start (7th consecutive)". **[observed as
agent-authored text inside `result_payload`]**: the "7th" count is the agent's claim, not my measurement;
the ephemerality itself is established independently in
`.scratch/changes/2026-11-20-journal-persistence/README.md` §1a-§1b. Making an inbound sink work would mean a public tunnel = a new third-party
service, **and** it would expose an unauthenticated write endpoint, since none of the current routes carry
any auth **[observed]**. Rejected on both effort and security grounds.

**S3 — the structured complement, live tonight, with two measured caveats.** The desk's durable store is
`memstore_00vred2knjpq9k09ei99`, mounted read-write in the sandbox at `/data/.agent/awareness/`, and it is
**one store shared by all four agents** because all 7 schedules fire the coordinator template while
researcher/executor/risk_auditor run as threads inside that session
(§1a of `.scratch/changes/2026-11-20-journal-persistence/README.md`, applied LIVE 10:54:56Z). Measured now
**[observed]**: 6 memories — `paper-desk-constraints.md` 55,582 B, `market-data-feeds.md` 20,061 B,
`event-calendar-nov17-19-2026.md` 10,814 B, `entry-window-mechanics.md` 2,881 B,
`guard-build-pinning.md` 2,583 B, `MEMORY.md` 1,847 B. `desk-journal.md` is **still absent**, as expected:
the first run under the amended prompt is tonight's REPORT at 21:15Z.
Two caveats that change the design:
1. The **list** endpoint `GET /memory_stores/{store}/memories` returns
   `id, type, memory_store_id, path, content_size_bytes, content_sha256, metadata, created_at, updated_at`
   and **no `content` key** **[observed]**. Content needs a second call per memory;
   `GET /memory_stores/{store}/memories/{mem_id}` → 200 **does** return `content` **[observed]**.
   So a journal-based panel is 1 + N requests, not 1.
2. `content_size_bytes` is **bytes**, not characters: `MEMORY.md` declared 1,847 B and the returned string
   measured 1,821 JS chars **[observed]**. **[inferred]** non-ASCII content. Anything sizing a pane should
   use `Buffer.byteLength(content)`, not `.length`.
Also note the **100 KiB per-memory cap** **[documented]**
(`.scratch/changes/2026-11-20-journal-persistence/probe/ms-schemas.md`), which a growing daily journal will
eventually hit — so S3 wants a roll-over rule before it is load-bearing.

**S2 — the free-page variant of S1.** `/api/mailbox` proves the house pattern for a zero-API-call panel:
it is pure `fs` reads of `.scratch/mailbox/` and its comment says so deliberately
([server.js:199-203](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L199-L203)).
The 2-minute cron wake already runs on this box, so it could `GET /schedule_runs` and write
`.scratch/desk/runs.json` for the route to read. **Not recommended as the first move:** it duplicates the
fetch, adds a step and a failure mode to a hot path, and costs up to 2 minutes of extra latency, in
exchange for saving one authenticated GET per 30 s page refresh — which S1 can absorb in the existing
`cached()` helper ([server.js:55-62](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L55-L62)).

---

## 4. What is NOT a gap, and one that IS

The dashboard already surfaces the **structured** skill output: `mineSession()` walks each session's event
history and classifies embedded JSON blobs into `guard` / `signal` / `equity_row` / `stats`
([server.js:160-191](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L160-L191)), and
`/api/overview` publishes the decision log, signals and equity curve `:403-443`. So verdicts and numbers
already reach the page.

The genuine gap is the **narrative**: nothing anywhere in `server.js` or `public/` references
`schedule_run`, `result_payload` or `push_status` **[observed — negative search]**, and the brief prose the
BRIEF/SCAN/REPORT legs produce is visible today only inside `logs/`, `.scratch/` dumps and this mailbox —
i.e. nowhere the owner looks. **S1 closes exactly that gap and nothing else.**

---

## 5. Recommendation

**Do S1.** Add one read-only `app.get('/api/runs')` to `server.js` that calls
`GET /schedule_runs?identity_id=…&limit=100`, joins `schedule_id → name` from `GET /schedules`, keeps the
newest row per leg (BRIEF / SCAN-* / FLAT / REPORT), and returns `{leg, name, status, triggered_at,
completed_at, duration_ms, error_message, payload}`. Reuse `qoderGet()` and wrap it in `cached('runs',
20_000, …)`. No new dependency, no `.env` change, no cloud write, no credential, no body parser.

**Then S3 tonight, only if the journal actually lands.** Re-run `check-store.mjs` after 21:15Z
(command in §7). If `desk-journal.md` exists, add it as a second pane — it is *structured* and
*desk-authored*, which `result_payload` is not. If it is absent, the auditor amendment is not doing its
job and that is the finding, not the sink.

**Do not** touch `sinks[]`, and do not add an inbound POST.

---

## 6. Handoff to the activity strip (mailbox `...-d2c86f`) — coordinate, don't duplicate

d2c86f is **alive and owns `server.js` + `public/\*`**: its claim was rewritten 12:30:25Z with
`session_id cf337d21-c3b5-5891-a220-14277c8077a8` **[observed]**. I therefore **did not edit `server.js`,
`public/app.js`, `public/index.html` or `public/style.css`** — the strip is its deliverable, and this file
is a proposal to it, not a competing implementation. It has written nothing yet (`files_changed: []`, and
no `.scratch/*d2c86f*` directory exists **[observed]**), so the routes are still at the 08:00 local state.

The strip ask needs "today's count of entries / exits / rejections by sleeve and the time of the last
agent action". **S1 answers the second half for free, and it should not be built twice:**

| strip field | source |
|---|---|
| last agent action (time) | newest `schedule_runs[].completed_at` |
| which leg last ran | its `schedule_id` → `GET /schedules[].name` |
| running / failed / timed out | `status` + `error_message`; `duration_ms == execution.timeout_ms` is the timeout signature |
| per-leg "last result" text | `result_payload` |
| entries / exits / rejections by sleeve | **NOT here** — that is guard/fill semantics; use `/api/overview`'s `decision_log` and the sleeve-B order rows. `result_payload` is prose and must not be counted. |

Three defensive rules, each bought with an observation:

1. **A `schedule_id` on a run may not resolve to any schedule.** The newest run right now belongs to
   `sched_fc9fc2c0aed7195258e8e3de`, which is **absent from `GET /schedules`** — `once` schedules
   auto-archive and drop out of the list while their runs persist **[observed]**. Never build a lookup
   that assumes the join succeeds; fall back to the raw id.
2. **A payload can be almost empty.** The same run carries **88 characters** **[observed]**, against a
   742-ch minimum in the older cached rows. Render it as a truncation-free paragraph with a min-height,
   not a card designed around ~3 KB — this is the same "never crash the page" instruction d2c86f was
   already given for unknown option row shapes.
3. **Content is not fresh.** Every one of the 27 rows I have carries both `completed_at` and a non-null
   `result_payload`, and I never observed an in-flight row, so treat the payload as landing **at run end**
   **[observed]** — do not build a panel that expects partial text mid-leg. Measured trigger→completed lag
   **148 s – 1,800 s**, median ~513 s over 27 rows **[observed]**, so a SCAN's text appears ~5–20 minutes
   after it starts. The 1,800 s extreme is verified rather than guessed: SCAN-1005
   `sched_9e39ba55d65df537f059e7e5`, `status:"failed"`, `duration_ms == timeout_ms == 1800000`,
   `error_message: "consume schedule session stream failed: context deadline exceeded"` **[observed]** —
   and it still delivered 986 ch of payload, which is the case the pane must render well. Label the pane
   "after the leg finishes", never "live"; a *live* indicator has to come from session status
   (`/api/sessions`), not from runs.

**Today, for context:** as of ~12:47Z the only 2026-11-20 run recorded is the 08:42Z probe above — none of
the seven desk legs has fired today, the earliest being BRIEF at 14:00Z **[observed]**. So the first thing
this sink would show is yesterday's REPORT, 933 minutes old. A `last result` pane that goes quiet all
morning is therefore **correct**, not broken, and should say so (e.g. "no leg has run today").

---

## 7. Commands — all read-only, nothing to apply from this memo

Prove the central claim (GET only; prints counts, field names and sizes, never payload text and never the
PAT): `node --env-file=.env .scratch/delivery-ca4b5d/probe.mjs`
Run it on this machine, re-verified live ~12:46Z: 21 rows, `result_payload` non-null 21/21,
`push_status ["skipped"]`, `push_sink` null 21/21, 7 schedules all `sinks=[]`, 6 memories,
`desk-journal.md` absent.

Check tonight whether S3 earned its pane (after 21:15Z):
`node --env-file=.env .scratch/changes/2026-11-20-journal-persistence/tools/check-store.mjs`

**There is no `GO=1` line here and none should be typed.** S1 is a *local code* change to files d2c86f
owns; the owner's action is to accept or reject §5/§6 and let that child (or a follow-up dispatch) write
the route. No cloud object was created or modified by this task **[observed]**.

---

## 8. What I could not establish

- **The schema of a non-empty `sinks[]` entry, and what `push_*` becomes when a sink is configured.**
  No such row or doc exists on this machine **[undiscoverable]**. Anyone later setting `sinks` cannot
  verify it from a read-back of the field alone; they must check `push_status` moves off `"skipped"`.
- **Whether `result_payload` has a server-side cap.** Max observed 7,401 ch with no truncation marker
  (0/27 rows end in an ellipsis **[observed]**); nothing near a limit was produced, so a cap is
  unproven either way.
- **Whether `result_payload` is the coordinator's *final* message or a concatenation.** In the REPORT row
  it reads as one narrative that merges the dispatch note and the completion note into a single string
  **[observed]**, which is why §6 forbids counting entries from it. The producing rule is
  **[undiscoverable]** from the row.
- **Channel-side behaviour** (Slack/Feishu/etc.): docs-only **[documented]**, and untestable here without
  the excluded credential.
- **Whether `desk-journal.md` will in fact appear** — that resolves only after tonight's 21:15Z REPORT.
- **`MAILBOX_DIR` is read by [server.js:22](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/server.js#L22)
  but is absent from `.env.example`** **[observed]** — an undocumented-but-harmless override, noted only so
  nobody later mistakes it for a delivery setting.

## 9. Change log

- 2026-11-20 ~12:50Z — created by mailbox `20261120T115505Z-ca4b5d`. Files added: this memo and
  `.scratch/delivery-ca4b5d/probe.mjs`. No other file touched; `server.js` and `public/*` deliberately
  left to `d2c86f`.
