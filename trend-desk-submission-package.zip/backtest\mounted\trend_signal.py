#!/usr/bin/env python3
"""trend-signal: opening-range breakout + VWAP trend signal and regime filter (stdlib only).

Usage:
  python trend_signal.py signal --input summary.json
  python trend_signal.py regime --input snapshot.json
The model supplies a compact summary (a handful of numbers per ticker), not hundreds of bars, to save tokens.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

# long ETF used for the signal -> bearish instrument (we never short shares: inverse ETFs have no borrow fee)
# SPY's bearish instrument was SPXS until 2026-11-20; it was removed because its net assets sit below the
# competition's $500M eligibility floor. SPY keeps its LONG leg and has no short instrument until the owner
# names an eligible replacement: short is None, and signal() returns NONE instead of guessing a substitute.
PAIRS = {
    "QQQ": {"long": "QQQ", "short": "SQQQ", "lev": 3},
    "SMH": {"long": "SMH", "short": "SOXS", "lev": 3},
    "SPY": {"long": "SPY", "short": None, "lev": None},
}

# ---- regime inputs: fail closed on missing / invalid / stale data ----
# Required numeric inputs, each sourced natively from moomoo index day-klines via the
# double-dot format (US..VIX, US..VXN, US..NDX, US..SPX, US..SOX). If any is absent,
# non-numeric, out of range, NaN/inf, or the snapshot is stale, regime() returns the most
# conservative real bucket (bear_high_vol) instead of raising — fail closed, not fail crash.
REQUIRED = ("vix", "vxn", "ndx_close", "ndx_sma200", "spx_close", "spx_sma200", "sox_5d_return_pct")
# Loose sanity bounds so a wrong-field value (e.g. VIX=7000) is treated as invalid rather than
# silently producing an absurd regime. Wide enough to never reject a real print.
BOUNDS = {
    "vix": (1.0, 200.0), "vxn": (1.0, 200.0),
    "ndx_close": (1000.0, 1_000_000.0), "ndx_sma200": (1000.0, 1_000_000.0),
    "spx_close": (100.0, 1_000_000.0), "spx_sma200": (100.0, 1_000_000.0),
    "sox_5d_return_pct": (-90.0, 200.0),
    # Optional: breadth is the one regime input with no native moomoo price source (it is a
    # new-highs-minus-new-lows count, not a quote). It contributes a bear flag only when a
    # value is supplied; its ABSENCE never fails the regime closed, so the desk can still read
    # a genuine regime from the 7 natively-sourced fields.
    "nasdaq_highs_minus_lows": (-100_000.0, 100_000.0),
}
FAIL_CLOSED = {"regime": "bear_high_vol", "size_mult": 0.5, "allow_long": False,
               "allow_bearish_etf": True, "hedge_mult": 1.5}


def _fnum(s, key):
    """Return s[key] as a finite float inside BOUNDS, else None (bool/None/str/NaN/inf/out-of-range)."""
    if not isinstance(s, dict):
        return None
    v = s.get(key)
    if isinstance(v, bool) or v is None:
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    if x != x or x in (float("inf"), float("-inf")):
        return None
    lo, hi = BOUNDS.get(key, (float("-inf"), float("inf")))
    if not (lo <= x <= hi):
        return None
    return x


def _stale(s):
    """(is_stale, reason). Only assessed when both as_of_et and now_et are present
    (YYYY-MM-DD or ISO); absent timestamps are NOT treated as stale (value checks still apply).
    Freshness window defaults to 4 calendar days (bridges a normal weekend); override with
    stale_max_days."""
    if not isinstance(s, dict):
        return (False, None)
    a_raw, n_raw = s.get("as_of_et"), s.get("now_et")
    if not a_raw or not n_raw:
        return (False, None)
    try:
        a = datetime.fromisoformat(str(a_raw)[:10])
        n = datetime.fromisoformat(str(n_raw)[:10])
    except ValueError:
        return (True, f"unparseable as_of_et/now_et ({a_raw!r}/{n_raw!r})")
    age = (n - a).days
    win = _fnum(s, "stale_max_days")
    win = 4.0 if win is None else win
    if age > win:
        return (True, f"data age {age}d exceeds {win:g}d freshness window")
    return (False, None)


def bear_flags(s: dict) -> list[str]:
    """Bear flags from whatever inputs are valid; a missing/non-numeric value simply skips that
    comparison (recorded by regime(), which fails closed on any REQUIRED gap). Thresholds unchanged."""
    f = []
    ndx_c, ndx_s = _fnum(s, "ndx_close"), _fnum(s, "ndx_sma200")
    spx_c, spx_s = _fnum(s, "spx_close"), _fnum(s, "spx_sma200")
    vix, vxn = _fnum(s, "vix"), _fnum(s, "vxn")
    sox5 = _fnum(s, "sox_5d_return_pct")
    nhl = _fnum(s, "nasdaq_highs_minus_lows")
    if ndx_c is not None and ndx_s is not None and ndx_c < ndx_s:
        f.append("NDX below 200-day")
    if spx_c is not None and spx_s is not None and spx_c < spx_s:
        f.append("SPX below 200-day")
    if vxn is not None and vix is not None and vxn - vix > 8:
        f.append(f"VXN-VIX spread {vxn - vix:.1f}")
    if sox5 is not None and sox5 < -8:
        f.append(f"SOX {sox5:.1f}% in 5 days")
    if nhl is not None and nhl < -100:
        f.append("breadth: new lows dominate")
    if vix is not None and vix >= 30:
        f.append("VIX >= 30")
    return f


def regime(s: dict) -> dict:
    """Computed regime when all REQUIRED inputs are valid and fresh; otherwise the conservative
    bear_high_vol bucket, marked source=fail_closed so logs separate degraded from real reads.
    allow_bearish_etf is True in every path (unchanged): a degraded read vetoes longs, not shorts."""
    flags = bear_flags(s)
    missing = [k for k in REQUIRED if _fnum(s, k) is None]
    stale, stale_reason = _stale(s)
    if missing or stale:
        reasons = []
        if missing:
            reasons.append("missing/invalid inputs: " + ", ".join(missing))
        if stale:
            reasons.append("stale: " + stale_reason)
        sys.stderr.write("[trend-signal] REGIME FAIL-CLOSED (NOT a computed regime): "
                         + "; ".join(reasons)
                         + " -> conservative bear_high_vol, allow_long=False\n")
        out = dict(FAIL_CLOSED)
        out["bear_flags"] = flags
        out["degraded"] = True
        out["source"] = "fail_closed"
        out["degraded_reasons"] = reasons
        return out
    vix = _fnum(s, "vix")
    if vix >= 35:
        name, mult, longs, shorts, hedge = "crisis", 0.25, False, True, 1.5
    elif vix >= 28 or len(flags) >= 4:
        name, mult, longs, shorts, hedge = "bear_high_vol", 0.5, False, True, 1.5
    elif len(flags) >= 2:
        name, mult, longs, shorts, hedge = "caution", 0.75, True, True, 1.5
    elif vix < 13:
        name, mult, longs, shorts, hedge = "low_vol", 0.5, True, True, 1.0
    else:
        name, mult, longs, shorts, hedge = "normal", 1.0, True, True, 1.0
    # In a bearish regime long ideas need an extra condition (checked in signal): confirmation above VWAP AND range high.
    return {"regime": name, "size_mult": mult, "allow_long": longs, "allow_bearish_etf": shorts,
            "hedge_mult": hedge, "bear_flags": flags, "degraded": False, "source": "computed"}


def signal(s: dict, reg: dict) -> dict:
    """s: ticker, time_et 'HH:MM', price, vwap, or_high, or_low, [inverse_price]. Opening range = first 30 minutes."""
    t = s["ticker"]
    if t not in PAIRS:
        return {"action": "NONE", "reason": f"{t} not a signal ticker"}
    h, m = s["time_et"].split(":")
    now_m = int(h) * 60 + int(m)
    if now_m < 10 * 60:
        return {"action": "NONE", "reason": "opening range not complete before 10:00 ET"}
    if now_m > 14 * 60 + 30:
        return {"action": "NONE", "reason": "too late for a new trend entry"}
    price, vwap, hi, lo = s["price"], s["vwap"], s["or_high"], s["or_low"]
    rng = hi - lo
    rng_pct = rng / price * 100
    if not 0.15 <= rng_pct <= 1.5:
        return {"action": "NONE", "reason": f"opening range {rng_pct:.2f}% outside 0.15-1.5%"}
    mid = (hi + lo) / 2
    pair = PAIRS[t]
    if price > hi + 0.1 * rng and price > vwap and price - hi <= rng:
        side = "LONG"
    elif price < lo - 0.1 * rng and price < vwap and lo - price <= rng:
        side = "SHORT"
    else:
        return {"action": "NONE", "reason": "no confirmed breakout beyond the opening range on the right side of VWAP"}
    if side == "LONG" and not reg["allow_long"]:
        return {"action": "NONE", "reason": f"regime {reg['regime']}: no long entries"}
    if side == "SHORT" and not reg["allow_bearish_etf"]:
        return {"action": "NONE", "reason": f"regime {reg['regime']}: no bearish entries"}
    if side == "LONG":
        stop = max(mid, vwap) - 0.1 * rng
        dist = price - stop
        target = price + 1.5 * dist
        instrument, entry, lev = pair["long"], price, 1
    else:
        if pair["short"] is None:
            return {"action": "NONE", "reason": f"{t} has no eligible bearish ETF configured - long entries only"}
        stop = min(mid, vwap) + 0.1 * rng
        dist = stop - price
        target = price - 1.5 * dist
        instrument, lev = pair["short"], pair["lev"]
        entry = s.get("inverse_price")
        if entry is None:
            return {"action": "NONE", "reason": "need inverse_price to size the bearish ETF"}
    if dist <= 0 or dist > rng:
        return {"action": "NONE", "reason": "stop distance invalid or wider than the opening range (poor reward/risk)"}
    pct = dist / price
    inst_stop = entry * (1 - lev * pct)
    inst_target = entry * (1 + lev * 1.5 * pct)
    return {"action": side, "signal_ticker": t, "instrument": instrument, "leverage": lev,
            "underlying": {"price": price, "stop": round(stop, 2), "target": round(target, 2)},
            "entry": round(entry, 2), "stop": round(inst_stop, 2), "target": round(inst_target, 2),
            "reward_risk": 1.5, "reason": f"{side} breakout of {rng_pct:.2f}% opening range, price {'above' if side == 'LONG' else 'below'} VWAP",
            "regime": reg["regime"], "regime_mult": reg["size_mult"]}


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["signal", "regime"])
    ap.add_argument("--input", required=True)
    a = ap.parse_args()
    if a.cmd == "regime":
        try:
            data = json.loads(Path(a.input).read_text())
        except (OSError, ValueError) as e:
            sys.stderr.write(f"[trend-signal] REGIME FAIL-CLOSED (NOT a computed regime): input unreadable/invalid JSON: {e}\n")
            print(json.dumps({**FAIL_CLOSED, "bear_flags": [], "degraded": True,
                              "source": "fail_closed", "degraded_reasons": [f"input read error: {e}"]},
                             ensure_ascii=False))
            return
        print(json.dumps(regime(data), ensure_ascii=False))
    else:
        data = json.loads(Path(a.input).read_text())
        print(json.dumps(signal(data["summary"], data["regime"]), ensure_ascii=False))


if __name__ == "__main__":
    main()
