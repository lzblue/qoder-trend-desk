# Trend desk — trading journal (submission ledger)

Append-only ledger for the Moomoo x Qoder AI Trading Agent Challenge entry.
Trading window: **17–28 Nov 2026**. Submission deadline: **30 Nov 2026, 23:59 SGT**.
Account: **5830104** — "Moomoo x Qoder AI Paper Trading Agent Challenge" (SIMULATED funds only).

**NAV convention (owner ruling, 2026-11-25): position basis** — NAV includes the open
position's cost basis, so a fill's commission is charged to cost basis rather than shown
as a separate fee line. The desk's own `equity` ledger and the broker's `total_asset`
both use this basis (broker reads `99825.821` at the 24 Nov close).

**Two phases, deliberately separated.** 17–23 Nov was build and bring-up: the desk was
being wired, instrumented and de-blocked, and it placed no strategy orders. **Live
strategy trading started 24 Nov 2026.** Performance is therefore measured from the first
live trading day, not from the start of the window. Do not present 17–23 Nov as a
performance period — it is the engineering period, and it is reported as such.

## 1. Equity ledger

Source: `logs/equity.csv`, extracted from Forward session events by
`node tools/export-decisions.mjs`. Columns are the desk's own journal header.

| et_date | nav | spy_close | peak_nav | signals | vetoes | approvals | fills | closes | net_realized_pnl | expectancy | n |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 2026-11-20 | 99,998.11 | 689.81 | 100,000.00 | na | na | na | 0 | 0 | 0.00 | na | na |
| 2026-11-23 | 99,998.11 | 722.29 | 100,000.00 | 0 | 0 | 0 | 0 | 0 | 0.00 | na | 0 |
| **2026-11-24** | **99,825.82** | 718.78 | 100,000.00 | **1** | 0 | **1** | **1** | **1** | **-172.29** | -172.29 | **1** |
| 2026-11-25 | — | — | — | | | | | | | | |
| 2026-11-26 | — | — | — | | | | | | | | |
| 2026-11-27 | — | — | — | | | | | | | | |

No equity rows exist for 17, 18 or 19 Nov: the journal was created during bring-up and
the first `journal.py equity` write landed on 20 Nov. The 17 Nov starting NAV is known
independently — the account opened at 100,000.00.

## 2. Reconciliation — the whole P&L, to the cent

| Component | Amount | Evidence |
|---|---|---|
| Starting capital, 17 Nov | 100,000.00 | account open |
| 19 Nov calibration probe (AAPL 1 sh round trip) | **-1.89** | fills `3393381` / `3393382` |
| 24 Nov strategy trade (SQQQ 119 sh round trip) | **-172.29** | fills `3401709` / `3401916` |
| **NAV at 24 Nov close** | **99,825.82** | journal + broker `total_asset` |

100,000.00 - 1.89 - 172.29 = 99,825.82. Every dollar of competition P&L is explained by
two round trips, one of which was a market-mechanics calibration test and is disclosed as
such. Cumulative return **-0.174%**; peak-to-trough drawdown **0.174%**.

## 3. Narrative by day

### Phase 1 — build and bring-up (17–23 Nov), no strategy risk

| Date | What actually happened | Orders placed |
|---|---|---|
| 17 Nov | Launch. Templates, skills and schedules created; guard crash (`AttributeError` on the option proposal) discovered and worked around by disabling Sleeve B. | 0 |
| 18 Nov | Venue/eligibility probes. Five SPY test orders placed outside market hours, all cancelled — zero fills. This is where the "market order is rejected for an index ticker on this account" finding came from. | 5 (0 filled) |
| 19 Nov | Fill mechanics calibrated: 1-share AAPL round trip to learn how the paper venue matches pre-market limits, plus one option probe that was cancelled (no fill). Cost: **-1.89**. | 3 (2 filled) |
| 20 Nov | First equity row written (99,998.11). Guard veto path verified. `docs/decisions/vix-gate-and-zero-trades-nov20.md` written: 30 SCAN sessions replayed, **0 trades**, and the owner's VIX/`allow_long` theory was refuted with evidence. | 0 |
| 23 Nov | Desk stood flat: `signals 0`. Guard vetoed new risk with `state_unavailable`; a second probe vetoed with `ticket_price_stale`. Both are the fail-closed rule working, not a data gap. | 0 |

Bring-up blockers found and cleared (each has its own dated record under
`docs/decisions/`, `docs/incidents/` and `docs/bugs/`): option proposal crash, SPXW
rejected by the stock-eligibility gate, **no protective stop exists on this paper venue**
(limit/market only, and rule 17 makes a below-last-price sell limit match rather than
rest) — which forced the monitored-stop redesign — option fees not exposed by any fee
endpoint, expired option chains purged, MCP tool definitions missing from the first model
request, and per-session sandbox storage that does not survive a run boundary.

### Phase 2 — live trading (24 Nov onward)

**24 Nov — first strategy signal, approved, filled, and closed by risk rule.**

| Step | Record |
|---|---|
| 11:00 ET SCAN | Sleeve A signal on **SQQQ** (bearish idea, 3x inverse ETF) — `signals 1` |
| Approval | Guard verdict `approved: true`, 119 shares, stop 48.25 — planned risk 119 x $1.46 = **$173.74**, 0.174% of NAV — `approvals 1` |
| Entry | LIMIT buy 119 @ 49.71 → **filled 119 @ 49.71**, order `3401709` |
| Protective leg | tp_limit SELL 119 @ 51.90, order `3401719` — cancelled before it could match |
| Exit | 12:30 ET: resting stop breached → LIMIT sell 119 @ 48.26 → **filled 119 @ 48.279**, order `3401916` |
| Result | realized gross **-170.29**, fees **2.00**, **net -172.29** (-0.172%) |
| Book after | flat, `qty 0, mv 0`, balance = total_asset = 99,825.821 |

**What this proves:** the full round trip ran end-to-end without a human in the loop —
signal → independent guard approval → limit entry → monitored stop → close → ledger.
Position was risked for 89 minutes and never exceeded its approved size.

**What failed:** the bearish signal was taken on a session that rebounded. The desk's own
fills put SQQQ at 49.71 → 48.279, i.e. **-2.88% against the position in 89 minutes**,
while SPY closed **down 0.49%** that day (722.29 → 718.78, verified daily close series).
So the exit was correct and fast, the entry was not. Two lessons were carried forward:
the stop distance was tighter than the instrument's own intraday range, and the signal
fired on a partial-day VWAP/opening-range context rather than a confirmed break.

Benchmark, verified daily closes (`US.SPY`, `quote_cur_kline` ktype Day):

| et_date | 17 Nov | 18 | 19 | 20 | 23 | 24 |
|---|---|---|---|---|---|---|
| SPY close | 732.44 | 730.20 | 715.87 | 689.81 | 722.29 | 718.78 |

Measured from the first live trading day (24 Nov prior close 722.29 → 718.78), **SPY fell
0.486% and the desk fell 0.172%** — the desk lost less than the index on its first trading
day, which is the correct comparison for a risk-adjusted-return claim. The alternative
comparison (index down 1.87% from 17 Nov while the desk sat idle) is **not** performance
and is excluded from the return claim by design.

### 25–27 Nov — the remaining window, and what still has to be appended

The calendar below is **read**, not assumed: `quote_trading_days(US, 2026-11-24 →
2026-11-30)` returns 24, 25, 27 and 30 Nov only — 26 Nov is absent (closed) and 27 Nov
comes back `MORNING / 12,600 s`, a three-and-a-half-hour session. `calendar_rules.py` in
the mounted guard build encodes the same two facts.

| Date | Broker calendar | Desk state it maps to | Consequence for risk |
|---|---|---|---|
| Wed 25 Nov | `WHOLE`, 23,400 s | `status: open`, `size_mult 0.75` | entries 10:00–14:00 ET; PCE, GDP and jobless claims all print 08:30 ET, ahead of the entry window; the fly stays permitted (owner ruling B7, 2026-11-22 withdrew the Wednesday condition) |
| Thu 26 Nov | absent — **closed** | `status: closed` | coordinator logs a note and stops. The crons are Mon–Fri, so they still fire: the day gate is the only thing between them and an order. **Never exercised** — this desk has not run a closed day on the production schedule |
| Fri 27 Nov | `MORNING`, 12,600 s | `status: half_day`, `size_mult 0.5` | 09:30–13:00 ET; entry cut-off 11:30, flat by 12:45; `FLY_OFF` covers the date because the final ranking is taken at that close |
| Mon 30 Nov | `WHOLE` | — | outside the trading window; submission day, no risk |

**Disclosed gap.** The half-day branch substitutes `timing.entry_end_et` → 11:30 and
`timing.flat_by_et` → 12:45, which the share sleeves read. It does **not** reach
`structure.exit`: `last_check_et` 15:30 and `shorts_flat_by_et` 15:25 are read verbatim
(`guard.py:975,986` take them straight from `ex`), and the crons — SCAN-1400,
OPT-CLOSE-1530, FLAT 15:30, REPORT 16:15 — do not move either. On 27 Nov that branch is
unreachable only because `FLY_OFF` covers the date. The blackout, not the clock.

**Config change on the morning of 25 Nov.** desk-risk-guard published `1795571706823549`
(rules `2026-11-25.1`) at 01:55:06Z and the three trading templates were re-pinned to it
within the next minute; a second build `1795575276828792` (rules `2026-11-25.2`) went out at
02:54:36Z and the same three were re-pinned to it at 02:55:13Z. The intermediate stamp is not
re-readable — `/templates` keeps only one `updated_at`, and it now shows the later write.
(`GET /templates` returns `updated_at` in `+08:00` and `GET /skills` returns it in `Z`; the
two agree once the offset is applied — the first draft of this paragraph read the `+08:00`
stamp as UTC and was wrong by eight hours.)
`guard.py`, `book.py`, `levels.py` and `SKILL.md` are byte-identical across all three builds
(`guard.py` sha256 `a4ea554b1d1a…`) — the deltas are `structure.max_loss_pct_of_nav`
**0.75 → 1.5** and `structure.fee_max_pct_of_credit` **10.0 → 12.5**, whose reason is recorded
in the file itself: at 0.75% one SPY lot risked $778 on 23 Nov (0.78% of NAV needed) and
$1,267 on 24 Nov (1.27%) against a $750 budget, so the sleeve could not be sized at any price
the market quoted. 1.5 is the largest value this file can carry while
`risk.max_open_risk_pct` stays 1.5. The live mounted head as of 25 Nov 03:00Z is
`1795575276828792`, bound on all six desk templates (coordinator carries no skills at all).

To append after each of the three remaining days: signals, approvals, fills with order
ids, closes with realized P&L, end-of-day NAV, and one paragraph on what worked / failed /
why. After 27 Nov close, freeze the ledger, re-run `node tools/export-decisions.mjs
--fetch`, and re-generate the deck from these files.

### Measured usage, re-derived 2026-11-25 from the event cache

Buckets are the session's `created_at` date (UTC). Credits are deduplicated to **one
figure per session** — the maximum `total_credits` across that session's `session.usage`
events — then summed; summing the events themselves double-counts by an order of magnitude.

| Day | Sessions | Credits |
|---|---|---|
| 17 Nov | 15 | 59.39 |
| 18 Nov | 13 | 112.56 |
| 19 Nov | 23 | 165.13 |
| 20 Nov | 7 | 149.89 |
| 23 Nov | 32 | 113.18 |
| 24 Nov | 31 | 47.25 |
| **total** | **121** | **647.40** |

647.40 = 575.42 model + 71.42 sandbox + 0.56 other. The same 121 session files carry
**60,936 events**. This is a **lower bound**: the sessions list rejects `limit=100` and
returns at most 50 per template per request, and this pass did not paginate, so a few
early sessions may be missing.

The first live round trip (24 Nov, 11:00 → 12:33 ET) therefore costs **47.25 credits, not
"about 15"** — that figure was an 18 Nov SCAN measurement and is corrected here and on the
deck. Attribution by role is coarse: 24 Nov splits 44.32 coordinator + 2.93 executor, and
child threads run inside the parent session, so their spend lands in the coordinator's
number.

All eleven schedules carry `trigger_policy.last_run_at` on 2026-11-24 (BRIEF 14:00Z →
REPORT 21:15Z), so "11 / 11 fired on 24 Nov" is the platform's own record rather than an
inference from session counts.

## 4. Backtest — risk and return from the desk's own strategy code

The live record through 25 Nov is one strategy round trip. One trade is not a risk statistic,
so the desk's **in-built strategy** — the same signal module, the same rules file, the same
arithmetic the guard uses — was replayed bar-by-bar over historical 5-minute data to produce a
return and risk profile that belongs to this entry rather than to some other book.

### 4.1 What is the real thing and what is simulated

| Layer | Source | Provenance |
|---|---|---|
| Breakout decision, stop, target, instrument, regime gate | `trend_signal.py` **as mounted on the researcher**: build `1795160305077544`, sha256 `7b0f712ea701…`, imported unmodified | downloaded 25 Nov from `/skills/{id}/versions/{v}/content` |
| Size, fees, entry window, flat time, risk % of NAV, inverse-ETF pairing | `rules.json` **as mounted**: build `1795580552453332`, rules version `2026-11-25.2`, sha256 `060fc5b572d6…` — the capture used for this replay (`1795575276828792`) is **byte-identical** in all six files, guard.py `a4ea554b1d1a…` | same download, re-verified 25 Nov against the live pin |
| Regime per session (`normal`/`caution`/`bear_high_vol`/`crisis`, `size_mult`, `allow_long`) | mounted `regime()` fed **only** daily closes strictly before that session (200-bar SMA, SOX 5-day return) — point-in-time, no look-ahead | `regimes.json`, all rows `source: "computed"` |
| Broker mechanics: ladder vs marketable entry, signal- vs fill-anchored levels, next-check vs monitored stop, 3x inverse ETF as the bearish vehicle, 11-minute trigger→order latency, 30-minute scan cadence, one new position per scan | the harness only. It re-decides nothing | `.scratch/bt-1125/engine.py` |
| Fade decision (Sleeve C): VWAP cross count, z band 1.5–3.0, sigma floor, its own entry window | `chop.py` **as pinned on the researcher**: build `1795160305163946`, imported unmodified | downloaded 25 Nov, `/skills/{id}/versions/{v}/content` |
| Fly geometry (Sleeve B): expected move, $1.00 strike grid, ATM pick, the D4 quiet-and-tight gate, minutes-to-close | `sleeve_b_fly.py` **as pinned on the executor**: build `1795402814211564` | same download |

§4 covers all three sleeves: A and C are scored in dollars (§4.4, §4.4b), B is scored as
build-side coverage only (§4.4c), and the reason it stops there is stated rather than glossed.

Two price checks were run rather than assumed. Re-pointing the harness from the stale build it
was written against (`trend-signal 1795047415929677`, rules `2026-11-17.1`) to the mounted
bytes moved the result on the 38-session store then in place from **46 trades to 40** — the
whole difference is SPY shorts, which the mounted `trend_signal.py` now refuses with `SPY has
no eligible bearish ETF configured - long entries only` (17 of the 492 evaluations in §4.3 are
exactly that refusal). And the store's last 5-minute SPY close reproduces the official daily
closes the journal uses as benchmark (732.44 / 730.20 / 715.87 / 689.81 / 722.29 for 17, 18,
19, 20, 23 Nov), so the bar feed and the benchmark feed agree. The 41-session figures below are
the mounted-bytes run after the store was extended; the stale build was never re-run on it.

### 4.2 Coverage, including the two holes

* **41 complete sessions, 28 Sep – 23 Nov 2026**, 78 five-minute bars each, built from
  `quote_history_kline` (ktype 6, num 370) pages merged **per bar**. An earlier per-date merge
  guard silently kept only the first bar of any newly fetched day; fixing it took the sample
  from 38 to 41 sessions and net P&L from +$510.20 to +$704.03, after a verification pass
  confirmed 17,784 already-stored bars were byte-unchanged.
* **21 and 24 Nov have no 5-minute data** — the broker cache returns neither, in either
  direction window. So the replay **cannot cover 24 Nov, the first live trading day**. A
  session whose first bar is not 09:35 is refused by the harness rather than invented.
* 25–27 Nov were still in the future when this was written; §4.8 is the recipe that folds them
  in when the data exists.

### 4.3 How selective the in-built entry rule actually is

492 evaluations (41 sessions × 3 families × 4 SCAN stamps), classified by the exact reason
`trend_signal.signal()` returned:

| Outcome | n | share |
|---|---|---|
| **Signal emitted** — 72 LONG, 22 SHORT | **94** | **19.1%** |
| No break beyond the opening range ±10%, on the right side of VWAP | 226 | 45.9% |
| Opening range wider than 1.5% (median rejected width 2.30%, max 4.32%) | 92 | 18.7% |
| Broke out, but already more than one opening-range width extended | 53 | 10.8% |
| SPY short — no eligible bearish ETF configured (mounted rule) | 17 | 3.5% |
| Opening range narrower than 0.15% | 4 | 0.8% |
| Stop geometry rejected | 6 | 1.2% |

94 signals became 41 trades. 24 were refused by `one equity entry per family per day` and 18
never filled inside the 10-minute ladder — both logged in the replay's rejection ledger. The
remaining 11 were never attempted: the harness evaluates the three families in order and stops
at the first entry of the scan, which is the coordinator's "at most ONE new position per scan"
rule (`engine.py:210`). No signal was lost to rounding: `size zero` appears 0 times in the
ledger. 22% of sessions produced no signal at any scan.

Two mechanisms explain why the desk sits out the biggest moves, and they are the reason the
live record has n=1:

1. **The width band.** On 23 Nov — the sharpest day of the window, regime computed `crisis`,
   `size_mult 0.25` — all twelve evaluations failed on width alone (QQQ 2.20%, SPY 1.56%, SMH
   4.28%). The in-built rule will not enter a session whose opening range is that large.
2. **The extension ceiling.** The break must be *within one opening-range width* of the level
   (`lo - price <= rng`). On 19 Nov (bear_high_vol, SOX −8.6% in five days) QQQ at 11:00 sat
   $8.65 below an opening range that was $5.25 wide, so a −3.5% trend day produced no trade.

Sensitivity, changing only the band ceiling and nothing else: 1.5% → 2.5% would have added 20
candidate evaluations across 9 sessions; → 4.0% would add 36 across 13. The band is the binding
constraint on volatility, and it is a **risk choice**, not a defect — widening it buys trades by
entering sessions where the stop distance is already 2–4% of price.

### 4.4 Risk and return — Sleeve A alone

As-run is what the desk does today: no monitored stop, so an open position is closed at the
next scheduled check. Design-path is the configuration the desk is moving to: a monitored stop
evaluated at every check. Same signals, same sizing, same fees — only the exit path differs.
**This table is Sleeve A only**, because it is the table that was measured first and every row
in it is one ledger. §4.4b is the combined Sleeve A + C book, which is the number the deck
quotes, and §4.4c is Sleeve B.

| Metric | As-run (41 sessions) | Design-path (41 sessions) | Eligible window 17–23 Nov, as-run |
|---|---|---|---|
| Trades | 41 | 50 | 2 |
| Net P&L on $100,000 | **+$704.03** | **−$146.44** | +$272.34 |
| Return | +0.704% | −0.146% | +0.272% |
| SPY, same span | −5.658% | −5.658% | −1.386% |
| Excess vs SPY | +6.362 pp | +5.512 pp | +1.658 pp |
| Win rate | 51.2% (21/20) | 44.0% (22/28) | 100% (2/2) |
| Average R | +0.051 | −0.189 | +0.705 |
| Median R | +0.139 | −0.133 | +0.705 |
| SD of R | 0.767 | 1.219 | 0.406 |
| Avg win / avg loss (R) | +0.671 / −0.600 | +0.966 / −1.096 | +0.705 / — |
| Payoff ratio | 1.12 | 0.88 | — |
| Profit factor | 1.33 | 0.97 | — |
| Expectancy per trade | +$17.17 | −$2.93 | +$136.17 |
| **t-statistic on mean R** | **0.43** | **−1.09** | not a statistic |
| Best / worst trade | +$535.04 / −$442.20 | +$520.40 / −$569.87 | +$193.83 / +$78.51 |
| Best / worst R | +1.53 / −1.59 | +1.49 / **−3.39** | +1.11 / +0.30 |
| Max drawdown (realised, at closes) | −$821.18 (0.821%) | −$1,625.35 (1.625%) | $0 |
| Longest time under water | 20 sessions | 21 sessions | 0 |
| Max consecutive losses | 6 | 7 | 0 |
| Worst intraday mark while held | −$479 (−0.48% NAV, −1.37R) | −$808 (−0.81% NAV, **−4.80R**) | −$192 (−0.19% NAV) |
| Median MAE / MFE (R) | −0.57 / +0.65 | −0.86 / +0.68 | −0.48 / +1.50 |
| Exits that printed **through** the ticketed stop | 6 of 41, +$515 total, +$171 worst | 18 of 50, +$1,014 total, +$400 worst | 0 of 2 |
| Exit mix — target / stop / next check / flat | 1 / 0 / 32 / 8 | 9 / 18 / 0 / 23 | 0 / 0 / 2 / 0 |
| Daily mean / SD of realised return | +0.0259% / 0.1723% | +0.0062% / 0.2657% | +0.0482% / 0.0835% |
| Sharpe (252-day, close-to-close) | 2.39 — 2.82 on the sessions that held risk | 0.37 — 0.42 | 9.17 (n=2, quoted only to show why it must be ignored) |
| Sortino | 3.80 | 0.59 | — |
| Exposure | 73.2% of sessions carry risk, median hold 90 min | 78.0%, median hold 168 min | 40% of sessions |
| Beta / correlation vs SPY | −0.016 / −0.138 | −0.030 / −0.166 | −0.017 / −0.618 |
| Long / short entries | 29 / 12 | 37 / 13 | 0 / 2 |
| Fees | $83.88 ($2.05 per round trip) | $101.81 ($2.04) | $4.04 |

### 4.4b The combined Sleeve A + C book

This is the number the deck quotes. One harness, one shared ledger: Sleeve A acts first at each
scan, and Sleeve C is handed the evaluations A refused **because of opening-range width** (the
0.15–1.5% band, both edges). Cash, the one-position-per-family-per-scan cap, the daily entry
gate and the open-risk cap are shared, so the sleeves are not two separate books added
afterwards.

| Metric | A + C as-run | A + C design-path | Sleeve A alone, as-run |
|---|---|---|---|
| Trades | 42 | 51 | 41 |
| Net P&L on $100,000 | **+$967.99** | **−$342.21** | +$704.03 |
| Return | +0.968% | −0.342% | +0.704% |
| Excess vs SPY (−5.658%) | +6.626 pp | +5.316 pp | +6.362 pp |
| Win rate | 52.4% (22/20) | 45.1% (23/28) | 51.2% (21/20) |
| Average / median R | +0.074 / +0.192 | −0.184 / −0.103 | +0.051 / +0.139 |
| SD of R | 0.772 | 1.251 | 0.767 |
| **t-statistic on mean R** | **0.62** | −1.05 | 0.43 |
| Profit factor / payoff | 1.45 / 1.14 | 0.93 / 0.86 | 1.33 / 1.12 |
| Expectancy per trade | +$23.05 | −$6.71 | +$17.17 |
| Best / worst trade | +$535.04 / −$442.20 | +$517.28 / −$632.20 | +$535.04 / −$442.20 |
| Max realised drawdown | −$821.18 (0.821%) | −$1,995.62 (1.996%) | −$821.18 (0.821%) |
| Longest stretch under water | 20 sessions | 31 sessions | 20 sessions |
| Sessions with a trade | 30 of 41 | 32 of 41 | 30 of 41 |
| Exit mix — target / stop / next check / flat | 1 / 0 / 33 / 8 | 10 / 19 / 0 / 22 | 1 / 0 / 32 / 8 |
| Exits that printed **through** the ticketed stop | 6 of 42 (+$515, worst +$171) | 19 of 51 (+$1,301, worst +$400) | 6 of 41 (+$515, worst +$171) |
| Median MAE / MFE (R) | −0.55 / +0.69 | −0.89 / +0.68 | −0.57 / +0.65 |
| Sharpe (252-day, daily marks) | 2.81 (3.32 on risk days) | 0.08 | 2.39 (2.82 on risk days) |
| Beta / correlation vs SPY | −0.012 / −0.094 | — | −0.016 / −0.138 |
| Fees | $85.92 ($2.05 a round trip) | $103.94 | $83.88 |

Three things worth naming before the table is read as a better result than §4.4:

1. **Sleeve C contributes one trade, not a second book.** 42 trades where §4.4 had 41; the
   marginal dollar contribution is that one ticket, +$262.65.
2. **Three Sleeve A tickets are one share larger here.** 13 Nov 405→406, 16 Nov 314→315,
   20 Nov 102→103, because sizing reads NAV and C's 11 Nov win raises it. Net effect on A:
   **+$705.34 combined vs +$704.03 standalone**. Same signals, same exits — a $1.31
   arithmetic artifact, disclosed rather than smoothed away.
3. **The Sharpe is not stable across the two runs** (2.39 for the A-only ledger, 2.81 combined,
   3.05 for the A rows re-drawn from inside the combined ledger). It is a ratio of daily means,
   and the daily mean moves when the sleeve mix moves. The dollar figures, the R distribution
   and the drawdown are the ones that reproduce; **the Sharpe here should be quoted only
   together with the ledger it came from.**

Sleeve C's own census, over the 89 width-band vetoes handed to it: **33** one-sided sessions
(0 or 1 VWAP crosses), **28** with the distance from VWAP outside the fade band 1.5–3.0σ,
**22** outside the sleeve's own window (needs data after 10:30 ET and 90 minutes before flat),
**3** whose width was actually inside A's band, **2** still extending. One qualified — 11 Nov,
an SMH-family fade taken via SOXS, 173 @ 42.02 → 43.55, +$262.65 at 1.0R. n=1 is the whole
evidence, and the design-path column prices that one idea differently again (2 C trades, net
−$242.08), which is exactly why the sleeve is reported as a census and not as a track record.

### 4.4c Sleeve B — what is measurable, and what is not

Sleeve B (the 0DTE legged iron fly) **is not in any P&L figure in this journal**. A fly needs
the top of book on four contracts at one moment, moomoo chains are live-only, and expired
symbols are purged 3–4 weeks after expiry, so the credit of a September 0DTE is unrecoverable.
What *is* derivable from the stored bars is everything the builder decides before it asks for a
quote, so that is what is reported — build-side coverage, from the pinned `sleeve_b_fly.py`:

* **31 of the 41 sessions reach the builder.** The 10 declines are all the same gate — D4
  (quiet and tight over 09:35–10:00) — on 29 Sep, 4, 5, 6, 9, 10, 12, 13, 16 and 20 Nov. No
  session is lost to the calendar or to missing bars.
* Wings land on the $1.00 SPY grid at 6, 7, 8, 9 or 13 dollars (17 / 9 / 2 / 2 / 1 sessions),
  from an EM of 5.57–12.64 built on the point-in-time VIX close (14.84–35.89) scaled by the
  0.812 SPY transfer ratio fitted on 848 real option rows.
* **27 of 31 closes sit inside the modelled wings.** The four that do not are 0.37, 0.90, 2.75
  and 12.13 dollars beyond a wing (30 Sep, 16 Oct, 2 Nov, 19 Nov).
* Sized at the live ceiling — `structure.max_loss_pct_of_nav` 1.5, fee ceiling 12.5% of credit
  on the 6 planned orders — each fly is 1–3 SPY lots risking **$778 to $1,386**. The fee gate
  vetoes **0 of 93** session/credit combinations.
* Payoff at expiry, with credit taken as the measured band rather than a quote:
  **+$2,205.77** at 13.6% of width, **+$6,619.05** at 24.0%, **+$12,865.95** at 34.0%.
* The mirror of that bracket, stated in the same arithmetic: the same 31 flies, sized the same
  way, carry **$33,955 to $38,988 of structural max loss (34–39% of NAV)** across the 59–87
  modelled lots if they all expire beyond the wings — which is what the 1.5% ceiling permits by
  construction, one fly per day. The bracket is an upper bound conditional on the 87%
  inside-rate observed in this sample, not an expectation.
* Not modelled, and not claimed: the live exit path (`structure.exit` — release at 25% of
  credit, stop at 50% of max loss, shorts flat 15:25), the SPXW branch (a 0DTE index fly needs
  ~12.2% of NAV at Tuesday's EM, so it stays unreachable by rule, not by data), and assignment
  or bid-flow on the wings.

### 4.5 What the numbers say about risk

1. **A stop on this venue is a trigger, not a bound.** Neither path can rest a stop order
   (paper venue: limit or market only, and competition rule 17 makes a sell limit below last
   price match rather than rest), so both exit at the next check's price. In the design path 18
   of 50 exits printed beyond the ticketed level, $1,014 in total, $400 on the worst one, and
   one trade realised **−3.39R** against a 1R stop. This is the single most important risk
   statement in the submission: sizing to 0.35% of NAV is *not* the same as losing at most
   0.35%.
2. **The edge is not statistically distinguishable from zero.** Mean R is +0.051 with an
   in-sample standard error of 0.120 — t = 0.43 on 41 trades. Same statement on the combined
   Sleeve A + C ledger: +0.074 against an SE of 0.119, t = 0.62 on 42 trades. The positive net
   P&L of the as-run path is a small-sample result and is presented as such; it is not evidence
   of skill, and adding a second sleeve does not change that.
3. **Return comes from the flat rule, not from the target.** Only 1 of 41 as-run exits reached
   the 1.5R target; 32 closed because the position was unmonitored and 8 because the desk is
   flat by 15:45. Median MFE is +0.65R against a target of +1.5R, so the strategy's own take
   level is almost never the thing that ends the trade.
4. **Drawdown is modest because exposure is modest.** The book is in the market 73% of sessions
   but only ~90 minutes at a time, and it carries no overnight risk except the hedge. Peak-to-
   trough on realised NAV is 0.82% as-run, 1.63% design-path.
5. **The desk is not a beta book.** Correlation to SPY is −0.14 and beta −0.02 across the
   sample; the +6.36 pp excess over −5.66% is a function of that, not of timing the index.
6. **Fees are not the story.** $2.05 a round trip, 10.6% of gross P&L as-run. The design path
   pays more ($101.81) because it trades nine more times, and it earns less.
7. **Basis note.** The replay books commission as an explicit fee line; the live ledger uses
   position basis (owner ruling, 25 Nov). The two must not be added — §4.4 and §1 are separate
   measurements of the same policy.

### 4.6 Per-session ledger for the eligible window

Simulated rows are the replay; the 24 Nov row is the **live** ledger and is not comparable
evidence — it is stated so the window is complete.

| Session | SPY close | day chg | regime | mult | longs | signals at the 4 scans | replayed trades | replay P&L | cum, window only |
|---|---|---|---|---|---|---|---|---|---|
| 17 Nov Tue | 732.44 | — | caution | 0.75 | yes | 2 (SMH SHORT ×2) | 1 | +78.51 | 100,078.51 |
| 18 Nov Wed | 730.20 | −0.31% | caution | 0.75 | yes | 0 (no break ×8, width ×4) | 0 | 0 | 100,078.51 |
| 19 Nov Thu | 715.87 | −1.96% | bear_high_vol | 0.50 | **no** | 0 (extended ×6, no break ×2, width ×4) | 0 | 0 | 100,078.51 |
| 20 Nov Fri | 689.81 | −3.64% | bear_high_vol | 0.50 | **no** | 1 (QQQ SHORT) | 1 | +193.83 | 100,272.34 |
| 21 Nov Sat | — | — | — | — | — | no 5-minute data in the broker cache | — | — | — |
| 23 Nov Mon | 722.29 | +4.71% | crisis | 0.25 | **no** | 0 (width ×12) | 0 | 0 | 100,272.34 |
| 24 Nov Tue | 718.78 | −0.49% | caution | 0.75 | yes | **not replayable** — no 5-minute data | **live: 1** | **live: −172.29** | see §1 |
| 25 Nov Wed | — | — | caution (as of the 24 Nov close) | 0.75 | yes | to be appended after the close | | | |
| 26 Nov Thu | — | — | — | — | — | broker closed | 0 | 0 | — |
| 27 Nov Fri | — | — | — | — | — | half day: entry cut-off 11:30, flat 12:45 | | | |

The last column restarts at $100,000 for the window cut, so it is **not** the account NAV in
§1 — the 24 Nov live row deliberately shows `see §1` rather than blending the two bases.

The two replayable profitable sessions are worth reading against the live trade: 20 Nov is the
same bearish-ETF logic working (+$193.83 on a QQQ short — 27.5% of the whole 41-session net
P&L in one trade), and 24 Nov is the same logic losing. The window is 5 replayable sessions and
2 trades; nothing in §4.4's window column should be treated as a statistic.

### 4.7 What the simulation does **not** model

Stated because each omission flatters or penalises the numbers in a known direction:

* the drawdown ladder (`half_size` at 3%, `hedges_and_closes_only` at 5%, `kill_switch` at 8%)
  and the 2% daily loss limit — the replay never de-risks mid-sample, so the design path's
  −1.63% (Sleeve A) / −2.00% (Sleeve A + C) drawdown would in reality have been truncated, but
  its 20- and 31-session underwater stretches also would not have been reached;
* Sleeve B's **P&L**, the overnight option hedge, and any short of the underlying itself. B's
  coverage, wings and fee gate are measured in §4.4c; its credit is not recoverable, so no
  dollar figure in §4.4 or §4.4b contains a fly;
* partial fills, the executor's 0.3% ticket-staleness cancel, and the pre-/after-hours limit
  requirement — entries are filled at bar prices, so **no slippage is modelled beyond the
  ladder arithmetic**;
* the live queue: the replay assumes each scan runs at its stamp, while the desk measured
  10–12.6 minutes from trigger to order-ready, and a SCAN attempt can occupy 50–85 minutes;
* half-day calendars (27 Nov) and the closed-day gate (26 Nov) — `derive_session` was tested
  against full sessions only;
* credit cost, which is real and separate: 47.25 credits for the 24 Nov round trip (§3).

### 4.8 Re-running this, and how 25–27 Nov fold in

Inputs are files, not network calls at analysis time: every bar comes from a
`quote_history_kline` payload captured under `.scratch/bt-1125/pages/` (ktype 6 num 370 for
the 5-minute series, ktype 2 num 370 for the index closes the regime needs).

```
cd .scratch/bt-1125
# 1. re-run the MCP fetches for the new dates into pages/ (manual; one call per symbol)
python3 merge_pages.py            # union each BAR into bars/<TICKER>.json, store wins per bar
$PYTHON mkregime_1125.py          # edit NEW = [...] to the added dates first; writes regimes.json
python3 engine.py                 # both exit paths -> sim_out.json + stdout table
python3 signal_census.py          # §4.3: the reason every scan said what it said
python3 stats.py                  # §4.4 + §4.5
python3 window_table.py           # §4.6
```

`$PYTHON` is the local 3.12 interpreter — plain `python` is not on this PATH.

§4.4b and §4.4c are produced one directory over, against the **same bars store**, from the bytes
the cloud actually has mounted (the version ids below are the ones the harness headers record):

```
cd .scratch/bt-abc
py -3 sleeve_ac.py        # A + C, one shared portfolio -> sim_ac.json   (8 exit-path variants)
py -3 stats_ac.py         # -> risk_stats_ac.json  (§4.4b as-run columns)
py -3 sleeve_b_elig.py    # Sleeve B coverage      -> sleeve_b_rows.json (§4.4c)
```

Modules are read from local captures of pinned skills — trend-signal `1795160305077544`,
vwap-chop `1795160305163946`, option-adapter `1795402814211564`, desk-risk-guard
`1795575276828792` with `rules.json` `2026-11-25.2` — and the design-path column of §4.4b is
the `marketable/fill/mon/etf` variant of the same run, so **one run produces both columns of
every table**; only the exit and fill assumptions differ.

The store is additive: adding a session changes only that session. `merge_pages.py` asserts
per-session completeness (78 bars everywhere) on every run; the stronger check — comparing all
17,784 already-stored bars against the union — was run once for this extension and reported 0
changed. When 25 and 27 Nov land (26 Nov will not — the broker calendar has no session that
day), §4.4's window column, §4.4b, §4.4c and §4.6 all gain rows with no other edit, and the
full-sample columns become **43 sessions**, of which 27 Nov is a half day that `derive_session`
has never been tested against. Anything quoted from §4.4 or §4.4b before that should carry
its n.

## 5. Decision-log exhibit

- `logs/decisions.jsonl` — **157 guard verdict records** mined from **121 Forward
  sessions** across the four templates (coordinator list is capped at 50 per request).
- `logs/errors.jsonl` — 61 error/exception records captured from the same events.
- `logs/fills.csv` — the **authoritative** fill/order exhibit, 11 rows, complete broker
  history (`pagination.has_more = false`), retrieved 2026-11-25 from
  `sim_trade_history_order_list`.
- `logs/fills.jsonl`, `logs/orders.jsonl` — session-derived index. **Text-scraped and
  over-inclusive**; use `fills.csv` for any number that goes in front of a judge.
- Competition vetoes recorded in the ledger: **0** (no signal was rejected on 24 Nov).
  The veto path was exercised during bring-up (`state_unavailable`,
  `ticket_price_stale`) and those records are in `decisions.jsonl`. Say this plainly —
  "0 vetoes" is a real result, not a missing artifact.

Known gaps, stated rather than papered over: option fees are not exposed by any fee
endpoint (`account_order_fees` → Forbidden, -32603), so option P&L carries an estimated
fee only; expectancy from the live ledger is n=1 and not a statistic — **§4 is what stands in
for one**, and its own as-run mean R is only 0.43 standard errors from zero;
`sim_trade_account_list` returns an empty list for this account, so account binding is asserted
from the account-id allowlist in `rules.json`, not from a name string.
