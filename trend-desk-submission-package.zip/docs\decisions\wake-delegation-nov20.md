# Wake delegation — making "dispatch, don't do" structural

**Verdict: the behaviour was real, the cause was not the concurrency cap, and the fix is three
mechanism changes plus the wording that points at them.**

- Task: `20261120T030605Z-9c417b` (Tier A, mailbox-infrastructure reliability), worker session
  `f144c7da-14f2-58af-aa3d-91974995edfd`, spawned by wake conversation
  `e0d7833d-c71b-43fe-858c-7e27e0dd2f4a` at 03:06:19Z.
- Window: 2026-11-20 03:06–03:50Z (20:06–20:50 ET, Fri).
- Claim tags: **[documented]** written in a tool description or an official page I read this turn;
  **[observed]** read from a live artefact this turn; **[inferred]** derived from those;
  **[undiscoverable]** I could not establish it from what I can reach.
- Nothing in the cloud: no template, skill, schedule or vault write. Nothing on account 5830104:
  no order, no `sim_trade_*`, no `account_*`. No secrets (`.env` referenced by path only).
  No repo file deleted; no new session spawned.

---

## 0. Bottom line

1. **The inline-execution complaint is confirmed by artefact, not by impression.** **[observed]**
   The wake turn of 01:19:53Z (conversation `754afa52-…`, one tick) contains ~98 tool calls including
   20 `Edit` and 10 `Write` — it built the `ack.mjs` guard and the `recon.mjs` `--fix` half *inside
   the tick*, and its own running commentary says so: "Now the recon.mjs self-correct half",
   "12/12 pass and the guard is live". That is substantive engineering done by a dispatcher.
2. **The cap was never the constraint, and "max 4" is per-batch prose.** **[observed]**
   `list_chat_sessions` this turn: **7 sessions `running` at 03:47Z**, 6 at 03:18Z, and `plan.mjs`
   counting **5 distinct dispatched children with open claims** in the same window — all above 4.
   `create_chat_session`'s schema exposes no concurrency parameter at all, and states "no
   nesting-depth limit" for delegation. So the ceiling in force is policy-only, applied per batch
   rather than globally, which is exactly how ten children coexisted at 00:36Z.
3. **The reason a wake absorbs work is that everything it is guaranteed to read tells it to.**
   **[observed]** The single user message in both wake transcripts is verbatim `CRON_PROMPT.txt`:
   "…follow … CONTRACT.md exactly: **process every inbox message, ack each into acks/, then move it
   to done/**". No delegation verb, no ceiling, no overflow path. The only sentence in the system
   that a wake cannot fail to read is the one that says *do it all*.
4. **Delegation was unauditable, so nothing pushed back.** **[observed]** `ack.mjs` line 61 rebuilt
   every ack with `session_id: src.session_id ?? null` — a terminal ack that omitted the field
   erased the claim's child link. Measured across the live mailbox: **12 of 21 finished `spawn`
   items (57%) carry a terminal ack with no session attribution at all**, e.g. `7b19d4` went
   `accepted`+`session_id=113d4a8c…` → `done`+`session_id=null`. "Delegated or inline?" was
   unanswerable by construction.
5. **Three mechanism fixes now ship alongside the wording:** `plan.mjs` (read-only dispatcher that
   computes the tick's queue and its overflow), the `dispatched_to` link in `ack.mjs` (makes
   delegated-vs-inline machine-checkable), and both `check.sh`/`check.ps1` printing the plan (so the
   queue is a script output, not a habit). See §4.
6. **What I could not do: change what the cron actually sends.** **[observed / needs owner action]**
   `CRON_PROMPT.txt` on disk is a *mirror* of the schedule's instruction text, not the source.
   The live task (`05d67f16-dfaf-428e-94f2-261d65c34a46`) stores its own copy; the wake's user
   message matches the file byte-for-byte because someone pasted it in. Editing the file is a no-op
   until the task text is re-applied with the cron tool — which a worker session does not hold and
   which is out of my authorization. See §6 for the exact one-field change the owner needs to make.
   **The change still takes effect without it**, because the two surfaces a wake reads live —
   `CONTRACT.md` (read every tick, observed) and the `check` output (the tick's first bytes) — both
   now carry the rule.

---

## 1. Which text actually governs the wake

| Candidate | Governs the wake? | Evidence |
|---|---|---|
| `CRON_PROMPT.txt` | **Yes — the entry point**, but only as a mirror of the schedule text | **[observed]** it is the entire user message of both wake transcripts (`754afa52` at 01:19:53.639Z, `e0d7833d` at 03:06:19.883Z) |
| `CONTRACT.md` | **Yes — the operative rule set** | **[observed]** `Read CONTRACT.md` is tool call #2/#3 of the 03:06 tick; rules 2/2a/2b/4/5 are what the tick follows |
| `DRIVER.md` §9 | **No — it governs the producer side** | **[documented by its own header]** "Driver playbook — Claude Desktop (orchestrator)"; its "Max 4 parallel per batch" is written for `mbx.mjs batch tasks.json`, i.e. how Claude dispatches, not how the wake consumes |
| `check.sh` / `check.ps1` | **Yes — now the strongest**, because their output is the first thing the tick reads | **[observed]** the tick's behaviour is driven by the printed list; it already carries the `overlap:` advisory |

**Choice made:** the durable rule went into `CONTRACT.md` as **rule 4a** (adjacent to rule 4, which
it constrains; the `2a`/`2b` sub-letter convention already exists there), the enforcement went into
`plan.mjs` + the two `check` scripts, and `CRON_PROMPT.txt` was amended **for parity** so the mirror
matches what the schedule *should* say. `DRIVER.md` was left alone deliberately — it is the wrong
audience, and editing it would have implied the fix lives in a document the wake is not required
to read.

**Why not rule 2c:** `2c` is `f2b7ad`'s reserved slot — `RECON_CLAUSE.md` proposes exactly that
number, and `grep '^2c\.' CONTRACT.md` still returns **0** (re-checked at 03:5xZ). Choosing 2c would
have set up a future collision with a merge that has not landed.

**`f2b7ad` / `38f4a13f` status, as asked:** **[observed]** worker `38f4a13f-c819-572a-aac3-e0c4c50439ea`
is `cold`, last `updatedAt` 1795134626811 = **00:30:26Z** — it has not resumed in the ~80 minutes
since. The rule-2c merge therefore **did not land**; `RECON_CLAUSE.md` remains delivered-as-text.
`CONTRACT.md`'s last write before mine was 09:57 local (≈01:57Z) and was not that worker — the
01:37:28Z `9a0e52` rule-4 reversal is what accounts for it (`docs/decisions/ack-ownership-nov20.md`
§5 records that edit). So the territory was free, but I verified it rather than assuming: each of
the five live files was byte-compared against the sha my staged copy was built from
(`publish-log.json`), all five matched, then renamed over.

---

## 2. Root cause of the inline behaviour

Four independent causes, in the order they bite:

1. **The entry text says "process every inbox message".** **[observed]** A wake that reads only its
   own prompt has been told to process everything and never told to dispatch anything. Rule 4 does
   say "start them together", but rule 4 is reached only by reading a 12 KB contract, and its verb is
   buried under rules 1–3 (claim, dedupe, overlap).
2. **The cap has no overflow destination.** **[observed]** `check.sh`/`check.ps1` glob
   `inbox/*.json` and print *every* file, including ids another session already claimed. Rule 4
   says "max 4" and then stops: nothing in the contract or the scripts says what to do with items
   5..N. A list plus a cap plus no destination resolves, in practice, to "the leftovers are mine".
   That is the mechanism — not a failed spawn, not a platform limit.
3. **`session_id` was dropped on every terminal ack.** **[observed]** 12/21 finished spawns have no
   attribution; the link between an id and the child that did it existed for exactly one status
   transition (`accepted`) and then vanished. Without evidence, the habit had no feedback loop, so
   it stayed invisible even when the owner noticed the throughput stall.
4. **Two rules actively invite the wake to finish someone else's item.** **[observed]** rule 2a(ii)
   takeover and the `RECON_CLAUSE.md` resume path. Tonight's own artefacts: `e84a1f`
   ("TAKEOVER CLAIM … resuming e84a1f under the delegating conversation's revised brief", no
   session_id) and `7b19d4` ("PART A of a two-part task (sibling session has Part B and **wake
   merges**)"). The 02:50 tick even said out loud that Part B was "reassigned to report in-channel
   for me to merge" — a deliberate, contract-permitted inline absorption. Rule 4a now forbids the
   merge-in-turn half while leaving recon/takeover for the *ack*, which is bookkeeping.

Also worth naming: **overlap makes the flat list worse over time.** **[observed]** `wakes.jsonl`
(31 ticks, 23:38:40Z→03:06:50Z) has gaps of 14s, 26s, 43s, 122s, 144s and also 1786s, 2355s, 2379s —
the nominal `*/2` is not the real cadence. Ticks that land while a peer is mid-run each see the whole
inbox, so the same leftovers get offered to several wakes at once.

---

## 3. Measured concurrency ceiling

| Question | Answer | Basis |
|---|---|---|
| Is 4 enforced by the platform? | **No.** 7 worker sessions were `running` simultaneously at 03:47Z; 6 at 03:18Z; and `plan.mjs`, counting only file-visible claims, reported **`active_children=6` at 03:5xZ** — 50% over the cap, with `slots_left=0` computed correctly anyway. | **[observed]** `list_chat_sessions` (46 rows, `nextCursor: null` = complete unarchived set) + `plan.mjs` output |
| Is 4 enforced by policy adherence? | **Only per batch.** A tick dispatches ≤4 and never counts what earlier ticks left running, so global concurrency = 4 × overlapping ticks. The 02:50 tick said "I just hit [the cap] exactly" while four of its children's siblings were still live. | **[observed]** + the wake's own ack text |
| Is there a hard ceiling above that? | **[undiscoverable]** I cannot probe it without spawning sessions, which this brief forbids. Nothing in `create_chat_session`'s schema offers a concurrency field; its only stated limit-like text is "no nesting-depth limit" for nested delegation. | **[documented]** tool schema read this turn |
| Does credit burn act as the de-facto ceiling? | **Indirectly, and it is the one worth respecting.** Costs measured 2026-11-18: 100.54 credits/day with SCAN 14.97–20.54 each and trigger→order-ready 10–12.6 min; a schedule has no budget field. So the practical constraint is turn duration and daily burn, not a session count. | **[observed earlier, quoted from project memory — not re-measured this turn]** |

**Consequence for the rule:** keep 4 as the number, but make it *global and file-visible*, which is
what `plan.mjs`'s `active_children` does. The number only becomes real once overflow has a queue.

---

## 4. What changed

Diffs: `.scratch/changes/2026-11-20-wake-delegation/diffs/*.diff` · sha log: `publish-log.json`

| File | Δ | sha256 before → after |
|---|---|---|
| `.scratch/mailbox/CONTRACT.md` | +3 / −2 lines (new rule 4a; `parallel_ok` line points at it) | `4f95a44e…` → `77e944ab…` |
| `.scratch/mailbox/CRON_PROMPT.txt` | 1 sentence replaced (+422 chars) | `85e2f350…` → `599758ef…` |
| `.scratch/mailbox/check.sh` | +19 / −2 (`--root` seam; plan printed last) | `d4acaa90…` → `f582f5af…` |
| `.scratch/mailbox/check.ps1` | +17 / −2 (`param([string]$Root)`; plan printed last) | `1819df54…` → `68e907a8…` |
| `.scratch/mailbox/ack.mjs` | +8 / −1 (`dispatched_to` preserved) | `5481b97a…` → `6f1883b9…` |
| `.scratch/mailbox/plan.mjs` | **new**, 107 lines, read-only | — → `30e0fe09…` |

New text, verbatim, is in rule 4a (§1) — duties (a)–(e), the MUST-NOT list, "Overflow is queued,
never absorbed", the measured-cap sentence, the `spawn-failed` path, and the evidence requirement.

**Transient side effect of publishing, disclosed:** `ack.mjs`'s rename briefly exposed a partially
rebuilt `acks/20261120T030605Z-9c417b.json` (my own id, momentarily `session_id: null`) because a
concurrent tick re-ran `ack.mjs` mid-publish. It self-healed by 03:47Z (re-verified `accepted` +
`session_id=f144c7da…`). No other session's id was written, and no ack was downgraded — the
terminal→non-terminal guard is unchanged and still refuses (test D below).

---

## 5. Test proof

Harness: `.scratch/changes/2026-11-20-wake-delegation/harness/` · outputs in `harness/out/`.
Nothing in the harness touches the live root: fixtures use `20991231T2359xxZ-aa00xx` ids, which
collide with nothing, and every run is either a copy-root or read-only.

**A. Wording lint** (`lint-wake-text.cjs`, 16 assertions over the wake-facing text):
`1/16 pass` on the pre-edit snapshot → **`16/16 pass`** on live. `out/lint-before.txt`, `out/lint-after.txt`.

**B. Before/after on identical synthetic fixtures** (11 inbox items: 8 unclaimed parallel spawns,
1 unclaimed serial, 1 notify, plus 4 claims covering in-flight / undocumented / terminal / stale):

- **Before** (`out/before-check.txt`): 10 flat `inbox/…json` paths, nothing else — no ceiling, no
  queue, no actor named. This is exactly the state that let a wake read the batch as its own to-do list.
- **After** (`out/staged-check.txt`): same list plus a computed plan —
  `spawn:` ×2, `hold:` ×4 (two parallel overflow, one undocumented claim, one serial-queue-full),
  `in-flight:` ×1 `recon:` ×1 `archive:` ×1 `reply:` ×1 `skip:` ×1,
  `plan: cap=4 active_children=2 dispatched_now=2 slots_left=0 held_for_next_tick=4 inbox=11`.
  Every branch of the dispatcher fired, including rule 3's unparseable-ack skip — which my first
  draft got wrong (it treated an unparseable ack as "no ack" and would have re-dispatched
  in-flight work; caught by the fixture, fixed, re-tested before publish).

**C. Delegation-evidence behaviour test** (`run.cjs acks` → `out/ack-tests.txt`), same four cases in
both roots:

| Case | before-root | after-root |
|---|---|---|
| B: terminal `done` written without `session_id` | link **LOST** — cannot prove delegation | `dispatched_to=sessCHILD…` **PRESERVED** |
| C: wake-authored terminal ack | mismatch **invisible** | `session_id=sessWAKE…`, `dispatched_to=sessCHILD…` → **mismatch visible** |
| D: guard, terminal → `accepted` | rc=4 REFUSED | rc=4 REFUSED (**no regression**) |

Case C is precisely tonight's `7b19d4` "wake merges" shape; it is now detectable from the ack alone.

**D. Default path is unchanged.** **[observed]** `mirror-test.cjs` copies the *entire* live mailbox to
`mirror-root` and runs `check.sh` with **no arguments** from an unrelated cwd — the exact invocation
the tick uses. rc=0, plan printed, mirror heartbeat/wakes updated, and the live `heartbeat.json`,
`wakes.jsonl`, my ack and the ack count are byte-identical before/after (`out/mirror-default-path.txt`).
`check.ps1`'s no-argument path is covered by `param([string]$Root)` defaulting to `$PSScriptRoot`
(lint assertion 15); I did not execute PowerShell against the live root for the same reason I did not
execute `check.sh` there: a real tick's proof requires writing the shared heartbeat and letting
`sweep.mjs` publish `outbox/` notices, which would perturb other sessions mid-run.

**E. Read-only, against the real queue** (no fixtures). The proof is static, not a hash comparison,
because a live tree hash is confounded — other sessions write `acks/` and `inbox/` continuously, so a
changing hash proves nothing either way. Self-correction recorded because it matters to the standard:
an earlier draft of this section asserted "tree hash unchanged", from a live before/after measurement
whose two echo lines I had also mislabeled; that claim is withdrawn and replaced by the two proofs
below. **[observed]** `plan.mjs` touches exactly two directories
(`files('acks')` at line 50, `files('inbox')` at line 69) and a scan for every write/exec API
(`writeFileSync|renameSync|appendFileSync|mkdirSync|unlinkSync|rmdirSync|spawnSync|cpSync|rmSync|
createWriteStream|open(...'w')`) returns **zero matches**. Corroborated dynamically on an
unconfounded copy root (`harness/planread-root`): tree `ac9ca2dd1b923f92` before and after the run —
**identical**, rc=0.

The run at 03:5xZ against real state is the best evidence the mechanism works, because the queue
computed itself and *refused to hand the wake anything*:

```
recon: 20261120T024430Z-2a6c8e … claim_age=3701s past 20min - run recon.mjs, this turn does not judge it
recon: 20261120T030605Z-9c417b … claim_age=2394s past 20min - run recon.mjs, this turn does not judge it   <- me
in-flight: 20261120T034745Z-d20f3e child=b75908b7… claim_age=332s - leave alone
hold: 20261120T035258Z-84b7e1 ceiling reached (4 active) - stays in inbox/ for the next tick; do NOT run it in this turn
plan: cap=4(policy, CONTRACT rule 4) active_children=6 dispatched_now=0 slots_left=0 held_for_next_tick=1 inbox=9
```

`hold:` is the overflow destination that rule 4 never had — a fifth-and-beyond item now gets a line
telling the wake to leave it, instead of landing in its own turn. `active_children=6` while `cap=4`
is the ceiling claim of §3, printed by the script rather than asserted by me. An earlier run of the
same script (03:31Z) showed the other two new branches doing their job on live data:
`archive: 20261120T022735Z-e84a1f ack=done … no work, rule 2 dedupe` and
`hold: …14af6d ceiling reached (4 active)`.

By 03:44Z (test D's mirror of live state) the same script had caught a **new** instance of the defect
in the wild: `undocumented: 20261120T033816Z-3bd872 … a claim that names NO child session` — a wake
that claimed an id without a child, 20 minutes before rule 4a could reach its own prompt.

---

## 6. Not proven / limits / what the owner must do

1. **The schedule text still says the old sentence.** To make the entry point match, the owner (or a
   session holding `qoder_cron`) must replace the mailbox task's instruction with the contents of
   `CRON_PROMPT.txt` as amended. Task `05d67f16-dfaf-428e-94f2-261d65c34a46`. This is a *schedule*
   write; I am not authorized for it and made no attempt.
2. **Whether the wording alone changes behaviour is not yet measurable.** The next ticks will show
   it: the observable is `undocumented:` lines per tick trending to zero and `hold:` ids surviving in
   `inbox/` instead of being absorbed. First sample is one tick; do not treat it as a pattern.
3. **`active_children` is a file-only proxy.** A script has no session tools, so a child that finished
   without acking keeps its slot occupied (under-counts capacity), and a claim written without
   `session_id` contributes nothing (over-counts capacity). Both are printed rather than hidden —
   that is what the `undocumented:` line is for.
4. **Rule 4a does not bind in-flight children or in-flight wakes.** A wake that started before 03:4xZ
   read the old text; its turn can last 12–50 minutes (observed: the 03:06 tick still `running` at
   03:18Z; a 00:29Z run recorded `lastDurationMs: 2997998` ≈ 50 min). Expect a tail of old behaviour.
5. **`plan.mjs` deliberately cannot judge a child's state** — `recon:` hands that to `recon.mjs`, which
   needs the session API supplied by the wake. I did not fold recon's logic in: silence fails closed.
6. **Not fixed here** (recorded, out of scope): rule 2b still cannot detect a peer wake, because
   `list_chat_sessions` never returns an automation execution — **[observed]** again: the catalogue
   this turn held 46 sessions and none of them was a wake. The `overlap:` advisory is the only signal
   that crosses that boundary, and it is a heartbeat-age heuristic, not a lock.
7. **My own claim went stale mid-run.** **[observed]** `plan.mjs` at 03:5xZ listed
   `9c417b … claim_age=2394s past 20min` — the context compaction pushed this turn past rule 2a's
   20-minute window, so a takeover of my item by another wake was legitimate by the contract while I
   was still working on it. Three of my neighbours (`2a6c8e`, `5e81ac`, `14af6d`) sat in the same
   state. The window is sized for a dispatched child, not for a turn that survives compaction; that
   mismatch is a live question for the owner, not something I changed.
8. **One attribution ambiguity I am flagging rather than resolving:** `d20f3e`'s claim names child
   `b75908b7…`, which is also the namespace key under which this turn's background `Bash` jobs are
   filed. Either a wake recorded one of my runtime ids as that item's child, or those keys are simply
   per-runtime rather than per-session and the resemblance is empty. One sample cannot decide between
   those, and the answer changes what `session_id` is worth as evidence — so it needs a second sample
   from a session that knows its own id, not a guess from me.

---

## 7. Rollback

`bash .scratch/changes/2026-11-20-wake-delegation/rollback.sh` restores the five files from
`before/` (tmp + atomic rename per file) and **moves** `plan.mjs` to `removed/plan.mjs` — never
`rm`, so the rollback stays reversible and no repo file is deleted. Each restore is gated on the live
sha still matching the value this change published; if any file moved since, that file is skipped with
a message rather than clobbered. Status: `bash -n` clean **[observed 03:5xZ]**, **not executed** —
running it would undo the change I was asked to land, and it writes five live files, so it is
delivered as a tested-by-inspection path for the owner, not as something I fired to "prove" it works.
After rollback the `check` scripts stop printing a plan and rule 4a disappears, returning the wake to
"process every inbox message" — so roll back only to re-scope, not to park.
