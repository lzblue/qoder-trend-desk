# Loosening the three named filters in `trend_signal.py` — what the 84-session replay says

> **§9 verification, added `2026-11-20T04:05Z` (this banner `04:19Z`) by a second session working the same mailbox task.** §1–§8 are
> the sibling's work and are left byte-unchanged. §9 reproduces §0's numbers with the same harness (all four
> deltas and all four leave-one-out values match to the cent), and records two gaps worth knowing before this
> doc is cited: the LOO column in §0.1 has no producing artifact among the five commands in §8, and the printed
> bootstrap endpoints depend on seed-consumption order. **Read §9 before quoting a band from §0 or §5.**

**Status: analysis and proposal only. Nothing here was applied.** No `rules.json` edit, no live threshold
change, no template write, no skill publish, no schedule change, no order, probe or cancel on any account.
The only cloud access this task made was read-only `GET`s to confirm which `trend-signal` version is pinned;
the QODER_PAT was read into a shell variable from `./.env`, used only inside an `Authorization` header, and
appears in no file and in no output.

- Task `20261120T023636Z-7b19d4`, Part B (a sibling session has Part A) · written 2026-11-20.
- Source under test: `trend-signal` skill version `1795047415929677`, the version pinned on `researcher`
  as of this task. Local bytes sha256 `60d5573de1eb139d75378f537b689c733f648ae8dd52e444fd44194e5ba9bed8`,
  10,405 bytes (`out_verify.txt:1-2`), taken from `.scratch/p0/allver/1795047415929677/`.
- Harness: `.scratch/bt-regime-1120/` (method, provenance, limits in its `README.md`); this task's scripts and
  outputs in `.scratch/loosen-1120/`. Everything is reproducible with the five commands in §8.
- Claim tags as in `regime-robustness-nov20.md`: **[observed]** = produced by a run executed for this memo or
  read from a live system; **[documented]** = written in a file in this repo or in the pinned skill bytes;
  **[undiscoverable]** = not knowable from what is reachable here.
- Money figures in §2–§5 are *per-session independent $100k accounts* (the `Sim` is rebuilt each day), which is
  the pairing unit the bootstrap needs. They are not the continuous-account totals of `run_regime.py`; where the
  two are comparable they agree (§2.4).

---

## 0. Bottom line

1. **None of the three filters is a hidden constraint worth loosening on evidence.** Across 16 loosened
   configurations and 84 sessions, exactly **one** paired-bootstrap band excludes zero (extension cap
   1.0 → 2.0, +$1,428.98, band [+0.25, +39.18]), and **that band crosses zero as soon as its single best new
   trade is removed** (+$907.44, band [−0.24, +25.50]). With 16 correlated looks on the same data, one
   marginal hit is the expected shape of noise. **[observed]**
2. **The only per-trade contrast that is reliably non-zero is negative**: extension cap 1.0 → 1.25 admits 8
   trades worth **−$536.96** (25 % win, −0.371 R), per-trade net −$67.12, band **[−126.26, −21.34]** —
   *NEGATIVE*. Its new exposure lands in both known loss cells at once (new `normal`-day shorts −$316.90 at
   0 % win; new bull-bucket trades −$311.58 at 33 %). This is the candidate to reject explicitly. **[observed]**
3. **Loosening does not mainly add tickets — it changes which ticker takes the slot.** In all 16 variants the
   dollar delta equals (new trades) − (displaced baseline trades) to within **$0.24**, i.e. kept trades are
   essentially untouched and only fee rounding on a few of them moves. Widening width admits mostly
   **SMH/SOXS at the 12:45 slot**, which preempts the **SPY** trade that would have run in that scan
   (`TICKERS` order QQQ, SMH, SPY + one-new-position-per-scan). At width 1.65: 13 candidates → 5 tickets
   and **1 displaced winner (+$76.93)**. **[observed]**
4. **Every widening of the width cap or the extension cap is a mix of new trades and removed trades.** A third
   of the 2.0× extension case's measured gain is simply the 5 displaced baseline losers (−$476.05) not
   happening again, and half of what remains is one new trade. Reporting new-trade P&L alone would overstate
   all of these. **[observed]**
5. **Several loosenings shift new exposure toward `normal`-day shorts — the short share of new trades is above
   the 30.6 % baseline in 8 of the 14 variants — but in this sample that cell does not reproduce its −$1,281.77
   shape.** New `normal`/SHORT trades are net **positive** in 11 of
   14 variants that add any, and all three that worsen it (extension 1.25, buffer 0.00, distance 1.25) are also
   net-negative overall. The width family's larger settings (1.95 → 3.50) trade busier *into* the bucket that
   already loses: their new bull-bucket trades are −$183.43 at 33 % win, and C1 (width 1.95 + distance 1.25)
   −$242.18 at 40 %. **[observed]**
6. **The brief's item (3) is mis-named, and the name comes from the code itself.** `:192` is
   `if dist <= 0 or dist > rng:` — a **stop-distance cap** (stop must be inside the opening range), whose
   message happens to say "poor reward/risk". The reward/risk ratio is not a variable: `target = price + 1.5*dist`
   at `:182`/`:187` and `"reward_risk": 1.5` at `:200`. Loosening `:192` therefore widens *stops*, not geometry;
   every trade still carries 1.5 R. **[documented]** (`trend_signal.py:182,187,192,200`)

---

## 1. What was measured

| item | value |
|---|---|
| sessions replayed | 84, 2026-03-26 → 2026-11-18 (`out_sweep.txt:1`) |
| candidate rows | 1,008 (= 84 × 4 scans × QQQ/SMH/SPY) |
| rows producing a live signal | 157 (`out_probe.txt:16`) |
| rows becoming tickets (fill anchor, live thresholds) | 108 |
| baseline totals (per-session accounts) | fill anchor **+$419.69**; signal anchor **+$79.84**; 108 trades |
| derived buckets | bull 52 / sideways 22 / bear 34 trades; bull **−$1,158.18** (fill) / **−$1,119.86** (as-run) |
| published continuous-account cells for comparison | EXT bull −$1,155.14 (anchor) / −$1,118.02 (as-run) — agree within ~$4 |

The three filters, verbatim from the pinned bytes (**[documented]**, `trend_signal.py`):

```
:165   if not 0.15 <= rng_pct <= 1.5:                          # opening-range width band
:169   if price > hi + 0.1 * rng and price > vwap and price - hi <= rng:      # LONG breakout + buffer + extension cap
:171   elif price < lo - 0.1 * rng and price < vwap and lo - price <= rng:    # SHORT equivalent
:175/:177  regime long/short veto (unchanged in every variant)
:192   if dist <= 0 or dist > rng:                             # stop-distance cap
```

**Method.** For each loosened configuration a derived module was generated from the pinned source by a single
asserted string replacement (`sweep.py` `ANCHORS`; a replacement that does not match exactly once aborts the
run), then loaded and injected as `engine.ts`. `verify.py` confirms `gen/ts_live.py` is byte-identical to the
live file and prints the exact changed lines for all 16 modules (`out_verify.txt:2-18`). Each variant is run
through the *same* `Sim` (ladder entry, 11-min latency, take-profit on touch, one new position per scan, one
equity entry per family per day, flat by 15:45), so the only variable is the filter. An independent offline
re-scorer (`probe.py`) replays all 1,008 rows and reproduces the live/NONE verdict in **both** directions with
**0** mismatches (`out_probe.txt:3-4`).

**Thresholds chosen in each filter's own units** (+10/20/30 % of the band, or the natural halving/saturation
point elsewhere):

| filter | live | loosened settings tested |
|---|---|---|
| width band | 0.15 – **1.5 %** | 1.65 (+10 %), 1.80 (+20 %), 1.95 (+30 %), 2.50, 3.50 |
| breakout buffer | **0.1 × rng** | 0.05, 0.00 |
| extension cap | **1.0 × rng** | 1.25, 1.50, 2.00 |
| stop-distance cap | **1.0 × rng** | 1.25, 1.50, 2.00 |
| combinations | — | C1 = w1.95+dist1.25 · C2 = buf0.05+ext1.25 · C3 = w1.80+ext1.25+dist1.25 |

---

## 2. How many additional signals, and what they are worth

### 2.1 Candidate counts

"New candidates" = rows where the loosened signal fires and the live one returns NONE. It is *not* the ticket
count: the desk's own gates (one per scan, one per family per day, latency/no-fill) decide that, and for every
variant a loosening can also **remove** a baseline ticket.

| policy | new candidates | tickets 108 → | NEW / DROPPED | conversion |
|---|---|---|---|---|
| width 1.65 | 13 | 112 | 5 / 1 | 38 % |
| width 1.80 | 26 | 117 | 11 / 2 | 42 % |
| width 1.95 | 34 | 121 | 15 / 2 | 44 % |
| width 2.50 | 39 | 122 | 16 / 2 | 41 % |
| width 3.50 | 51 | 127 | 22 / 3 | 43 % |
| buffer 0.05 | 25 | 122 | 18 / 4 | 72 % |
| buffer 0.00 | 54 | 129 | 32 / 11 | 59 % |
| extension 1.25 | 15 | 111 | 8 / 5 | 53 % |
| extension 1.50 | 22 | 114 | 11 / 5 | 50 % |
| extension 2.00 | 26 | 116 | 13 / 5 | 50 % |
| distance 1.25 | 14 | 111 | 3 / 0 | 21 % |
| distance 1.50 | 16 | 113 | 6 / 1 | 38 % |
| distance 2.00 | 16 | 113 | 6 / 1 | 38 % |
| C1 w1.95+dist1.25 | 50 | 123 | 17 / 2 | 34 % |
| C2 buf0.05+ext1.25 | 25 | 122 | 18 / 4 | 72 % |
| C3 w1.80+ext1.25+dist1.25 | 72 | 127 | 28 / 9 | 39 % |

**[observed]** (`out_sweep.txt`, `out_detail.txt:66-83`). Note the shape: 54 candidates at buffer 0.00 buy
+21 tickets; 13 at width 1.65 buy +4 net. The desktop is capacity-bound, not signal-bound.

One row is refused by the regime gate in every width/extension variant and is nobody's candidate: the
2026-03-31 14:00 SMH LONG on a `bear_high_vol` day. The offline probe (which omits the regime veto) therefore
counts 14/27/35/40/52 and 16/23/27 — exactly one more than the full signal.

### 2.2 Newly-admitted trades alone (fill anchor)

| policy | n | net $ | win % | avg R | per-trade 95 % band | verdict |
|---|---|---|---|---|---|---|
| width 1.65 | 5 | +243.73 | 80.0 | +0.064 | [−96.79, +170.84] | not separated |
| width 1.80 | 11 | +692.51 | 81.8 | +0.166 | [−17.48, +139.21] | not separated |
| width 1.95 | 15 | +398.20 | 60.0 | +0.055 | [−38.86, +95.24] | not separated |
| width 2.50 | 16 | +322.11 | 56.2 | +0.033 | [−41.56, +84.94] | not separated |
| width 3.50 | 22 | +802.46 | 59.1 | +0.129 | [−29.01, +109.26] | not separated |
| buffer 0.05 | 18 | +610.64 | 55.6 | +0.174 | [−68.66, +144.64] | not separated |
| buffer 0.00 | 32 | +224.92 | 59.4 | +0.130 | [−49.34, +64.58] | not separated |
| extension 1.25 | 8 | **−536.96** | 25.0 | −0.371 | **[−126.26, −21.34]** | **NEGATIVE** |
| extension 1.50 | 11 | +303.87 | 45.5 | +0.025 | [−72.61, +147.19] | not separated |
| extension 2.00 | 13 | +952.93 | 53.8 | +0.164 | [−36.24, +193.96] | not separated |
| distance 1.25 | 3 | −50.98 | 66.7 | −0.033 | [−60.23, +7.77] | not separated |
| distance 1.50 | 6 | +593.40 | 66.7 | +0.328 | [−22.13, +271.18] | not separated |
| C1 | 17 | +390.77 | 58.8 | +0.050 | [−33.83, +82.81] | not separated |
| C3 | 28 | +573.76 | 60.7 | +0.065 | [−25.22, +66.72] | not separated |

**[observed]**. These are the "newly-admitted trades separated from the existing edge". The next section shows
why they are not the same thing as the change's effect.

### 2.3 The effect on the whole book (paired by session, 20,000 resamples, seed 702411)

| policy | Δ net $ (fill) | 95 % band | verdict | sessions it costs money in | Δ without its best new trade |
|---|---|---|---|---|---|
| width 1.65 | +166.75 | [−5.49, +9.64] | not separated | 1 | **−86.25** |
| width 1.80 | +542.55 | [−3.64, +17.36] | not separated | 3 | +278.37 |
| width 1.95 | +248.24 | [−8.10, +14.67] | not separated | 7 | **−15.94** |
| width 2.50 | +172.39 | [−9.23, +14.09] | not separated | 8 | — |
| width 3.50 | +522.52 | [−9.27, +23.55] | not separated | 10 | +5.89 |
| buffer 0.05 | +444.28 | [−15.48, +27.76] | not separated | 7 | **−92.48** |
| buffer 0.00 | +21.13 | [−18.84, +19.76] | not separated | 11 | — |
| extension 1.25 | −60.91 | [−3.40, +2.04] | not separated | 4 | −72.14 |
| extension 1.50 | +779.92 | [−1.15, +23.89] | not separated | 4 | +107.61 |
| extension 2.00 | **+1,428.98** | **[+0.25, +39.18]** | **POSITIVE** | 4 | **+907.44, band [−0.24, +25.50]** |
| distance 1.25 | −50.98 | [−2.15, +0.28] | not separated | 1 | −58.75 |
| distance 1.50 | +605.94 | [−1.32, +21.67] | not separated | 1 | +107.61 (of its own best; band [−1.97, +5.77]) |
| distance 2.00 | +605.94 | [−1.32, +21.68] | not separated | 1 | identical ticket set to 1.50 |
| C1 | +240.81 | [−8.09, +14.48] | not separated | 8 | **−23.37** |
| C2 | +444.28 | [−15.48, +27.76] | not separated | 7 | **−92.48** |
| C3 | +871.85 | [−2.39, +24.32] | not separated | 7 | +581.72, band [−4.31, +18.90] |

**[observed]** (`out_sweep.txt`; the leave-best-out column is a re-run with the largest new trade subtracted
from its own session before bootstrapping, same seed). The signal-anchored picture is the same shape
(`out_sweep.txt` prints both): extension 2.00 is the only band excluding zero, at +$1,508.90 [+0.23, +41.44].

**Read the two tables together.** Extension 2.00's new-trade P&L is +$952.93, but a third of its measured Δ is
the 5 removed baseline losers (−$476.05) not happening again, and 55 % of the rest is one trade (+$521.54).
Where new trades are genuinely added without much displacement (buffer 0.00: 32 new, 11 dropped), the net
effect is **+$21** — a bigger book buying nothing.

### 2.4 Decomposition (the identity that makes the numbers readable)

Checked on **all 16** variants: Δ = (new trades) − (displaced baseline trades) to within **$0.24** — width
1.80 → +$692.51 − $149.91 = +$542.60 vs measured +$542.55; extension 2.00 → +$952.93 − (−$476.05) =
+$1,428.98 exactly; C3 → +$573.76 − (−$298.14) = +$871.90 vs +$871.85; the largest residual across all 16 is
+$0.24. Those cents are fee rounding on a few kept trades (2026-08-18 SPXS 14:15 is the visible one), not
different trading. **[observed]**

So "does a loosening help" is the question "are the trades it swaps in better than the ones it swaps out" —
and at these sample sizes the answer is not separated from zero anywhere except extension 1.25, where it is
*no*.

---

## 3. Exposure: does the widening feed the two known loss cells?

Reference cells (per-session fill anchor; the published continuous-account cells are −$1,281.77 / 33 / 42.4 %
and bull −$1,155.14): `normal`-day SHORT **−$1,279.67 / 33 trades / 42.4 % / −0.159 R**; bull bucket
**−$1,158.18 / 52 / 44.2 % / −0.012 R**. Baselines: `normal`/SHORT is 33 of 108 tickets = **30.6 %**; bull is
52 of 108 = **48.1 %**.

| policy | new `normal`/SHORT trades | new bull-bucket trades | SHORT share of new trades | reading |
|---|---|---|---|---|
| width 1.65 | n=2, +$194.71, 100 % | n=1, +$12.75 | 40 % | 2 trades; the "BETTER cell" band is an artefact of n=2, not evidence |
| width 1.80 | n=2, +$194.71, 100 % | n=2, **−$59.43**, 50 % | 27 % | neutral on the loss cell, slightly worse in bull |
| width 1.95 | n=3, +$70.71, 66.7 % | n=3, **−$183.43**, 33.3 % | 27 % | **worsens the bull bucket** |
| width 2.50 | n=3, +$70.71 | n=3, −$183.43, 33.3 % | 25 % | same, more candidates, no more tickets |
| width 3.50 | n=6, +$436.44, 66.7 % | n=3, −$183.43, 33.3 % | 36 % | bull still worse; adds 6 normal-day shorts that happen to win |
| buffer 0.05 | n=8, +$483.50, 62.5 % | n=7, +$282.10, 57.1 % | 56 % | most short-heavy change; in this sample it pays |
| buffer 0.00 | n=12, **−$187.39**, 50 % | n=17, +$93.09 | 47 % | **drifts toward the loss cell** at 19 % more tickets |
| extension 1.25 | n=2, **−$316.90, 0 %** | n=3, **−$311.58, 33.3 %** | 25 % | **provably bad: both loss cells at once** |
| extension 1.50 | n=4, +$148.76 | n=4, +$71.99 | 45 % | one +$383.57 trade drives it; the other 10 new trades net ≈ −$80 |
| extension 2.00 | n=6, +$797.82, 66.7 % | n=6, +$721.05, 66.7 % | 54 % | good in sample, single-trade dependent (§2.3) |
| distance 1.25 | n=2, −$58.75 | n=3, −$50.98 | 0 % | small, negative, no upside |
| distance 1.50 | n=3, +$439.58 | n=3, −$50.98 | 50 % | one +$498.33 trade is 84 % of the new-trade total |
| C1 | n=5, +$11.96 | n=5, **−$242.18**, 40 % | 35 % | adds width, imports the bull-bucket problem |
| C3 | n=9, +$253.17, 66.7 % | n=12, +$47.34, 58.3 % | 36 % | the most *balanced* variant (13 sessions better / 7 worse) |

**[observed]** (`out_detail.txt:8-46`, `out_sweep.txt`).

**Explicit "busier but worse" list** (the flag the brief asks for):

- **extension 1.25** — 3 more tickets, Δ −$60.91, the only reliably negative new-trade set. Reject.
- **distance 1.25** — 3 more tickets, Δ −$50.98, all three new trades in the bull bucket, no upside. Reject.
- **buffer 0.00** — +21 tickets for Δ +$21, and its new `normal`-day shorts are −$187. This is the clearest
  "trading looks busier, nothing improves" case. Reject.
- **width 1.95 / 2.50 / C1** — more tickets, Δ ≈ +$172…+$248 (noise), and the new bull-bucket trades lose
  $183–$242 at 33–40 % win. Do not adopt.

**Not the loss cells:** no widening *reproduces* the −$1,281.77 cell at scale. The largest loss on any new
`normal`-day short set is extension 1.25's −$316.90 on **2** trades; the widest new set (buffer 0.00) is −$187
on 12. The pattern does not transfer, and with ≤12 trades per cell it could not be detected if it did.

---

## 4. The only tape the desk actually saw: 18–19 Nov

The 30 recovered rows from `.scratch/vixgate-1120/harness/scans.json` (byte dumps of the desk's own session
events) re-run through the pinned module reproduce **30/30** recorded verdicts (`out_twoday.txt:3-4`). Their
refusal reasons also reproduce the brief's 30-row tally exactly: **10** width refusals (all SMH — 4 on 18 Nov
at 3.39–3.43 %, 6 on 19 Nov at 1.83–1.92 %), **15** geometry, **3** stop-distance, and 2 SHORT signals.

Rows each threshold would newly admit on those two days (**[observed]**, `out_twoday.txt:6-18`):

| policy | rows | what |
|---|---|---|
| width 1.65 / 1.80 | 0 | the 19 Nov SMH range is 1.84–1.92 % |
| width 1.95 | 4 | 19 Nov SMH at 10:17/10:20/10:26 (one 10:05 scan round, sampled three times) and 11:00 — **2 distinct scan rounds** |
| width 3.50 | 4 | same rows. The 18 Nov SMH rows never broke their range at any width — 10:05 price 460.79 sits inside 453.83–469.50, and the refusal at 3.50 is still "no confirmed breakout" |
| buffer 0.05 | 0 | — |
| extension 1.25 | 0 | — |
| extension 1.50 | 1 | 19 Nov 11:00 SPY |
| extension 2.00 | 2 | 19 Nov 11:00 QQQ and SPY |
| distance 1.25 | 1 | 19 Nov 10:05 SPY |
| distance 1.50 | 3 | 19 Nov 10:05 QQQ, SPY (two sampled rows) |
| C3 | 1 | 19 Nov 10:05 SPY |

Two honest caveats: Nov 19 is a `bear_high_vol` session (`allow_long=False`), so the admitted SMH/QQQ rows
would have been SHORT ideas; and **admission at the signal layer is not an executable ticket** — the earlier
memo measured a SCAN round-trip of 21 m 47 s against the researcher's 5-minute staleness rule, which voided
both of that day's actual signals (`vix-gate-and-zero-trades-nov20.md`). What those rows would have made is
**[undiscoverable]** here: the rows do carry an inverse price (SOXS 54.26 at 10:17, 54.26 at 10:20, 54.67 at
10:26, 56.71 at 11:00), but the replay bar store ends 2026-11-18 and there is no intraday path for 19 Nov to
score the trades against.

---

## 5. Significance, honestly

- Bootstrap exactly as `regime-robustness-nov20.md`: seeded `random.Random(702411)`, 20,000 resamples,
  2.5/97.5 percentiles. For whole-book effects the resample unit is the **trading session** (each session is an
  independent 100k account); for new-trade quality it is the **trade**; the leave-best-out column resamples
  sessions after subtracting one trade.
- Result: **15 of 16 variants have bands that straddle zero.** The single exception (extension 2.00) sits
  $0.25 above zero on a $17/session mean and collapses when its best trade is removed. I do not claim
  significance for it, and nothing else here is significant in either direction.
- The one negative result (extension 1.25 new trades) is a per-trade band on 8 trades; it is the strongest
  statement in this memo and still a small sample.
- With 16 correlated thresholds searched on the same 84 sessions and scored on the same 84 sessions, at least
  one band should exclude zero by chance at roughly coin-flip rates (1 − 0.95¹⁶ ≈ 56 % for independent looks).
  The observed pattern — one marginal hit that disappears when a single trade is removed — is what noise
  looks like, not what an edge looks like.

**Limits, stated once:** in-sample threshold search (no holdout); one window (Mar–Nov 2026, no `crisis`
session); one engine and one fill model (11-min latency, touch-based take-profit, no partial fills, no
slippage beyond the limit ladder); new-trade subsets of 3–32 trades; 108 → 129 tickets in total, so aggregate
deltas of a few hundred dollars are two or three trades. The replay ends 2026-11-18; 19 Nov exists only as the
30 recovered rows.

---

## 6. Proposals

**P1 — If anything is changed, change the stop-distance cap at `:192` from `rng` to `1.5 * rng`.**
Fewest moving parts of any setting whose new-trade set is not negative.

- Threshold: `if dist <= 0 or dist > 1.5 * rng:` (line 192), nothing else.
- Backtested cost/benefit: 16 candidates → **6 new tickets, 1 displaced (a −$12.54 SMH loser at 12:45,
  replaced by a QQQ entry in that slot and by SMH re-entering at 14:15)**, 113 vs 108 tickets. Δ **+$605.94, band [−1.32, +21.67] — not separated**. New trades +$593.40 (66.7 % win, +0.328 R),
  but **$498.33 of it is one trade** (2026-11-02 SPXS); without it +$107.61, band [−1.97, +5.77].
  Loss-cell exposure: new `normal`/SHORT +$439.58 (3 trades, 66.7 %), new bull −$50.98 (3 trades) — it does
  not feed either cell.
- Saturation: `1.5` and `2.0` admit the **identical 16 rows** (max observed `dist/rng` = 1.476), so 1.5 is
  the whole envelope; going further buys nothing. Cost: stops up to 1.5× the range the trade is breaking out
  of — an entry whose stop is 50 % wider than its opening range; 5 tickets in 84 sessions is the only
  behavioural change.
- Verdict: **acceptable as a bundled experiment, not on its own merits.** Expected value is within noise of
  zero; ship it only if a bundle needs the extra samples.

**P2 — width band 1.5 % → 1.8 % is the best width setting and is still not an edge.**
- Threshold: `if not 0.15 <= rng_pct <= 1.8:` (line 165), nothing else.
- Backtested cost/benefit: 26 candidates → **11 new, 2 displaced winners (−$149.91)**, 117 tickets (8 % more).
  Δ **+$542.55, band [−3.64, +17.36] — not separated**; without its best new trade +$278.37. All of the
  new-trade profit is **4 sideways-bucket SMH/SOXS trades (+$597.71, 100 % win)** — one bucket, one season
  (June–August). New bull trades −$59.43; one caution-day LONG −$216.73 (2026-04-01 SMH) is the worst single
  addition.
- Cost: 2 known-good baseline trades displaced (2026-08-03 SPY +$76.93, 2026-11-09 SPY +$72.98) to gain
  trades that are indistinguishable from them in expectation. 1.65 is strictly dominated (Δ +$166.75 and
  −$86.25 without its best trade); 1.95+ adds bull-bucket losses. If width moves at all, 1.8 is the number.
- Verdict: **experiment only**, explicitly to increase sample count at unchanged quality — not a P&L claim.

**P3 — Do not adopt: buffer 0.00, extension 1.25, extension 2.00 (and any combination containing them).**
- **buffer 0.00** (`price > hi` / `price < lo`, no buffer): 54 candidates → 129 tickets (+19 %), 32 new /
  11 dropped, Δ **+$21.13 [−18.84, +19.76]** — zero for a third more tickets, and new `normal`-day shorts
  −$187.39. Look-busier, do-nothing.
- **extension 1.25** (`price - hi <= 1.25 * rng`): Δ −$60.91, new trades **−$536.96, band [−126.26, −21.34] —
  NEGATIVE**, new `normal`/SHORT 0 % win and new bull 33 % win simultaneously. The one change the data
  positively dislikes.
- **extension 2.00**: the only POSITIVE band (+$1,428.98 [+0.25, +39.18]), but it is +$521.54 from one trade
  (2026-06-16 SOXS) plus the avoidance of 5 displaced losers (−$476.05). Without the single trade the band is
  [−0.24, +25.50]. It also re-admits the late/extended breakouts the earlier memo rejected on latency
  grounds (`vix-gate-and-zero-trades-nov20.md`, item C: 2 chase tickets that the desk's 21-minute round trip
  cannot act on). Do not adopt on one trade.
- C3 (width 1.80 + extension 1.25 + distance 1.25) is the one bundle worth a second look *if* P1 and P2 are
  ever adopted together: +$871.85, 13 sessions better / 7 worse, band [−2.39, +24.32] still straddling, and
  without its best new trade +$581.72 [−4.31, +18.90]. Its new exposure is the most balanced of any variant.
  Still not evidence — it is the least noisy of the noisy options.

---

## 7. What could not be verified

- **Whether the 30 recovered rows are the complete record of 18–19 Nov.** They are the desk's own recorded
  events (provenance per row) and reproduce every verdict, but completeness of the harvest is
  **[undiscoverable]** from here.
- **What the newly admitted 19 Nov rows would have earned.** Prices exist (including the inverse ETF), but the
  replay bar store ends 18 Nov, so there is no intraday path to evaluate entry, stop, target or 15:45 flat
  against. **[undiscoverable]**
- **How these thresholds behave in a `crisis` session.** The window contains none. **[undiscoverable]**
- **Live fill quality.** The replay's ladder entry is a model; no session in the extension window was traded
  live. **[observed]** for the replay, **[undiscoverable]** for live slippage.

---

## 8. Reproduction

```
PY=/c/Users/tteh/AppData/Local/Programs/Python/Python312/python.exe
cd .scratch/loosen-1120
$PY probe.py   > out_probe.txt   2>&1    # 1,008 rows, offline re-score, asserts 0 mismatches
$PY sweep.py   > out_sweep.txt   2>&1    # 16 variants, per-session paired bootstrap, writes out_sweep.json
$PY detail.py  > out_detail.txt  2>&1    # exposure shift, cell comparison, ticker/scan mix, conversion
$PY verify.py  > out_verify.txt  2>&1    # live sha, ts_live byte-identity, changed lines per derived module
$PY twoday.py  > out_twoday.txt  2>&1    # 30 recovered rows, 30/30 reproduction, per-threshold admissions
```

All five are read-only over `.scratch/` data and write only their own output files.

**[§9 correction]** The five commands above do **not** regenerate the "Δ without its best new trade"
column of §2.3, and therefore do not reproduce §0.1's bottom line: `sweep.py` contains no leave-best-out
code (it stores counts and aggregates into `out_sweep.json`, and the per-trade detail lives only in its
own stdout for the *other* columns). A sixth command is needed and §9.2 gives one that reproduces all
four checked rows to the cent.

## 9. Independent verification by the parallel Part A session (added 2026-11-20T04:05Z)

The same mailbox task (`20261120T023636Z-7b19d4`) was split: this memo is Part B, written by a sibling
session; Part A was worked by the session that wrote
[`vix-gate-proposal-a-nov20.md` §9](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/vix-gate-proposal-a-nov20.md).
Part A's session was told to verify Part B's line numbers rather than trust them, and §0.1 — "the only
band that excludes zero crosses it as soon as its single best new trade is removed" — was the one claim
in this memo that had no artifact behind it. This section is that check.

**Nothing was applied or changed.** No cloud call of any kind (not even a `GET`), no `rules.json` edit, no
threshold change, no template or skill write, no order or account call. The work is one offline script
reusing this memo's own harness:
[`loo_check.py`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/loocheck-1120/loo_check.py),
output [`out_loo.txt`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/loocheck-1120/out_loo.txt).
It imports `sweep.py` rather than reimplementing it (same engine, same 84 sessions, same anchor
substitutions, same `Sim`), and redirects `sweep.GEN` to its own directory so no `gen/ts_*.py` of Part B
is rewritten.

Run it with:

```bash
PY=/c/Users/tteh/AppData/Local/Programs/Python/Python312/python.exe
cd /c/Users/tteh/Documents/qoder-trend-desk-dashboard
$PY -X utf8 .scratch/loocheck-1120/loo_check.py       # offline, ~2 min, writes only .scratch/loocheck-1120/
```

### 9.1 Every checked number reproduces [observed]

| variant (fill anchor) | Δ this memo | Δ re-run | new n | LOO this memo | LOO re-run | largest new trade |
|---|---|---|---|---|---|---|
| ext2.00 | +1,428.98 | **+1,428.98** | 13 / 13 | +907.44 | **+907.44** | +521.54, 2026-06-16 SOXS SHORT |
| w1.65 | +166.75 | **+166.75** | 5 / 5 | −86.25 | **−86.25** | +253.00, 2026-08-03 SMH LONG |
| buf0.05 | +444.28 | **+444.28** | 18 / 18 | −92.48 | **−92.48** | +536.76, 2026-04-21 SQQQ SHORT |
| C3 | +871.85 | **+871.85** | 28 / 28 | +581.72 | **+581.72** | +290.13, 2026-06-16 SQQQ SHORT |

Plus `base_net` +419.69, `variant_net` +1,848.67, dropped 5, and the signal-anchor Δ +1,508.90 — all
identical to §2.3 and the prose under it. **The arithmetic in §0.1 and §2.3 is sound**, and the memo's
stated identity (Δ = new − displaced, §2.4) holds here too: 952.93 − (−476.05) = 1,428.98 exactly.

### 9.2 What was missing, and what is now added

1. **The leave-best-out column had no producing artifact** — not in `out_sweep.txt`, not in
   `out_sweep.json` (which stores `new`/`dropped` as *counts*, `tickets` as an int, and no per-trade
   list), not in any of §8's five commands. `loo_check.py` is that sixth command. Its result agrees with
   the memo to the cent on all four rows, so this is a provenance gap closed, not a number corrected.
2. **Seed-order dependence of the printed band endpoints — stated nowhere in this memo.**
   `sweep.main()` builds one `random.Random(702411)` and consumes it across all 32 sequential bootstrap
   calls (16 variants × 2 anchors, plus the per-trade bootstrap), so a variant's 2.5/97.5 percentiles
   depend on how many draws were consumed before it. Re-bootstrapping the *same* deltas with a fresh rng
   per call gives ext2.00/fill **[+0.27, +39.04]** rather than [+0.25, +39.18]. Across five independent
   seeds the lower bound spans **+0.15 … +0.52** and the upper **+39.04 … +39.47**; the signal anchor
   spans [+0.15, +41.17] … [+0.52, +41.64] against the memo's [+0.23, +41.44]. Every value lands inside
   the memo's rounding of the same distribution, so nothing was wrong — but the exact endpoints are not
   reproducible as printed, and a reader re-running §8 and diffing the file will see them move.
3. **The verdict is seed-robust, which strengthens §0.1 rather than weakening it.** The as-is band
   excludes zero on **all five** seeds (+0.15 to +0.52 > 0), and the leave-best-out band **crosses zero
   on all five** (lower bound −0.28 to −0.10). So "one marginal hit that evaporates when its best trade
   is removed" is not an artifact of one lucky draw order. The same holds for the two rows the memo marks
   negative-without-their-best-trade: w1.65 LOO crosses zero on all five seeds, buf0.05 likewise.
4. **Unit note for anyone comparing the two memos.** This memo's baseline cells are `normal/SHORT`
   **−$1,279.67** (n=33, 42.4 %) and `bull` **−$1,158.18** (n=52) at the fill anchor
   (`out_detail.txt:2-4`), because the `Sim` is rebuilt per session. The brief's figures — −$1,281.77
   over 33 at 42.4 %, and bull −$1,118.02 — are from
   [`regime-robustness-nov20.md`:24,:39-40](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/regime-robustness-nov20.md#L24)
   in that memo's continuous-account unit. Same trades, two bookkeeping bases; §0's preamble says so, but
   the numbers do not match digit-for-digit and a reader who diffs them across files needs this line.

### 9.3 The named filters' line numbers, re-verified against the live pinned bytes [observed]

The brief warned these "may have moved". They have not. Downloaded and unpacked from the version pinned
on `researcher` (`trend-signal@1795047415929677`), sha256
`60d5573de1eb139d75378f537b689c733f648ae8dd52e444fd44194e5ba9bed8`, 10,405 bytes, 226 lines — byte-identical
to `bt-regime-1120/trend_signal_patched.py` that this harness patches (and to the copy in
`.scratch/changes/2026-11-20-scan-staleness/before/trend-signal-1795047415929677/`, fetched independently
at `2026-11-20T03:11:10Z`):

| filter | brief said | live bytes | the line |
|---|---|---|---|
| opening-range width band | `:165` | **`:165`** ✓ | `if not 0.15 <= rng_pct <= 1.5:` |
| breakout geometry / extension cap | `:169-174` | **`:169`/`:171`** ✓ | `if price > hi + 0.1 * rng and price > vwap and price - hi <= rng:` / the `elif` mirror |
| R/R / stop-distance test | `:192` | **`:192`** ✓ | `if dist <= 0 or dist > rng:` |

`sweep.py:47-49` already asserts each anchor string occurs exactly once in that source and refuses
otherwise, so a moved line would have failed the harness rather than silently shifting the analysis.
The kill counts the brief named (10 SMH rows at the width band, 15 at geometry, 3 at the R/R test) are a
property of §2's admission tables, which reproduce above.

### 9.4 Not verified by this section

Twelve of the sixteen variants (only ext2.00, w1.65, buf0.05 and C3 were re-run), §3's exposure tables
beyond the four baseline cells, §4's 18–19 Nov tape, `probe.py`'s 1,008-row re-score and `twoday.py`'s
30 recovered rows — all of which this session neither re-ran nor contradicts. Nothing here changes any
proposal in §6: P1/P2's "not separated" verdicts are exactly what §9.2(3) confirms.
