# SCAN latency: measurement, diagnosis, and the fixes that survive it

Date decided: 2026-11-21 (ET). Task: measure and cut SCAN latency before Mon 23 Nov 2026.
Author: Qoder Desktop (this session). Status: **measured, built and staged — nothing applied.**
The owner applies. Evidence: `.scratch/latency/scan-hops-nov17-20.csv` (105 rows),
`.scratch/latency/scan-segments-nov17-20.json` (16 runs), `.scratch/changes/2026-11-22-scan-latency/`.

Every claim is labelled **OBSERVED** (a payload/byte I read), **DOCUMENTED** (a repo file),
**INFERRED** (a model over observations) or **UNDISCOVERABLE** (no field exists to prove it).

## 1. Where the time actually goes (OBSERVED)

All 16 scheduled SCAN runs Nov 17-20 (4 slots x 4 days), from Forward session events. Wall =
trigger -> last session event.

| segment | median | p90 | max | what it is |
|---|---|---|---|---|
| **(a) cold start** | 1 s | 1 s | 1 s | trigger -> session first event. Irrelevant. |
| **(b) first dispatch** | **56 s** | 86 s | 103 s | coordinator's own first turn: reads the trigger, composes the dispatch text. No child has started yet. |
| **(c) tool round-trip** | 8 s | 11 s | 15 s | paired `tool_use`->`tool_result` visible in the parent stream (~1% of wall). |
| **(d) coordinator model time** | **158 s** | 223 s | 238 s | 97% of coordinator turn wall; thinking + writing. |
| **(e) researcher leg** | **377 s** | 637 s | 1292 s | thread created -> its reply delivered. Dominates. |
| **(e) auditor leg** | 226 s | 489 s | 553 s | same, for the gate/monitoring leg. |
| (e) executor leg | 0 s | 0 s | 50 s | only 2 of 16 runs woke it. |
| **all child legs** | **620 s** | 1073 s | 1734 s | **84% of the 739 s median wall.** |
| close-out | 36 s | 66 s | 108 s | last reply -> last event. |
| **wall** | **739 s** | 1296 s | 1800 s | 15 `completed`, 1 `failed`. |
| credits | 21 | 33 | 35 | `session.usage.total_credits`, median. |

Topology (OBSERVED, all 16 runs, all four days): one coordinator **session**; researcher,
auditor and executor are **agent threads inside it** (`create_agent` -> `sthr_...`,
`send_to_agent`). Zero child sessions exist in any SCAN window. **DOCUMENTED claim refuted:**
`docs/agent-handover-2026-11-21.md` 3A says each role is "a separate Forward session" — untrue
for the whole measured window.

Segments I could **not** split, with the reason (per "do not guess the split"):

- **(b) MCP/tool resolution inside a child — UNDISCOVERABLE.** A child thread emits nothing into
  the parent stream except its idle event and its reply. `agent.tool_use`/`agent.mcp_tool_use`
  carry no thread id, so no tool call inside a leg can be attributed to that leg. `mcp_calls_visible`
  is 0 on all 16 runs; that is an observability limit, **not** evidence the desk skips moomoo.
- **(c)/(d) inside a child leg — UNDISCOVERABLE.** Only the leg's wall is measurable.
- **token counts — UNDISCOVERABLE.** No event field carries them; `span.model_request_end`
  carries `model_usage.credits`, which is where the credit column comes from.

Answers to the two mandated questions:

1. **Does a HOLD wake the auditor and executor?** Auditor: **yes, every time** — 14 no-candidate
   close-out legs across the 16 runs, 48-319 s, median **84 s**, 1,663 s total, and in each case it
   was the **last hop the run waited on**. Executor: **no** — never woken on a HOLD (0/14).
2. **Is the 1800 s timeout the binding rail?** No, and it is already fixed: wall p90 1296 s vs the
   live 3000 s (SCAN-1005) / 5100 s (1100/1230/1400), i.e. p90 x 1.5 = 1752 s is exceeded by
   nothing. OBSERVED corollary: the Nov-19 15:05 run is recorded `failed`
   ("context deadline exceeded") at the old 1800 s while its session ended cleanly with
   `stop_reason: end_turn` ~35 s later — a rail that is too tight converts successes into failures.
   **F8 needs no schedule write.**

## 2. Diagnosis

Three causes, in size order:

1. **The desk serialises a fetch behind a check.** Live coordinator says: "the auditor runs the
   monitoring check on open positions first and sends any close ticket **before you ask for
   signals**" (OBSERVED, `before/system-coordinator.bin` L11). So the researcher's 377 s leg starts
   only after a 226 s leg finished. On 10 of 12 runs Nov 18-20 the fetch was provably behind
   monitoring; median idle fetch time **202 s**, max **331 s**.
   The *ordering* is right — no new risk before a breach is handled. The *object* of the ordering is
   wrong: nothing in a market-data fetch can act on a position. What must be ordered is the release.
2. **The coordinator rewrites a protocol every run.** 8,692 chars of freshly generated dispatch text
   per SCAN (median, OBSERVED from `agent.message` payloads), most of it restating rules the child
   already carries in its own template. That is what segment (b) (56 s) and much of (d) (158 s) buy.
3. **A no-candidate scan still pays a full gate leg** (14/14, median 84 s) for a reply that by
   construction cannot contain a verdict.

Not causes: cold start (1 s), transport (8 s, ~1%), model speed per se, credits (median 21/run —
the earlier "budget cap" hypothesis is void: schedules expose only `session_mode`,
`max_concurrent_runs`, `max_attempts`, `timeout_ms`; no budget field exists, and a cap can end a
run but never speed one).

## 3. Fix evaluation (F1-F8 from the brief)

| fix | verdict | measured basis |
|---|---|---|
| F1 early exit on all-HOLD | **BUILT** | removes the 84 s median last hop on 14/16 runs. Coordinator has `skills: []` (OBSERVED live GET) so it **cannot** journal the record itself — the brief's version of F1 was not implementable as written; the record moves to the researcher, which does have decision-journal. |
| F2 re-quote at decision + guard staleness | **ALREADY LIVE / not rebuilt** | researcher step 2 already mandates an immediate re-quote + re-run before any LONG/SHORT ships (OBSERVED live). No `guard.py` staleness check added: it would be a second consumer of data guard does not receive. Tier B untouched, so **no skill publish from this package** and no collision with c2. |
| F3 pre-compute at BRIEF into the awareness store | **REJECTED** | BRIEF runs 09:00; a signal at 14:00 must be 5 min fresh. Pre-computed numbers cannot satisfy the rule the brief forbids loosening; it would only move staleness into a file. |
| F4 batch quotes | **BUILT** | `quote_stock_quote.code_list` is an array; live text fetched per symbol. |
| F5 terse fixed-JSON hand-offs | **BUILT** | attacks (b) 56 s and part of (d) 158 s; kills 8,692 chars/run of regenerated protocol. |
| F6 MCP resolution guard, one retry, then HOLD | **PARTLY LIVE / BUILT for the gap** | researcher already has a probe ("TOOLSET ABSENT (moomoomcp)", OBSERVED live). Auditor and executor had **none**: an unmounted toolset made the auditor emit a *risk veto* for a config fault. Added to both. |
| F7 collapse a hop (researcher runs the guard pre-check) | **NOT BUILT — and it is the only thing that reaches 6 min** | it is the sole measured lever big enough (saves a ~120-226 s hop), but it hands the researcher the gate output. The auditor must still run `check` itself, so the saving is partial and the doctrine surface is worse. Owner's call, not mine to stage. |
| F8 timeouts at p90 x 1.5 | **ALREADY SATISFIED** | see 1.2. No schedule write. |

Bonus fix found while anchoring (**F5b**): live coordinator L5 advertises "Skills: trend-signal,
desk-risk-guard, decision-journal" while its live binding list is `skills: []` and `mcp: []`.
Dead text that invites a failed tool round mid-scan. Replaced with an explicit "nothing is mounted
on you; do not try".

## 4. What is reachable (the honest target)

Baseline median wall 739 s. Modelled after the staged patch (INFERRED by adding measured leg
lengths; **not rehearsed**, see 6):

- **no-candidate SCAN: ~470 s (7m50s)** — F5 -36 s, L1 -150 s, F1 -84 s.
- **candidate-bearing SCAN: ~550-650 s + ~50-90 s executor** — F1 does not apply, the gate leg must
  run for real.

**The brief's 6-minute median is not reachable by prompt changes alone.** The residual is the
researcher's ~230 s compute-and-emit leg plus the auditor's ~120-226 s gate leg: both are model
generation inside child threads, neither observable, and F7 is the only lever that removes one.
What *is* plausibly reachable: **zero signals voided purely by pipeline age** — the VIX memo's two
Nov-20 age-outs came from fetch -> monitor -> compute ordering; L1 makes the cached numbers
<= 5 min old when SIGNALS starts. That mechanism is INFERRED from leg lengths, not observed.

## 5. Staged package

`.scratch/changes/2026-11-22-scan-latency/` — 9 anchored edits, 4 templates, `system` only.

- `before/system-<role>.bin` — fresh live GET, field `system` (not `system_prompt`), all four
  byte-identical to the live digests at capture: `6828253d4c20` / `573c2051551d` / `ef9214565277` /
  `84c192f72273`, re-checked by `payload.mjs` on every run ("base bytes == live GET sha256: true" x4).
- `tools/payload.mjs --base {live|c4}` — aborts unless each anchor occurs **exactly once**.
  Both bases apply with **identical net deltas** (+1638/+1754/+373/+244), i.e. the patch is
  base-independent. 8 of 9 anchors are disjoint from Sleeve B c4; the ninth was re-placed after
  detecting that c4 adds its own numbered step 5 to the researcher, so the new block is unnumbered
  prose. **Bundling is therefore available in either order**, satisfying 4's "same per-template write".
- `tools/verify.mjs` — **33/33 checks pass on both bases**: doctrine + naming lint: freshness rule, the
  sleeve-A re-quote, rule 1 exact-ticket approval, "only voice that can approve", kill-switch states,
  "no stop order on this account", flat-by-15:45, "at most TWO new positions", 10:45 release cutoff,
  HOLD-on-stale-evidence all unchanged; and every script/tool name this patch *puts into a prompt* is
  checked against the live binding list (`sim_trade_account_list` on two MCP-bound templates; the
  coordinator is asserted to hold nothing because it does).
- `tools/gate.mjs` — shared DRIVER 6.4 engine, read-only. Verdict at 16:07Z: **all four REFUSED,
  reason "outside the 16:45-08:30 ET change window", same-day ledger entries 0** — the window is the
  blocker, not the budget. Next eligible **2026-11-21T21:45Z = 16:45 ET = 05:45 SGT Sat 22.**
- `tools/write-one.mjs` — sibling's guarded engine (CONFIRM pair, live-drift abort, body carries only
  `system`, read-back requires every *other* top-level field to be unchanged because a merge patch
  silently drops what it is not told about, no `process.exit()` with the fetch pool open).
  Tested read-only: refusal with no/wrong CONFIRM; dry run with the right pair; `restore` on
  unchanged live returns **NO CHANGE (idempotent)**. **No POST has been made by this session.**
- Rollback = the same script's `restore` mode with the pair reversed.
- `server.js`: **no key changes needed.** A `{kind:"verdict", ts}` blob is claimed as `journal` at
  `server.js:205`, before `GUARD_KEYS`/`SIGNAL_KEYS`, so `no_candidate` cannot be harvested as a
  guard verdict. Verified against live `journal.py` instead: `stats` counts a veto as
  `not r.get("approved", True)`, so the shipped text forbids writing an `approved` field at all
  (missing = not a veto; explicit `false` would inflate the day's veto count) and requires
  `--agent researcher` because the flag defaults to `unknown`.

## 6. Not done, and what it costs

- **The rehearsal replay (brief 4) was not run.** It requires editing a cloud template to load the new
  prompts, and it is 11:07 ET on a trading day: 6 forbids writes 09:00-16:30 ET. The runbook is staged
  at `REHEARSAL.md`; owner-attended, one rehearsal template, ~15-25 credits.
  Consequence: section 4's numbers are **modelled, not measured**. Per 5's slip rule the fallback set
  (F1, F5, F6) is fully staged; L1 and F4 are in the same writes and can be dropped by omitting their
  edit ids and rebuilding.
- `guard.py` staleness (F2 Tier B) deliberately untouched -> no desk-risk-guard publish -> no collision
  with c2. The single-combined-guard-version question is therefore moot for this package.
- Sleeve B c4/c5: answered by the sibling's own ack rather than by my three outbox questions — the
  owner accepted the fly proposal and wants an **owner-attended** apply tonight; the sibling explicitly
  refused to let a child write take coordinator/auditor change #2. Compatible with this package: apply
  c4 first, then rebuild here with `--base c4` (manifest already staged).

## 7. Corrections issued during this task

1. I earlier presented the coordinator passage "Desk: Three roles, each a separate Forward session...
   Send the NONE list ... as a close-out" as live text. **No file in the repo contains it**
   (`grep -rl` empty) — it was my own reconstruction, and F1 was designed against it. Re-derived from
   bytes: live has no instruction to wake the auditor on a HOLD; the wake is model behaviour
   (14/14 observed). F1 is therefore an added prohibition, not a deletion.
2. My "144 model requests / 2435 s tool time / 192 tool_use" figures for the 15:05 run were void: the
   capture file held 100 unique events duplicated 12x because `next_cursor` does not exist on these
   endpoints (only `after_id` advances; `cursor`/`after`/`starting_after` are accepted and ignored,
   and `limit` caps at 100). Refetched; real values 12 / ~203 s / 16.
3. F2, F6 (researcher) and F8 were already live before this task — three of the eight mandated fixes
   needed no change.
