"""Sleeve B - options overlay on a Sleeve A entry that guard.py already approved.

Stdlib only, no network, no MCP, no order path. Returns a contract decision plus the ticket
fields an executor would need, as data; it never submits anything and it never places, modifies
or cancels an order.

Two invariants that the rest of this file exists to protect:

  * Price comes from the quote's `last_price` (or, when supplied, the order book's ask). It is
    NEVER `option_ex_data.premium`: that field is not a price - 0.123 was observed against a
    real last of 8.55. Only delta / IV / open interest / multiplier come from `option_ex_data`
    and they are read through OPTION_DATA_KEYS, which drops `premium` before anything else sees
    the row. `guard.py` sizes and fee-checks off the number this module calls `premium`, so a
    wrong source here becomes an unfillable limit order there.
  * A filled OPTION order row has never been observed on this sim (the 2026-11-19 probe ran
    pre-open, so it only ever saw resting -> cancelled). classify_fill() therefore recognises
    states positively, from the row shape that has been observed, and answers `state_unavailable`
    for anything else rather than guessing a field name. Same doctrine as equity stop recovery.

Sizing and fees are not re-implemented here for the debit-spread path (`select`): the proposal is handed
to desk-risk-guard's existing `sleeve="option"` branch, unchanged, exactly as the 2026-11-19 dry-run did.
The 0DTE iron fly (`fly`, in sleeve_b_fly.py) is the exception the source-of-truth §6 C1 asked for: it is
a credit structure sized on **max loss**, not premium, so its sizing arithmetic lives there and the guard
re-derives it instead of trusting it.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

DELTA_LO = 0.25
DELTA_HI = 0.50
ENTRY_TOL_PCT = 5.0
EXPANSION_RATIO_MIN = 1.5
CLOSE_LOC_HIGH = 0.66
CLOSE_LOC_LOW = 0.34
CONTRACT_MULTIPLIER = 100

# The only quote fields this module will accept as an option's price, in priority order.
PRICE_SOURCES = ("last_price", "ask")
# option_ex_data keys this module is allowed to read. `premium` is deliberately absent.
OPTION_DATA_KEYS = ("delta", "implied_volatility", "open_interest", "contract_multiplier")
# Read from rows but never used for a decision; listed so the fail-closed rule is explicit.
IGNORED_ROW_KEYS = ("today_buy_qty", "today_sell_qty", "today_buy_avg_price",
                    "today_sell_avg_price", "today_buy_namount", "today_sell_namount")

OBSERVED_STATUS = {2: "resting", 4: "filled", 5: "cancelled"}

OSI_RE = re.compile(r"^([A-Z.]{1,7})(\d{6})([CP])(\d{5,8})$")

# Verified against the live 2026-11-19 pre-market probe, which used these exact values.
TICKET_TEMPLATE = {"acc_id": "5830104", "market": 100, "order_type": 1, "order_side": 1,
                   "order_trade_time_type": 0}


def num(value):
    """Finite number from int/float/decimal-string, else None. Bools are not numbers here."""
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(value) else None
    if isinstance(value, str):
        try:
            out = float(value.strip())
        except ValueError:
            return None
        return out if math.isfinite(out) else None
    return None


def unavailable(reason, **extra):
    out = {"sleeve": "B", "action": "STATE_UNAVAILABLE", "reason": reason,
           "detail": reason, "allow_new_entries": False}
    out.update(extra)
    return out


def none(reason, **extra):
    out = {"sleeve": "B", "action": "NONE", "reason": reason}
    out.update(extra)
    return out


# ---------------------------------------------------------------- contract symbols

def parse_osi(symbol):
    """US.SPY261119C740000 -> {ticker, expiry, right, strike}. None if it is not an OSI option."""
    if not isinstance(symbol, str):
        return None
    tail = symbol.split(".", 1)[1] if symbol.startswith("US.") else symbol
    m = OSI_RE.match(tail.upper())
    if not m:
        return None
    ticker, ymd, cp, strike_raw = m.groups()
    strike = int(strike_raw) / 1000.0
    return {"ticker": ticker, "expiry": ymd, "right": "CALL" if cp == "C" else "PUT",
            "strike": strike, "osi": "US.%s%s%s%d" % (ticker, ymd, cp, int(strike_raw))}


def build_osi(ticker, expiry_ymd, right, strike):
    cp = "C" if str(right).upper().startswith("C") else "P"
    return "US.%s%s%s%d" % (str(ticker).upper(), expiry_ymd, cp, int(round(float(strike) * 1000)))


def is_option_symbol(symbol):
    return parse_osi(symbol) is not None


def dte_from_expiry(expiry_ymd, today):
    """Whole calendar days from `today` (YYYY-MM-DD or ISO datetime) to the expiry. None if unusable."""
    if not isinstance(expiry_ymd, str) or len(expiry_ymd) != 6 or not expiry_ymd.isdigit():
        return None
    try:
        exp = datetime(2000 + int(expiry_ymd[:2]), int(expiry_ymd[2:4]), int(expiry_ymd[4:6]),
                       tzinfo=timezone.utc)
    except ValueError:
        return None
    today_txt = str(today)[:10]
    try:
        base = datetime.strptime(today_txt, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    except ValueError:
        return None
    return (exp.date() - base.date()).days


# ---------------------------------------------------------------- quote normalisation

def quote_rows(payload):
    """Accept the raw MCP envelope or a bare list; return the per-contract quote rows."""
    if payload is None:
        return []
    node = payload
    if isinstance(node, dict):
        for key in ("data", "result", "ret"):
            if isinstance(node.get(key), (dict, list)):
                node = node[key]
                break
    if isinstance(node, dict):
        for key in ("quote_list", "quotes", "list"):
            if isinstance(node.get(key), list):
                node = node[key]
                break
    return node if isinstance(node, list) else []


def book_rows(payload):
    out = {}
    for r in quote_rows(payload):
        if not isinstance(r, dict):
            continue
        code = r.get("code") or r.get("symbol")
        if not isinstance(code, str):
            continue
        bid, ask = num(r.get("bid")), num(r.get("ask"))
        if isinstance(r.get("bid"), list) and r["bid"]:
            bid = num(r["bid"][0][0] if isinstance(r["bid"][0], (list, tuple)) else None)
        if isinstance(r["ask"], list) and r["ask"]:
            ask = num(r["ask"][0][0] if isinstance(r["ask"][0], (list, tuple)) else None)
        if ask is not None or bid is not None:
            out[code] = {"bid": bid, "ask": ask}
    return out


def option_ex_data(row):
    """Whitelisted greeks only. `premium` cannot survive this filter, so nothing downstream can read it."""
    ex = row.get("option_ex_data")
    if not isinstance(ex, dict):
        return {}
    return {k: ex[k] for k in OPTION_DATA_KEYS if k in ex}


def normalize_contracts(payload, today, book=None, min_volume=0):
    """Quote payload -> (contracts, warnings). Each usable contract carries `premium` and `price_source`."""
    book = book or {}
    contracts, warnings = [], []
    for row in quote_rows(payload):
        if not isinstance(row, dict):
            warnings.append("skipped a non-object quote row")
            continue
        code = row.get("code") or row.get("symbol")
        parsed = parse_osi(code)
        if not parsed:
            continue
        ex = option_ex_data(row)
        ask = (book.get(code) or {}).get("ask")
        bid = (book.get(code) or {}).get("bid")
        premium, price_source = num(row.get("last_price")), "last_price"
        if premium is None or premium <= 0:
            if ask is not None and ask > 0:
                premium, price_source = ask, "order_book_ask"
            else:
                warnings.append("%s: no last_price and no usable ask - contract dropped" % code)
                continue
        mult = num(ex.get("contract_multiplier"))
        if mult is not None and mult != CONTRACT_MULTIPLIER:
            warnings.append("%s: contract_multiplier %g is not 100 - budget math would be wrong, dropped" % (code, mult))
            continue
        delta = num(ex.get("delta"))
        days = dte_from_expiry(parsed["expiry"], today)
        vol = num(row.get("volume"))
        contracts.append({
            "symbol": parsed["osi"], "ticker": parsed["ticker"], "right": parsed["right"],
            "strike": parsed["strike"], "expiry": parsed["expiry"], "dte": days,
            "delta": delta, "iv": num(ex.get("implied_volatility")),
            "open_interest": num(ex.get("open_interest")), "volume": vol,
            "premium": premium, "price_source": price_source,
            "bid": bid, "ask": ask,
            "usable": delta is not None and days is not None and (vol is None or vol >= min_volume),
            "unusable_reason": (None if (delta is not None and days is not None)
                                else "delta or expiry missing - cannot be gated"),
        })
    return contracts, warnings


# ---------------------------------------------------------------- confluence gate

def prior_day_expansion(daily, ratio_min=EXPANSION_RATIO_MIN):
    """Direction of the prior session's range expansion, or 0. Same thresholds as the dry-run."""
    if not isinstance(daily, list) or len(daily) < 21:
        return None, "need 21 completed daily bars"
    y = daily[-1] if isinstance(daily[-1], dict) else {}
    o, h, l, c = (num(y.get(k)) for k in ("open", "high", "low", "close"))
    if None in (o, h, l, c) or o <= 0 or h <= l:
        return None, "prior-session OHLC missing or degenerate"

    def rng(d):
        vals = (num(d.get("open")), num(d.get("high")), num(d.get("low")))
        if None in vals or vals[0] <= 0 or vals[1] <= vals[2]:
            return None
        return (vals[1] - vals[2]) / vals[0]

    base = [rng(d) for d in daily[-21:-1]]
    if any(b is None for b in base):
        return None, "a baseline session has missing or degenerate OHLC"
    base = sum(base) / 20.0
    if base <= 0:
        return None, "no baseline range"
    ratio = rng(y) / base
    loc = (c - l) / (h - l)
    if ratio >= ratio_min and loc >= CLOSE_LOC_HIGH:
        return 1, "prior session %.2fx range, closed at %.0f%% of it" % (ratio, loc * 100)
    if ratio >= ratio_min and loc <= CLOSE_LOC_LOW:
        return -1, "prior session %.2fx range, closed at %.0f%% of it" % (ratio, loc * 100)
    return 0, "no qualifying expansion (%.2fx, close at %.0f%%)" % (ratio, loc * 100)


# ---------------------------------------------------------------- selection

def candidates(contracts, right, dte_min, dte_max, delta_lo=DELTA_LO, delta_hi=DELTA_HI):
    out = []
    for c in contracts:
        if c["right"] != right:
            continue
        if not c["usable"]:
            continue
        if not (dte_min <= c["dte"] <= dte_max):
            continue
        if not (delta_lo <= abs(c["delta"]) <= delta_hi):
            continue
        out.append(c)
    return sorted(out, key=lambda c: (-abs(c["delta"]), c["dte"], c["strike"]))


def pick(contracts, right, dte_min, dte_max, budget_usd, fee_ok,
         delta_lo=DELTA_LO, delta_hi=DELTA_HI, entry_tol_pct=ENTRY_TOL_PCT):
    """First contract that fits band, DTE, budget and the fee gate. Mirrors the dry-run's order."""
    trace = []
    for c in candidates(contracts, right, dte_min, dte_max, delta_lo, delta_hi):
        limit = round(c["premium"] * (1 + entry_tol_pct / 100.0), 2)
        qty = int(budget_usd // (limit * CONTRACT_MULTIPLIER)) if limit > 0 else 0
        if qty < 1:
            trace.append({"symbol": c["symbol"], "fate": "qty<1", "budget": round(budget_usd, 2),
                          "limit": limit})
            continue
        if not fee_ok(c["premium"], qty):
            trace.append({"symbol": c["symbol"], "fate": "fee_gate", "qty": qty, "limit": limit})
            continue
        trace.append({"symbol": c["symbol"], "fate": "picked", "qty": qty, "limit": limit})
        return c, qty, limit, trace
    return None, 0, 0.0, trace


# ---------------------------------------------------------------- rules / guard

def load_rules(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dte_bounds(rules):
    rk = (rules or {}).get("risk") or {}
    lo, hi = num(rk.get("dte_min")), num(rk.get("dte_max"))
    if lo is None or hi is None or hi < lo:
        return None, None, "rules.json risk.dte_min/dte_max absent or inverted - refusing to assume a DTE band"
    return int(lo), int(hi), None


def option_budget(rules, nav, size_mult=1.0):
    return nav * num(rules["risk"]["option_trade_risk_pct"]) / 100.0 * size_mult


def build_proposal(contract, underlying, size_mult=1.0):
    """The sleeve="option" proposal shape desk-risk-guard already consumes. Never "hedge"."""
    return {
        "sleeve": "option", "kind": "option", "ticker": underlying, "underlying": underlying,
        "option": {"premium": contract["premium"], "dte": contract["dte"],
                   "symbol": contract["symbol"], "delta": contract["delta"]},
        "regime_mult": size_mult,
        "note": "Sleeve B overlay; premium is quote %s, never option_ex_data.premium"
                % contract["price_source"],
    }


def build_portfolio(nav, peak_nav, day_start_nav, cash, positions=None, orders_today=0,
                    closed_trades=None, account_name="Moomoo x Qoder AI Paper Trading Agent Challenge",
                    account_id="5830104"):
    return {"account_name": account_name, "account_id": str(account_id), "account_mode": "SIMULATE",
            "nav": str(nav), "peak_nav": str(peak_nav), "day_start_nav": str(day_start_nav),
            "cash": str(cash), "orders_today": orders_today,
            "positions": positions or [], "closed_trades": closed_trades or {}}


def run_guard(proposal, portfolio, now_iso, guard_dir, phase="bounded", rules_path=None):
    """Read-only call into desk-risk-guard's CLI. Returns (verdict, None) or (None, error)."""
    guard_py = Path(guard_dir) / "guard.py"
    if not guard_py.is_file():
        return None, "guard.py not found at %s" % guard_py
    if proposal.get("sleeve") == "hedge":
        return None, "hedge path is not reachable from Sleeve B"
    tmp = tempfile.mkdtemp(prefix="sleeveb-")
    p_path = os.path.join(tmp, "proposal.json")
    f_path = os.path.join(tmp, "portfolio.json")
    Path(p_path).write_text(json.dumps(proposal), encoding="utf-8")
    Path(f_path).write_text(json.dumps(portfolio), encoding="utf-8")
    cmd = [sys.executable, str(guard_py), "check", "--proposal", p_path, "--portfolio", f_path,
           "--now", str(now_iso), "--phase", phase]
    if rules_path:
        cmd += ["--rules", str(rules_path)]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except Exception as exc:
        return None, "guard.py could not run: %s" % exc
    finally:
        for f in (p_path, f_path):
            try:
                os.remove(f)
            except OSError:
                pass
    if res.returncode != 0:
        return None, "guard.py exited %d: %s" % (res.returncode, (res.stderr or "").strip()[:300])
    line = (res.stdout or "").strip().splitlines()
    if not line:
        return None, "guard.py printed no verdict"
    try:
        return json.loads(line[-1]), None
    except ValueError:
        return None, "guard.py verdict was not JSON: %s" % line[-1][:300]


# ---------------------------------------------------------------- fill states

def classify_fill(row, require_option=False):
    """Positive-only match against the observed sim order-row schema. Never infers a state."""
    if not isinstance(row, dict):
        return unavailable("fill row is not an object", check="row_type")
    for key in ("status", "qty", "cum_qty"):
        if key not in row:
            return unavailable("required field %r absent from the fill row" % key, check="missing_field")
    status = row["status"]
    if isinstance(status, bool) or not isinstance(status, int):
        return unavailable("status %r is not an integer - the observed rows carry int status"
                           % (status,), check="status_type")
    qty, cum = num(row.get("qty")), num(row.get("cum_qty"))
    if qty is None or cum is None or qty < 0 or cum < 0:
        return unavailable("qty/cum_qty are not non-negative numbers: %r, %r" % (row.get("qty"), row.get("cum_qty")),
                           check="qty_type")
    parsed = parse_osi(row.get("symbol") or row.get("code"))
    if require_option and parsed is None:
        return unavailable("row is not an OSI option contract: %r" % (row.get("symbol"),), check="not_option")

    fields = {"status": status, "qty": qty, "cum_qty": cum,
              "avg_fill_price": num(row.get("avg_fill_price")),
              "symbol": (parsed or {}).get("osi") or row.get("symbol")}
    # Recorded for the day a real option fill is finally captured; never read for a decision.
    present_ignored = [k for k in IGNORED_ROW_KEYS if row.get(k) is not None]

    if status not in OBSERVED_STATUS:
        return unavailable("status %d has no observed meaning on this sim (only 2, 4, 5 do)" % status,
                           check="status_value", fields=fields)
    state = OBSERVED_STATUS[status]

    if state == "resting":
        if cum > 0:
            return unavailable("status 2 with cum_qty %g of %g - a resting partial fill has not been observed"
                               % (cum, qty), check="resting_partial", fields=fields)
        return {"sleeve": "B", "action": "RESTING", "state": "resting", "qty": qty, "cum_qty": cum,
                "reason": "order rests, unfilled", "fields": fields, "allow_new_entries": True}
    if state == "cancelled":
        if cum > 0:
            return unavailable("status 5 with cum_qty %g - cancelled-with-partial has not been observed" % cum,
                               check="cancelled_partial", fields=fields)
        return {"sleeve": "B", "action": "CANCELLED", "state": "cancelled", "qty": qty, "cum_qty": cum,
                "reason": "order cancelled, no exposure", "fields": fields, "allow_new_entries": True}

    # status 4
    if cum != qty:
        return unavailable("status 4 but cum_qty %g != qty %g - filled only when they are equal" % (cum, qty),
                           check="fill_quantity", fields=fields)
    if fields["avg_fill_price"] is None or fields["avg_fill_price"] <= 0:
        return unavailable("status 4 without a positive avg_fill_price (%r) - the cost basis is unreadable"
                           % (row.get("avg_fill_price"),), check="fill_price", fields=fields)
    return {"sleeve": "B", "action": "FILLED", "state": "filled", "qty": qty, "cum_qty": cum,
            "avg_fill_price": fields["avg_fill_price"],
            "reason": "fully filled at avg_fill_price, the authoritative cost basis",
            "ignored_today_fields": present_ignored,
            "warnings": ["filled OPTION row shape not yet observed on this sim - first occurrence should be captured, not trusted"],
            "fields": fields, "allow_new_entries": True}


def position_is_open(row):
    """(open, reason). A closed position persists with qty 0 and must not be read as live."""
    if not isinstance(row, dict):
        return None, "position row is not an object"
    qty = num(row.get("qty"))
    if qty is None:
        return None, "position qty %r is not numeric" % (row.get("qty"),)
    return (True, None) if qty > 0 else (False, "qty 0: the row is a closed position, not an exposure")


def reconcile(positions, order_rows, today=None, dte_min=None, dte_max=None, rules=None):
    """Fail-closed monitor: any option exposure whose state is not positively matched vetoes new entries."""
    warnings = []
    if rules is not None:
        lo, hi, err = dte_bounds(rules)
        if err:
            return unavailable(err, check="rules_dte")
        dte_min, dte_max = lo, hi
    open_pos = []
    for p in positions or []:
        is_open, why = position_is_open(p)
        if is_open is None:
            return unavailable(why, check="position_row")
        if is_open and is_option_symbol(p.get("symbol") or p.get("code")):
            open_pos.append(p)

    by_symbol = {}
    for r in order_rows or []:
        if isinstance(r, dict):
            key = r.get("symbol") or r.get("code")
            if isinstance(key, str):
                by_symbol.setdefault(key.split(".", 1)[-1].upper(), []).append(r)

    exposures, blocking = [], False
    for p in open_pos:
        parsed = parse_osi(p.get("symbol") or p.get("code"))
        sym = parsed["osi"] if parsed else p.get("symbol")
        rows = by_symbol.get(sym.replace("US.", ""), [])
        if not rows:
            exposures.append({"symbol": sym, "state": "state_unavailable",
                              "reason": "open option position with no order row to reconcile against"})
            blocking = True
            continue
        states = [classify_fill(r, require_option=True) for r in rows]
        bad = [s for s in states if s["action"] == "STATE_UNAVAILABLE"]
        live = [s for s in states if s["action"] in ("RESTING", "FILLED")]
        if bad and not live:
            exposures.append({"symbol": sym, "state": "state_unavailable",
                              "reason": bad[0]["reason"], "check": bad[0].get("check")})
            blocking = True
            continue
        if not live:
            exposures.append({"symbol": sym, "state": "closed", "reason": "every order row cancelled"})
            continue
        filled = [s for s in live if s["action"] == "FILLED"]
        cost = (filled[-1]["avg_fill_price"] if filled else None)
        days = dte_from_expiry(parsed["expiry"], today) if today else None
        if days is None:
            warnings.append("%s: DTE not checked - reconcile needs `today` to read the expiry" % sym)
        elif dte_min is not None and not (dte_min <= days <= dte_max):
            warnings.append("%s sits at %d DTE, outside the [%d,%d] Sleeve B band - it was not opened here"
                            % (sym, days, dte_min, dte_max))
        exposures.append({"symbol": sym, "state": "filled" if filled else "resting",
                          "dte": days, "cost_basis": cost,
                          "reason": "reconciled against %d order row(s)" % len(rows)})
    out = {"sleeve": "B", "action": "STATE_UNAVAILABLE" if blocking else "OK",
           "allow_new_entries": not blocking, "open_option_positions": len(open_pos),
           "exposures": exposures, "warnings": warnings}
    if blocking:
        out["reason"] = "one or more option exposures could not be positively matched to the observed row schema"
        out["detail"] = out["reason"]
    return out


# ---------------------------------------------------------------- ticket

def ticket_fields(symbol, qty, price):
    """DATA for the executor, in the shape the 2026-11-19 live probe verified. Never submitted here."""
    out = dict(TICKET_TEMPLATE)
    out.update({"symbol": symbol, "qty": str(int(qty)), "price": "%.2f" % float(price)})
    return out


def decide(inputs, guard_dir=None, rules_path=None, phase="bounded", run_guard_check=True):
    """Full pipeline: confluence -> band -> budget/fee -> guard -> ticket. Fail-closed at every gap."""
    today = inputs.get("today") or inputs.get("now")
    now_iso = inputs.get("now")
    if not isinstance(today, str) or not isinstance(now_iso, str):
        return unavailable("`today` and `now` are both required - DTE cannot be computed from a guess")

    rules_file = rules_path or inputs.get("rules_path")
    if not rules_file:
        return unavailable("no rules.json supplied - dte_min/dte_max and the fee gate come from there")
    try:
        rules = load_rules(rules_file)
    except (OSError, ValueError) as exc:
        return unavailable("rules.json unreadable: %s" % exc)
    dte_min, dte_max, err = dte_bounds(rules)
    if err:
        return unavailable(err, check="rules_dte")

    a = inputs.get("a_intent")
    if not isinstance(a, dict):
        return unavailable("a_intent is required: Sleeve B only overlays an entry Sleeve A already opened")
    underlying = a.get("underlying")
    direction = num(a.get("dir"))
    if direction not in (1.0, -1.0):
        return unavailable("a_intent.dir must be +1 or -1 - cannot choose CALL or PUT without it")
    entry, target = num(a.get("underlying_entry")), num(a.get("underlying_target"))
    if entry is None or target is None or entry <= 0:
        return unavailable("a_intent underlying_entry/underlying_target missing - the take-profit is derived from them")

    nav = num((inputs.get("portfolio") or {}).get("nav"))
    cash = num((inputs.get("portfolio") or {}).get("cash"))
    if nav is None or cash is None:
        return unavailable("portfolio nav/cash missing or non-numeric - the sleeve budget is a fraction of nav")

    exp_dir, exp_note = prior_day_expansion(inputs.get("daily") or [])
    if exp_dir is None:
        return unavailable("confluence evidence unavailable: %s" % exp_note, check="expansion")
    if exp_dir == 0:
        return none("no confluence: %s" % exp_note)
    if exp_dir != direction:
        return none("no confluence: prior-session expansion (%+d) does not agree with today's breakout (%+d)"
                    % (exp_dir, int(direction)))

    contracts, warnings = normalize_contracts(inputs.get("quotes"), today, book=book_rows(inputs.get("book")))
    if not contracts:
        return unavailable("no option rows parsed from the quote payload", check="no_contracts", warnings=warnings)
    right = "CALL" if direction > 0 else "PUT"
    size_mult = num(inputs.get("size_mult"))
    if size_mult is None:
        return unavailable("size_mult is required - the option budget scales with the regime multiplier", check="size_mult")
    budget = option_budget(rules, nav, size_mult)
    held = num(inputs.get("held_option_premium")) or 0.0
    cap = nav * num(rules["risk"]["max_open_option_premium_pct"]) / 100.0 - held
    budget = max(min(budget, cap), 0.0)

    def fee_ok(premium, qty):
        f = rules["fees"]
        fee = 2 * (f["option_min_commission"] + f["option_platform_per_contract"] * qty)
        return fee <= f["option_fee_max_pct_of_premium"] / 100.0 * qty * premium * CONTRACT_MULTIPLIER

    sel, qty, limit, trace = pick(contracts, right, dte_min, dte_max, budget, fee_ok)
    if sel is None:
        return none("no contract fits delta band [%.2f, %.2f], DTE [%d, %d], budget $%.0f and the fee gate"
                    % (DELTA_LO, DELTA_HI, dte_min, dte_max, budget),
                    candidates_examined=len(trace), trace=trace[:8], warnings=warnings)

    proposal = build_proposal(sel, underlying, size_mult)
    verdict, guard_err = (None, "no guard directory supplied - guard.py must size and fee-check this")
    if run_guard_check:
        if not guard_dir:
            return unavailable(guard_err, check="guard_not_run", contract=sel["symbol"], qty=qty)
        verdict, guard_err = run_guard(proposal, inputs["portfolio"], now_iso, guard_dir, phase,
                                       rules_path=inputs.get("rules_guard_path"))
        if verdict is None:
            return unavailable("guard.py could not be consulted: %s" % guard_err, check="guard_error")
        if not verdict.get("approved"):
            return none("guard.py vetoed the overlay: %s" % "; ".join(verdict.get("reasons") or []),
                        guard_verdict=verdict, contract=sel["symbol"])
        qty = min(verdict.get("qty", qty), qty) if isinstance(verdict.get("qty"), int) else qty
        if qty < 1:
            return none("guard.py sized the overlay to zero", guard_verdict=verdict)

    move = abs(target - entry)
    tp = round(sel["premium"] + abs(sel["delta"]) * move, 2)
    return {
        "sleeve": "B", "action": "BUY_TO_OPEN", "underlying": underlying, "dir": int(direction),
        "signal_ticker": underlying, "family": underlying, "kind": "option",
        "contract": sel["symbol"], "right": sel["right"], "strike": sel["strike"], "dte": sel["dte"],
        "delta": sel["delta"], "premium": sel["premium"], "premium_source": sel["price_source"],
        "qty": int(qty), "limit": limit, "tp_limit": tp,
        "max_loss_usd": round(limit * CONTRACT_MULTIPLIER * qty, 2),
        "expansion": exp_note, "budget_usd": round(budget, 2),
        "exit": "resting take-profit limit; otherwise closes with its parent A position; FLAT with the sleeve by day['flat_by']",
        "ticket": ticket_fields(sel["symbol"], qty, limit),
        "proposal": proposal, "guard_verdict": verdict,
        "reason": "%s delta %.2f, %d DTE, confluence with prior-session expansion; premium from %s"
                  % (sel["right"], sel["delta"], sel["dte"], sel["price_source"]),
        "warnings": warnings,
    }


# ---------------------------------------------------------------- CLI

def _read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def main():
    ap = argparse.ArgumentParser(prog="sleeve_b.py")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("select", help="contract selection + ticket fields for one approved Sleeve A entry")
    s.add_argument("--input", required=True)
    s.add_argument("--rules", help="rules.json (the live one, from desk-risk-guard)")
    s.add_argument("--guard-dir", help="directory holding desk-risk-guard's guard.py")
    s.add_argument("--phase", default="bounded", choices=["approval", "bounded"])
    s.add_argument("--no-guard", action="store_true", help="skip the guard.py call and report the pre-guard pick")
    r = sub.add_parser("reconcile", help="fail-closed fill/position state for existing option exposure")
    r.add_argument("--positions", required=True)
    r.add_argument("--orders", required=True)
    r.add_argument("--rules", required=True)
    c = sub.add_parser("classify", help="classify one or more raw order rows")
    c.add_argument("--input", required=True)
    c.add_argument("--option", action="store_true")
    f = sub.add_parser("fly", help="build the 0DTE legged iron fly (Sleeve B) from a quote envelope")
    f.add_argument("--input", required=True, help="envelope: quotes, book, combo, bars5, spot, iv, "
                                                 "portfolio, now, today")
    f.add_argument("--rules", help="rules.json (the live one, from desk-risk-guard)")
    f.add_argument("--guard-dir", help="directory holding desk-risk-guard's guard.py")
    f.add_argument("--phase", default="bounded", choices=["approval", "bounded"])
    f.add_argument("--no-guard", action="store_true", help="report the structure without asking the guard")
    f.add_argument("--acc-id", default="5830104")
    m = sub.add_parser("mark", help="mark an open fly from live quotes - never reads account option P&L")
    m.add_argument("--proposal", required=True, help="the entry proposal `fly` produced")
    m.add_argument("--input", required=True, help="current quotes/book envelope, or a full envelope")
    m.add_argument("--spot", help="underlying price now; required for the intrinsic and ITM tests")
    m.add_argument("--now", help="ISO timestamp. Omitting it falls back to the epoch stamps on the quotes, "
                                 "then the envelope's `now`, then the proposal's entry stamp; the winner is "
                                 "reported as `now_source` and only the last one skips the time rules")
    m.add_argument("--rules")
    pr = sub.add_parser("proposal", help="rebuild the open fly's entry proposal from broker state, for a "
                                         "scheduled OPT-CHECK that has no ticket in its conversation")
    pr.add_argument("--positions", required=True, help="the file saved from sim_trade_position_list")
    pr.add_argument("--orders", required=True, help="a sim_trade_history_order_list page (or a list of rows)")
    pr.add_argument("--rules", help="rules.json (the live one, from desk-risk-guard)")
    pr.add_argument("--now", help="ISO timestamp; omitting it falls back to the freshest `update_time` "
                                  "on the order rows and says so in warnings")
    ab = sub.add_parser("abort", help="unwind plan for a leg the broker REFUSED mid-entry: close tickets, "
                                      "journal record, and the sleeve_b_disabled flag if it was a short")
    ab.add_argument("--proposal", required=True, help="the entry proposal whose legs were sent")
    ab.add_argument("--outcomes", required=True, help="per-leg report, [{seq, code, state, raw}]; state is "
                                                      "filled|resting|cancelled|rejected|unknown|pending")
    ab.add_argument("--book", help="current two-sided book, so each close ticket gets a live price")
    ab.add_argument("--rules", help="rules.json (the live one, for the fee model)")
    ab.add_argument("--now", help="ISO timestamp, stamped on the journal record")
    ab.add_argument("--acc-id", default="5830104", help="account the refusal was seen on; recorded on the "
                                                        "flag, because the owner attestation never covered "
                                                        "this account")
    a = ap.parse_args()

    if a.cmd == "select":
        try:
            inputs = _read(a.input)
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        out = decide(inputs, guard_dir=a.guard_dir, rules_path=a.rules, phase=a.phase,
                     run_guard_check=not a.no_guard)
    elif a.cmd == "fly":
        # Imported lazily so the debit path keeps working if sleeve_b_fly.py is ever missing, and so
        # the two modules can reference each other without an import cycle at load time.
        import sleeve_b_fly
        try:
            inputs = _read(a.input)
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        out = sleeve_b_fly.main(inputs, rules=load_rules(a.rules) if a.rules else {}, phase=a.phase,
                                run_guard_check=not a.no_guard,
                                guard_dir=a.guard_dir, rules_path=a.rules, acc_id=a.acc_id)
    elif a.cmd == "mark":
        import sleeve_b_fly
        try:
            prop = _read(a.proposal)
            raw = _read(a.input)
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        env = raw if isinstance(raw, dict) else {"quotes": raw}
        out = sleeve_b_fly.mark_structure(
            prop, quotes=env.get("quotes") or env.get("quote_list") or raw,
            book=env.get("book"), spot=num(a.spot) if a.spot is not None else env.get("spot"),
            now=a.now, env_now=env.get("now"),
            rules=load_rules(a.rules) if a.rules else {})
    elif a.cmd == "proposal":
        import sleeve_b_fly
        try:
            pos = _read(a.positions)
            ords = _read(a.orders)
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        out = sleeve_b_fly.reconstruct_proposal(pos, ords,
                                                rules=load_rules(a.rules) if a.rules else {},
                                                now=a.now)
    elif a.cmd == "abort":
        import sleeve_b_fly
        try:
            prop = _read(a.proposal)
            raw = _read(a.outcomes)
            book = _read(a.book) if a.book else None
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        book = book.get("book") if isinstance(book, dict) and "book" in book else book
        out = sleeve_b_fly.entry_abort_plan(
            prop.get("legs") or [], raw.get("legs") if isinstance(raw, dict) else raw,
            qty=int(num(prop.get("qty")) or 1), book=book,
            rules=load_rules(a.rules) if a.rules else {},
            structure_key_value=prop.get("structure_key"), now=a.now, acc_id=a.acc_id)
    elif a.cmd == "reconcile":
        try:
            rules = load_rules(a.rules)
            pos = _read(a.positions)
            orders = _read(a.orders)
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        out = reconcile(pos.get("positions") if isinstance(pos, dict) else pos,
                        orders.get("orders") if isinstance(orders, dict) else orders, rules=rules)
    else:
        try:
            raw = _read(a.input)
        except (OSError, ValueError) as exc:
            print(json.dumps(unavailable("input unreadable: %s" % exc)))
            return
        rows = raw.get("orders") if isinstance(raw, dict) else raw
        out = [classify_fill(r, require_option=a.option) for r in (rows or [])]
    print(json.dumps(out, ensure_ascii=False, default=str))


if __name__ == "__main__":
    main()
