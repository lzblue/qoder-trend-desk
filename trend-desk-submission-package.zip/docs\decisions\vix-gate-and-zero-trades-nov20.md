# Tier B decision memo — the VIX/regime gate and the two zero-trade days (Nov 18–19)

**Tier B — owner sign-off required before any part of this goes live.**
Nothing in this document was applied. No template write, no skill publish, no re-pin, no
`rules.json` / `guard.py` / `calendar_rules.py` / `trend_signal.py` edit, no schedule change, no
`AUTONOMY_PHASE` change, no order, cancel or probe on account 5830104. Every cloud call was a `GET`;
every moomoo call was zero — this session made no MCP call at all. The one live change this memo
proposes exists only as a **payload builder**,
[`.scratch/vixgate-1120/apply/apply-scan-vintage-draft.mjs`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/vixgate-1120/apply/apply-scan-vintage-draft.mjs):
it can construct the two new prompts and refuse on any anchor ambiguity, but it contains no `PUT`, and
its `--selftest` mode (the only mode run here) makes no network call. §8 states what an owner would have
to add before applying it.


Task: `20261119T235019Z-a2c7f8` (delegated from conversation
`c1bb70a3-12a2-4632-ad38-977abb0c72f7`), addendum `20261119T235514Z-8d1a56` (folded in at §7).
Written 2026-11-20. Harness:
[`.scratch/vixgate-1120/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/vixgate-1120)
(its README states what the harness does and does not prove).

**Filename.** The spawn prompt named `docs/decisions/vix-gate-and-zero-trades-nov20.md`; the payload
named `vix-gate-review.md`. Same document, one name — this is the instructed path, and the ack cites
it. Sibling memos from the same wake did the same
([`first-scan-volatility-gate-nov20.md`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/first-scan-volatility-gate-nov20.md)).

---

## 0. How to read the claims

Every substantive statement carries one tag:

| tag | means |
|---|---|
| **[observed]** | a value or behavior this session read from a live source: the live skill bytes (sha256-matched), a `GET` of the Forward API, or a byte-exact local dump of a desk message. The command and file are named. |
| **[documented]** | written down by the desk itself in a recovered session dump or journal record, or in a repo file. The desk may be wrong; the claim is only that it said so. |
| **[undiscoverable]** | not determinable from what exists. Named, not glossed. |

Rule applied throughout: one sample is not a pattern, and a gate that is never reached is not the
thing blocking trades. Order of evaluation was established from the live source before any gate was
blamed (§2).

---

## 1. Bottom line

**The owner's theory is refuted on both days, and refuted with numbers rather than argument.**

[observed] Across **30 recovered scan/ticker rows** covering all **8 SCAN slots** (Nov 18 10:05,
11:00, 12:30, 14:00; Nov 19 10:05 at three quote vintages — 10:17, 10:20, 10:26 — plus 11:00, 12:30,
14:00), the number of rows in which live `trend_signal.signal()` ever *reached* the `allow_long`
branch at `trend_signal.py:175` is **0**. Forcing `allow_long` true, or physically deleting both
regime-gate branches from a derived copy of the live source, changes the verdict on **0 of 30 rows**.
With longs allowed the engine yields exactly **2 signals** — the same two SHORT tickets (SQQQ, SPXS)
the desk already produced at 10:17 on Nov 19.

So the gate the owner suspected **could not have withheld a single trade**, because no long idea ever
existed for it to refuse. On Nov 18 it was doubly moot: the researcher's own runner passed
`allow_long: True` placeholders, verbatim:

```
REGIME = {"regime": "UNAVAILABLE", "size_mult": 0.5, "allow_long": True,
          "allow_bearish_etf": True, "hedge_mult": 1.0}
```

[documented] `out/nov18-1005-runner.txt`, byte-exact dump of the file the researcher wrote into its
sandbox at 2026-11-18T15:12:36Z — an input this session read rather than recomputed.

What did block, in order (§4): the opening-range **width band** `0.15%–1.5%` (`:165`, all 10 SMH rows,
1.84%–3.43%), **breakout geometry** (`:169`/`:171`: no print ever cleared the OR extreme by the 0.1×
buffer, or had already run past the 1.0× extension cap), the **reward/risk test** (`:192`, 3 rows), and
**one scheduling case** (Nov 18 14:00 sat inside the FOMC-minutes no-entry window — proved against
live `guard.py`, §5). The regime was *computed* and correct on Nov 19 (`bear_high_vol`, and the desk
recorded that the >3-point VIX re-run trigger did not fire); it scaled size and was never the veto.

**The zero trades are two different zeros, and only one of them is a market read** (§6):

1. **28 of 30 rows: no candidate was ever made.** The engine refused the tape. `guard.py` was not
   involved, and the desk's own records say so — `tickets_run_through_check: 0`, and the journal's
   cumulative `vetoes: 0`, `entries: 0`, `exits: 0`.
2. **2 of 30 rows: a real candidate was made and then expired.** The 10:17 SQQQ/SPXS SHORTs were
   *superseded by quote vintage*, not rejected on risk. [documented] coordinator's 10:35:35 ET ruling:
   "The 10:15–10:17 SQQQ/SPXS shorts were **superseded by vintage expiry**, not rejected — no `check`,
   no ticket, no order". Against live `guard.py` with the day's reconstructed portfolio, both would have
   been **approved** (SQQQ qty 85, SPXS qty 203) — so the desk's only real trade idea of both days died
   in the ~22-minute SCAN round trip, not at a risk gate. That is the one thing worth changing (§8).

**One-line answers.**
- **a2c7f8:** the VIX/regime gate is not the cause — 0/30 rows reached it, 0 verdicts change when it is
  removed, and the two genuine signals of the two days were approved by live `guard.py` offline and died
  on quote staleness inside the SCAN round trip; the causal gate was width, breakout geometry and R/R.
- **8d1a56 (`risk.dte_min`/`dte_max`):** **keep them — they are already wired, and the wiring is in the
  adapter, not in `guard.py`.** Do not duplicate the band into `guard.py`; see §7 for the one line.

---

## 2. The order of evaluation in the live engine (established before blaming anything)

Live `trend_signal.py`, sha256 `60d5573d…` (§10), lines in order:

| step | line | condition | can it veto a SHORT? |
|---|---|---|---|
| 1 | `:153-155` | ticker in `PAIRS` (QQQ/SMH/SPY) | yes (never fired: all rows are signal tickers) |
| 2 | `:156-161` | 10:00–14:30 ET | no (all rows inside) |
| 3 | `:165` | opening-range width 0.15%–1.5% of price | **yes — killed 10/10 SMH rows** |
| 4 | `:169-174` | break the OR by 0.1×, be on the right side of VWAP, stay within 1.0× of extension | **yes — killed 15 rows** |
| 5 | `:175` | `allow_long` false ⇒ no long entries | no — long only. **Reached by 0/30 rows.** |
| 6 | `:177` | `allow_bearish_etf` false ⇒ no bearish entries | dead code: `regime()` returns it `True` in every path, including fail-closed (`:44`, `:137-148`) |
| 7 | `:189-191` | inverse quote present | yes, when a short reaches here without one |
| 8 | `:192` | stop distance > 0 and ≤ 1 range | **yes — killed 3 rows** |

[observed] Steps 3, 4 and 8 sit *ahead* of step 5 on the long path and ahead of 6 on the short path, so
a width or geometry refusal cannot be a regime refusal in disguise. The only regime-shaped refusal the
engine can emit on the short side is `:177`, and it is unreachable.

`guard.py` (sha `8fe26118…`) has **no direction veto at all**: `grep` for `allow_long` /
`direction` / `regime` over the live file returns nothing, and regime enters only as
`proposal.get("regime_mult", 1.0)` at `:167`, i.e. as a **size** multiplier:

```
mult = day.size_mult × (0.5 if state == "half_size") × proposal["regime_mult"]     # guard.py:167
qty  = floor(nav × trade_risk_pct/100 × mult / dist)                                # guard.py:209
```

Three `grep` hits for `dte` in guard.py are `:240` (the hedge band, hardcoded 7–45) and `:258` (a 0DTE
warning). The desk's own auditor reached the same conclusion in live session, which this memo
independently re-verified against the bytes: [documented] `guard.py`/`rules.json` have no `allow_long`
input anywhere … A LONG ticket would be **approved and sized** (2026-11-19 12:30).

---

## 3. Inputs, and proof they are the real ones

[observed] `harness/scans.json` holds 30 rows, each with its own `provenance` string naming the dump
file and event index, a `price_quality` tag (`quoted` / `computed_from_recorded_bars` / `synthetic`),
the regime dict the desk passed, and the verdict the desk recorded. Sources:
`out/scan-messages.txt` (97 KB of `agent.thread_message_sent` / `agent.message` payloads) and
`out/scan-journal.txt` (the desk's own `journal.py log` records) — byte-exact local dumps of the desk's
session-event files. [documented] that the dumps are byte-exact comes from the extractor code; this
session read no cloud session API.

[observed] **Reproduction:** live `signal()` returns the same **action for 30/30** rows and the same
**reason string for 28/30**. The 2 residuals are the desk's own rounding of one printed percentage
(`0.79%` vs `0.78%`, `1.84%` vs `1.83%`) — same gate, same verdict. [observed] Reproduction used the
Nov 18 placeholder for Nov 18 rows and the recorded `bear_high_vol` for Nov 19.

[observed] **The Nov 19 regime was really computed, not degraded.** Re-running live `regime()` on three
sets of recorded index inputs gives `bear_high_vol`, `size_mult 0.5`, `allow_long false`,
`source: "computed"`, `degraded: false`, bear flags `NDX below 200-day`, `SPX below 200-day`,
`VXN-VIX spread 8.6–8.7`, `SOX -8.6 to -9.6% in 5 days` (inputs verbatim from
`out/scan-messages.txt:512-519` and `:600-606`). So this is not a fail-closed artifact either: the
regime was correct, and it still never bound.

---

## 4. Per-scan causal chain (the 8 slots, row by row)

Full table with both counterfactual columns:
[`out/memo-table.md`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/vixgate-1120/out/memo-table.md).

| slot | what the live engine actually returned | named condition | regime involved? |
|---|---|---|---|
| **Nov 18 10:05** | QQQ 659.80 and SPY 731.995 sit inside the buffers (`>663.535` / `<652.915`; `>735.708` / `<727.932`); SMH 3.40% wide | `:169`/`:171`; `:165` | **no** — [documented] the desk's own runner: "trend-signal regime gate NOT reached for any ticker this pass" |
| **Nov 18 11:00** | same three shapes (OR is frozen all day; prints drift) | `:169`/`:171`; `:165` | no |
| **Nov 18 12:30** | QQQ 661.92 misses the long buffer by 0.73; SPY 733.402 misses the short buffer by 4.47; SMH 3.39% | `:169`/`:171`; `:165` | no |
| **Nov 18 14:00** | nothing broke; **and** the slot sat in the no-entry window | `:169`/`:171` then `guard.py:158-160` | no |
| **Nov 19 10:05 @10:17** | **QQQ → SQQQ and SPY → SPXS SHORTs fired.** SMH 1.84% wide | `:197` (ticket) | no — shorts; and `:177` is unreachable |
| **Nov 19 10:05 @10:20** | re-quote after the fall: both stop distances now exceed one range (6.905 vs 5.245; 5.053 vs 4.480) | `:192` | no |
| **Nov 19 10:05 @10:26** | QQQ past the 1.0× cap (5.975 vs 5.245) *and* would fail R/R; SPY fails R/R (5.742 vs 4.480); SMH 1.84% | `:171`, `:192`, `:165` | no |
| **Nov 19 11:00** | QQQ 8.655 and SPY 6.300 pts past the OR low vs a 1.0× cap of 5.245 / 4.480 | `:171` extension cap | no |
| **Nov 19 12:30** | 15.665 / 11.640 pts past the low vs the same caps | `:171` | no |
| **Nov 19 14:00** | 21.175 / 16.170 pts past the low; SMH 1.92% | `:171`, `:165` | no |

[documented] The desk's own journal names exactly these gates, never `allow_long`: 11:00
`per_ticker_failing_gate: {QQQ: breakout_extension "price extension 1.65x vs 1.0x cap", SMH:
range_filter "OR width 1.8567% > 1.5% cap"}`; 14:00 `QQQ extension 21.175 vs cap 5.245, SPY extension
16.17 vs cap 4.4799, SMH width 1.9153% outside 0.15-1.5`. My independent recomputation reproduces those
numbers to the third decimal, which is the strongest available check that the recovered inputs are the
ones the desk used.

[observed] **Admissible-band check** (`harness/run.py bands()`, built from live predicates only): a
ticket is possible only inside `lo − rng ≤ price < lo − 0.1×rng` (short) or `hi + 0.1×rng < price ≤
min(hi + rng, stop + rng)` (long). **0/30 rows** sit in a long band; **6/30** in a short band — 4 of
those are SMH rows already killed at `:165`, so the 2 genuine short prints are the whole long list.
The long bands are **0.183%–1.029% of price** wide (Nov 19 QQQ: `[675.824, 677.398]`, 1.574 pts) and the
tape was **never** there on either day.

---

## 5. Was the veto *risk*, not the signal? — live `guard.py` counterfactuals

[observed] `harness/guard_counterfactual.py` runs the live `guard.py check` as a subprocess against a
`portfolio.json` reconstructed from the day's auditor reads (Nov 19: nav/cash 99998.11, peak 100000,
`orders_today` 3, flat; Nov 18: 100000 / `orders_today` 5, flat). These are offline hypotheticals; they
create no verdict the desk ever had, and the desk explicitly declined to run a post-hoc `check` because
doing so "would fabricate a verdict".

- **Q1 — the two real signals.** SQQQ 44.62/43.60/46.15 → `approved: true, qty 85, risk_usd 88.71,
  size_mult 0.25, state normal, needs_human_approval false`. SPXS 27.64/27.21/28.28 → `approved: true,
  qty 203`. **Risk did not refuse them.** Note `size_mult 0.25` = the calendar table's day factor
  (`calendar_rules.py:27-31`, Nov 19 `size_mult 0.5`) × the regime's 0.5 — the combined VIX-and-event
  haircut still produced an 85-share ticket, i.e. sizing was never the binding constraint.
- **Q2 — the only indirect VIX veto guard has** (`:224` "size rounds to zero"). Sweeping
  `regime_mult`: qty 171/128/85/42/8/1/1 at 1.0/0.75/0.5/0.25/0.05/0.01/0.006, and refusal only at
  **≤0.005**. Inverting `guard.py:209` for a one-share minimum, `mult ≥ dist/(nav × 0.0035)`, gives
  **0.00291** for the SQQQ geometry and **0.00123** for SPXS. The lowest multiplier live `regime()` can
  emit is `crisis` **0.25** — ~86× above the threshold that would zero a ticket. [observed] Even
  *below* the threshold the refusal string would read "size rounds to zero (binding: risk per trade)",
  not a regime veto.
- **Q3 — where a long veto would live.** A **SYNTHETIC** price (676.09) placed just above the Nov 19
  QQQ long trigger: with `allow_long: false` live `signal()` returns `regime bear_high_vol: no long
  entries`; with longs open it returns `LONG QQQ 676.09 / 672.15 / 682.00`, and live `guard.py check`
  **approves it, qty 22**. This proves the veto is entirely in `trend_signal.py:175`; guard would have
  traded the long if the signal had emitted one. The price is synthetic — no Nov 19 read was above the
  long trigger (§4).
- **Q4 — Nov 18 14:00, scheduling not signal.** Same synthetic-breakout method on that day's real OR and
  VWAP: at `2026-11-18T14:04` live guard returns `event blackout 13:45-14:30 ET`
  (`calendar_rules.py:22`); at `14:35` it approves, qty 27. [documented] the auditor reached the same
  ruling on the day: "DENIED by scheduling, not by the gate".
- **Q5 — the extension cap's own boundary.** On the Nov 19 QQQ range: 680.545 (exactly one range past
  the high) is refused by `:192`; 680.595 and 685.79 by `:169`. The cap and the R/R rule are adjacent,
  which matters for §8.

---

## 6. "Signal never fired" vs "guard vetoed a real signal" — the separation

| | count | evidence |
|---|---|---|
| Scan rows where live `signal()` returned NONE (no candidate existed) | **28/30** | §4 table, `out/memo-table.md`, 30/30 action reproduction |
| Candidates routed to `guard.py check` by the desk | **0** | [documented] `tickets_run_through_check: 0` (11:00); "ZERO candidates reached the gate ⇒ no `check`, no ticket, no order" (10:05); "No guard.py check was invoked because there was nothing to check; nothing was sized" |
| Guard vetoes of a real candidate, cumulative | **0** | [documented] journal `stats`: `signals 12, entries 0, exits 0, vetoes 0, errors 3` |
| Real signals produced and then lost | **2** (SQQQ, SPXS @10:17 Nov 19) | [observed] both approved offline (§5 Q1); [documented] voided for vintage, not risk |
| Longs the gate refused | **0** | 0/30 rows reach `:175` |

This is the payload's distinction, and it is one-sided: there is no "guard said no" story in these two
days at all. The desk never asked.

---

## 7. The `dte_min` / `dte_max` decision required by addendum 8d1a56

**One line: keep both keys and do not wire anything new — they are already live and already consumed;
the gap is that the consumer is mounted on no template, which is a separate Tier B choice (§8, rejected
item D).**

[observed] The keys exist in the live package: `rules.json:43-44` = `"dte_min": 1`, `"dte_max": 5`
(sha `49dbeaf4…`). [observed] They are read in exactly one place — the published-but-unbound
`option-adapter`: `sleeve_b.py:296-298` `dte_bounds()` returns
`"rules.json risk.dte_min/dte_max absent or inverted - refusing to assume a DTE band"` and the caller
emits `action: "STATE_UNAVAILABLE"` (`:77`); `:261` filters candidates `dte_min ≤ c["dte"] ≤ dte_max`;
`:483` re-checks held positions in `reconcile()`. [observed] `guard.py` never reads them (`grep dte`:
`:240` hedge band 7–45 hardcoded, `:258` 0DTE warning).

[observed] **The desk-risk-guard pin moved while this memo was being written** (v12 `1795100050849622` →
`1795138181446404`, published 01:29:41.464633Z, pinned on all three templates at 01:29:44Z — §9). I
downloaded the new package and diffed it file by file against the bytes the harness ran:
`scripts/guard.py` `8fe26118…`, `references/rules.json` `49dbeaf4…`, `scripts/levels.py` `746a0151…`,
`scripts/book.py` `6b8071da…`, `SKILL.md` `24c424d2…` are **byte-identical**, so `dte_min`/`dte_max` and
every guard line number in this memo are still exact against the currently pinned version. The single
delta is `scripts/calendar_rules.py` (`9e57f3c8…` 3,414 B → `557c3cf2…` 3,568 B), and the diff is one
hunk inside the **2026-11-20** entry: a new `"no_entry": [("11:45", "12:30")]` (Cook speaks 12:15 ET).
The 2026-11-18 and 2026-11-19 entries this memo quotes are untouched and keep their line numbers — the
FOMC `no_entry` is line 22 in both versions, the 19-Nov `size_mult 0.5` row is line 27 in both.

So deleting or commenting the keys out would not simplify anything — it would turn the adapter's every
run into `STATE_UNAVAILABLE`, which is the fail-closed behavior we want it to keep. The `docs/`
contradiction is stale, not live: [documented]
[`docs/sleeve-b-findings-nov19.md:17`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/sleeve-b-findings-nov19.md#L17)
says the keys "do not exist in `rules.json`" — true when written; they were added with the v12 rules
change and are in the bytes read today. [observed] The adapter itself was re-published twice more during
this task, still mounted on **zero** templates: `1795132449689060` (2026-11-19T23:54:09.703Z, 13,579 B) →
`1795136690073060` (01:04:50.088Z, 15,451 B) → `1795137189020914` (01:13:09.037Z, 15,698 B, current
`latest_version`). Across all three, `scripts/sleeve_b.py` is **byte-identical** (31,397 B,
`c3152251329f…`) — only `SKILL.md` grew (7,805 → 12,624 → 13,291 B), and I read the newest one:
[documented] it states the band as a precondition at line 148 ("`rules.json` carries `risk.dte_min` and
`risk.dte_max` (live v12: 1 and 5). Missing or inverted → refuse") and lines 109–110/126–127 record the
rehearsal in which, once the ET date reached 2026-11-20, "a contract expiring today has dte 0 and is
unbuyable, so … the Nov 20 expiry — the one that was in band on Nov 19 — " fails `dte_min` before delta is
ever consulted. That is the same conclusion as §8's rejected item E (the keys already have one consumer,
don't duplicate them), reached in that file by whoever published it, not by me. Nothing in this section
needs re-checking against the newest adapter bytes, because the file that would matter is the unchanged
one.

### 0DTE exposure (the payload's standing question), in one paragraph

[observed] Nothing on the live scheduled path can open an option today, let alone a 0DTE. `guard.py`
sizes options in two branches and gates both before any size: a `sleeve: "hedge"` proposal is refused
outright unless `7 ≤ dte ≤ 45` (`:240`, hardcoded, and it is the only DTE *refusal* in guard), and a
non-hedge `option` proposal has **no** DTE test — it is only warned about at `:258`
(`if sleeve != "hedge" and o.get("dte", 1) == 0`, "0DTE: ETF options auto-exercise after 16:00 ET"),
which is an advisory string in an otherwise-approved verdict, not a gate. The band that would actually
refuse a 0DTE (`risk.dte_min = 1`) lives in the adapter, which [observed] is bound to **0** templates in
both live reads — so the adapter cannot be reached by any schedule, and the only live prompts that can
produce tickets (researcher sleeve A, sleeve C, and the hedge) never emit a non-hedge `kind: "option"`
proposal. **Residual risk, stated plainly:** if someone binds the adapter *and* adds a prompt line
routing to it, the guard-side hole at `:258` becomes reachable, because guard's approval would then
carry a 0DTE warning rather than a refusal. The cheap prophylactic, if and only if that binding is
approved, is to make guard's non-hedge option branch decline on `dte < risk.dte_min` instead of warning
— that is a `guard.py` change, Tier B, and I have not drafted it because the routing decision comes
first.

---

## 8. What I would change (Tier B, one change), and what I would not

### The finding that warrants a change

[observed] The desk's only two real signals were destroyed by latency inside one SCAN run:

```
10:05:00 ET  SCAN-1005 fires (coordinator session)
10:10:54.330 coordinator -> researcher trigger message   [dump: 2026-11-19T15:10:54.330672Z]
10:17        researcher's quote vintage (SQQQ/SPXS signals computed)
10:26:30     researcher re-prints quotes ("quotes stamped 10:26:30 ET")
10:32:41.728 researcher -> coordinator message sent       [dump: 2026-11-19T15:32:41.728356Z]
10:35:35.243 coordinator ruling recorded                  [dump: 2026-11-19T15:35:35.243468Z]
```

[observed] Trigger→researcher-reply = **21 min 47 s**; the freshest number in that reply was already
**6 min 11 s** old when it was emitted and **9 min 05 s** old at the ruling. [observed] The rule it died
on is five minutes: live researcher `system`, SCAN step 2 — "If any number is missing, stale (older
than 5 minutes) or inconsistent, return NONE with the reason". [observed] The 5 minutes is prompt text
with **no counterpart in guard.py** (`grep` finds no freshness rule), and it is structurally
unsatisfiable: the coordinator's own SCAN line puts the auditor's monitoring check *before* the
researcher is asked for signals, and the researcher session then takes ~20 minutes. A signal emitted
inside a Forward session is therefore older than the rule allows by the time anyone can act on it. This
is the whole gap between "the engine fired" and "the desk traded", and it is not a market-read failure.

[documented] The desk saw this and partly fixed it itself, in-session: the 11:00 record adds "quote
vintage at the top of output and signals computed within 3 min of the slot so a decision fits inside the
5-min freshness window". That mitigation addresses the researcher's internal ordering, not the
round trip, and the 11:00 slot produced no signal anyway (extension cap), so it was never tested.

### Proposal A (Tier B) — make the freshness clock start at emit, and re-quote at emit

One sentence appended to researcher SCAN step 2 plus a matching routing clause appended to the
coordinator's SCAN line, both built by anchor insertion — no other character of either prompt changes.
The draft is
[`apply/apply-scan-vintage-draft.mjs`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/vixgate-1120/apply/apply-scan-vintage-draft.mjs).
**Nothing in `apply/` was ever run against the cloud.** The only mode executed is `--selftest`, which
makes no network call; the tripwired shell wrapper this task's brief pictures (`VIXGATE_I_KNOW=Y`) was
not written, so the `.mjs` itself is the reviewable artifact and step 4 below is what an owner would
have to add before any apply. [documented]

[observed] Anchor and preflight check, re-run against the live bytes at four separate times
(`00:17:48.785Z`, `01:12:56.629Z`, `01:29:08.956Z`, `01:39:15.643Z` — the `system` field is byte-identical
in all four, sha `f4057916…` researcher / `16572c95…` coordinator): the
researcher anchor sits on line 13 of 18 and occurs exactly once; the coordinator anchor on line 11 of
22, exactly once. `--selftest` on the 01:29:08Z bytes builds both new texts with no anchor collision
and a length delta equal to the inserted sentence exactly (researcher +362 chars → 4,138;
coordinator +248 → 3,522).

The two insertions, verbatim as the draft holds them:

| target | appended text |
|---|---|
| researcher, after "…(action, instrument, entry, stop, target, reason)." | ` If a signal fires, re-quote the instrument and the underlying once, immediately, and re-run trend-signal `signal` on those fresh numbers before you send: the verdict on the fresh numbers is the one you send, and a fresh number that changes the verdict changes the verdict -- never stamp a stale one. Stamp every signal with the timestamp of THAT final re-quote.` |
| coordinator, after the SCAN-10:05/11:00/12:30/14:00 line | ` A ticket is routed only if its own re-quote stamp is less than 5 minutes old when the auditor receives it; route it in that same message, and if it has aged out say so in the summary instead of leaving the reader to guess whether a signal existed.` |

- **Expected effect.** It converts the failure mode we measured (a valid signal voided because the run
  was slow) into either a fresh ticket or an explicit `NONE` with the reason *re_quote_failed*. It does
  **not** manufacture signals: on these two days it could only have changed the outcome for the 10:17
  pair, and only if the re-quote still confirmed the break. It cannot shorten the auditor/executor legs,
  so on today's plumbing the realistic saving is a couple of minutes, not twenty.
- **What it costs if wrong.** A re-quote at emit can *confirm* a chase: the 10:26 re-quote of the same
  idea already failed `:192`/`:171`, so a re-quote rule must re-run `signal()` on the new numbers, not
  just stamp a timestamp. The draft does say that; a reviewer should check that sentence specifically.
- **Verification path, in order, none of it live until step 4.** (1) `GET` the template, byte-compare
  the `system` field against `apply/before-researcher-system.txt`; (2) dry-run the draft and assert both
  anchors hit exactly once; (3) re-read the two changed prompts and confirm the rest of the field is
  unchanged apart from the intended delta (length delta should equal the added sentences exactly);
  (4) only then apply, and exercise it on **one** SCAN slot, priced at the measured SCAN cost of
  **14.97–20.54 credits** (and note this session's boundary forbade even that). Acceptance: the journal
  record for that scan carries `signal_vintage` ≤ 5 min at the coordinator, or an explicit
  `re_quote_failed` NONE.
- **Rollback.** `PUT` the verbatim bytes of `apply/before-researcher-system.txt` (3,776 chars / 3,784
  UTF-8 bytes, sha256
  `f4057916db3279448fd5fea7ceb77a7b52e7fa95a167dc8912223116f8e412fd`) and
  `apply/before-coordinator-system.txt` (3,274 bytes, sha256
  `16572c95062b259fcf43671cd81386488ab9ecca2b5c4e4bce825a8c41fedc84`) back into their `system` fields.
  Those two files are byte-equal to the live field in all three reads above, including the fresh
  `apply/live-now-{researcher,coordinator}-system.bin` captured at 01:29:08Z, so rollback is one write
  and one re-read per template, not a diff. [observed]
  *Correction during drafting:* an earlier version of this memo cited `670a2c10…`/3,804 bytes for the
  researcher text. That figure came from an extraction in this session that three independent captures
  of the same field contradict, and it is not reproducible from anything in `apply/`; the digests above
  are the ones that were re-derived from the live bytes.

### Considered and rejected

| | why not |
|---|---|
| **A. Loosen or invert `allow_long` (the owner's original fix)** | Nothing to fix: 0/30 rows reach it, 0 verdicts change when it is deleted, and `guard.py` has no direction veto to remove. It is a real policy lever for a *long* day — on these two days it was inert. |
| **B. Widen the 5-min rule to 10–15 min instead of re-quoting** | Cheaper, but it accepts entries on a 15-minute-old print while the live stop doctrine (`guard.py:261-263`, `mechanism: "monitored"`) already only exits at the *next* scheduled check. Stale in **and** stale out compounds. |
| **C. Loosen the R/R cap (`:192`) or the 1.0× extension cap (`:169`/`:171`)** | The extension cap binds on 7 rows, and deleting only those two clauses (`gen/trend_signal_noext.py`) yields **2** tickets — the 11:00 QQQ→SQQQ 44.77/43.73/46.33 and 11:00 SPY→SPXS 27.62/27.12/28.37, whose stop distances sit 0.108/0.098 pts inside one range. The other 5 fail `:192` as well, by 1.08–6.06 pts. So the cap is not hiding five trades; it is hiding two **chase** entries 6.57 and 4.70 pts below prints the desk had already seen. The desk's own 14:00 journal named `breakout_extension` as the reason it stood down — that gate is doing the job the strategy asked for ("fewer, cleaner trades"). |
| **D. Bind `option-adapter` to `risk_auditor`** | It would open a sleeve whose guard-side DTE hole is described in §7, and no prompt yet tells anyone to use it. Out of scope for tonight; a decision in its own right. |
| **E. Duplicate `dte_min`/`dte_max` into `guard.py`** | Two sources of truth for one band, and the current consumer already fails closed without it. |
| **F. Move the SCAN slots off 10:05/11:00/12:30/14:00** | [undiscoverable] from this data whether another time would have seen a clean breakout; the 8 slots we have produced no long-band print at all, so there is no evidence base for a schedule change. |
| **G. Change `AUTONOMY_PHASE`, the blackout window, or the account mapping** | Outside this task's boundary, and nothing measured here implicates them. |

---

## 9. Provenance: what was read, and proof nothing was changed

[observed] Four read-only verification passes (reads 1–3 by
[`04-live-verify.mjs`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/vixgate-1120/04-live-verify.mjs)
(`GET /skills`, `/skills/{id}/versions`, `/templates/{id}`, `/schedules`; the PAT is read from `./.env`
into a variable and never printed or written to output — the JSON reports contain no credential field):

| | read 1 | read 2 | read 3 | read 4 |
|---|---|---|---|---|
| time (UTC) | `00:17:48.785` | `01:12:56.629` | `01:29:08.956` | `01:39:15.643` |
| `system` (prompt) text, four production templates | baseline | **identical**, byte for byte | **identical** | **identical** (researcher `f4057916…`/3,776 chars, coordinator `16572c95…`/3,274, executor `84c192f7…`/4,918, risk_auditor `25f67310…`/6,606) |
| names, `mcp_servers` (`moomoomcp` on three, none on coordinator), `environment_variables {}`, `files {}`, tool entries, descriptions | baseline | identical | identical | identical |
| 7 schedules (BRIEF, SCAN-1005/1100/1230/1400, FLAT, REPORT) | all `active`, all on `tmpl_19f984c8f0fd516965b63998` | identical, `next_run` included | identical | identical |
| trend-signal `1795047415929677` / vwap-chop `1795095917868411` pins | baseline | identical | identical | identical |
| decision-journal pin | `1795094895883552` | `1795094895883552` | **`1795137748003137`** | unchanged |
| desk-risk-guard pin | `1795100050849622` | `1795100050849622` | `1795100050849622` | **`1795138181446404`** |
| `created_at`/`updated_at` on researcher/executor/risk_auditor | `2026-11-19T22:55–56+08:00` | unchanged | **`2026-11-20T09:22:41–42+08:00`** (= 01:22:41–42Z) | **`2026-11-20T09:29:44+08:00`** (= 01:29:44Z) |
| coordinator | `2026-11-19T22:05:04+08:00` | unchanged | unchanged | unchanged |
| every binding on all four templates carries an explicit version (none resolve to latest) | yes | yes | yes | yes — `unpinned: []` in `out/read4/live-read-report.json` |
| option-adapter `latest_version`, bound templates | `1795132449689060`, **0** | `1795136690073060`, **0** | `1795137189020914`, **0** | `1795137189020914`, **0** |

[observed] **This is not a frozen cloud, and this section was wrong when it said it was.** Two writes by
*other* sessions landed inside the 82 minutes these reads span: decision-journal
`1795094895883552` → `1795137748003137` on researcher, executor, risk_auditor (and
`executor-gating-rehearsal`) at 01:22:41–42Z, and desk-risk-guard v12 → `1795138181446404` — published
01:29:41.464633Z, pinned 01:29:44Z, i.e. **33 seconds after read 3 and 31 seconds before read 4** — on
the same three templates. [documented] The `created_at` == `updated_at` reset is this platform's behaviour
on edit (already recorded in this repo), so the reset is evidence that a write happened, not of a new
template. None of it changes any conclusion here, and I verified that rather than assuming it:

- decision-journal is the journal of record; it is not a predicate in `signal()` or in `guard.py`, so no
  row of §3–§6 depends on its version.
- the guard version bump changes **one file**: `calendar_rules.py`, and only inside the 2026-11-20 entry
  (a `no_entry 11:45–12:30` for the 12:15 ET Cook speech). `guard.py`, `rules.json`, `book.py`,
  `levels.py`, `SKILL.md` are byte-identical between v12 and it, and the two `calendar_rules.py` lines
  this memo quotes (the 18-Nov FOMC `no_entry` at `:22`, the 19-Nov `size_mult 0.5` row at `:27`) are
  those same line numbers in the new file. Full per-file digests: `out/guardnew/diff-report.json`.
- the adapter stays unbound in all four reads, so §7's answer does not depend on which adapter version is
  current; and `sleeve_b.py` is byte-identical across all three versions in that window (§7).

[observed] **Code identity.** `livecode/` is the live package, and each file's sha256 equals the
independent snapshot in `.scratch/livestate-1120` — recorded in
`out/live-code-sha256.txt`: `trend_signal.py 60d5573de1eb139d…` (10,405 B), `guard.py 8fe26118b2a8a3fd…`
(16,032 B), `calendar_rules.py 9e57f3c89d2f1fc3…` (3,414 B), `rules.json 49dbeaf4d2d21278…` (2,010 B);
plus v11/v12 additions `book.py 6b8071da…`, `levels.py 746a0151…`. All four compared files match.
[observed] Re-checked at 01:39:15Z against the **currently pinned** guard package
(`1795138181446404`): `guard.py`, `rules.json`, `book.py`, `levels.py`, `SKILL.md` byte-identical to those
digests, and `calendar_rules.py` differs only in the one 2026-11-20 hunk shown in §7. Every line number
this memo cites from `trend_signal.py`, `guard.py` and `rules.json` is therefore still a line in what is
mounted now; the two `calendar_rules.py` lines it cites (`:22`, `:27-31`) sit above that hunk and are
unchanged in the new file. Nothing cited sits after the insertion, so no line number in this memo moved —
for completeness: in the new file `day_rules()` is `:60` and `base = DAYS.get` is `:65`, where v12 had
`:58` and `:63`.

[observed] No moomoo MCP call, no order, no cancel, no probe, no schedule change, no template write, no
skill publish, no re-pin, no `rules.json`/`guard.py`/`calendar_rules.py`/`trend_signal.py` edit — the
two derived variant sources under `harness/gen/` are local files built by string-replacement from the
downloaded live code, with anchors asserted, and are not mounted anywhere.
[observed] The dashboard was never started, so nothing on :4173 and nothing on :4189.

**Known conflicts, not smoothed over.**
- [observed] `AGENTS.md` is a stale 2026-11-17 snapshot and is wrong about today in ways that matter:
  the researcher is now `tmpl_d7df3829ed5d73548bb5e9ed` with a clean name and four bound skills (it
  shows `vwap-chop`), `risk_auditor`'s live `system` is 6,606 chars, the coordinator's is 3,274, and a
  fifth template exists — `executor-gating-rehearsal`, `tmpl_f3214189de633d9d34ce77b6`, bound to
  decision-journal only (read `2026-11-20T01:29:08.956Z`, HTTP 200; my own read-4 pass 404'd on it because
  I typo'd the id suffix, which is exactly why this line carries the id from the saved report). Nothing in
  this memo relies on `AGENTS.md`.
- [undiscoverable] what the price did *between* scan prints — no per-scan bar series was recovered, so
  §4's bands are tested against the scan prints only. "The long band was never entered" means "never at
  a sampled instant".
- [undiscoverable] the regime dicts for the Nov 18 12:30 and 14:00 passes (those runs printed only
  "regime UNVERIFIED"), which is why those rows are run under *every* `allow_long` value rather than an
  assumed one.
- [documented] that the local dumps are byte-exact comes from the extractor code; this session did not
  re-read them from the cloud session API.
- [observed] This is **two days, 8 slots, 30 rows**. It is enough to prove a 0/30 unreachability; it is
  not enough to characterise the strategy's win rate, and no P&L is claimed anywhere here.

**What to check next, if the owner wants more than the two days.**
1. Re-run `harness/run.py` over a longer window *with* per-scan bar captures, so band-vs-intraday stops
   being undiscoverable. The band arithmetic is already written; it needs inputs.
2. Instrument the round trip once on live (timestamps at trigger / emit / receipt / ruling) — a
   read-only journal field would settle whether the 21m47s is researcher-side compute or scheduling
   overhead, which is the difference between fixing the prompt and fixing the plumbing.
3. Decide §8's Proposal A or B explicitly rather than by default; today the desk voids its own signals
   without anyone choosing that.

---

## 10. Reproduce it

```bash
cd /c/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/vixgate-1120
node 04-live-verify.mjs        # read-only GETs; needs QODER_PAT in ../../.env; never printed
                               # set VIX_OUT=<dir> to re-run without overwriting the earlier read
node 07-fetch-system-fields.mjs  # read-only: sha256 + byte/char counts of the live `system` fields
PY=/c/Users/tteh/AppData/Local/Programs/Python/Python312/python.exe   # `python3` on PATH is a broken Store stub
$PY -X utf8 harness/run.py                 # 30-row reproduction + both deletion variants + bands + size threshold
$PY -X utf8 harness/guard_counterfactual.py  # live guard.py Q1-Q5 (subprocess, offline portfolios)
node apply/apply-scan-vintage-draft.mjs --selftest  # local only; asserts anchor count == 1 and length delta
```

`-X utf8` is required, not cosmetic: the console code page is cp1252 and the dumps contain non-ASCII
characters that raise `UnicodeEncodeError` without it.

Outputs: `out/counterfactual.json`, `out/table.md`, `out/memo-table.md`,
`out/table-extension-cap.md`, `out/guard-counterfactual.json`, `out/live-code-sha256.txt`,
`out/live-read-report.json` (read 1), `out/recheck/` (read 2), `out/read3/` (read 3),
`out/read4/live-read-report.json` (read 4, with the pin map), `out/guardnew/diff-report.json`
(currently pinned guard, per-file vs v12), `out/adapter-versions.json`,
`apply/live-now-{researcher,coordinator}-system.bin`.
