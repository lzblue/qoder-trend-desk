# Mailbox ack ownership — Automations/Workspaces hypothesis tested, and the real mechanism

**Verdict: disconfirmed — with the real mechanism identified.** The Automations-vs-Workspaces
"cannot observe the child" hypothesis is false as stated: an automation wake observes a spawned
conversation's completion perfectly well, and it proved it tonight. What actually left four acks
stuck was an **ownership vacuum**: CONTRACT rule 4 assigned the terminal ack to a spawner turn that
routinely ends before a 20–50-minute child does, every child brief explicitly forbade the child from
touching `acks/`, and takeover was gated on a human go-ahead. "Was told not to" — not "cannot
deliver". The ownership fix the owner proposed is still the right fix; its justification changes.

- Task: `20261120T013728Z-9a0e52` (mailbox wake, `kind:spawn`, priority high)
- Evidence collected 2026-11-20 01:45–02:00Z from the live platform and the four incident acks.
- Claim tags: **[documented]** written in an official page or a tool description I read this session;
  **[observed]** read from a live system artefact this session; **[inferred]** derived from those;
  **[undiscoverable]** I could not establish it from what I can reach.
- Nothing was traded. No cloud template, skill, schedule, `rules.json`, `guard.py` or account action.
  The only shared file touched is `.scratch/mailbox/CONTRACT.md`, rule 4 only (§5).

---

## 0. Bottom line

1. **The automation's execution is a workspace task, not a separate execution domain.** **[observed]**
   `mcp__builtin__qoder_cron` `action:list` returns task `05d67f16-dfaf-428e-94f2-261d65c34a46`
   ("Mailbox wake (Claude to Qoder)") with `executionScope: {kind: "workspace",
   workspaceId: "5074fd1f-43e1-4800-af51-775307750e07", cwd: "...\qoder-trend-desk-dashboard"}`,
   `model: "efficient"`, `outputMode: "independent"`, `executionPolicy.permissionMode:
   "bypassPermissions"`. The children carry the same `executionHostLabel: "Local"` and the same `cwd`
   in `list_chat_sessions`. Same host, same workspace, same directory, same tool surface.
2. **The only real split is catalogue visibility, and it does not block observation.** **[documented]**
   `qoder_cron` states automations "execute in their own conversations, accessible from Automations".
   **[observed]** The wake conversation `754afa52-…` is absent from both `list_chat_sessions` pages
   (35 unarchived rows, `nextCursor: null`; archived page empty) — and I read it in full anyway, by id.
3. **Polling reaches the child's terminal state, and a wake has already used it.** **[observed]** I
   reproduced the four incidents by direct read: three children are terminal and three acks are still
   `accepted` (one hour later), and the `e1a7b5` ack shows a wake reading a child and writing at
   00:22:40Z *after* the child's first turn ended. So the premise "no matter how it polls" is false.
4. **The failure is textual and structural, not plumbing.** Rule 4 gave the ack to the spawner; the
   child briefs forbade the child; rule 2a(ii) takeover was made to require an owner go-ahead. Nobody
   was obliged or permitted to write the terminal ack once the spawner's turn ended. **[observed]**
5. **`ack.mjs`'s new terminal-downgrade guard is what makes the fix safe.** The original reason for
   rule 4 — "two writers colliding on one file" — is now handled mechanically (guard tests T4–T7).
   Rule 4 was amended (§5) so the session that finishes writes the record.

---

## 1. What the hypothesis claimed

> the cron wake runs under Automations, the workers run under Workspaces, these two categories do not
> share session visibility, lifecycle or completion-event delivery — so an automation-side wake
> fundamentally cannot reliably observe a workspace-side child's completion, no matter how it polls.

Broken into testable parts:

| Part | Result | Basis |
|---|---|---|
| A. wake and child are in different execution domains | **false** | `executionScope.kind = workspace`, same workspaceId/cwd as the children **[observed]** |
| B. the two do not share *session visibility* | **half true** | automation executions are hidden from `list_chat_sessions` enumeration **[documented + observed]**, but readable by id **[observed]** — I read the wake from inside its own child; the reverse direction is **[inferred]** from the child appearing in the catalogue |
| C. completion *event* delivery is category-specific | **undiscoverable** | callback text is generic and says "best-effort"; no page, tool description or transcript I read distinguishes categories **[documented + undiscoverable]** |
| D. polling cannot reach completion | **false** | three terminal children read by state, tonight **[observed]** |
| E. therefore the fix must be ownership | **right conclusion, wrong reason** | §3 |

The one part that is genuinely broken is B, and it breaks something else entirely: **rule 2b's overlap
check cannot see a peer wake, ever** (§6, item 1).

---

## 2. Evidence

### 2.1 The wake is an ordinary conversation in the same workspace

**[observed]** `read_chat_session 754afa52-1dcb-4b47-9391-8671be8cb839` returns
`title: "Mailbox wake check"`, `runtimeState: "running"`, `activeTurnId: "7429520e-d09f-4842-8e28-3d325a320d99"`,
one user message at `2026-11-20T01:19:53.639Z` whose text is verbatim the automation instruction
("Mailbox wake. Run … check.ps1 … follow … CONTRACT.md exactly"), and an assistant message with 70+ tool
calls (`Bash`, `Read`, `Edit`, `Write`, `mcp_call`). `qoder_cron list` gives
`runningAt: 1795137593635` = `2026-11-20T01:19:53.635Z`, four milliseconds before that user message:
**that conversation is the automation execution**, not a manually named look-alike.

It also runs longer than the ack model assumes. **[observed]** The same task record reports
`lastRunAt: 1795134595602` (= 00:29:55.6Z) with `lastDurationMs: 2997998` (49 min 58 s); read as the
run's *start* — the only reading under which the pair is coherent — that run ended at 01:19:53.6Z, the
same instant as `runningAt` for the run this document was written inside. A wake turn can therefore
outlive a 20–35-minute child; it just usually does not, and nothing in the system obliges it to.

### 2.2 Catalogue visibility, both directions

**[documented]** `list_chat_sessions` excludes "hidden collaboration execution conversations …
unless explicitly pinned into the task list", and describes itself as returning "discoverable Qoder
task conversations". **[observed]** My own call (`limit 50`) returned 35 sessions — every worker child,
two "manual check" sessions, older named desk sessions — with no `754afa52` and no field that could
have identified it as an automation run. `archived: true` returned `[]`.

**[observed]** The same conversation is fully readable by id, including `activeTurnId`, tool list and
message statuses. Visibility for *reading* is not split; visibility for *enumerating* is.

### 2.3 The four incidents, re-verified rather than inherited

Read directly this session (times UTC):

| id | ack (status @ ts) | child session | child state now | terminal? |
|---|---|---|---|---|
| `20261119T225823Z-e1a7b5` | `accepted` @ 00:22:40 | `95012987-bf28-5725-a1cd-d44472585701` | `cold`, `activeTurnId null`, all counters 0, last assistant `completed` | **yes** |
| `20261119T235019Z-a2c7f8` | `accepted` @ 00:08:09 | `93c45aec-32d2-52d8-a1a1-f834253dc046` | `ready`, `activeTurnId null`, all counters 0, last assistant `completed` | **yes** |
| `20261119T235025Z-5e8c3a` | `accepted` @ 00:08:09 | `e472d289-efa8-5ff3-a8b7-d5550810202f` | `cold`, `activeTurnId null`, all counters 0, last assistant `completed` | **yes** |
| `20261120T000632Z-d53f19` | `accepted` @ 00:16:04 | `79128931-ab93-5095-ab36-838edd93ff6c` | `running`, `activeTurnId` set, an `Agent` tool running | no — genuinely in flight |

Three of four are terminal with stale acks; the fourth is honestly mid-turn. The terminal test used is
the one in `RECON_CLAUSE.md` step 3 (runtime not `running`, last assistant `status: "completed"`,
`activeTurnId` null, interaction/background counters 0).

`95012987`'s transcript contains a *second* user message, `2026-11-20T00:20:47.409Z`: "Continue the same
task (id 20261119T225823Z-e1a7b5). Your turn ended right after the self-correction table …". That is a
wake sending a follow-up to a child and then writing the ack at 00:22:40 — **an automation execution
observing and acting on a workspace child, after that child's first turn had ended.** It is the
counter-example to the hypothesis, recorded by the same system that produced the incident.

### 2.4 "Was told not to"

**[observed]** Two of the spawn acks quote the prohibition they put in the child's brief: "It was told
it does not own its ack and may not write into inbox/acks/done/outbox" (`a2c7f8`, `5e8c3a`). My own
brief repeats it: "the wake owns your ack, so do NOT write .scratch/mailbox/inbox, acks or done".
**[documented]** CONTRACT rule 4 says "a spawned session must not ack its own id — the spawner owns the
ack". The child was not merely slow to write; the contract and its own brief both told it not to.

### 2.5 What the platform docs did and did not establish

Read this session (all via `https://docs.qoder.com/llms.txt` → the page URL below):

- **`qoder/automations.md`** — schedules, local vs cloud, `Independent task` (separate conversation per
  run) vs `Merged task`, execution authorization for unattended runs, Run history as the way to verify
  a run, "Do not treat a created automation as proof that a scheduled run succeeded". It says nothing
  about cross-surface event delivery.
- **`qoder/task-management.md`** — sidebar grouping: "The heading changes to **Workspaces**, **Custom
  groups**, or **Recent conversations** … Grouping, sorting, and filtering change only what the sidebar
  shows; they do not move or delete tasks." "Workspaces" is a *grouping label over one task list*, not
  a separate session class. This is the strongest documentation-level refutation of the premise.
- **`qoder/task-monitor.md`** — "For delegated work, inspect the task relationship, progress, and
  result"; "Paused animation, an offline device, or unloaded history does not by itself mean a task has
  stopped." No category split.
- **`qoder/hooks.md`** — deterministic lifecycle events exist (`SessionStart`/`SessionEnd`,
  `Stop`/`StopFailure`, `SubagentStart`/`SubagentStop`), configured per machine. Not used here (it is a
  settings change outside this task's scope), but it is the platform's real event-delivery surface and
  it is not category-scoped in the docs.
- **`desktop/overview.md`** — IDE product overview; nothing about automations. No help.
- **Tool descriptions** (`create_chat_session`, `list_chat_sessions`, `qoder_cron`) — `callbackMode:
  "supervise"` promises a callback "when its turn completes", with the caveat "Callbacks are
  best-effort; if one seems overdue, check the conversation with read_chat_session or wait_chat_sessions
  using timeoutMs 0". Nothing states that a finished automation conversation cannot receive one.

**Not established:** whether a supervise callback is delivered to an automation conversation whose turn
already ended. No document says either way and I cannot observe my own spawner after my turn ends. It is
also not needed: §3 does not depend on cross-session events.

---

## 3. The real mechanism

Four texts combined to guarantee a stale ack, and none of them is a plumbing defect:

1. **Rule 4** gave the terminal ack to the spawner.
2. **The spawner's turn is the wrong lifetime.** A wake turn ends when the model stops; the children in
   question ran 20–50 minutes. `e1a7b5`'s spawner wrote its last ack 84 minutes after spawn and still
   before the work finished.
3. **Every child brief forbade the child to write.** The one entity guaranteed to be present at
   completion was contractually silent.
4. **Takeover was gated on a human.** `RECON_CLAUSE.md` step 4: "Takeover requires the owner's
   go-ahead", while rule 2a(ii) alone would have allowed a 20-minute takeover. So the wake that *could*
   see the terminal child was not authorised to act, and the acks waited for a person.

The 23:43:49–52Z incident (unconditional rename clobbering a terminal ack) was the original
justification for rule 4 — two writers colliding on one file. `ack.mjs` now refuses that direction by
default (`REFUSED`, exit 4, logged to `ack-guard.log`; tests T4–T7 in
`.scratch/changes/2026-11-20-ack-guard/test/guard.test.mjs`, 12/12). The hazard rule 4 was written
against is guarded; the cost rule 4 imposed is the incident.

---

## 4. The ownership design

**Who writes the terminal ack: the session that finished the work.** For a mailbox `spawn`, that is the
spawned (leaf) session. The spawner keeps only the claim.

| Actor | Writes | When | Through |
|---|---|---|---|
| spawner (wake) | `accepted` + `session_id` for each id it dispatches | before dispatch; it doubles as the rule 2 claim | `ack.mjs` |
| child (worker) | `done` / `failed` for its **own** id, with `result`, `files_changed`, `tests` (and its `session_id` when it has one — `list_chat_sessions` shows it) | after its deliverables are on disk and its own checks have run, as its last action before the turn ends | `ack.mjs` (tmp + atomic rename, terminal-downgrade refusal, >4000 chars spilled to `results/<id>.md`) |
| spawner (wake) | may replace the ack with `done`/`failed` | only while it is still in the same turn **and** the child has not written | `ack.mjs` |
| any wake | takeover of a stale claim | rule 2a(ii), 20 min, after supplying terminal session state to `recon.mjs` | `recon.mjs` / `ack.mjs` |

Why the child is the right owner: it is the only party guaranteed to be alive at the moment the work
ends, it knows what it actually changed and ran (better than a relayed summary), and the write it makes
is monotonic by construction — a child cannot downgrade a terminal ack, so two writers can no longer
destroy evidence. `recon.mjs`'s existing `--fix` path stays as the second line: it already refuses to
write `accepted`, refuses to clear a claim with `failed`, and requires a full terminal session state.

### If the child dies mid-turn

Nothing is written, and that is the correct outcome: an ack that says `done` for work that stopped is
worse than a stale claim. The ack stays `accepted` and the gap is **visible**:

1. `recon.mjs` classifies it after 20 minutes (rule 2a(ii) window) and escalates once per
   (id, reason) to `outbox/` — never silently.
2. If the spawner is still in its own turn, it reads the child (`read_chat_session`, last assistant
   message, `activeTurnId`, counters) and either resumes it (`send_message_to_chat_session`) or writes
   the terminal ack from the child's final message — the `e1a7b5` resume at 00:20:47Z is the working
   precedent.
3. If not, the next wake with terminal session state runs `recon --fix`, or takes over under 2a(ii) with
   the owner's go-ahead; the takeover ack names the child `sessionId`.
4. A child that returns a permission denial or a half-finished deliverable should write `failed` with
   `error` itself, rather than leaving the claim for someone else to interpret.

---

## 5. What changed in CONTRACT.md

Rule 4 only, one paragraph, authorship sentence plus the "supervise, replace the ack" clause that
contradicted it. Rules 2, 2a, 2b, 7, 8 and 9 were not touched.

- before-bytes: `.scratch/changes/2026-11-20-ack-ownership/CONTRACT.md.before`
  (sha256 `08ef0ea19215038290d996f5716c66aaf7dccfdff058b2d04a24f73e714b0a2c`, captured 01:56:37Z)
- after-bytes: `.scratch/changes/2026-11-20-ack-ownership/CONTRACT.md.after`
- patch: `docs/decisions/ack-ownership-rule4.patch`
- The file was re-read immediately before the edit and the anchor matched verbatim. If a later editor
  finds the anchor changed, this patch is the record of intent, not an instruction to re-apply blindly.

**Scope limit that must be respected:** rule 4 does not change a brief. A wake still has to *write*
"Task id `<id>`: run `node .scratch/mailbox/ack.mjs <payload>` with `done` as your last action" into the
child prompt; in-flight children were briefed under the old text and will not ack themselves. The four
stale ids stay stale until a wake harvests them under 2a(ii).

---

## 6. Remaining failure modes after this change

1. **Rule 2b cannot work as written.** `list_chat_sessions` never returns an automation execution, so
   "call `list_chat_sessions`; if another mailbox wake is already running, stand down" can only detect
   *children*, never a peer wake. `wakes.jsonl` shows 21 wakes between 23:38 and 01:20Z in bursts
   14 s apart and gaps of 34 minutes, so the nominal `*/2` tick does not describe real cadence either.
   A workable replacement needs a signal a wake can write without knowing its own session id — it is
   not in the catalogue either, as this session's own wake was not. The cheapest candidate is to
   promote the existing `overlap:` heartbeat-age test from advisory to a stand-down lock with a TTL,
   since `heartbeat.json` is already written by `check.sh` before any model work. **Not changed here**
   (rule 2b was out of scope); recorded so the next wake does not trust 2b as an overlap guard it does
   not provide.
2. **A child can still write a false `done`.** The guard blocks terminal→non-terminal, not wrong-claims.
   The mitigation is unchanged and non-structural: Claude verifies `files_changed` and re-runs the
   checks.
3. **A child can write under a mistyped id.** `ack.mjs` validates the id *format*, not that the id exists
   in `inbox/`; a transposed character creates a harmless orphan ack. Spawner and child should copy the
   id from the message, not retype it.
4. **A child that ends its turn without acking** (crash, permission denial mid-run, exhausted budget)
   leaves `accepted`; the recovery is the recon/takeover path above, i.e. latency rather than loss.
5. **Two live writers remain possible** between the read and the rename inside `ack.mjs`; the guard
   narrows the damaging direction, it does not make the pair atomic.
6. **Callbacks are still best-effort and unobserved.** Nothing here depends on them; if a future design
   does, it must first establish empirically whether a finished automation conversation receives a
   `supervise` callback.
