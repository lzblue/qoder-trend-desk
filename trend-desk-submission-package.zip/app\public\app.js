const POLL_MS = 30_000;

// The desk prints percentages in two different units and the formatters are not
// interchangeable: journal.py computes `drawdown_pct` as (peak-nav)/peak*100 and guard
// carries `day_loss_pct` the same way (already percent points), while stats() `win_rate`
// is a 0-1 fraction (`round(wr, 3)`). One auto-detecting helper silently renders a 0.4 %
// drawdown as 40.00 %, which on a risk dashboard reads as a breached limit.
function fmtPointsPct(v) {
  if (v === null || v === undefined || v === '') return '—';
  const n = Number(v);
  return Number.isFinite(n) ? `${n.toFixed(2)}%` : '—';
}
function fmtFracPct(v) {
  if (v === null || v === undefined || v === '') return '—';
  const n = Number(v);
  return Number.isFinite(n) ? `${(n * 100).toFixed(2)}%` : '—';
}
function fmtUsd(v) {
  if (v === null || v === undefined || v === '') return '—';
  const n = Number(v);
  return Number.isFinite(n) ? `$${n.toLocaleString(undefined, { maximumFractionDigits: 2 })}` : '—';
}
// fmtUsd on a negative number renders "$-172.29"; a P&L figure wants the sign in front.
function fmtSignedUsd(v) {
  if (v === null || v === undefined || v === '') return '—';
  const n = Number(v);
  return Number.isFinite(n) ? `${n < 0 ? '-$' : '$'}${Math.abs(n).toLocaleString(undefined, { maximumFractionDigits: 2 })}` : '—';
}
// Returns plain text. Any value that does not parse as a date falls through as the
// original string, so an HTML-building call site must use fmtTimeHtml, not this.
// Rendered in America/New_York because that is the desk's clock and the contest's trading
// day; this machine runs UTC+8, so the local formatter put a 16:15 ET report on screen as
// 5:15 AM the next day.
function fmtClockEt(d) {
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
    }).formatToParts(d).reduce((a, p) => (a[p.type] = p.value, a), {});
    return `${parts.hour}:${parts.minute}:${parts.second} ET`;
  } catch (_) {
    return d.toLocaleTimeString();
  }
}
function fmtTime(s) {
  if (!s) return '—';
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return String(s);
  try {
    const parts = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
    }).formatToParts(d).reduce((a, p) => (a[p.type] = p.value, a), {});
    return `${parts.year}-${parts.month}-${parts.day} ${parts.hour}:${parts.minute}:${parts.second} ET`;
  } catch (_) {
    return d.toLocaleString();
  }
}
function fmtTimeHtml(s) {
  return esc(fmtTime(s));
}

function drawLineChart(canvas, series, { color = '#5aa7ff', fill = false, zeroLine = false, scale = {} } = {}) {
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0, 0, w, h);
  if (!series.length) {
    ctx.fillStyle = '#8ea0b8';
    ctx.font = '13px sans-serif';
    ctx.fillText('No data yet — waiting for the first session.', 16, h / 2);
    return;
  }
  const values = series.map((p) => p.y);
  const min = Math.min(...values, zeroLine ? 0 : values[0]);
  const max = Math.max(...values, zeroLine ? 0 : values[0]);
  const range = max - min || 1;
  const padX = 12, padY = 12;
  const stepX = series.length > 1 ? (w - padX * 2) / (series.length - 1) : 0;

  const toXY = (i, y) => [
    padX + i * stepX,
    h - padY - ((y - min) / range) * (h - padY * 2),
  ];

  if (zeroLine) {
    const [, zy] = toXY(0, 0);
    ctx.strokeStyle = '#2a3650';
    ctx.beginPath();
    ctx.moveTo(padX, zy);
    ctx.lineTo(w - padX, zy);
    ctx.stroke();
  }

  ctx.beginPath();
  series.forEach((p, i) => {
    const [x, y] = toXY(i, p.y);
    if (i === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  });
  ctx.strokeStyle = color;
  ctx.lineWidth = 2;
  ctx.stroke();

  if (fill) {
    const [lastX] = toXY(series.length - 1, series[series.length - 1].y);
    const [firstX, baseY] = toXY(0, min);
    ctx.lineTo(lastX, baseY);
    ctx.lineTo(firstX, baseY);
    ctx.closePath();
    ctx.fillStyle = color + '22';
    ctx.fill();
  }

  // The axis is auto-scaled, which is honest about the shape but not about the size: four
  // ledger points spanning 0.17% of NAV drew as a cliff. State the range and the dates so a
  // reader can tell a 0.17% dip from a crash.
  const fmtY = scale.fmtY || ((v) => String(Math.round(v)));
  ctx.fillStyle = '#8ea0b8';
  ctx.font = '11px sans-serif';
  ctx.textAlign = 'right';
  ctx.fillText(fmtY(max), w - 6, padY + 10);
  ctx.fillText(fmtY(min), w - 6, h - padY - 3);
  ctx.textAlign = 'left';
  ctx.fillText(String(series[0].x), padX, h - 3);
  ctx.textAlign = 'right';
  ctx.fillText(String(series[series.length - 1].x), w - 6, h - 3);
  ctx.textAlign = 'left';
}

function renderDecisionLog(rows) {
  const box = document.getElementById('decision-log');
  if (!rows.length) {
    box.innerHTML = '<div class="empty">No guard decisions recorded yet.</div>';
    return;
  }
  box.innerHTML = rows
    .map((r) => {
      const verdict = r.approved ? '<span class="approved">APPROVED</span>' : '<span class="blocked">BLOCKED</span>';
      const reasons = (r.reasons || []).join('; ') || (r.warnings || []).join('; ') || '';
      // A row of "state: —" says nothing; guard.py only prints the ladder state on the
      // verdicts that consulted it, so leave it off rather than render a dash.
      const bits = [fmtTimeHtml(r.at), r.agent ? esc(r.agent) : null, r.state ? `state: ${esc(r.state)}` : null];
      return `<div class="log-row">
        <div class="meta">${bits.filter(Boolean).join(' · ')}</div>
        <div>${verdict} ${r.qty ? `qty ${esc(r.qty)}` : ''} ${r.risk_usd ? `risk ${fmtUsd(r.risk_usd)}` : ''}</div>
        ${reasons ? `<div class="meta">${esc(reasons)}</div>` : ''}
      </div>`;
    })
    .join('');
}

function renderSessions(rows) {
  const box = document.getElementById('sessions-box');
  if (!rows.length) {
    box.innerHTML = '<div class="empty">No sessions yet — nothing has fired. Check back after the next scheduled run.</div>';
    return;
  }
  box.innerHTML = rows
    .map(
      (s) => `<div class="log-row">
        <div class="meta">${fmtTimeHtml(s.created_at)} · ${esc(s.agent)}</div>
        <div>${esc(s.id)} — <strong>${esc(s.status || 'unknown')}</strong> (${esc(s.source_type || 'n/a')})</div>
      </div>`
    )
    .join('');
}

function fmtRegime(v) {
  // A coordinator echo carries the whole regime() call, so `regime` can arrive as
  // {inputs, source, out:{regime:…}} rather than the bare string the researcher prints.
  if (v === null || v === undefined) return null;
  if (typeof v === 'object') {
    if (v.out && v.out.regime) return v.out.regime;
    // `source` names where the number came from, not what it was — printing it under the
    // label "regime" reads as a regime called "computed".
    return 'not stated in this record';
  }
  return String(v);
}

function renderSignals(rows) {
  const box = document.getElementById('signals-box');
  if (!rows.length) {
    box.innerHTML = '<div class="empty">No signal evaluations recorded yet.</div>';
    return;
  }
  box.innerHTML = rows
    .map((s) => {
      // regime/size_mult/bear_flags are printed by different tools in different shapes, so a
      // row that states none of them is still a mined record — say which parts are missing
      // instead of printing "regime: — · size_mult: —".
      const bits = [];
      if (s.regime !== null && s.regime !== undefined) bits.push(`regime: ${esc(fmtRegime(s.regime))}`);
      if (s.size_mult !== null && s.size_mult !== undefined) bits.push(`size_mult: ${esc(s.size_mult)}`);
      if (s.bear_flags) bits.push(`bear_flags: ${esc(s.bear_flags)}`);
      const body = bits.length ? bits.join(' · ') : 'signal record stating neither regime nor size';
      return `<div class="log-row">
        <div class="meta">${fmtTimeHtml(s.at)} · ${esc(s.agent || '')}</div>
        <div>${body}</div>
      </div>`;
    })
    .join('');
}

function setChip(state) {
  const chip = document.getElementById('status-chip');
  chip.textContent = state || 'unknown';
  // style.css only colours the states guard.py can print. A sentence like "no guard verdict
  // mined" must not become a class name, or the chip renders unstyled and reads as a bug.
  const known = ['normal', 'caution', 'defensive', 'halt', 'blocked', 'open', 'closed', 'unbound', 'unknown'];
  const key = String(state || 'unknown').toLowerCase();
  chip.className = `chip ${known.includes(key) ? key : 'unknown'}`;
}

function esc(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function renderMailbox(m) {
  const box = document.getElementById('mailbox-box');
  if (!m) {
    box.innerHTML = '<div class="empty">Mailbox status unavailable.</div>';
    return;
  }
  // row() is the only path these fields take to innerHTML, and every value is read out of
  // a mailbox file the wake script writes, so label and value are both escaped here.
  const row = (k, v) => `<div class="kv"><span class="k">${esc(k)}</span><span>${esc(v)}</span></div>`;
  const acks = (m.recent_acks || [])
    .map(
      (a) => `<div class="log-row">
        <div class="meta">${fmtTimeHtml(a.ts)} · ${esc(a.id)}</div>
        <div><span class="status-${esc(a.status)}">${esc((a.status || 'unknown').toUpperCase())}</span>${a.error ? ` — ${esc(a.error)}` : ''} · ${a.files_changed ?? 0} file(s)</div>
      </div>`
    )
    .join('');

  box.innerHTML =
    `<div class="chip ${esc(m.state)}" style="display:inline-block;margin-bottom:10px">${esc(m.state)}</div>` +
    row('Last wake', `${fmtTime(m.last_wake)}${m.last_wake_age_min === null ? '' : ` · ${m.last_wake_age_min} min ago`}`) +
    row('Heartbeat written', fmtTime(m.last_wake_mtime)) +
    row('Interval nominal', `${m.nominal_interval_min} min`) +
    row('Interval observed', m.observed_interval_min === null ? 'need 2+ wakes' : `${m.observed_interval_min} min`) +
    row('Wakes recorded', `${m.wake_count_observed}`) +
    row('Inbox waiting', m.inbox_count === null ? '—' : m.inbox_count) +
    row('Acks open / total', m.acks_total === null ? '—' : `${m.acked_not_closed === null ? '—' : m.acked_not_closed} / ${m.acks_total}`) +
    `<div class="meta" style="margin:6px 0 10px">${esc(m.why || '')}</div>` +
    (acks ? `<div class="scroll-box">${acks}</div>` : '<div class="empty">No acks yet.</div>');
}

function renderSleeveB(snap, meta) {
  // window.SleeveB is public/sleeveb.js, shared with the offline fixture test. If it is
  // missing (stale cache of the old page) the panels say so instead of throwing.
  if (!window.SleeveB) {
    document.getElementById('options-positions').innerHTML = '<div class="empty">sleeveb.js not loaded — hard-reload the page.</div>';
    document.getElementById('options-structures').innerHTML = '<div class="empty">sleeveb.js not loaded — hard-reload the page.</div>';
    return;
  }
  const p = window.SleeveB.buildPanel(snap);
  document.getElementById('options-positions').innerHTML = window.SleeveB.renderPositions(p);
  document.getElementById('options-structures').innerHTML = window.SleeveB.renderStructures(p);
  document.getElementById('options-risk').innerHTML = window.SleeveB.renderRisk(p);
  document.getElementById('options-timeline').innerHTML =
    window.SleeveB.renderTimeline(p) + window.SleeveB.renderStateRecords(p);
  const f = p.freshness || {};
  const bits = [];
  if (f.latest_order_row_at) bits.push('latest broker order row ' + fmtTime(f.latest_order_row_at));
  if (f.latest_structure_at) bits.push('latest sleeve B structure ' + fmtTime(f.latest_structure_at));
  if (f.latest_ticket_at) bits.push('latest sleeve B ticket ' + fmtTime(f.latest_ticket_at));
  if (meta && meta.running_sessions) bits.push(meta.running_sessions + ' session(s) running');
  if (snap && snap.max_loss_cap_source) {
    // The load-bearing caveat, in one line: which cap the desk actually enforces today.
    bits.push(/NOT live/i.test(snap.max_loss_cap_source)
      ? 'max-loss cap is the D3 dashboard constant — rules.json has no structure block live yet'
      : 'max-loss cap from rules.json structure.max_loss_pct_of_nav');
  }
  document.getElementById('options-meta').textContent = bits.join(' · ');

  document.getElementById('activity-box').innerHTML = window.SleeveB.renderActivity(p.activity);
}

async function refresh() {
  let overviewRes = null;
  try {
    const [ov, sessionsRes] = await Promise.all([
      fetch('/api/overview').then((r) => r.json()),
      fetch('/api/sessions').then((r) => r.json()),
    ]);
    overviewRes = ov;

    if (overviewRes.error) throw new Error(overviewRes.error);

    setChip(overviewRes.status?.state);
    document.getElementById('stat-nav').textContent = fmtUsd(overviewRes.latest_nav);
    document.getElementById('stat-dd').textContent = fmtPointsPct(overviewRes.status?.drawdown_pct);
    document.getElementById('stat-dayloss').textContent = fmtPointsPct(overviewRes.status?.day_loss_pct);
    // journal.py stats() returns one object per sleeve plus `all`; the flat win_rate this
    // line used to read only existed in the older single-sleeve output.
    const st = overviewRes.stats || null;
    const winRate = st ? (typeof st.win_rate === 'number' ? st.win_rate : st.all && st.all.win_rate) : null;
    const statsN = st && st.all && st.all.n != null ? st.all.n : (st && st.n != null ? st.n : null);
    const led = overviewRes.ledger || null;
    // A day with no closes has no win rate. Printing "—" there read as a broken panel; the
    // desk's own stats blob says n=0, so say that, and put the lifetime figure from the
    // ledger next to it so the card is never an unexplained blank.
    document.getElementById('stat-winrate').textContent = typeof winRate === 'number'
      ? fmtFracPct(winRate)
      : (statsN === 0 ? 'no closes' : fmtFracPct(winRate));
    const statNote = (id, text) => {
      const el = document.getElementById(id);
      if (el) el.textContent = text || '';
    };
    // The card prefers the ledger because guard.py scores drawdown and day loss against the
    // peak_nav and nav the proposal envelope declares, and a proposal that declares
    // peak_nav = nav reports 0.0 % on a day the broker read 0.17 %. Saying both, once, is the
    // difference between a risk card and an advertisement.
    const differs = (card, stated) => typeof stated === 'number'
      && typeof card === 'number' && Math.abs(stated - card) >= 0.01;
    const srcNote = (source, stated, card) => {
      if (!source) return '';
      return `source: ${source}` + (differs(card, stated)
        ? ` · the guard's verdict stated ${stated.toFixed(2)} % against a proposal-declared anchor` : '');
    };
    statNote('stat-dd-note', srcNote(overviewRes.status?.drawdown_source,
      overviewRes.status?.guard_verdict_drawdown_pct, overviewRes.status?.drawdown_pct));
    statNote('stat-dayloss-note', srcNote(overviewRes.status?.day_loss_source,
      overviewRes.status?.guard_verdict_day_loss_pct, overviewRes.status?.day_loss_pct));
    statNote('stat-winrate-note', [
      statsN === null ? null : `${statsN} close(s) in the mined stats window`,
      led ? `lifetime expectancy ${fmtSignedUsd(led.expectancy)} over n=${led.n}` : null,
    ].filter(Boolean).join(' · '));
    const skipped = overviewRes.mining?.doc_read_events_skipped;
    document.getElementById('data-source').textContent =
      `${overviewRes.sessions_scanned} most recent sessions (top-level events plus their child threads), ` +
      `read live from Qoder Cloud Forward; equity and closes from the desk's own ledger.` +
      (skipped ? ` ${skipped} event(s) whose source was a read of a markdown document — a skill's SKILL.md or the desk's own notes — were dropped, because text copied out of a document is an example, not something the desk decided.` : '') +
      ` ${overviewRes.generated_at}`;

    const equitySeries = (overviewRes.equity_curve || [])
      .filter((p) => typeof p.nav === 'number')
      .map((p) => ({ x: p.date, y: p.nav }));
    drawLineChart(document.getElementById('equity-chart'), equitySeries, {
      color: '#35d08a',
      fill: true,
      scale: { fmtY: (v) => '$' + Math.round(v).toLocaleString('en-US') },
    });

    const ddSeries = (overviewRes.equity_curve || [])
      .filter((p) => typeof p.drawdown_pct === 'number')
      .map((p) => ({ x: p.date, y: p.drawdown_pct }));
    drawLineChart(document.getElementById('drawdown-chart'), ddSeries, {
      color: '#ff5d6c',
      zeroLine: true,
      scale: { fmtY: (v) => v.toFixed(2) + '%' },
    });

    renderDecisionLog(overviewRes.decision_log || []);
    renderSignals(overviewRes.signals || []);
    renderSessions(Array.isArray(sessionsRes) ? sessionsRes : overviewRes.sessions || []);

    document.getElementById('last-updated').textContent = `Updated ${fmtClockEt(new Date())}`;
  } catch (err) {
    document.getElementById('last-updated').textContent = `Error: ${err.message}`;
  }
  // Kept out of the block above so a dashboard restart without the new route
  // cannot take the trading views down with it.
  try {
    const res = await fetch('/api/mailbox');
    renderMailbox(res.ok ? await res.json() : null);
  } catch (_) {
    renderMailbox(null);
  }
  // Same isolation for the sleeve B views: an overview payload from an older server has
  // no `sleeveb` key, and the options panels must not blank the rest of the page.
  try {
    let snap = overviewRes && overviewRes.sleeveb;
    let activity = overviewRes && overviewRes.activity;
    if (!snap || !activity) {
      const r = await fetch('/api/sleeveb');
      if (r.ok) {
        const j = await r.json();
        snap = j.sleeveb;
        activity = j.activity;
      }
    }
    if (snap && activity) {
      renderSleeveB({ ...snap, activity: { ...activity, running_sessions: overviewRes.running_sessions } },
        { running_sessions: overviewRes.running_sessions });
    } else {
      const none = '<div class="empty">This server returned no sleeve B data.</div>';
      document.getElementById('options-positions').innerHTML = none;
      document.getElementById('options-structures').innerHTML = none;
      document.getElementById('activity-box').innerHTML = '<div class="empty">This server returned no activity data.</div>';
    }
  } catch (err) {
    const msg = '<div class="empty">Sleeve B views unavailable: ' + esc(err.message) + '</div>';
    document.getElementById('options-positions').innerHTML = msg;
    document.getElementById('options-structures').innerHTML = msg;
  }
}

document.getElementById('refresh-btn').addEventListener('click', refresh);
refresh();
setInterval(refresh, POLL_MS);
