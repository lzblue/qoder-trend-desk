# Sleeve B / Pre-Market Fill Mechanics — Key Findings (2026-11-19)

## Pre-market fill mechanics (resolves the "must wait for P0.4" question)
- The sim **does match equity orders pre-market**, not just during regular session (08:55 ET AAPL probe: buy submitted 13:55:28Z, filled 13:55:36Z, 8s, at 353.59 — inside the spread, not at the limit).
- Options do **not** reliably fill pre-market — a marketable SPY 0DTE call limit rested 16s and never filled pre-open (separate probe). Equity ≠ options pre-market behavior.
- This means real fill-row data no longer requires waiting for P0.4 (14:35Z) — it can be obtained via a bounded equity probe at any time the market allows equity matching.

## Verified order/position row schema (from the AAPL probe, account 5830104)
- **Status enum (sim-specific, does NOT match Futu's real-account docs):** `2` = resting/live, `4` = fully filled (only when `cum_qty == qty`), `5` = cancelled.
- `avg_fill_price` + `cum_qty` on the order row is the authoritative fill record — there is no separate deal/fill-list tool (`account_order_fills_today` errors with MCP -32603, same as the whole `account_*` family).
- A **closed position's row persists with `qty:"0"`** — any position-reading logic must filter `qty>0` or it will misread a closed probe as a live position and misprice NAV.
- `today_*` fields (today_buy_qty, today_sell_avg_price, etc.) stay **null even on a same-day fill** — never rely on them; use `cum_qty`/`avg_fill_price` instead.
- **Fees are real** — reconcile NAV off `sim_trade_cash_info.balance`, never off position `profit`. (Round trip observed: +$0.10 gross, balance dropped to 99,998.11 — consistent with ~$1.99 fees, unconfirmed exact breakdown.)

## Sleeve B pre-market dry-run (desk_sleeves_v2.py + live guard.py v9, read-only)
- **Confluence gate (Gate 3) blocks today's overlay outright, independent of everything else**: neither SPY (0.87x prior-day expansion, close at 41%) nor QQQ (0.76x, 66%) clears the required 1.5x ratio + ≥0.66/≤0.34 close-location threshold. No B overlay opportunity today on either underlying, either direction.
- **Gap found: `dte_min`/`dte_max` do not exist in `rules.json`**, despite `sleeve_b_overlay`'s docstring claiming they're sourced from there. Dry-run used an explicitly-labeled assumption of 0–2 DTE. **Needs a `rules.json` edit (adding keys) — requires explicit user authorization before any live change.**
- **Structural risk: the contract picker defaults to 0DTE every time** — sort is max-|delta| first with DTE only as tiebreak, and the nearest expiry has the highest deltas at affordable strikes. 0DTE carries auto-exercise risk after 16:00 ET. A `dte_min ≥ 1` would close this gap.
- **Field-path gotcha**: `option_ex_data.premium` is **not** the option's price (observed 0.123 vs. real last of 8.55). Greeks/IV/OI live under `option_ex_data.*`; bid/ask only via `quote_order_book` (US options = 1 level depth).
- Hedge path correctly can **never** take overlay contracts — the DTE 7-45 gate fires unconditionally for 0-1 DTE contracts, confirming Sleeve B must go through `sleeve="option"` ($250 budget today), never the hedge path.
- Guard's budget **stacks day × regime multiplier** — today (Nov 19) gives $250 (0.5 size_mult × $500 base); a size_mult-1.0 day (Nov 20+) would give $500. Budget is calendar/regime-dependent, not static.
- Sizing basis mismatch (documented, not urgent): guard sizes qty off raw premium; `desk_sleeves_v2` sizes off the +5% tolerance limit. dv2's qty is always ≤ guard's — in the $2.38–2.50 premium range, guard would approve qty=1 where dv2 emits NONE. Worth knowing when building the real adapter.
- Pipeline (selection, budget/fee/entry-window gates) verified end-to-end except the fill itself, which the confluence gate makes moot for today anyway.

## P1.6 backtest — the one validated live change
- Across the 38-session live-faithful replay: fixing **only** the signal→fill anchor, keeping the existing ladder-chase entry and close-at-next-check protection, is the one robust, positive-at-every-tested-point result (+$1,016.99 vs as-run +$572.83, same trade set, no new path-dependence).
- Marketable-limit entry and monitored-stop protection both underperform in every tested variant — **do not adopt either for Sleeve A** based on this evidence.
- Inverse ETF beats direct short once financing costs are modeled — use inverse ETFs, not short-selling.
- Candidate-ticker expansion (IWM/DIA/XLF/TLT/GLD/XLE) blocked: ERY/GLL are 2x leverage not 3x as assumed, and none of the 12 symbols exist in `rules.json`'s universe — needs explicit authorization before any candidate ticker goes live.
