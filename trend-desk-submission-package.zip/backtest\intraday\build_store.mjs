// Merge the raw MCP 5-min payload dumps into the engine's bars/<SYM>.json store.
//
// Ticker identity comes from the payloads, not the filenames: each moomoo bar carries the
// fund's long `name` ("SPDR S&P 500 ETF"), so a name is assigned to the symbol whose files
// exclusively contain it. A name seen in two prefixes is an ambiguous payload and aborts,
// because trading the wrong ticker under a right-looking label is the failure this guards.
import fs from 'node:fs';
import path from 'node:path';

const ROOT = 'C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/bt-intraday';
const PAGES = path.join(ROOT, 'pages');
const OUT = path.join(ROOT, 'bars');
const WINDOWS = [
  ['W1_2016aug', 20160801, 20160831],
  ['W2_2018jan', 20180102, 20180131],
  ['W3_2020mar', 20200302, 20200331],
  ['W4_2022apr', 20220401, 20220429],
];
const WANT = ['SPY', 'QQQ', 'SMH', 'SQQQ', 'SOXS'];

const files = fs.readdirSync(PAGES).filter(f => f.endsWith('.json')).sort();
const nameVotes = {};          // fund name -> Set(prefix)
const bars = {};               // prefix -> {time_key: bar}
const anomalies = [];

for (const f of files) {
  const m = f.match(/^([A-Z]+)_W([1-4])_(\d+)\.json$/);
  if (!m) { anomalies.push(`skip (not a payload file): ${f}`); continue; }
  const prefix = m[1], win = 'W' + m[2];
  if (!WANT.includes(prefix)) { anomalies.push(`unexpected prefix in ${f}`); continue; }
  let j;
  try { j = JSON.parse(fs.readFileSync(path.join(PAGES, f), 'utf8')); }
  catch (e) { anomalies.push(`UNPARSEABLE ${f}: ${e.message}`); continue; }
  if (j.ret_code !== 0) { anomalies.push(`ret_code ${j.ret_code} in ${f}: ${j.ret_msg}`); continue; }
  const kl = ((j.data || {}).kline_list) || [];
  if (!kl.length) { anomalies.push(`EMPTY kline_list in ${f}`); continue; }
  const lo = WINDOWS.find(w => w[0].startsWith(win))[1], hi = WINDOWS.find(w => w[0].startsWith(win))[2];
  const b = bars[prefix] || (bars[prefix] = {});
  let kept = 0, outside = 0;
  for (const r of kl) {
    (nameVotes[r.name] || (nameVotes[r.name] = new Set())).add(prefix);
    if (r.date < lo || r.date > hi) { outside++; continue; }
    if (b[r.time_key]) continue;     // de-duplicate: overlapping pages are expected
    b[r.time_key] = { date: r.date, open: r.open, high: r.high, low: r.low, close: r.close,
                     volume: r.volume, turnover: r.turnover, time_zone: r.time_zone,
                     last_close: r.last_close };
    kept++;
  }
  console.log(`${prefix} ${win} page ${m[3]}: kept ${kept} outside-window ${outside} store now ${Object.keys(b).length}`);
}

// a fund name must belong to exactly one symbol
for (const [nm, set] of Object.entries(nameVotes)) {
  if (set.size > 1) anomalies.push(`AMBIGUOUS name "${nm}" in prefixes ${[...set].join(',')}`);
}
fs.mkdirSync(OUT, { recursive: true });
const summary = {};
for (const sym of WANT) {
  const b = bars[sym] || {};
  const byDay = {};
  for (const [tk, bar] of Object.entries(b)) (byDay[bar.date] ||= []).push(Number(tk));
  const days = Object.keys(byDay).map(Number).sort((x, y) => x - y);
  const truncated = days.filter(d => {
    const t = Math.min(...byDay[d]) + (b[byDay[d].find(k => true)].time_zone * 3600000);
    const mins = new Date(t).getUTCMinutes(), hr = new Date(t).getUTCHours();
    return !(hr === 9 && mins === 35) && !(hr === 10 && mins === 0);   // 10:00 start = half day
  });
  summary[sym] = { bars: Object.keys(b).length, sessions: days.length,
                   first: days[0], last: days[days.length - 1],
                   incomplete_open: truncated.length, incomplete_days: truncated.slice(0, 40) };
  fs.writeFileSync(path.join(OUT, `${sym}.json`), JSON.stringify(b));
  console.log(`${sym}: ${summary[sym].bars} bars / ${summary[sym].sessions} sessions ` +
              `${summary[sym].first}..${summary[sym].last}, open-truncated ${truncated.length}`);
}
console.log('fund names seen:', JSON.stringify(Object.entries(nameVotes)
  .map(([n, s]) => ({ name: n, sym: [...s].join('|') })), null, 1));
fs.writeFileSync(path.join(ROOT, 'store_summary.json'),
  JSON.stringify({ summary, anomalies, windows: WINDOWS }, null, 1));
if (anomalies.length) console.log('ANOMALIES:\n  ' + anomalies.join('\n  '));
