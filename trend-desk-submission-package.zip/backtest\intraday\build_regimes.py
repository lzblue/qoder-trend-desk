"""Per-session regime ladder for the 2016-2022 windows, from the mounted signal module.

The bucket is produced by trend_signal.regime() itself (the file whose sha256 the live
researcher mount carries), fed with data as-of the PRIOR trading day: no same-day
information and no re-implementation of the desk's ladder in this harness.
Index/vol inputs come from the calibrated daily panel (SPX/NDX/SOX/VXN matched moomoo's own
dailies to r=1.00000 in .scratch/bt-long/ingest.mjs; VIX to r=0.99967).
"""
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "mounted"))
import trend_signal as ts  # noqa: E402

PANEL = json.load(open(os.path.join(HERE, "..", "bt-long", "panel.json"), encoding="utf-8"))
DAYS = {}
for sym, blk in PANEL.items():
    DAYS[sym] = {int(r["day"]): float(r["close"]) for r in blk["rows"]}
ORDER = sorted(DAYS["SPX"])          # panel trading calendar


def series_before(sym, day, n):
    """Last n closes strictly before `day`, newest first."""
    out = [DAYS[sym][d] for d in ORDER if d < day and d in DAYS[sym]]
    return out[-n:]


def sma200(sym, day):
    prev = series_before(sym, day, 200)
    return (sum(prev) / len(prev)) if len(prev) >= 150 else None   # fail closed if immature


def build(day):
    p = lambda s: series_before(s, day, 1)
    r = lambda s: p(s)[0] if p(s) else None
    ndx_s, spx_s = sma200("NDX", day), sma200("SPX", day)
    sox5 = series_before("SOX", day, 6)
    snap = {
        "vix": r("VIX"), "vxn": r("VXN"),
        "ndx_close": r("NDX"), "ndx_sma200": ndx_s,
        "spx_close": r("SPX"), "spx_sma200": spx_s,
        "sox_5d_return_pct": ((sox5[-1] / sox5[0] - 1.0) * 100.0) if len(sox5) == 6 else None,
        "as_of_et": str(day), "now_et": str(day),
    }
    reg = ts.regime(snap)
    reg["inputs"] = {k: (round(v, 4) if isinstance(v, float) else v) for k, v in snap.items()}
    spx21 = series_before("SPX", day, 22)
    reg["spx_21d_return_pct"] = ((spx21[-1] / spx21[0] - 1.0) * 100.0) if len(spx21) == 22 else None
    return reg


def main():
    store = json.load(open(os.path.join(HERE, "store_summary.json"), encoding="utf-8"))
    days = set()
    for sym, s in store["summary"].items():
        for f in s.get("incomplete_days") or []:
            pass
    # session days come straight from the merged store, so a day is simulated only if bars exist
    import glob
    for f in glob.glob(os.path.join(HERE, "bars", "*.json")):
        for k, b in json.load(open(f, encoding="utf-8")).items():
            days.add(int(b["date"]))
    out = {str(d): {"regime": build(d)} for d in sorted(days)}
    json.dump(out, open(os.path.join(HERE, "regimes.json"), "w", encoding="utf-8"), indent=1)
    counts = {}
    for d, v in out.items():
        counts[v["regime"]["regime"]] = counts.get(v["regime"]["regime"], 0) + 1
    print("sessions", len(out), "buckets", json.dumps(counts))
    for d in sorted(days)[:3] + sorted(days)[-3:]:
        r = out[str(d)]["regime"]
        print("  %s %-13s mult %-5s long %-5s flags %s spx21d %s" % (
            d, r["regime"], r["size_mult"], r["allow_long"], len(r["bear_flags"]),
            None if r["spx_21d_return_pct"] is None else round(r["spx_21d_return_pct"], 2)))


if __name__ == "__main__":
    main()
