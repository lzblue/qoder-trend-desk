# Ticker diversification — replay, eligibility, leverage and the 5-artifact package

**Status: Tier B — scope and prepare only. Nothing was applied.** No skill publish, no rules.json
edit, no template write or re-pin, no schedule change, no order, probe or cancel on account
5830104 or any other. Every cloud call in this task was a `GET`; every moomoo call was a
quote-side read (`quote_history_kline`, `quote_market_snapshot`, `quote_user_security`).
`QODER_PAT` was used only inside an `Authorization` header and appears in no file and no output.

- Task `20261120T024106Z-c25e91`. Add-on inbox items folded in: `20261120T024230Z-9d4e1f`,
  `20261120T024430Z-2a6c8e`, `20261120T024530Z-6f2d91`.
- Written 2026-11-20, live reads 02:0x–03:12Z (`date -u` = 2026-11-20T03:12:41Z at time of writing).
- Prepared package: [`.scratch/changes/2026-11-20-ticker-diversification/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-ticker-diversification/)
- Claim tags: **[observed]** = a run I executed or a live read this session; **[documented]** = a file in
  this repo or published skill bytes; **[undiscoverable]** = not knowable from what I can reach.

---

## 1. EXACT REPLAY — 18–19 Nov 2026, candidate by candidate

**Method.** `.scratch/tickdiv/replay.py` loads the **live published** `trend_signal.py`
(version `1795047415929677`, sha `60d5573d…bed8`) by `importlib` and calls its own
`signal()` — no re-implementation, no loosened threshold. The only change between the two runs
is the `PAIRS` entry each candidate would add. Bars are the 5-minute klines captured from
moomoo (`ktype=6`, `end=2026-11-20`, 78 bars per session), deduped by `time_key`.
Opening range = first six bars (09:35–10:00 ET, close-stamped), running session VWAP, price =
the close of the last bar at or before each stamp. Stamps: the four scheduled SCAN times
(10:05, 11:00, 12:30, 14:00) **plus 10:17**, the wall-clock time the real 18–19 Nov SCAN actually
produced its signals after the round trip. Regimes are the point-in-time labels: 18 Nov `caution`
(`allow_long` true, size_mult 0.75), 19 Nov `bear_high_vol` (`allow_long` false, size_mult 0.5).

**Fidelity check first.** With the live `PAIRS` (QQQ/SPY only; no SMH bars were captured), the
replay emits exactly the two tickets the live desk actually formed, at exactly the numbers on
them:

```
2026-11-19 10:17 QQQ SHORT -> SQQQ entry 44.45 stop 43.59 target 45.74 lev 3
2026-11-19 10:17 SPY SHORT -> SPXS entry 27.60 stop 27.19 target 28.22 lev 3
```

and at the **scheduled 10:05 stamp it emits NONE for both** — "no confirmed breakout beyond the
opening range on the right side of VWAP". [observed] That single contrast is the most important
finding on this page and it is taken up in §1.3.

### 1.1 Verdict table, ticker by ticker

| day | ticker | OR width | 10:05 | 10:17 | 11:00 | 12:30 | 14:00 | fires |
|---|---|---|---|---|---|---|---|---|
| 18 Nov | **GLD** | 0.43 % | **SHORT GLL** | **SHORT GLL** | **SHORT GLL** | NONE | NONE | 3 |
| 18 Nov | **IWM** | 1.14 % | NONE | NONE | NONE | **LONG IWM** | **LONG IWM** | 2 |
| 18 Nov | QQQ | 1.34 % | NONE | NONE | NONE | NONE | NONE | 0 |
| 18 Nov | SPY | 0.88 % | NONE | NONE | NONE | NONE | NONE | 0 |
| 18 Nov | **TLT** | 0.43 % | NONE | NONE | NONE | NONE | **LONG TLT** | 1 |
| 18 Nov | **XLE** | 2.63 % | NONE (width) | NONE (width) | NONE (width) | NONE (width) | NONE (width) | 0 |
| 18 Nov | **XLF** | 0.76 % | NONE | **SHORT FAZ** | **SHORT FAZ** | NONE | NONE | 2 |
| 19 Nov | **GLD** | 0.39 % | NONE | NONE | NONE | NONE | NONE | 0 |
| 19 Nov | **IWM** | 0.92 % | NONE | NONE | **SHORT TZA** | **SHORT TZA** | NONE | 2 |
| 19 Nov | QQQ | 0.78 % | NONE | **SHORT SQQQ** | NONE | NONE | NONE | 1 (real) |
| 19 Nov | SPY | 0.61 % | NONE | **SHORT SPXS** | NONE | NONE | NONE | 1 (real) |
| 19 Nov | **TLT** | 0.36 % | NONE | NONE | vetoed: regime | vetoed: regime | vetoed: regime | 0 |
| 19 Nov | **XLE** | 1.02 % | NONE | NONE | **SHORT ERY** | **SHORT ERY** | **SHORT ERY** | 3 |
| 19 Nov | **XLF** | 0.60 % | NONE | **SHORT FAZ** | NONE | NONE | NONE | 1 |

"vetoed: regime" = the breakout condition was met but `bear_high_vol` sets `allow_long` false, so
the engine returned `NONE — regime bear_high_vol: no long entries`. XLE on 18 Nov never got as far
as a breakout test: its opening range was 2.63–2.66 % against the engine's `0.15–1.5 %` band.

**Totals: 16 fires, 2 of which are the real live tickets and 14 of which are candidate-only.**

### 1.2 The 14 candidate fires, with the levels they would have produced

| # | when | ticker | side | instrument | entry | stop | target | lev |
|---|---|---|---|---|---|---|---|---|
| 1 | 18 Nov 10:05 | GLD | SHORT | GLL | 30.35 | 30.21 | 30.56 | 2 |
| 2 | 18 Nov 10:17 | GLD | SHORT | GLL | 30.38 | 30.23 | 30.61 | 2 |
| 3 | 18 Nov 11:00 | GLD | SHORT | GLL | 30.45 | 30.29 | 30.70 | 2 |
| 4 | 18 Nov 12:30 | IWM | LONG | IWM | 272.07 | 269.75 | 275.55 | 1 |
| 5 | 18 Nov 14:00 | IWM | LONG | IWM | 271.47 | 270.07 | 273.57 | 1 |
| 6 | 18 Nov 14:00 | TLT | LONG | TLT | 80.20 | 80.05 | 80.42 | 1 |
| 7 | 18 Nov 10:17 | XLF | SHORT | FAZ | 33.15 | 32.70 | 33.83 | 3 |
| 8 | 18 Nov 11:00 | XLF | SHORT | FAZ | 33.13 | 32.80 | 33.62 | 3 |
| 9 | 19 Nov 11:00 | IWM | SHORT | TZA | 52.01 | 51.37 | 52.97 | 3 |
| 10 | 19 Nov 12:30 | IWM | SHORT | TZA | 52.69 | 51.87 | 53.93 | 3 |
| 11 | 19 Nov 11:00 | XLE | SHORT | ERY | 9.41 | 9.33 | 9.54 | 2 |
| 12 | 19 Nov 12:30 | XLE | SHORT | ERY | 9.45 | 9.36 | 9.58 | 2 |
| 13 | 19 Nov 14:00 | XLE | SHORT | ERY | 9.45 | 9.37 | 9.58 | 2 |
| 14 | 19 Nov 10:17 | XLF | SHORT | FAZ | 33.70 | 33.26 | 34.37 | 3 |

Levels are the engine's own `entry*(1 ∓ lev*pct)` arithmetic at the pair's real leverage, so a
2× pair (GLD/GLL, XLE/ERY) carries half the stop distance of a 3× pair for the same underlying
move. That is only correct if the leverage in `PAIRS` is the fund's real one — §3.4.

Counted by direction: **3 long, 11 short.** Counted by ticker: IWM 4, GLD 3, XLE 3, XLF 3, TLT 1.

### 1.3 Would any of them have cleared the staleness failure that killed SQQQ/SPXS?

**No — and no ticker choice can make it clear.** The evidence, in order:

1. The staleness failure is not a property of the signal; it is a property of the handoff. On
   19 Nov the SCAN fired at 10:05, the researcher read data at ~10:17, and by the time the
   auditor applied its 5-minute rule the round trip had consumed **21 m 47 s**, so the only two
   approvable tickets were voided as stale (measured in `docs/decisions/vix-gate-and-zero-trades-nov20.md`).
2. The replay reproduces exactly that geometry. At the **10:05** stamp — the moment the trigger
   fired — the engine said NONE for QQQ and SPY. The tickets existed only once it was fed the
   **10:17** data the researcher actually read. So the tickets were "fresh when generated" and
   still dead when they arrived.
3. Therefore every candidate fire at 10:17 or later (13 of 14) enters the identical pipeline and
   dies the identical way. The one exception is GLD's 10:05 fire — and it also fires at 10:17 and
   11:00, so a desk that traded it would have been looking at the same 10:17 read and the same
   age-of-quote problem. It is not a rescue; it is the same event with a longer history.
4. The only way any of these becomes fillable is to shorten the handoff (fetch, signal, verdict
   inside five minutes) or to relax the rule. Neither is a ticker change, so **nothing in this
   memo's candidate set changes the outcome of the two sessions that actually happened.**

What the replay *does* establish is the thing the desk did not have: a measured rate. **14 candidate
signals in two sessions**, against 2 for the live universe, on days when the live engine produced
zero at the scheduled stamp and two only at the latency-shifted stamp.

### 1.4 Limits of this replay, stated plainly

- **SMH was not replayed by this pass.** No 5-minute SMH bars were captured here, so the live-pair
  column covers QQQ and SPY only. The live replay is therefore 2-of-2 on the pairs it covers, not
  3-of-3.
- Bars are vendor 5-minute closes, not a tick feed; VWAP is the standard `typical_price × volume`
  approximation over those bars, not the exchange's own VWAP.
- Two sessions, one regime each. This is a frequency probe, not an expectancy estimate: no fills,
  no fees, no exit modelling. §7 must be read with that in mind.
- The one-new-position-per-scan rule (§4 of the live coordinator) caps the desk at four entries a
  day. The 14 fires compete for at most 2 slots on 18 Nov and 4 on 19 Nov — expansion changes
  *which* ticker fills a slot, never how many slots exist.

---

## 2. What the replay plus the eligibility check actually settles

1. **The diversification gap is real and it is one-sided.** Every candidate's profitable-looking
   activity in these two sessions is a **short**, and every short needs an inverse ETF. 11 of 14
   fires are shorts. The three longs (IWM ×2, TLT ×1) are the only tickets that need no new
   instrument at all — and on a `bear_high_vol` tape the regime vetoes longs outright, which is
   what happened to TLT on 19 Nov.
2. **Every new inverse vehicle fails the owner's $500M floor.** IWM→TZA $197.6M, IWM→SRTY $75.7M,
   XLF→FAZ $94.1M, XLE→ERY $50.3M, GLD→GLL $93.2M, TLT→TMV $200.2M. The only inverse ETFs above
   the bar are the two already live (SQQQ $1.76B, SOXS $1.36B); the third live vehicle, SPXS at
   $322.7M, is itself below the bar and already in use. So a strict reading of the floor admits
   **no** new pair at all — see §8 for the one route that keeps every traded instrument eligible.
3. **Leverage is confirmed, including the two 2× funds.** ERY −2.0 and GLL −2.0, three ways (§3.4).
   Recording 3 for either would put the stop and target 1.5× too far out — the exact error the
   task asked not to repeat.
4. **The one-line strategy sentence is not a ticker list.** The coordinator prompt says "bearish
   ideas buy a **3x** inverse ETF (SQQQ, SOXS, SPXS)". Adding ERY or GLL makes that sentence false,
   so the prompt edit is a leverage-aware rewrite, not an append (§4, artifact 5).
5. **The re-pin budget is already spent for three of the four templates** (§4.3). Coordinator is
   the only one writable today.

---

## 3. Eligibility: the candidates against the floor (item 1 of the task)

Floor as the owner states it: US-listed stock/ETF/option, **price > $1**, **market cap > $500M**.
For an ETF the nearest comparable figure is net assets (the snapshot reports `trust_aum` /
`net_asset` and `trust_valid: true`; it does not report a "market cap" for a trust). I use net
assets and label it as such rather than pretending the two are the same.

`quote_market_snapshot`, `data_date` 2026-11-19 **[observed]**. ADV is my own computation: the
arithmetic mean of daily `volume` over the last **20 sessions** (2026-10-23 … 2026-11-19) from
`quote_history_kline ktype=2 num=370` payloads, per `.scratch/tickdiv/adv.py`. Average dollar
turnover is the mean of `turnover` over the same 20 sessions.

### 3.1 The long leg (the 1× ETF the desk would buy)

| ticker | last | net assets | 20-session ADV | avg $ turnover | $500M | liquidity |
|---|---|---|---|---|---|---|
| IWM | 264.22 | $74.96B | 18.78 M sh | $5.24B/day | **pass (150×)** | deep |
| XLF | 55.58 | $51.91B | 36.88 M sh | $2.12B/day | **pass (104×)** | deep |
| XLE | 60.89 | $39.74B | 29.29 M sh | $1.92B/day | **pass (79×)** | deep |
| GLD | 335.18 | $126.17B | 7.09 M sh | $2.60B/day | **pass (252×)** | deep |
| TLT | 80.35 | $47.35B | 35.05 M sh | $2.84B/day | **pass (95×)** | deep |

All five clear the price floor by two orders of magnitude and the liquidity bar by roughly 80–250×.
At a risk-sized ticket — $19k–35k of market value in the §4.4 guard runs — nothing here is within
reach of the [documented] "fill only against 20× real volume" rule.

### 3.2 The bear leg (the inverse ETF every short needs) — this is where it breaks

| pair | last | net assets | 20-session ADV | avg $ turnover | true lev | $500M |
|---|---|---|---|---|---|---|
| IWM → **TZA** | 54.20 | **$197.6M** | 4.07 M sh | $190.6M/day | 3× | **fail (0.40×)** |
| IWM → SRTY (alt) | 30.53 | $75.7M | 2.17 M sh | $58.6M/day | 3× | fail (0.15×) |
| XLF → **FAZ** | 34.74 | **$94.1M** | 1.95 M sh | $62.8M/day | 3× | **fail (0.19×)** |
| XLE → **ERY** | 9.50 | **$50.3M** | 23.53 M sh | $198.6M/day | **2×** | **fail (0.10×)** |
| GLD → **GLL** | 32.00 | **$93.2M** | 2.74 M sh | $74.1M/day | **2×** | **fail (0.19×)** |
| TLT → **TMV** | 44.81 | **$200.2M** | 1.44 M sh | $62.4M/day | 3× | **fail (0.40×)** |
| *(live)* QQQ → SQQQ | 49.42 | $1.76B | 44.64 M sh | $1.89B/day | 3× | pass |
| *(live)* SPY → SPXS | 29.71 | $322.7M | 14.17 M sh | $370.1M/day | 3× | **fail — already live** |

**Not one candidate bear vehicle is eligible under the stated floor, and neither is the SPXS the
desk has been trading.** Liquidity is not the problem — ERY turns over $199M/day and TZA $191M/day,
more than enough for a $20k ticket. Eligibility is the problem, and it is structural: the inverse
ETFs that clear $500M are the broad-index and semiconductor ones, i.e. exactly the tech/semi
exposure the desk already has. Diversifying the *short* book through inverse ETFs necessarily
imports a sub-$500M instrument.

Two honest caveats on the bar itself:
- The floor is stated for "stocks"; whether it binds ETF **net assets** is an open question already
  raised in `docs/decisions/ticker-universe-nov20.md` §5.2 / §13.1 and never answered. If the
  organisers say it does not apply to ETFs, §3.2 stops being a blocker and the ranking in §7 is
  the operative one.
- `guard.py` does not enforce it either way: `min_market_cap_usd: 500000000` exists in
  `rules.json` and appears in no code path (prior memo §7.4). So a ticket for GLL would be
  **approved by the desk** and would very likely fill — nothing in the system would stop it.

### 3.3 What the equity universe actually looks like after this

`universe.shares` would go from 9 to 18 symbols, `leverage` from 5 to 10. Composition by sector
before and after:

- **before:** SPY, QQQ, SMH (long) + SQQQ, SOXS, SPXS (short) + TQQQ, SOXL (long, unreachable),
  IWM (long, unreachable). Semis/tech = 6 of 9 tradable names.
- **after (all five):** adds IWM, XLF, XLE, GLD, TLT + TZA, FAZ, ERY, GLL, TMV. Tech/semi share
  falls from 6/9 to 6/18. That is the actual diversification gain, and it is delivered almost
  entirely on the **long** side (see §2.1: 11 of 14 fires were shorts).

### 3.4 Leverage — the two 2× funds, confirmed three ways (item 2 of the task)

The task is explicit that the earlier ERY/GLL error must not repeat: a 2× fund recorded as 3×
makes `inst_stop = entry*(1 - lev*pct)` and `inst_target = entry*(1 + lev*1.5*pct)` **1.5× too far
out**, so the ticket understates risk against the level the desk actually enforces. Three
independent lines of evidence, none of which depends on the others:

1. **Issuer wording.** Direxion's own product page and fact sheet: TZA "seek daily investment
   results … of 300 %, or 300 % of the inverse (or opposite), of the Russell 2000"; ERY "of 200 %,
   or 200 % of the inverse (or opposite), of the Energy Select Sector Index". ⚠ These domains
   refuse direct fetches from this environment, so the quotations are from the search index of the
   issuer's own pages, not a page I rendered — see the caveat in §9.
2. **60-session daily-return regression**, `beta` of the inverse on the underlying (`.scratch/tickdiv/adv.py`,
   `out_adv.txt`), calibrated on the two **known** 3× live pairs:

   | pair | beta | r | reads as |
   |---|---|---|---|
   | QQQ → SQQQ *(calibration)* | **−2.975** | −1.000 | 3× |
   | SPY → SPXS *(calibration)* | **−2.997** | −1.000 | 3× |
   | IWM → TZA | −2.982 | −1.000 | 3× |
   | IWM → SRTY | −2.973 | −1.000 | 3× |
   | XLF → FAZ | −2.913 | −0.999 | 3× |
   | TLT → TMV | −2.961 | −0.998 | 3× |
   | **XLE → ERY** | **−1.987** | −0.999 | **2×** |
   | **GLD → GLL** | **−2.005** | −0.999 | **2×** |

   The two calibrations are the point: this method returns ≈ −2.98 for a fund that is certainly 3×,
   so −1.99 is not a rounding artefact, it is a different product. r ≈ 1.0 throughout, so the
   ratio is precise, not noisy.
3. **Six-session ratio table** already in `docs/decisions/ticker-universe-nov20.md` §2: on the two
   large-move days (where a 2×/3× error cannot hide in rounding) ERY printed 1.98× the inverse of
   XLE and GLL 2.01× the inverse of GLD; a 3× fund would have printed ≈ +9.8 % and ≈ +9.6 %.

Vendor name strings agree ("Direxion Daily Energy Bear **2X**", "ProShares UltraShort Gold /
2倍做空黄金") but are **not** counted as one of the three — the moomoo label table is known to be
wrong at least once in this project's records (EDZ labelled 3× when it is not), which is why the
regression exists at all.

Consequence for the package: `PAIRS["XLE"].lev = 2`, `PAIRS["GLD"].lev = 2`, and `universe.leverage`
carries `"ERY": 2, "GLL": 2`. `verify.py` check B fails if any of the three copies disagree.

---

## 4. The 5-artifact change set, with before-snapshots (item 3 of the task)

Package: [`.scratch/changes/2026-11-20-ticker-diversification/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-ticker-diversification/)

```
before/    rules.json · trend_signal.py · chop.py  (verbatim live bytes) + the two template dumps
proposal/  apply.py   — builds every artifact from before/, anchors must match exactly once
           verify.py  — compiles, cross-checks, replays, and runs guard per new instrument
out/       *.after, diff/*.diff, universe.json, verify.txt
```

Live versions and hashes the package is cut against **[observed, 03:0xZ]**:

| artifact | live version | file | sha256 |
|---|---|---|---|
| desk-risk-guard | `1795138181446404` | `references/rules.json` | `49dbeaf4…fff4b` |
| trend-signal | `1795047415929677` | `scripts/trend_signal.py` | `60d5573d…bed8` |
| vwap-chop | `1795095917868411` | `scripts/chop.py` | `43810bd7…72e9` |

### 4.1 The five artifacts, one row each

| # | artifact | anchor in live bytes | change | release action | blast radius |
|---|---|---|---|---|---|
| 1 | `trend_signal.PAIRS` | `trend_signal.py:18-22` | one key per candidate `{long, short, lev}` | **new trend-signal version**; re-pin **researcher** | which tickets exist at all; stop/target conversion at `:195-196` |
| 2 | `chop.INVERSE` | `chop.py:28-29` | same keys `(short, lev)`; `FAMILY` derives itself | **new vwap-chop version**; re-pin researcher, risk_auditor, executor | Sleeve C coverage and its instrument levels |
| 3 | `universe.shares` **and** `universe.leverage` | `rules.json` `universe` block | add each long and its vehicle to `shares`; add each vehicle to `leverage` with its true ratio | **new desk-risk-guard version**; re-pin researcher, risk_auditor, executor | the veto list and every size cap |
| 4 | researcher SCAN step 1 | template `system` | `"For QQQ, SMH, SPY:"` → `"For QQQ, SMH, SPY, IWM, XLE, XLF, GLD and TLT:"` | template `POST` | which symbols the researcher even quotes |
| 5 | coordinator strategy line | template `system` | ticker list **and** the hardcoded `3x` → per-pair leverage | template `POST` | the doctrine the auditor reasons from |

Artifacts 1–3 are three copies of one mapping and must ship atomically: `PAIRS` ahead of
`rules.json` is caught by guard (`"not in the approved share universe"`) — the safe direction;
`rules.json` ahead of `PAIRS` leaves a universe nothing can emit; `shares` ahead of `leverage` is
**silently unsafe** (§4.4).

### 4.2 Per-candidate hunks

These are wrapped for width. The authoritative byte-level diffs are `out/diff/*.diff`, generated by
`apply.py` against the `before/` bytes; `verify.py` check B refuses any package where the three
copies of a pair disagree.

```diff
   "QQQ": {"long": "QQQ", "short": "SQQQ", "lev": 3},
   "SMH": {"long": "SMH", "short": "SOXS", "lev": 3},
   "SPY": {"long": "SPY", "short": "SPXS", "lev": 3},
+  "IWM": {"long": "IWM", "short": "TZA", "lev": 3},      # or SRTY, §7
+  "XLE": {"long": "XLE", "short": "ERY", "lev": 2},      # 2x — not 3
+  "XLF": {"long": "XLF", "short": "FAZ", "lev": 3},
+  "GLD": {"long": "GLD", "short": "GLL", "lev": 2},      # 2x — not 3
+  "TLT": {"long": "TLT", "short": "TMV", "lev": 3},
```

```diff
-INVERSE = {"QQQ": ("SQQQ", 3), "SPY": ("SPXS", 3), "SMH": ("SOXS", 3)}
+INVERSE = {"QQQ": ("SQQQ", 3), "SPY": ("SPXS", 3), "SMH": ("SOXS", 3),
+           "IWM": ("TZA", 3), "XLE": ("ERY", 2), "XLF": ("FAZ", 3),
+           "GLD": ("GLL", 2), "TLT": ("TMV", 3)}
```

```diff
-    "shares": [..., "SPXS"],
+    "shares": [..., "SPXS", "XLE", "XLF", "GLD", "TLT", "TZA", "ERY", "FAZ", "GLL", "TMV"],
     "option_underlyings": ["SPY", "QQQ", "IWM", "SMH", "XSP"],
-    "leverage": {"TQQQ": 3, "SQQQ": 3, "SOXL": 3, "SOXS": 3, "SPXS": 3}
+    "leverage": {"TQQQ": 3, "SQQQ": 3, "SOXL": 3, "SOXS": 3, "SPXS": 3,
+                 "TZA": 3, "ERY": 2, "FAZ": 3, "GLL": 2, "TMV": 3}
```

(`IWM` is already in `shares`, so it is not repeated — `apply.py` appends only absent symbols; the
first version of the patch emitted it twice and the verifier caught it.)

```diff
-1. For QQQ, SMH, SPY: get price, VWAP, and the high and low of the first six 5-minute bars.
+1. For QQQ, SMH, SPY, IWM, XLE, XLF, GLD and TLT: get price, VWAP, and the high and low of the first six 5-minute bars.
```

```diff
-...breakouts on QQQ, SMH and SPY that agree with VWAP; bullish ideas buy the 1x ETF, bearish
-ideas buy a 3x inverse ETF (SQQQ, SOXS, SPXS);...
+...breakouts on QQQ, SMH, SPY, IWM, XLE, XLF, GLD and TLT that agree with VWAP; bullish ideas buy
+the 1x ETF, bearish ideas buy the paired inverse ETF at the leverage its own pair carries
+(SQQQ 3x, SOXS 3x, SPXS 3x, TZA 3x, ERY 2x, FAZ 3x, GLL 2x, TMV 3x);...
```

That last one is why artifact 5 cannot be a mechanical append: the shipped sentence asserts every
bearish expression is 3×, and two of the five pairs are not.

### 4.3 Templates: what each one needs, and today's budget

| template | writes needed | last written (UTC) | budget today |
|---|---|---|---|
| researcher | prompt (art. 4) + re-pin trend-signal, vwap-chop, desk-risk-guard | **2026-11-20T01:29:44Z** | **spent** |
| risk_auditor | re-pin vwap-chop, desk-risk-guard | **2026-11-20T01:29:44Z** | **spent** |
| executor | re-pin vwap-chop, desk-risk-guard | **2026-11-20T01:29:44Z** | **spent** |
| coordinator | prompt (art. 5) | 2026-11-19T14:05:04Z | **available** |
| executor-gating-rehearsal (not production) | none needed | 2026-11-20T01:22:41Z | spent |

[observed — `GET /forward/templates`, API returns `+08:00`, converted to UTC.] So **three of the
four production templates that a release must touch are already spent for 2026-11-20**, and the
only writable one (coordinator) cannot carry the change alone: a coordinator prompt that names
tickers the researcher never quotes and the engine cannot emit is worse than no change. A partial
release is not possible; the earliest coherent window is the next template-budget reset.

### 4.4 Offline verification of the package — 42/42 pass, no network

`.scratch/changes/2026-11-20-ticker-diversification/out/verify.txt` **[observed]**:

- **A. compile** (2) — both patched modules compile.
- **B. cross-artifact coherence (32)** — for each of the five pairs: `PAIRS[t]` equals the spec,
  `INVERSE[t]` equals the spec, `FAMILY[short]` maps back, both symbols are in
  `universe.shares`, and `universe.leverage[short]` equals the pair's leverage; `shares` has no
  duplicate (18 unique); the three live pairs are byte-unchanged.
- **C. replay fidelity** — all **70** replayed stamps reproduce the verdicts recorded in §1 when
  run through the *patched* engine.
- **D. desk-risk-guard**, live `guard.py` bytes + patched `rules.json`, flat $100k account, one
  real ticket per new instrument at the replay's own levels:

  | ticket | qty | risk | stop |
  |---|---|---|---|
  | IWM 272.07 (long) | 113 | $264.18 | 269.75 |
  | ERY 9.41 (long the vehicle, short XLE) | 2,187 | $177.67 | 9.33 |
  | FAZ 33.15 | 583 | $264.52 | 32.70 |
  | GLL 30.35 | 1,153 | $163.78 | 30.21 |
  | TLT 80.20 | 436 | $67.52 | 80.05 |

  All five approved with a recorded stop level — including GLL and ERY, which the eligibility
  floor says should not be tradable at all. That is the point: **the desk cannot police this
  itself**; the floor is a decision, not a guard rail.
- **E. paired-edit arithmetic** — a $40k position in TZA books $120k of effective gross with the
  paired edit and $40k if it were added to `shares` but omitted from `leverage` (understated by
  67 %); ERY at 2× understates by 50 %. This is `guard.py`'s `leverage.get(ticker, 1)` default,
  reproduced on the new instruments.

---

## 5. Interaction with in-flight work, and whether ordering matters (item 4)

**a) The SPXS-eligibility packages (`.scratch/changes/2026-11-20-spxs-eligibility/`) — direct
collision, and ordering matters.**
- Packages `A-remove-spxs` and `B-substitute` (SWAP-SPXS-SH) edit **the same four lines** this
  package edits: `rules.json` `universe.shares`, `universe.leverage`, `trend_signal.PAIRS`,
  `chop.INVERSE`. They are not adjacent work; they are overlapping work.
- `A` removes SPXS, so `PAIRS["SPY"].short` disappears; `B` swaps in SH at 1×. If either ships
  first, this package's `before/` bytes are stale. `apply.py` would then **abort loudly** on the
  changed anchors (exactly-once match), which is the behaviour I want rather than a silent
  mis-patch — regenerate with `apply.py` against the new live bytes.
- **Order of operations:** settle the SPXS question first, because it is the same question asked
  about the one name already in production. If the answer is "the $500M bar does not apply to ETF
  net assets", then nothing changes for SPXS and every candidate in §3.2 becomes admissible at
  once, and this package ships whole. If the answer is "it applies", then SPXS must come out
  (package A), **and the bearing in §2.2 is that this whole package should not ship either** — it
  would replace one ineligible vehicle with five.
- Do **not** run them interleaved. Two publishes of desk-risk-guard and trend-signal inside one
  day, each re-pinning the same templates, would exceed the per-template daily budget anyway
  (§4.3), so the constraint enforces itself.

**b) `docs/decisions/regime-robustness-nov20.md` — no file conflict, real behavioural overlap.**
- Its **A2** (gate `allow_bearish_etf` on the prior-close tape, so shorts are permitted only when
  the classifier already says the tape is bearish) keys off the `normal` label. Both replay days
  are `caution` and `bear_high_vol`, so **A2 would have changed none of the 14 fires in §1.2** —
  worth saying plainly, because the opposite is the intuitive guess. The overlap is about the
  future rather than these two sessions: the 84-session study found the `normal`-day short cell at
  −$1,281.77 over 33 trades, and `normal` is where most ticket *frequency* comes from (66 of 84
  sessions). So a universe expanded on §1's two-day count is a universe whose incremental shorts
  would spend most of a normal week inside the cell A2 proposes to close. If both are wanted: A2
  first, then re-run this replay on the gated engine before shipping — the ordering is
  behavioural, not technical.
- Its **B1** (fill-anchored levels) changes the numbers in §1.2, not the set: the signals are
  unchanged, the stop/target are re-anchored to the fill. Note the interaction with leverage — B1
  and the 2×/3× error both feed `inst_stop`; they must not be shipped in the same version or a
  regression in either becomes unattributable.
- Its **B4** (the 1.5 % opening-range ceiling) is the gate that produced XLE's five NONE on 18 Nov
  (width 2.63–2.66 %). Loosening it would add XLE-class tickets without touching the universe. If
  the goal is more tickets, B4 is cheaper than this package — it needs no new instrument and no
  eligibility argument.
- Its §7 explicitly puts "universe expansion" out of scope for the remaining five sessions. This
  memo does not contradict that: it prepares and measures, and recommends no in-window ship.

**c) Already-shipped state that this package must not disturb.** desk-risk-guard
`1795138181446404` carries the calendar `no_entry [("11:45","12:30")]` window (Cook speech) in
`calendar_rules.py`. Artifact 3 touches only `references/rules.json`; `calendar_rules.py`,
`guard.py`, `book.py`, `levels.py` are untouched, so the 11:45–12:30 gate survives the release by
construction. The 14:00 XLE fires on 19 Nov sit outside that window; none of the fires in §1.2
would have been inside it.

---

## 6. The owner's watchlist (item 5)

**The tool is readable, and its name is verified rather than guessed [observed].**
`quote_user_security` with `group_name="US"` returns the account's watchlist; `quote_market_snapshot`
with the resulting `code_list` returns the fields used below. Note that
`quote_stock_screen` with `user_stock_list_mode: 1` returns **`items: [], total: 0`** on this
account's MCP auth (two attempts, including a property-based query), so the watchlist is *not*
reachable through the screener — it is reachable through `quote_user_security`. No
Accounts & Orders or Trade Execution scope was touched; these are quote-side tools only.

**Contents: 123 rows — 12 futures, 1 index, 7 ETFs, 103 stocks [observed].** The seven ETFs are
SPY, QQQ, SMH, IAU, TLT, SLV, DRAM.

### 6.1 The P/E TTM screen cannot be applied to a vehicle, and here is why

**Every ETF in the payload reports `pe_ttm_ratio = 0`** — SPY, QQQ, SMH, IAU, TLT, SLV, DRAM all
zero, which is correct behaviour for a trust with no earnings. So the instruction "positive TTM
P/E below 40" is **undetermined at the vehicle level**, not failed: there is no fund-level earnings
figure in this data to screen. I am not substituting a proxy and calling it a P/E. If a fund-level
earnings yield is wanted, the substitute source is the fund's own fact sheet (which the Desk has no
pipeline for) — I am reporting it undetermined rather than inventing a number.

For the 103 single stocks the screen is well defined and I applied it literally
(`0 < pe_ttm_ratio < 40`):

| outcome | count |
|---|---|
| **pass** (price > $1, cap ≥ $500M, 0 < P/E TTM < 40) | **71** |
| rejected — P/E ≤ 0 | 14 — ANT(−10.5), ASTS(−12.1), CRWV(−9.8), NET(−453.3), RKLB(−137.8), INTC(−23.7), IREN(−3.6), RDW(−5.4), ZS(−527.5), SPCX(−547.2), WULF(−6.9), KHC(−8.5), COHU(−85.0), MRNA(−28.3) |
| rejected — P/E ≥ 40 | 17 — NBIS(346.1), SBUX(47.3), TSLA(411.4), LLY(43.9), COST(52.7), AVGO(44.2), PLTR(108.2), AMD(106.1), CRDO(41.5), NOK(48.7), BE(101.9), MRVL(45.9), GLW(42.9), WMT(45.7), JNJ(40.6), CRWD(6406.8), MRK(134.2) |
| rejected — price | 1 — CRNX (last price $0 in the payload) |
| rejected — market cap | 0 |

### 6.2 Watchlist candidates, labelled by provenance

**From the owner's watchlist — ETFs that clear the floor on the long side (P/E undetermined):**

| ticker | what it is | net assets | vs the $500M floor | inverse pair |
|---|---|---|---|---|
| **IAU** | iShares Gold Trust | $55.67B | **pass (111×)** | GLL (gold, 2×, $93.2M) — **fails** |
| **SLV** | iShares Silver Trust | $22.86B | **pass (46×)** | not measured this session — **undetermined** |
| **DRAM** | memory/semiconductor ETF | $14.17B | **pass (28×)** | none located — and it is semis, i.e. the exposure the desk already has |

**From the owner's watchlist — stocks that pass all three screens.** 71 pass, but none of them can
be expressed other than **long**: a single stock has no inverse ETF, so a bearish view on it would
mean a direct short (which this desk's engine cannot emit — `PAIRS` maps to an instrument, and the
guard's "buys to open" invariant assumes purchases). The liquid non-tech names among the 71 that
would diversify away from semis include BRK.B ($1.2T, P/E 16.0), KO ($413B, 28.3), XOM ($648B,
16.4), PEP (P/E 17.5), FDX (8.7), NEE (15.1), CVX (15.2), TTE (8.6), GSK (17.1). Every one of them
is **long-only** in this architecture, which matters because §1.3 shows longs are vetoed on exactly
the tape the desk is currently in.

Honest reading: **the watchlist does not supply a short-side candidate.** Its ETFs are gold, silver
and semis; its stocks have no inverse. The watchlist adds long-side breadth (IAU and SLV are
genuinely independent of equity beta, unlike IWM/XLF/XLE) but nothing that addresses the 11-of-14
short skew in the replay.

---

## 7. Ranking, highest priority first (item 7)

Ranked by (fires in the replay × direction coverage) ÷ (eligibility distance + ship cost). The
expected-frequency column is a **two-session count**, not a rate estimate; the context column is
from `regime-robustness-nov20.md`, which measured 16 tickets in 15 `caution` sessions and 1 ticket
in 3 `bear_high_vol` sessions over 84 sessions.

| rank | candidate | fires (18–19 Nov) | of which shorts | vehicle | liquidity of vehicle | why here |
|---|---|---|---|---|---|---|
| **1** | **IWM → TZA** | **4** (2 long, 2 short) | 2 | 3×, $197.6M | $190.6M/day | only candidate that fired in **both** directions; already in `universe.shares` and `option_underlyings`, so it is the only one that is half-wired; TZA is the closest bear vehicle to the bar (0.40×); source ETF is $75B with 18.8M-share ADV. SRTY is the alternative vehicle (thinner: $75.7M, $58.6M/day) |
| **2** | **XLF → FAZ** | **3** (all short) | 3 | 3×, $94.1M | $62.8M/day | fired at **10:17 on both days** — i.e. in the same batch the researcher actually reads, so its signal would arrive in the same handoff as the real tickets; XLF is the deepest source ETF in the set ($2.12B/day). FAZ is thin: 1.95M-share ADV |
| **3** | **XLE → ERY** | **3** (all short) | 3 | **2×**, $50.3M | **$198.6M/day** | best *vehicle* liquidity of any candidate, and the only one whose fires persisted across three consecutive stamps. Costs the most: 2× forces the coordinator-prompt rewrite and is the pair where a leverage typo does the most damage (ERY is a $9.50 instrument; a 3× stop on a 2× fund is 1.5× too far) |
| **4** | **GLD → GLL** | **3** (all short, one morning) | 3 | **2×**, $93.2M | $74.1M/day | the only 10:05 fire in the whole sample, and a genuinely independent sleeve (gold does not follow the equity tape). Held back because all three fires are one 90-minute stretch on one day, and GLL is thin at 2.74M shares |
| **5** | **TLT → TMV** | **1** (long) | 0 | 3×, $200.2M | $62.4M/day | worst frequency: one fire in ten stamps, and its 19 Nov activity was a *long* the regime vetoed. TLT's opening range was 0.36–0.43 % — inside the band but close to the 0.15 % floor, which is the mirror-image risk of XLE's 2.6 % ceiling |

**If only one ships: IWM.** It is the only candidate whose incremental tickets are not all shorts,
it needs one `shares` line and no new name in `shares` at all (IWM is already there), and it is the
smallest state space. **If the $500M floor is read strictly (§3.2), none ships** — that is the
honest answer and it is the owner's call, not a packaging detail.

---

## 8. What would change the answer

1. **The $500M question, answered for ETFs.** Applies → nothing in §3.2 is admissible and the
   correct move is to shrink the short book (SPXS package A), not grow the universe. Does not
   apply → §7 is operative, ship IWM first.
2. **Direct short selling as the bearish expression.** [documented] `docs/contest-rules-notes.md`
   §"Important open design question": short selling is natively available on this account (60 %
   initial margin, 6 %/yr). A short of XLE is an eligible instrument; ERY is not. That route keeps
   every traded instrument inside the floor and removes the whole of §3.2 — at the cost of
   changing the engine's "never short shares: inverse ETFs have no borrow fee" comment
   (`trend_signal.py:17`), `guard.py`'s buy-to-open invariant, and adding daily short-interest
   accrual. **It is the only route I found that satisfies the floor and the 11-of-14 short skew at
   the same time.** It is a bigger build than 5 artifacts and should be measured, not shipped.
3. **A third and fourth session of bars**, to turn the two-session fire count in §1 into a rate.
   One caveat to budget for: 5-minute klines are token-heavy (~78 KB per symbol-session); pull
   them scripted to disk, as here, not in a conversation turn.
4. **The handoff latency.** Nothing in this memo fixes the 21 m 47 s that voided the only two
   approvable signals of the week. If that is not fixed, universe size is irrelevant — a bigger
   universe produces more signals that die in the same queue.

---

## 9. Reproducing this memo

```bash
P=/c/Users/tteh/AppData/Local/Programs/Python/Python312/python.exe
cd .scratch/tickdiv          && $P adv.py    > out_adv.txt      # ADV + 60-session return beta
                             && $P screen.py > out_screen.txt   # watchlist screen
                             && $P replay.py --pairs live      > out_replay_live.txt
                             && $P replay.py --pairs candidate > out_replay_cand.txt
cd ../changes/2026-11-20-ticker-diversification/proposal
$P apply.py  --candidates IWM,XLE,XLF,GLD,TLT                    # build artifacts + diffs
$P verify.py                                                     # 47 checks, no network
```

Sources: this repo — `docs/contest-rules-notes.md`, `docs/decisions/ticker-universe-nov20.md`,
`docs/decisions/regime-robustness-nov20.md`, `docs/decisions/vix-gate-and-zero-trades-nov20.md`,
`AGENTS.md`; live bytes in `.scratch/changes/2026-11-20-spxs-eligibility/live/`;
`.scratch/tickdiv/`.

External, read 2026-11-20: the Direxion product/fact-sheet text for TZA ("seek daily investment
results … of 300%, or 300% of the inverse (or opposite),") and ERY ("of 200%, or 200% of the
inverse (or opposite),") — [Direxion TNA/TZA product page](https://www.direxion.com/product/daily-small-cap-bull-bear-3x-etfs),
[TNA/TZA fact sheet](https://www.direxion.com/uploads/TNA-TZA-Fact-Sheet.pdf),
[Direxion ERX/ERY product page](https://www.direxion.com/product/daily-energy-bull-bear-2x-etfs),
[ERX/ERY fact sheet](https://www.direxion.com/uploads/ERX-ERY-Fact-Sheet.pdf). **Method caveat:**
both issuer domains refused direct fetches from this environment (`fetch failed`, 3 attempts), so
those quotations come from the search index of the issuer's own pages, not from a page I rendered
myself. They are corroborated independently by the regression in §3.4 — which is the evidence I
actually rely on.
