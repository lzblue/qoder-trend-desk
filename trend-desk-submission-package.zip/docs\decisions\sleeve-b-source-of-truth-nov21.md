# Sleeve B — source of truth (2026-11-21)

**What this file is.** The single authoritative record of everything known about Sleeve B (the option
sleeve) on the Moomoo × Qoder trend desk: what is live in the cloud, what exists only on this disk, what
was measured, what was disproved, what the owner now wants instead, and the exact gap between those two.
It is written for an AI agent with **no prior context** in this conversation.

**Provenance of the target strategy.** The owner pasted a spec titled *"0DTE Option Strategy — Legged
Iron Fly (Contest Nov 23–27)"*, sourced from a `claude.ai` artifact
(`https://claude.ai/artifact/Sdceh4EhxkLmx7Xdn1oBQ6`). That URL is **not machine-readable**: an
authenticated fetch returns only the claude.ai application shell, no content. §4 below is therefore the
canonical record of that spec in this repository. If the two ever disagree, the owner's artifact wins —
but re-read it before assuming a disagreement exists.

**Evidence labels used throughout.** `OBSERVED` = I read it today from a live endpoint, a live skill
download, or the local bytes. `DOCUMENTED` = stated by a file in this repo, cited by path. `INFERRED` =
arithmetic on OBSERVED inputs. `UNDISCOVERABLE` = no endpoint or file can answer it. Nothing here is
asserted without a label and a source.

**Nothing in this file was applied.** No skill publish, no re-pin, no template write, no schedule write,
no `rules.json` edit, no order on any account. All cloud interaction was GET/quote-level.

---

## 1. State in one paragraph

Sleeve B is **orphaned**: the `option-adapter` skill exists and has four published versions, but it is
bound to **0 templates** and the word "adapter" appears **0 times** in all four live system prompts
(OBSERVED). Sleeve C (`vwap-chop`) *is* wired — bound to 3 templates and named in the researcher and
auditor prompts. The strategy that Sleeve B currently implements is a **debit put hedge** sized on
premium paid; the owner's new spec is a **0DTE credit structure** sized on maximum loss. Those are not
two settings of one design — the sizing, risk, exit and journal semantics all differ. The pending
publish candidate (WS1's v5) implements the *old* design and must not be published (see §7).

## 2. Why the pivot is evidence-led, not a mood

The desk's own backtest (`docs/decisions/sleeve-b-backtest-nov21.md` §9–§11, written 2026-11-21)
measured, over 245 signals in three regimes:

| horizon | median achievable R:R (BULL / SIDEWAYS / BEAR) | % clearing 1.5R |
|---|---|---|
| **0DTE** | **1.63 / 1.84 / 2.00** | 60.2% / 67.2% / 72.5% |
| 1DTE | 0.59 / 0.65 / 0.67 | 3.0% / 0.0% / 11.8% |
| 5DTE | 0.25 / 0.27 / 0.27 | — |

Discount applied honestly by the same memo: true ratio = **0.83× modelled** (dense-grid factor), worst
matched cell **0.48×**, so the 0DTE pass rate is only known to lie between **~12% and ~55%**. The
**~2.8× step from 1DTE to 0DTE is a `sqrt(T)` consequence and is level-independent** — that step is the
part worth acting on. Stated as a burden on the parent equity strategy: to satisfy 1.5R at 1DTE the stop
must be **2.4–2.6× wider** than the engine computes ($4.67 vs $2.03 median); at 0DTE the multiplier is
**0.83×** — no widening at all.

Mechanism, in the memo's own framing: *the desk buys 1–5 days of theta on a position its own FLAT rule
forbids holding past 15:45 ET.* A 0DTE structure removes exactly that self-inflicted handicap. This is
why `dte_min: 1 → 0` is called the single highest-leverage available change, and why the owner's iron-fly
spec — which is 0DTE by construction — is the strategy form the measurements point at. It is **not** a
claim of edge; §8 lists what is still unknown.

## 3. Live cloud configuration (OBSERVED 2026-11-21T06:3–07:1Z)

Re-verify with (PAT in `.env`, never printed): `GET https://api.qoder.com/api/v1/forward/skills`,
`/schedules`, `/templates/<id>`. **A live GET is the only truth** — `AGENTS.md` is a stale 2026-11-17
snapshot and must not be trusted for config.

| Item | Value |
|---|---|
| Templates | coordinator `tmpl_19f984c8f0fd516965b63998` · researcher `tmpl_d7df3829ed5d73548bb5e9ed` · executor `tmpl_6c3c42cc4500efcbd6d60309` · risk_auditor `tmpl_bf2c477c0fba1a3363833f91` |
| Prompt field | **`system`** — not `system_prompt`. Probing the wrong key silently returns "no matches", which is how a check can fool its author. |
| `option-adapter` | `skill_00w0ip0yri8sgag736ks`, `latest_version 1795137189020914`, **`binding_info.agent_template_count: 0`**, description ends *"Proposes only; it has no order path"*, `metadata.source: sleeveb-build` |
| Other skills | `desk-risk-guard skill_00vqwa9tq5szk3y13lg4` · `trend-signal skill_00vqvkdtlzojk2xg1rku` · `decision-journal skill_00vqvbzcimznkggtyd1t` · `vwap-chop skill_00vz0dq461mv4e5iv1p3` (bound to 3) |
| Adapter versions | 4 published, sizes 13,579 → 14,556 → 15,451 → 15,698 B |
| Pins | every binding on every production template carries an explicit version; nothing resolves to `latest`. The effective config **omits** the version key entirely when unpinned. |
| Accounts | **5830104** = contest paper ($100k virtual, cloud desk only, never touched from this desktop) · **3732983** = "US Margin Account [Paper Trading]", this desktop's account |
| Schedules | 7, all on the coordinator: BRIEF 09:00, SCAN 10:05/11:00/12:30/14:00, FLAT 15:30, REPORT 16:15 ET. `execution.timeout_ms` = 3,000,000 (SCAN-1005) / 5,100,000 (other SCANs) / 1,800,000 (rest). **0 OPT-CHECK schedules exist.** |

### 3.1 Live `rules.json` option keys (OBSERVED, from the downloaded live skill tree)

`risk.option_trade_risk_pct: 0.5` · `risk.max_open_option_premium_pct: 1.5` · `risk.dte_min: 1` ·
`risk.dte_max: 5` · `risk.option_underlyings: ["SPY","QQQ","IWM","SMH","XSP"]` (**no SPX/SPXW**) ·
`risk.hedge_premium_pct: 1` · `risk.hedge_max_multiplier: 1.5` ·
`fees.option_min_commission: 1.99` · `fees.option_platform_per_contract: 0.3` ·
`fees.option_fee_max_pct_of_premium: 3.0`.

Verified by leaf-level diff: the WS1 publish candidate's `rules.json` differs from live by **exactly one
key** (`option_trade_risk_pct 0.5 → 1.0`). An earlier claim that it also removed SPXS was **false** —
"SPXS" appears zero times in either file. No live code reads `option_underlyings` (OBSERVED by grep), so
that list is prompt-driven.

### 3.2 Live `guard.py` — what the option branch actually does (OBSERVED, md5 `94169a5656a7b31911adb12cfcce3286`, 41 identical copies)

| Line | Behaviour | Consequence for a credit structure |
|---|---|---|
| `:66-68` | `option_round_trip_fee = 2 × (1.99 + 0.30 × n)` — hardcodes **2 orders**, no `max(1.99, 0.65n)` | Understates a 4-leg fly ~2–4× |
| `:236-237` | `o = proposal["option"]`; `cost1 = o["premium"] × 100` | **Premium-debit basis.** No legs, no width, no max-loss concept |
| `:240` | `if not 7 <= o.get("dte", 0) <= 45: veto` — **inside the `sleeve == "hedge"` branch only** | Does *not* block a 0DTE Sleeve B |
| `:245-248` | `budget = nav × option_trade_risk_pct/100 × mult`; `qty = floor(budget / cost1)` | Sizing measures premium, not risk |
| `:249-250` | `qty < 1` → veto *"option premium exceeds the sleeve budget"* | **Hard blocker for SPX — see §3.4** |
| `:252` | veto if fee > 3% of `qty × cost1` | Denominator is premium, wrong for credit structures |
| `:258-259` | 0DTE → **warning**, text says *"ETF options auto-exercise after 16:00 ET"* | Factually wrong (only ITM options are) |
| `:261-263` | `protection.mechanism = "monitored"`, note: no STOP order type exists on paper | Correct and load-bearing |
| `:169` | expectancy gate `min_trades_half_size = 10` | Unreachable in a 4-session contest |

### 3.3 Live `sleeve_b.py` — it is a single-leg engine (OBSERVED, md5 `8841758501bd0f0a3cd8b720ce460ee5`, 9 identical copies)

`grep -c leg` on the live 662-line file returns **0**. `candidates()` (`:254-266`) filters
`dte_min <= c["dte"] <= dte_max` at `:261` and sorts by `-abs(delta)` at `:266`. `pick()` (`:269-273`)
returns **one** contract of one right and prices `limit = round(premium × 1.05, 2)` (`:274`).
`dte_bounds()` (`:294-298`) reads `rules.json` and **refuses to assume a band if the keys are absent**.
`build_proposal()` (`:306-310`) emits `"option": {"premium": …, "dte": …}`.
**So the 0DTE block the spec objects to is real, but it lives here (`:261` + `:294`), not in `guard.py`.**

### 3.4 The blocker nobody has written down yet (INFERRED from §3.1 + §3.2 arithmetic)

Sizing a **1 SPXW contract** under the live keys: `cost1 = 1,783 × 100/100 = $1,783` premium basis
(§5.3), `budget = $100,000 × 0.5% × mult ≤ $500` → `floor(500/1783) = 0` → **veto at `:249`**, before any
other rule is evaluated. Even at the WS1-recommended 1.0% the budget is $1,000 and qty is still 0. This
is why SPX cannot be reached by turning a knob: the *unit of risk* is wrong, not its size.

The mirror-image failure on **SPY** is worse because it is silent. At a plausible 0DTE credit of $1.40
per lot: `cost1 = $140` → `floor(500/140) = 3 lots` approved, but 3 lots × max loss
$(5.00 − 1.40) × 100 = $360 each = **$1,080 = 1.08% of NAV** against the spec's 0.75% cap. At the
recommended 1.0%: `floor(1000/140) = 7 lots` → **$2,520 = 2.5% of NAV**, above the desk's own 2.0%
daily-loss limit. **Premium-basis sizing blocks the safe instrument and over-approves the risky one.**

## 4. The target specification, restated as requirements

Paraphrase of the owner's pasted artifact; the numbers are preserved. Design premise: **single-leg orders
only, no stop-loss orders** exist on the platform, so the worst case must come from the *shape* of the
position, not from an exit order, and the agent must perform all management.

| Element | Requirement |
|---|---|
| Underlying | SPX, else the smaller XSP if quotable/tradable, else SPY with stricter EOD rules |
| Structure | Iron fly: sell ATM call + ATM put, buy wings ~20–25 SPX points / $5 SPY away. Calmer variant: 16-delta iron condor |
| Size | Max structural loss ≤ **0.75% of NAV (~$750) per day**; one position per day |
| Entry window | **10:00–10:30 ET** only (opening range formed; desk's own entry window) |
| Leg order | ① buy put wing → ② buy call wing → ③ sell ATM put → ④ sell ATM call. Limit priced to fill immediately; **confirm each fill before sending the next**; re-price once after 60 s; if a short still will not fill, sell the wings and log **"no trade"**. **Never send a short before its wing has filled** |
| Profit target | **25% of credit**, as resting buy-back limits on the short legs (runs without the agent) |
| Loss exit | Agent check every 5–10 min. Close everything at **50% of structural max loss**, or if price closes beyond a short strike by more than half the wing width. Condor variant: loss = 100% of credit |
| Time stop | Shorts closed by **15:30 ET** (flat by 15:45); on Fri 27 by **12:30 ET** |
| Exits | Buy back threatened short first, then the other short. Sell a wing only if its **bid ≥ $0.05**, else let it expire worthless and skip the fee. On SPY also close any wing within $2 of the money by 15:45 |
| Fees | `max($1.99, $0.65 × n) + $0.318 × n` **per order**, not per round trip |
| Calendar | Full spec Mon 23 / Tue 24; Wed 25 skip if major data lands in the holding window; Fri 27 flat or a ½-size 0DTE put credit spread 10:00→12:30; **nothing open at 13:00** |
| Logging | Every leg with timestamp, fill, fee, and the rule it was checked against (part of the score) |

Scoring context the spec cites: 25% risk-adjusted return, **30% Qoder/Cloud Agent usage**, **30% strategy
and risk design**, 15% reusability and documentation; 4 sessions remain (Mon 23, Tue 24, Wed 25, Fri 27 —
Thanksgiving closed, Friday early close).

The spec's own open items, and where they actually stand: (1) the 0DTE config block is in `sleeve_b.py`,
not `guard.py`, and the *real* blocker is §3.4; (2) "can the account sell options / trade SPX" is
**half-answered** — SPX quotes are available (§5), sell-to-open is not tested; (3) options trading hours
do not affect the plan; (4) per-leg journaling needs **no skill change** (§6.4).

## 5. Instrument facts measured today

### 5.1 How to reach SPX options (OBSERVED) — and the trap

* `quote_stock_quote(["US..SPX"])` → valid: last **6910.39**, high 7198.67, low 6882.66, prev close
  7175.83, `data_date 2026-11-20` — a **−3.70%** Friday close inside a **4.40%** amplitude session.
* `quote_option_chain(symbol="US..SPX", index_option_type=1000)` → **works**: 594 rows for 2026-11-23,
  codes **`US.SPXW261123C6910000`**, `stock_owner "US..SPX"`, `lot_size 100`, `option_standard_type
  STANDARD`, `expiration_cycle WEEK`.
* `index_option_type=1002` (the value the tool's own enum labels as SPX) is **rejected**: *"must be equal
  to one of the allowed values"*, and the description asserts *"SPX(1002)/NDX(1004) currently have no
  backend data and are removed"*. **That description is what caused my false "SPX is unavailable"
  finding. Do not repeat it: use 1000.**
* `US.SPXW` and `US..SPXW` as *underlying* symbols → `invalid_symbol`. SPXW exists only at contract level.
* Near-ATM strikes are **$5 apart** (6800, 6805 … 7020 — 45 strikes); full range 3000…10000. Strike 6910
  exists, which is the ATM at 6910.39. A 20-point wing = 4 intervals ✓.
* Expiries exist for **all four contest days**: 11-23, 11-24, 11-25, 11-27 (XSP: 544/430/430/526 rows).

### 5.2 Bid/ask — the one thing that is worse on the index (OBSERVED, two independent routes agree)

| Route | SPY | SPXW | XSP |
|---|---|---|---|
| `quote_combo_option_quote` (4 legs, side+qty) | bid **−4.74** / ask **−4.38**, size 5/5 | **no bid/ask fields**, `bid_volume 0`, `ask_volume 0`, price −17.83 | **no bid/ask**, `bid_volume 0`, price −1.23 |
| `quote_order_book` (documented "US option 1 level") | 691P bid **7.13 × 5** / ask **7.22 × 10** | **`bid_list: []`, `ask_list: []`** with a fresh `exchange_data_time_ms` | not tested |

Interpretation: this is **not** "options have no book" — SPY's book came back. It is specific to the index
products. `UNDISCOVERABLE` today whether that is a permission level (LV1), a paper-account entitlement, or
weekend emptiness; it must be re-read intraday Monday (§9 check M1). Two of the spec's rules are
bid-denominated (*"priced to fill immediately"*, *"sell a wing only if its bid ≥ $0.05"*), so **without a
bid the agent would price a 4-leg structure off `last` alone, on legs with open interest of 1.**

Also OBSERVED and misleading if trusted: the combo response's `volume`/`turnover` merely **echo the first
leg** (4,662 / $3.46M equalled SPY 691C exactly). Never read them as structure liquidity.

### 5.3 A real SPXW iron fly, priced (OBSERVED — Friday's prints, 2 DTE)

| leg | last | delta | IV | theta/day | OI | volume | area |
|---|---|---|---|---|---|---|---|
| sell 6910C | 105.32 | 0.511 | 44.97 | −20.61 | **1** | 426 | **EUROPEAN** |
| sell 6910P | 58.21 | −0.489 | 25.67 | −11.14 | 141 | 1,465 | EUROPEAN |
| buy 6930C | 94.20 | 0.480 | 44.32 | −20.28 | **1** | 863 | EUROPEAN |
| buy 6890P | 51.50 | −0.438 | 26.85 | −11.58 | 92 | 1,511 | EUROPEAN |

* `contract_nominal_value 691,039` → 1 contract ≈ **$691k notional**; 20-pt width = **$2,000 gross risk**.
* credit = (105.32 + 58.21) − (94.20 + 51.50) = **17.83 pts = $1,783/lot**, matching the combo `price`
  −17.83 exactly → the combo price is (shorts − wings) in points.
* At this print the fly is **89% full** (17.83 of a possible ~20), so max loss = (20 − 17.83) × 100 =
  **$217/lot → qty 3** under a 0.75% cap. At 0DTE the credit shrinks toward the spec's ~13.75 →
  **1 contract**, i.e. the spec's design point is right for the *live* instrument.
* Fees: 6 orders × (max(1.99, 0.65) + 0.318) = **$13.85** → 3.1% of a 25% target ($445.75). The spec's
  "~5%" column is **confirmed**. Its `option_fee_max_pct_of_premium 3.0` gate at `guard.py:252` passes
  here (13.85 < $53.49), so on SPX the fee gate is not the blocker — §3.4's sizing basis is.
* `EUROPEAN` on all four legs confirms the spec's core reason for preferring the index (cash-settled, no
  early assignment). `option_area_type` for **SPY is `AMERICAN`**, so the SPY branch of the plan carries an
  early-assignment risk the spec has **no rule for** — and with $5 SPY wings (0.72% width) the shorts go ITM
  routinely by design.
* Caution on these prints: call IV 44.97 vs put IV 25.67 at the *same strike* is not a usable vol surface —
  they are single stale prints from a 4.4% range day. Use them for structure, not for IV.

### 5.4 XSP — keep it out of the plan (OBSERVED)

XSP last **691.04** = SPX/10 with the same ×100 multiplier → **$69k notional, identical to one SPY lot**.
The spec's fee advantage is a property of **SPX's $691k contract**, not of XSP. To carry the same 0.75%
risk you need ~12 XSP contracts, and then `max(1.99, 0.65n)` kicks in: ~$11.62/order × 6 = ~$70 against a
~$412 target ≈ **17% — worse than SPY's**. Its legs carry volume 30–186 and OI 0/3/0/17, and its combo
book is empty. The spec's *"both easily pass the 20×-volume fill rule"* is **false for XSP**. Recommendation
in §7: drop XSP from `option_underlyings`.

## 6. The change list, grouped into parallel chunks

**Dependency shape:** C0 must finish first (it can invalidate everything). C1/C2/C3/C5/C6 are mutually
independent and run **in parallel**; C1 and C2 must agree one JSON contract, so freeze the contract before
splitting. C4's four template writes are independent **of each other** but each is limited to 2 writes per
template per ET day (DRIVER §6.4 + `.scratch/changes/budget-ledger.json`). Schedules cannot be ledgered or
gated at all — a `sched_` write has no attribution record by the rule's own definition.

| # | Chunk | Artifacts | Tier | Blocks / blocked by |
|---|---|---|---|---|
| **C0** | 3 blocking facts | probes, no code | A (5830104 = B) | blocks C1, C2, instrument choice |
| **C1** | Adapter → structure builder | `option-adapter/scripts/sleeve_b.py`, `SKILL.md`, new `test_fly.py` | A (code) / B (enabling) | needs C0 |
| **C2** | Guard + rules → credit semantics | `guard.py:236-259`, `:66-68`, `references/rules.json`, `calendar_rules.py` | **B** (risk limits) | needs C0 |
| **C3** | Time engine | schedules (entry 10:10, checks, 15:30 / Fri 12:30) | A | nothing; credits need pricing |
| **C4** | Prompt wiring ×4 | researcher, executor, auditor, coordinator `system` | A (wording) / **B** (doctrine) | needs C1 contract |
| **C5** | Audit surface | `server.js:697` `/api/sleeveb` + `SLEEVEB_CAP_PCT` `:33`, this memo's successor, rule citations | A | needs C1/C2 output |
| **C6** | Retirement / guard-rails | READMEs of the superseded packages, `option_underlyings` | A | do **now** |

**C0 — three facts, nothing else**
1. **Can the account sell an option to open?** `UNDISCOVERABLE` without an order. The 2026-11-20 probe did
   buy-to-open → sell-to-close on 3732983 only. If sell-to-open is refused, **the entire strategy is dead**
   and C1–C5 are wasted. Test on 3732983, one contract, owner-attended; on 5830104 it is Tier B (real
   contest fees).
2. **Short-option position row shape, and a 4-leg row shape** — both `UNDISCOVERABLE` today. Decisive
   constraint already known: on the one populated option position row ever captured, `unrealized_profit`
   **and** `realized_profit` were **NULL** (even fully closed). So the loss test **must** be computed from
   `quote_combo_option_quote`, never read from the account. Also check whether an expiring OTM wing's row
   clears itself.
3. **SPXW bid/ask at intraday (§5.2 / check M1)** — decides the instrument.

**C1 — what has to be written** (the only large new code): `atm_strike()` on a $5 grid (SPX) or $1 (SPY),
`build_fly(underlying, expiry, width, qty)` returning **legs in ①②③④ order**, `credit()` /
`max_loss_per_lot()`, `qty = floor(0.0075 × NAV ÷ max_loss_per_lot)` **from the live combo quote**,
`mark_structure()` for the loss test, `exit_policy()` covering the four states (target / stop / time /
expire-worthless) plus the SPY-branch early-assignment rule, and the abort path
*"wings filled, short unfilled → sell wings → log `no_trade`"*.
Two required plumbing fixes: the **`SPXW` (contract) ↔ `US..SPX` + `index_option_type 1000` (chain)**
mapping, since `parse_osi()` (`:92-107`) will read the ticker as `SPXW` while the chain must be requested
against `..SPX`; and `dte_bounds()` (`:294-298`) must accept 0 — note it currently refuses to assume a
band when the keys are absent, so "just delete the keys" is not a workaround.
`quote_option_strategy_spread` + `quote_option_strategy` enumerate standard combos per underlying/expiry
(US equity/ETF only; HK index/JP return −8) — worth one spike before hand-rolling strike selection.

**C2 — risk semantics** (all Tier B because they change risk): sizing basis from premium → **max loss**;
`option_trade_risk_pct` either redefined or superseded by a new
`structure.max_loss_pct_of_nav: 0.75`; `max_open_option_premium_pct` reinterpreted (a credit structure
holds no premium — as written it caps *credit received*, a different quantity); fee model
`max(1.99, 0.65n) + 0.318n` **per order** with `orders_per_structure` (4 open + 2–4 close = **6–8**); the
`:252` gate denominator moved from premium to max-loss or target (it is *not* a blocker on SPX but *is*
conceptually wrong); `dte_min 0` scoped to the structure sleeve while leaving 1–5 for anything debit; the
wrong `:258-259` warning string; a fly counted as **one position** for `entries_per_scan` / one-per-scan;
`expectancy_gate.min_trades_half_size = 10` explicitly exempted (it can never be satisfied in 4 sessions,
so unmodified it vetoes the sleeve by default); and `calendar_rules.py` taught the **13:00 ET Friday
early close** (it currently closes only declared holidays and has no early-close concept).

**C3 — cadence, with the measured constraints and the cost.**
* Measured platform reality (DOCUMENTED, not re-measured today): trigger→order-ready **10–12.6 min**; full
  SCAN round trip **21m47s**; a scheduled attempt was **cancelled at 15m47.8s**. So *"every 5–10 min"* is
  not deliverable — effective worst-case enforcement lag is ~12–22 min, and **no single session can loop
  past ~15 min** to do the checking. Set 10–15 min, and state plainly in the risk doc that the loss exit
  runs late with the structure's max loss as the backstop. That is exactly the spec's own argument, so it
  is a documentation change, not a design change.
* Cost: at 10-min cadence 20–32 fires/day. Using measured per-run figures (FLAT **7.07 cr**, SCAN
  **14.97–20.54 cr**, whole desk day **100.54 cr**): **~140–230 cr/day = 2–3× the desk's entire current
  daily spend**; at 15-min ~95–160. Two mitigations to price first: fire the checks on the **executor
  template alone** (no coordinator fan-out) to stay in the ~7 cr class, and lean harder on the **resting
  25%-target buy limits**, which are the only exit that needs no session. The true cost floor for a
  "nothing to do" check is `UNDISCOVERABLE` until one is run.

**C4 — prompts.** researcher emits a *structure* (4 legs + credit + width + max loss) instead of one
signal; executor runs the legged machine (per-leg fill confirmation before the next send, one 60-s
re-price, wings-or-nothing invariant, abort-to-`no_trade`); auditor owns the quote-derived loss test, the
naked-window audit, and the fee-model override in the log; coordinator picks the run and enforces
one-position-per-day plus the Friday 12:30 close.
**Open doctrine question the owner must settle before any of this is written:** Sleeve B today is the
sleeve that *"may stay overnight"*. A fly that must be flat by 15:30 is not a hedge. If B becomes the fly,
then the coordinator's strategy line, FLAT's *"except the hedge"* exception, `hedge_premium_pct`,
`hedge_max_multiplier` and the hedge-only DTE veto at `guard.py:240` all become dead or false text, and
**the desk holds unhedged overnight gap risk Mon–Thu**. Either keep a separate hedge sleeve (extra work) or
strike the doctrine wording and accept it. Shipping prompts that still promise a hedge that no longer
exists is the worst of both.

**C5 — audit surface.** Per-leg journaling needs **no skill change**: `journal.py:9` already documents
that a `close` record carries `sleeve`, `realized_pnl`, `fees`, and `journal.py:61`
(`by.setdefault(r.get("sleeve", "unknown"), [])`) buckets `stats()` by an **unconstrained** sleeve key, so
`sleeve: "B"` works today and anything reading that stats block picks it up automatically. What is needed
is the *producer* (C4) and one computed-number rule: because the account returns NULL for option P&L, the
`close` record's `realized_pnl` must be derived from fills, and `fees` from the corrected model — a
decision the auditor log must cite. Dashboard: `/api/sleeveb` (`server.js:697`) divides by
`SLEEVEB_CAP_PCT` (`server.js:33`), a **local display constant** (1.5%) that is explicitly commented as
"not a live read"; under the fly it must become a max-loss denominator or a judge sees the wrong risk.

**C6 — retirement, do it now, costs nothing.** `docs/decisions/sleeve-b-golive-nov20.md` and
`.scratch/changes/2026-11-20-sleeveb/` + `-sleeveb-golive/` are **one `GO=1` away from executing** against
live templates (`CONFIRM=BIND-OPTION-ADAPTER` binds the **v4** adapter, whose `dte_bounds` band and
debit basis both contradict the new spec). The R:R-gate variant and the `option_trade_risk_pct 0.5 → 1.0`
recommendation are likewise superseded. Mark each README superseded-by-this-file and state the reason, in
place, without deleting anything.

## 7. Do-not-do list

1. **Do not publish WS1's `skills/after/option-adapter/scripts/sleeve_b.py`** (1,160 lines, md5
   `02e65c7c4abb2cfa1937eccc86b02d6a`). It is a *debit* hedge that adopts the `premium_quote` basis and adds
   ~500 lines of activity mode; its risk metric is the one §3.4 shows is wrong for a fly. Publishing mints
   an **immutable** version that can only be superseded, never deleted.
2. Do not run any `apply.sh` / `go-all.sh` / `template-skills.mjs` that binds the adapter as-is.
3. Do not relay or invent a `CONFIRM` token. Tokens are recomputed per build — read yours from your own
   fresh `PLAN` run. `GO=1` is typed by the owner only.
4. Do not trade or probe **5830104** without explicit Tier B authorization; probes there cost real fees
   against the contest score. Desktop-side work stays on **3732983**.
5. Do not trust `AGENTS.md` (stale 2026-11-17 snapshot) or the `index_option_type` enum text (§5.1).
6. Do not read a combo response's `volume`/`turnover` as structure liquidity (§5.2).
7. Do not price an option off `option_ex_data.premium` — use the quote `last_price` / combo bid-ask.
   DOCUMENTED: one capture showed 0.123 vs 8.55 for the same contract; the wrong field produced a $0.13
   unfillable limit.
8. Never score a gate or an edge against a **raw chain minimum** — a single 0.05 print at delta 0.16 fakes
   a P/delta of 0.31 that nobody could trade (DOCUMENTED, `sleeve-b-backtest-nov21.md` §11).

## 8. Known unknowns, ranked by how much they cost to resolve

| # | Question | Resolution cost | Decides |
|---|---|---|---|
| U1 | Does the paper account support **sell-to-open** on options? | ~~1 owner-attended order, ~$2 fees~~ **withdrawn 2026-11-22: CLEARED by owner attestation (DOCUMENTED, not OBSERVED on `5830104`); a refusal is now handled by `sleeve_b.py abort` + the sleeve-B disable flag** | the entire strategy |
| U2 | Does **SPXW populate a bid/ask intraday**? | 2 quote calls, ~0 | instrument (SPXW vs SPY) |
| U3 | Short-option / 4-leg **position row shape** | 1 probe round trip | how the loss test reads state |
| U4 | **Option fee schedule** — `account_order_fees` failed 3× with `-32603` | `UNDISCOVERABLE` | the log's `fees` field stays modelled |
| U5 | A **real 0DTE premium** for any past date | `UNDISCOVERABLE` — expired symbols age out of moomoo's cache 3–4 weeks post-expiry (`ret_code=-7`), so nothing before 2026-11-02 is reachable | §2's 0DTE column rests on `sqrt(T)` × a factor known only to 0.48–0.83 |
| U6 | Cost floor of a "nothing to do" management check | ~1 scheduled fire | whether C3 is 2× or 3× the daily spend |
| U7 | Does an expiring OTM wing's position row clear itself? | next expiry | whether FLAT needs a cleanup step |
| U8 | Who, if anything, hedges overnight once B is flat-by-15:30 | owner decision | whether C4 needs a fifth sleeve |

## 9. Monday pre-open checks (read-only, run before the 14:00Z BRIEF)

* **M1** `quote_order_book` on `US.SPXW<…>C<P>6910000` + `quote_combo_option_quote` for the 4 legs →
  is there a two-sided book? (re-run of §5.2, which was empty on Saturday)
* **M2** `quote_option_chain(US..SPX, index_option_type=1000, start=end=today)` → confirm today's 0DTE
  expiry is listed and the near-ATM $5 grid is intact.
* **M3** Live credit and width → recompute `max_loss_per_lot` and `qty` from **real 0DTE prices**;
  today's 2-DTE credit (17.83 of 20) will not hold.
* **M4** `GET /templates` + `/skills` read-back → confirm nothing was applied over the weekend and every
  pin is still explicit.
* **M5** Dump the current account positions before any probe (the §3.4 sizing arithmetic assumes a flat
  book and $100,000 NAV).

## 10. Decisions needed from the owner

1. **Instrument**: SPXW if M1 shows a book; otherwise SPY with an explicit early-assignment rule. XSP out.
2. **Wing width**: the spec's *"about 3% away"* contradicts its own table — 20 SPX points is **0.29%** and
   $5 SPY is **0.72%**; at a true 3% the max losses in its sizing row are 4–10× too small and 0.75% of NAV
   buys a different trade. Ship absolute widths, or restate the percentage.
3. **Cadence vs credits**: 10-min (2–3× daily spend) or 15-min, accepting ≥12-min enforcement lag.
4. **Overnight hedge**: kept as its own sleeve, or removed from the doctrine (§6 C4).
5. ~~**U1 probe**: authorize it on 3732983, or on 5830104 (Tier B, real contest fees).~~ **Answered without an
   order on 2026-11-22** — the owner attests to having sold options to open on this platform, so no probe is
   needed and none was authorised. The decision that remains is §15's: what the desk does if `5830104` itself
   refuses (abort + retire sleeve B for the contest), and who re-materialises that flag each run
   (`OWNER-RUNBOOK.md` §5.10).

## 11. Path index — where everything lives

| Purpose | Path |
|---|---|
| Published adapter source of record (9 identical copies exist) | `.scratch/sleeveb/build/option-adapter/scripts/sleeve_b.py` |
| Live downloads (the ground truth for §3) | `.scratch/bt-sleeveb/live-nov21/{adapter-tree,guard-tree}/`, `.scratch/changes/2026-11-20-sleeveb-tonight/skills/before/live-tree/` |
| Superseded publish candidate — **do not publish** | `.scratch/changes/2026-11-20-sleeveb-tonight/skills/after/option-adapter/scripts/sleeve_b.py` (+ mirror in `skills/verify/`) |
| Premium-fix-only variant (superseded) | `.scratch/sleeveb/golive/sleeve_b-v5-proposed.py` |
| R:R-gated variant (measured, superseded) | `.scratch/bt-sleeveb/sleeve_b_gated.py` |
| Orchestration (7 steps; `PLAN` mode is read-only) | `.scratch/changes/2026-11-20-sleeveb-tonight/go-all.sh` / `undo-all.sh` (+ untested `.ps1` twins) |
| Two competing binding packages (both bind **v4**) | `.scratch/changes/2026-11-20-sleeveb/`, `-sleeveb-golive/` |
| Probe package, flag currently `NO-GO` | `.scratch/sleeveb/probe/` (`arm.sh`, `armed-check.mjs`, `FIRE-RUNBOOK.md`, `run-2026-11-20/CAPTURE.md`) |
| Backtests and the DTE ladder | `.scratch/bt-sleeveb/` (`regime_stage{1,2}.py`, `horizon.py`, `minbias.py`, `estimator.py`, `opt/`) |
| The measurement record | `docs/decisions/sleeve-b-backtest-nov21.md` §9–§11; `sleeve-b-readiness.md`; `sleeve-b-golive-nov20.md` |
| Fee-model audit cited by the spec | `docs/decisions/rules-source-of-truth-nov20.md` §2.3, §6.2 |
| Raw payloads from today's instrument checks | `C:\Users\tteh\AppData\Local\Temp\qoder-mcp-outputs\moomoo_quote_option_chain_{3439725912aa,78957696e93b,3266dc5a53fa}.txt` (temp — re-run rather than rely on them) |

**Duplication baseline (md5, OBSERVED).** `sleeve_b.py`: `8841758501bd…` ×9 (= published v1–v4),
`02e65c7c4abb…` ×2 (after + verify mirror), `de22757faab7…` ×2 (premium-only + its test dir),
`aec4f0d18eb3…` ×1 (gated) → **14 files, 4 distinct variants**. `guard.py`: 64 files, **41 identical to
live**, 11 distinct hashes. `test_sleeve_b.py` identical ×3. `rules.json` differs from live in exactly one
key. A `.housekeeping-backup-2026-11-21/` with a restore manifest already exists; the historical trees are
mirrors, not forks, and none of them is a live dependency.

---

*Written 2026-11-21T~07:30Z. Supersedes, for Sleeve B: `sleeve-b-golive-nov20.md` (whole document),
`sleeve-b-readiness.md` §3, `sleeve-b-backtest-nov21.md` §9–§10's "no bullish phase" framing (corrected in
its own §11), and every "next step is to publish WS1 v5" instruction.*
