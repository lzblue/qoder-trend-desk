# Tier B decision memo — per-ticker concurrent Researcher children

**Status: design and recommendation only. Nothing was applied.** No template write, no skill publish or re-pin,
no schedule change, no `rules.json` edit, no order or account action on 5830104, no coordinator/researcher prompt
edit. Every cloud read was a cached-or-`GET` read. This memo changes no live behaviour.

- Task: `20261120T004212Z-2d8e63` (mailbox wake, `kind:ask`, payload `.scratch/mailbox/payloads/20261120T004212Z-2d8e63.md`)
- Evidence collected 2026-11-20 00:36–00:55Z from `.scratch/flaky/` run dumps (99 event arrays, 7 desk runs of
  2026-11-19) and two cached live template reads.
- Claim tags: **[documented]** = written in a repo file or an official page I read; **[observed]** = read from a
  live/cached system artefact this session; **[inferred]** = derived from those; **[undiscoverable]** = not
  knowable from what I can reach.

---

## 0. Bottom line

1. **The premise "regime is computed once and reused today" is true, but in a place the payload did not expect:
   regime is not computed in SCAN at all.** It is computed in the 09:00 BRIEF and the *resolved verdict is
   injected into each SCAN trigger by the coordinator*. **[observed]** So the desync risk the payload asked me to
   design around (child A and child B reading VIX at different moments and disagreeing) does not exist in the
   current data flow — and fan-out inherits that protection for free, provided each child is handed the same
   injected verdict rather than told to look it up.
2. **The 1,291 s is model reasoning, not data fetching.** Of SCAN-1005 researcher's 1,292 s wall, **1,255 s (97%)
   is inside model-request windows** across 63 rounds; tool calls neither stalled nor returned empty (82 `tool_use`
   events against 82 `tool_result` events — see the caveat in §2 on why per-call pairing cannot be proved from these
   dumps). Market-data latency is therefore *not* what per-ticker fan-out would fix, and payload question 4
   has a hard answer: parallelising the analysis does attack the dominant cost, because the dominant cost is the
   analysis turns.
3. **But a large slice of that cost is not ticker analysis at all.** 14 successive `Edit` calls against *one*
   shared output file (`research/signals_20261119_1005.json`) occupy 711 s → 1206 s — **~38% of the run in
   output-patching thrash**, plus 3 `Read`s of the same file. **[observed]** Fan-out with a shared signals file
   would convert a slow loop into a **write race between concurrent children** and make it worse. Per-child output
   files + coordinator-side aggregation are a precondition, not an optimisation.
4. **Every scan is late, not just the outlier.** Researcher model time on the non-outlier scans is 444–636 s
   against the desk's own ">5 min stale ⇒ NONE" rule (300 s). **[observed]** So this is not a tail-latency fix for
   one bad day; the steady state already breaches the rule that killed the SQQQ/SPXS signal. (Per-run mapping
   corrected mid-session from `9d4b1e`'s table, whose `active_s` column was permuted across the three later scans:
   SCAN-1100 = 636 s, SCAN-1230 = 444 s, SCAN-1400 = 584 s. It is a permutation of the same three values, so the
   444–636 s range and every conclusion above are unaffected. **[documented: `20261120T004725Z-b81f9a`]**)
5. **Go/no-go on the harvest-reliability dependency: the payload has the wrong dependency.** The mailbox
   ack-reconciliation work (f2b7ad/7fa2c8) is not what a per-ticker child reports through — see §5. My
   recommendation is **NO-GO for live implementation now, GO for a bounded rehearsal measurement**, for one reason
   that is *new* and not about tonight: whether the Forward multiagent schema permits N concurrent threads against
   the *same* agent entry is **[undiscoverable]** from anything on disk, and the whole design rests on it.

---

## 1. Current architecture — verified, not assumed

Live researcher template `tmpl_d7df3829ed5d73548bb5e9ed`, cached read `updated_at
2026-11-19T22:56:08+08:00` **[observed]**:

- `name: researcher` (the malformed `researcherTrend desk researcher: market` in the stale `AGENTS.md` snapshot
  has since been fixed — that file's observation 6 is out of date).
- `model: {id: efficient, context_window: 200000}`; **`max_tool_rounds` is absent from the object → unset/default**
  **[observed]**, which corroborates `9d4b1e`'s finding that no rounds cap is configured and the effective default
  is not readable via the API.
- `multiagent: null` **[observed]** — **the Researcher cannot itself spawn children.** Any fan-out must be done by
  the coordinator. This constrains the design more than anything else in the payload.
- 4 bound skills, version-pinned: `desk-risk-guard@1795100050849622`, `trend-signal@1795047415929677`,
  `decision-journal@1795094895883552`, `vwap-chop@1795095917868411` **[observed]**.

Live coordinator template `tmpl_19f984c8f0fd516965b63998`, cached read `updated_at
2026-11-19T22:05:04+08:00` **[observed]**:

- `multiagent: {type: coordinator, agents: [researcher, risk_auditor, executor]}` — so the stale `AGENTS.md`
  observation 1 ("coordinator has no delegation wiring") is **also out of date**; delegation wiring exists.

**Answer to "one turn over all tickers, or per-ticker separation already?":** one turn, fully serial.
The SCAN section of the researcher prompt is literally a loop — step 1 "For QQQ, SMH, SPY: get price, VWAP, and
the high and low of the first six 5-minute bars", step 2 "Run trend-signal `signal`", step 3 Sleeve C for each
ticker whose step-2 reason was `outside 0.15-1.5%`. Each SCAN run delivers the researcher **exactly one inbound
message** (9d4b1e established this; the SCAN-1005 dump has one `agent.thread_message_received`) **[observed]**, so
the whole 63-round run *is* one Turn. There is no per-ticker separation inside it.

**Concurrency already exists, just not along tickers.** In one SCAN the coordinator ran two children concurrently:
the monitoring/audit child at 1,765 s wall and the researcher at 1,292 s wall **[observed]**. So "N children of
*different* agents in parallel" is production behaviour today; "N children of the *same* agent" is not.

## 2. Where the 1,291 seconds went

SCAN-1005 researcher thread (`sthr_00vz80n9krchsnbhea59`, 359 events) **[observed]**:

| measure | value |
|---|---|
| wall (first→last event) | 1,292 s |
| sum of `span.model_request_start→end` over 63 rounds | **1,255 s (97%)** |
| tool uses / results | 82 `tool_use` events / 82 `tool_result` events |
| tool mix | `Bash` 27, `quote_cur_kline` 16, `Edit` 14, `Read` 9, `quote_stock_quote` 6, `Write` 2, `quote_history_kline` 3, `news_search` 2, calendar 1, `send_to_parent` 1 |
| model time by quarter of the run | 0–300 s: 331 s · 300–600 s: 249 s · 600–900 s: 304 s · 900–1292 s: 370 s |

**Dump-linkage caveat (corrected mid-session, and it changes what can be claimed).** These dumps cannot support a
"0 unresolved tool calls" claim by ID pairing, in either direction. Across all 12 child threads of the 7 logged
runs there are 487 `tool_use` events and 487 `tool_result` events — counts equal — but **139 of the 487 result
events (28.5%) carry no `tool_use_id` at all**, which leaves exactly 139 `tool_use` events apparently
unreferenced and 0 duplicate references. The deficit is a property of the event dump, not of the calls. So neither
"0 dangling" nor "28 dangling" is provable this way. What *is* provable, and what I checked instead: **all 12
threads end with a clean terminating sequence** — a `tool_result`, `agent.message` or `agent.thread_message_sent`
immediately preceding `session.thread_status_idle`, with no exception. On that evidence no call was left hanging,
and `9d4b1e`'s own "0 unresolved tool calls" number came from the same unusable pairing method (see
`20261120T004725Z-b81f9a`). **[observed]**

Model time is flat across the run — there is no single stall to remove; it is 63 sequential rounds of reasoning.
That is precisely the structure fan-out divides.

The counterweight: **~495 s of it (711 s→1206 s) is 14 `Edit`s + 3 `Read`s on one shared JSON output file.**
The file is being patched roughly every 10–15 s, which means each patch costs a full model round to emit. **[observed]**

**[inferred]** If those 17 rounds were replaced by "compose once, write once", the run loses ~35–40% of its wall
with **zero architectural change**. That is available tonight; fan-out is not.

## 3. Would fan-out actually cut latency?

Splitting 3 tickers across 3 concurrent children divides the per-ticker *analysis* rounds (steps 1–3) but not the
per-child constants: toolset probe (`quote_stock_quote` once, mandated as the first action of every run), the 5
`Read`s of SKILL.md + MEMORY.md at ~13 s, journaling, and the child→parent report. **[observed]**

| | today (1 child, 3 tickers) | 3 concurrent per-ticker children |
|---|---|---|
| per-ticker analysis | serial, ~sum of all | max of one ticker ≈ ⅓ |
| fixed per-child overhead | ×1 | **×3** (probe, skill reads, journal, report) |
| shared-file edit thrash | ×1, slow | **×3, racing — must be removed first** |
| aggregation | none | coordinator must join + fail-close per ticker |
| quote vintage at emit | end of run | end of *one short* run |

**[inferred]** Realistic best case is a 2–2.5× wall cut, not 3×: from 444–636 s to roughly 200–320 s, which is the
first time the desk's 300 s staleness rule is actually met in the steady state. The outlier class (SCAN-1005,
1,292 s) is dominated by the edit thrash, so removing the thrash matters more there than fan-out.

## 4. Proposed design (only if §5's measurement passes)

1. **Regime once, injected, never re-derived.** Keep today's flow: BRIEF computes `regime`, coordinator injects
   the resolved verdict + `size_mult` + windows into *every* SCAN child trigger verbatim. Add a rule that a child
   **must not** call `regime` itself — if the verdict is missing from its trigger it returns `UNAVAILABLE(reason:
   no_injected_regime)`. This is how desync is made structurally impossible rather than best-effort.
2. **One child per ticker, one output file per child.** Child writes
   `research/signals_<date>_<slot>_<ticker>.json` exactly once. No `Edit` retry loop on a shared file. Never give
   concurrent children a shared mutable artefact.
3. **Aggregate in the coordinator, which already has the join point** (it consumes `send_to_parent` from children
   today **[observed]**).
4. **Fail closed per ticker, never as NONE.** Coordinator holds an expected-child manifest (QQQ, SMH, SPY). A child
   missing at deadline, or erroring, produces an explicit
   `{"ticker":"SMH","action":"UNAVAILABLE","reason":"child_timeout_240s"}` journaled as a distinct kind. **`NONE`
   must remain reserved for "analysed, no signal"**, because the two are indistinguishable to the auditor
   otherwise — which is the payload's key correctness worry and I agree with it.
5. **Deadline derived from measurement, not hope** — see §5. Any deadline shorter than the observed fixed overhead
   + one ticker's analysis converts reliability into a new failure source.
6. **One new position per scan stays enforced at the coordinator**, above the fan-out, or 3 children become 3
   simultaneous entries.

## 5. The dependency question, answered explicitly

The payload asserts this "depends on the ack-reconciliation fix (f2b7ad/7fa2c8)". **That is the wrong dependency,
and it should not be cited as the gate.** **[inferred, from observed mechanism]**

- Tonight's 4/4 failures are **Qoder Desktop mailbox** spawns: a Desktop wake spawns a Desktop session and the
  spawner's turn ends before harvesting `acks/<id>.json`. The channel that fails is the mailbox filesystem.
- A per-ticker Researcher child is a **Forward multiagent thread** inside one cloud session. It reports through
  `send_to_parent`, and the parent consumes it in-session.
- Those are different mechanisms with different records. Across these dumps `send_to_parent` *works*: SCAN-1005's
  researcher terminated via `send_to_parent` (11,850 chars) then `end_turn` **[observed, per 9d4b1e's report]**,
  and the coordinator thread continued. There is no evidence in 99 event arrays of a Forward child result being
  dropped the way mailbox acks were.

**Resolution status of the mailbox fix as of this wake (so the judgement is current, not remembered):** partial.
`recon.mjs` now detects stale claims and read_chat_session can prove a child terminal, and it caught a live 5th
case (`9d4b1e`) which this wake harvested under explicit instruction from `4e9d71`. **[observed]** But the
mechanical hole is still open: `ack.mjs` renames over `acks/<id>.json` unconditionally, so a wake that has not
read the ack can still downgrade a `done` to `accepted` — the exact 23:43:49–52Z incident. Rule 2's "a claim never
overwrites a terminal ack" is reader discipline, **not enforced by the tool**. Detection improved; destruction is
still possible.

So: even taken at face value, that dependency is *not* "resolved enough" — and it is the wrong gate anyway. The
real gate is §0.5.

## 6. Recommendation

**NO-GO for live implementation. GO for one bounded measurement, then decide.**

Do, in order:

1. **Remove the edit thrash first (Tier A, no architecture change).** "Compose once, write once" on the signals
   file, plus the `Read`-back loop. Expected −35–40% wall from the same evidence that produced this memo. Cheapest,
   reversible, testable offline against the logged dumps, and it is a *precondition* for step 3 anyway because
   concurrent children must not share a file.
2. **Measure the blocker that is genuinely undiscoverable:** on a rehearsal template only, does Forward permit N
   concurrent threads against the *same* `multiagent.agents` entry (name `researcher`), and does the coordinator
   correctly demultiplex 3 same-name `send_to_parent` results? Nothing on disk answers this; the field is a
   name-keyed 3-entry list and only same-name fan-out would be new behaviour. **[undiscoverable]**
3. **Re-measure steady-state wall after step 1** before assuming fan-out is needed at all. If removing the thrash
   brings 444–636 s under 300 s, the staleness bug is fixed and step 2's added orchestration risk buys nothing.
4. Only then design the live change, and treat it as **Tier B — owner sign-off required before this goes live**,
   since it restructures the live signal-generation pipeline.

**Why not go now:** the payload's own instinct is right that a dropped ticker is the danger — it would present as
an incomplete scan indistinguishable from a real no-signal. But the argument for accepting that risk was "the
analysis is too slow", and the measurement says a third to two-fifths of the slowness is an output-patching loop
that should be deleted regardless. Fixing the architecture to route around a bug we can remove in a prompt is the
more expensive way to get the same latency.

## 7. What I did not do

No template, skill, schedule or `rules.json` write; no publish or re-pin; no session created against any
production template; nothing on account 5830104; no mailbox ack written by this memo other than its own task id.
No secret, PAT or vault value is quoted here; the cached template reads contain no credential material.
