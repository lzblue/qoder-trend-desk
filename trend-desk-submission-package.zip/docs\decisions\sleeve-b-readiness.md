# Sleeve B readiness — decision record, 2026-11-20

Task `20261119T225823Z-e1a7b5`. Scope: make the Sleeve B options overlay production-credible and say
plainly what is still not proven. Nothing was enabled: `option-adapter` is bound to **zero**
templates, and no order was placed, modified or cancelled on any account during this work.

## 1. What was verified

### The skill package

| version | id | module `sleeve_b.py` | SKILL.md | published (UTC) |
|---|---|---|---|---|
| v1 | `1795132449689060` | `c3152251329f4689` 31,397 B | `7113b17f` 7,805 B | 11-19 23:54 |
| v2 | `1795134420311970` | `c3152251329f4689` identical | `5d89d0f8` 10,463 B | 11-20 00:26 |
| v3 | `1795136690073060` | `c3152251329f4689` identical | `05beada3` 12,624 B | 11-20 01:04 |
| v4 | `1795137189020914` | `c3152251329f4689` identical | `b8293da3` 13,291 B | 11-20 01:13 |

v2–v4 changed documentation only. Each was verified by downloading the published zip and hashing
**each file** — the package `content_sha256` is not the hash of the zip, so a zip-level comparison
proves nothing. The module bytes have not moved since v1: all gate arithmetic below came from the
same code that is published.

v3 and v4 correct two things I had shipped wrongly in v1/v2:

- v1 claimed `owner_lot_multiplier` is checked. It is not — zero occurrences in the module — and
  live option rows carry `owner_lot_multiplier: 0` beside `contract_multiplier: 100`, so gating on
  it would drop every contract. Only `contract_multiplier` is checked.
- v1/v2 did not say how to choose the strike window, which turns out to decide whether B can answer
  at all (§3.4).

Neither v3 nor v4 has been exercised by a sandbox session. v2 was (below); since the module is
byte-identical, the exercised code path is unchanged, and what changed is prose.

### The live data path (v2's content, exercised by the session)

Written from real payloads, not inferred:

1. `quote_option_chain` / `quote_option_expiration_date` → candidate **codes** only. Observed: a
   658,537 B chain response, 1,300 rows, `chain has prices: False`, no `last_price` anywhere. Rows
   carry `code, strike_price, strike_time, option_type, lot_size, stock_owner`.
2. `quote_stock_quote` with `code_list=[<option codes>]` → the priced rows: `last_price` plus
   `option_ex_data` (18 keys incl. `delta`, `implied_volatility`, `open_interest`,
   `contract_multiplier`, and the trap field `premium`).
3. `quote_order_book` for one code → fallback price when `last_price` is 0 or absent.
4. `quote_history_kline`, daily, `num>=40` → 21+ completed bars after dropping the current
   session's incomplete bar.

There is **no** `quote_option_quote` tool. A chain payload fed in as `quotes` yields zero contracts
with a "no last_price and no usable ask - contract dropped" warning per row; that is the correct
failure, not a silent zero.

### Premium source — the trap is structural

`option_ex_data.premium` is not a price. Two independent captures agree: 0.123 against a real
`last_price` of 8.55 (2026-11-19), and **0.712 against 5.36** (sandbox row, 11-20 00:47Z). The field
sits an order of magnitude under the tradeable price. `sleeve_b.option_ex_data()` whitelists exactly
four keys, so `premium` cannot reach a decision — proven by test and by reading the function.
Sizing and the fee gate use the value this module calls `premium` (`last_price`, or the book ask),
and `price_source` records which was taken.

### Sandbox rehearsal — one session, real live data

Session `sess_00w0mt1lb7dogdo705u8` on rehearsal template `tmpl_f3214189de633d9d34ce77b6`, 11.1
credits, **9 MCP calls** (`quote_stock_quote` 4, `quote_option_chain` 2, `quote_cur_kline` 2,
`quote_option_expiration_date` 1) and **zero** order/account/position calls. Read from 160 events
directly, not from an ack.

It pulled the SPY chain, priced 20 ITM contracts through `quote_stock_quote`, took 24 completed
dailies, confirmed the mounted module sha `c3152251329f4689` in-sandbox, and got:

```json
{"sleeve":"B","action":"NONE","reason":"no confluence: no qualifying expansion (0.87x, close at 41%)"}
```

Its live candidate digest — computed outside the gates — found **10** SPY contracts inside DTE 1–5,
|delta| 0.25–0.50, multiplier 100, spread over dte 1, 4 and 5. Real in-band inventory exists; the
gate said no on evidence, which is the behaviour the design asks for.

The session ended mid-QQQ (final message: "Transcribing the 20 QQQ rows verbatim."). Its
`/data/rsh/*.json` inputs died with the session; only the printed rows survive in the event log, and
those are elided in the stored events, so they cannot be reassembled locally.

Sandbox sessions used: **1 of the 2 allowed.**

### Rehearsal template restored

`rollback.sh` was run for real against `tmpl_f3214189de633d9d34ce77b6`, which is also how it was
tested as a live write path rather than only a dry run. Field by field against the pre-change GET:

- `skills` reads back byte-identical to the before snapshot.
- All other fields identical — `system`, `model`, `tools`, `mcp_servers`, `vaults`, `files`,
  `environment_variables`, `multiagent` all match. Only `created_at` and `updated_at` moved, which
  the platform rewrites on any write with no way to set them. The array is restored; the clock is not.
- Dry-run against the three production templates reports `NO CHANGE` for each: they still equal
  their `before/` snapshots. No production template was written in this task.
- `GET /skills` binding counts: option-adapter **0**; decision-journal 4, vwap-chop 3,
  desk-risk-guard 3, trend-signal 1 — unchanged. Per template: coordinator `[]`, researcher 4,
  executor 3, risk_auditor 3, rehearsal 1, and no template lists `skill_00w0ip0yri8sgag736ks`.

## 2. Confluence gate, measured on live Nov-19 dailies

| underlying | prior session (Nov 19) | range | 20-session avg | ratio | close position | module verdict |
|---|---|---|---|---|---|---|
| SPY | o737.46 h739.8999 l715.65 c715.87 | 3.29% | 1.31% | **2.52x** | 0.9% of range | `-1` bearish expansion |
| QQQ | o671.09 h676.49 l644.34 c645.04 | 4.79% | 1.97% | **2.43x** | 2.2% of range | `-1` bearish expansion |

Both clear the ≥1.5x band and close in the bottom third, so on tonight's date (Nov 20, when Nov 19
is "prior session") the gate passes and the direction it wants is **PUT**.

This corrects the earlier dry-run reading. That run evaluated Nov 18 as the prior session (SPY
0.87x/41%, QQQ 0.76x/66% → NONE): the arithmetic was right, the date was one session behind. The
same 0.87x/41% reappeared in the sandbox because its ET clock still read Nov 19, so Nov 18 was
"prior" there too. The gate is date-sensitive in exactly the way it should be; "the confluence gate
blocks for real" applies to Nov 18, not to tonight.

## 3. What is genuinely not verified

1. **A filled option order row has never been observed on this account.** `classify_fill`'s `filled`
   branch is reachable only in unit tests. The sim status enum was established for resting (2),
   cancelled (5) and equity-curve `filled` rows, but no option order has filled, so the shape of
   `avg_fill_price`/`cum_qty` on an option row is inferred from stock rows, not seen. Until the first
   real occurrence is captured and diffed, `reconcile` behaves as designed: unrecognised means no new
   risk.
2. **No ticket has ever been produced from live bytes.** The live runs stopped at a gate (correctly).
   A `BUY_TO_OPEN` ticket — field set, `qty`/`price` strings, DTE, delta, budget, guard verdict — has
   only been demonstrated on fixtures whose rows mirror the live field names. This is the main gap
   between "verified" and "ready".
3. **The guard stage has never run against live Sleeve B input.** Gate 6 (guard.py's own
   `sleeve="option"` budget, round-trip fee and entry-window checks) was exercised in unit tests with
   the live v12 `guard.py` + `rules.json` copied unmodified, but not on a live-data ticket, because
   gate 4 empties the candidate list first. Related, learned the hard way: `guard.py` imports
   `calendar_rules` as a sibling, so a `--guard-dir` holding only `guard.py` dies with
   `ModuleNotFoundError` and the adapter fails closed with `check="guard_error"`. Correct behaviour,
   but it is not evidence about sizing. `stage/guard/` now carries the full v12 tree
   (`guard.py`, `calendar_rules.py`, `book.py`, `levels.py`) and all sizing evidence must be produced
   with it.
4. **The strike-selection, not the module, is the binding constraint — and the cause was mis-stated
   until today.** Replays of my saved SPY capture at ET dates Nov 20, 22 and 23 all returned
   `candidates_examined: 0`. Reading the capture itself explains it: 55 rows, 28 at expiry `261119`
   and 27 at `261120` — **only the two nearest expiries**. At Nov 20 the Nov 19 contracts are in the
   past and the Nov 20 contracts are dte 0, so every row fails `risk.dte_min` before delta is
   consulted. The delta band was never the reason. Fix, now in SKILL.md v4: request every expiry in
   `[today + dte_min, today + dte_max]` (usually 3–4 dates) and strikes on both sides of spot
   (±3%, chosen not measured). My first draft of this section attributed the zero to a one-sided
   strike window; the sandbox's 10 in-band contracts from the same evening is the counter-example I
   should have checked before writing it.
5. **No production adapter exists.** Nothing calls `select`. Sleeve A is not live, so there is no
   approved entry for B to sit on; the rehearsals used a synthetic `a_intent` and a synthetic
   portfolio (nav/cash 100000), both labelled as such in the output. No account tool was called for
   either.
6. **Sizing model mismatch.** guard.py sizes from raw premium while the dry-run model used
   `dv2 x 1.05`; pre-market repricing moves the delta band between the BRIEF and the SCAN. Owner
   questions, not mine to settle.

## 4. Tier B — owner decisions required before any enable

- Approve binding `option-adapter` **v4 `1795137189020914`** to researcher, executor and
  risk_auditor (three template writes — what `apply.sh` does; it has not been run).
- Decide the strike-selection rule the adapter should *require* of its caller, per §3.4, or accept
  that B will answer NONE most days.
- Decide whether B may act at all while Sleeve A is not live.
- Accept or fix the guard premium-model mismatch (§3.6) before the first real ticket.
- Set the option budget (`option_trade_risk_pct`, `max_open_option_premium_pct`) explicitly; the
  rehearsals used defaults.
- Approve one more paid probe to capture the first filled option order row, if the owner wants B
  monitored on observed rather than inferred shapes.

## 5. Reproducing this

```
cd .scratch/sleeveb/build
python3 stage/rehearsal-driver.py --underlying SPY --dir -1 \
  --codes smoke/codes_spy_real.json --quotes smoke/quotes_spy_real.json \
  --kline smoke/kline_spy_real.json --out smoke/in_spy_real.json \
  --skill-root ./option-adapter --guard-dir stage/guard
# --today 2026-11-20 replays the same saved bytes at a different ET date
```

At the sandbox's own date the run reproduces its answer exactly (`NONE`, 0.87x/41%); at Nov 20 it
passes confluence and returns `NONE` with `candidates_examined: 0` for the §3.4 reason:

```json
{"sleeve":"B","action":"NONE","reason":"no contract fits delta band [0.25, 0.50], DTE [1, 5], budget $500 and the fee gate","candidates_examined":0,"trace":[],"warnings":[]}
```

Artifacts: `before/` snapshots (5 templates incl. the rehearsal template, schedules, skills, the v1
zip), `apply.sh`, `rollback.sh`, `template-skills.mjs` under `.scratch/changes/2026-11-20-sleeveb/`;
the sandbox event dump at `.scratch/sleeveb/build/rehearsal-events-sess_00w0mt1lb7dogdo705u8.json`.

## 6. Corrections to things I said earlier in this task

- The first draft of §3.4 blamed a one-sided strike window for `candidates_examined: 0`. Wrong: the
  capture simply contained only the two nearest expiries. Corrected above; the sandbox's 10 in-band
  contracts from the same evening was the counter-example I should have checked before writing it.
- The first draft's §2 gave QQQ's Nov 19 bar as 660.29/663.85/642.75/644.16. Actual, re-measured from
  `smoke/kline_QQQ_real.json`: 671.09 / 676.49 / 644.34 / 645.04. The ratio and direction were right;
  the four prices were not.
- Two sha confusions on **`guard.py`**, resolved against live v12: my earlier printouts
  `f4018c8f…` and `09b57e55…` (both 16,032 B, labelled "live") are **not** live v12 bytes. Live v12
  `guard.py` is **`8fe26118b2a8a3fd…`**, 16,032 B — confirmed twice this turn, by a fresh download of
  version `1795100050849622` and by the sandbox session's own `sha256sum` of its mounted copy, which
  match each other and match `stage/guard/guard.py`. So the rehearsal ran real live guard bytes, and
  nothing in §1–§5 rests on those two bad printouts; the paths they named no longer exist, so they
  cannot be re-checked and I do not restate them as fact.
- The `option-adapter` module sha was earlier misquoted once as a `quote_stock_quote` payload hash
  (`a76db233…`) in a line I wrote after moving on from the listing. `sleeve_b.py` is
  `c3152251329f4689` in v1–v4, verified per-file on download each time.
- Two helper scripts I wrote under `.scratch/sleeveb/build/` had disappeared when I next tried to run
  them (`verify-downloads.mjs`, a `guard/` directory). I did not delete them and did not chase it;
  every byte figure above came from a fresh download rather than from those copies.

