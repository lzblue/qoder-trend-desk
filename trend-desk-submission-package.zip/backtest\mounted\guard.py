#!/usr/bin/env python3
"""desk-risk-guard: deterministic pre-trade gate and position sizer (stdlib only).

Usage:
  python guard.py check --proposal proposal.json --portfolio portfolio.json --now 2026-11-18T10:35:00-05:00 [--phase approval|bounded]
  python guard.py day   --now 2026-11-18T09:00:00-05:00
Prints one JSON object. Nothing here places an order; it only approves, sizes or vetoes.

portfolio["cash"] must be numeric: if it is absent or not a number the verdict declines with reason
"cash missing from portfolio.json" (or "... is not numeric ...") instead of guessing 0, which would
report a false binding cap. --allow-unknown-cash overrides that by assuming 90% of NAV -- the most
the 10% cash floor itself permits -- and records a warning; that assumption can size larger than the
real cash would allow, so use it only after reading the account.
"""
from __future__ import annotations

import argparse
import json
import math
import re
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import calendar_rules as cal  # noqa: E402

RULES_PATH = Path(__file__).resolve().parent.parent / "references" / "rules.json"


def load_rules(path=None) -> dict:
    return json.loads(Path(path or RULES_PATH).read_text())


def to_et(dt: datetime) -> datetime:
    try:
        from zoneinfo import ZoneInfo
        return dt.astimezone(ZoneInfo("America/New_York"))
    except Exception:  # no tz database in the sandbox: US Eastern is UTC-5 for 2 Nov - 31 Dec 2026
        return dt.astimezone(timezone(timedelta(hours=-5)))


def mins(hhmm: str) -> int:
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def drawdown_state(rules: dict, p: dict) -> tuple[str, float | None, float | None]:
    # An unread account figure is a data gap, not a zero: guessing one would report a drawdown that was
    # never measured, so the ladder state is declared unavailable and the caller declines instead.
    if not all(is_number(p.get(k, None)) for k in ("nav", "peak_nav", "day_start_nav")):
        return "state_unavailable", None, None
    peak_nav = float(p["peak_nav"])
    nav = float(p["nav"])
    day_start_nav = float(p["day_start_nav"])
    dd = (peak_nav - nav) / peak_nav * 100
    state = "normal"
    for rung in rules["risk"]["drawdown_ladder"]:
        if dd >= rung["dd_pct"]:
            state = rung["action"]
    day_loss = (day_start_nav - nav) / day_start_nav * 100
    if state in ("normal", "half_size") and day_loss >= rules["risk"]["daily_loss_limit_pct"]:
        state = "daily_halt"
    return state, round(dd, 3), round(day_loss, 3)


FEE_MODEL_PAGE = "moomoo_page_s8_per_order"
FEE_MODELS = {FEE_MODEL_PAGE: "max(1.99, 0.65n) + 0.318n per order, n = contracts that order touches"}
CONTRACT_MULTIPLIER = 100
FLY_LEGS = 4
FLY_SEQS = [1, 2, 3, 4]
OSI_RE = re.compile(r"^([A-Z.]{1,7})(\d{6})([CP])(\d{5,8})$")


def parse_osi(symbol):
    """US.SPY261119C740000 -> {ticker, expiry, right, strike, osi}. None if it is not a US OSI option.

    Mirrored from option-adapter on purpose. The skill that sizes and approves a structure must not
    validate it with the producer's own reader, or a bug in that reader approves itself; test_fly.py
    and test_credit.py pin both copies to the same fixture so they cannot drift apart quietly.
    """
    if not isinstance(symbol, str):
        return None
    tail = symbol.split(".", 1)[1] if symbol.startswith("US.") else symbol
    m = OSI_RE.match(tail.upper())
    if not m:
        return None
    ticker, ymd, cp, strike_raw = m.groups()
    strike = int(strike_raw) / 1000.0
    # "C"/"P", the same single letters legs[].right and option-adapter's parse_osi use. Two readers of
    # one code string that spell the same fact differently is a defect nobody downstream can see.
    return {"ticker": ticker, "expiry": ymd, "right": cp, "strike": strike,
            "osi": "US.%s%s%s%d" % (ticker, ymd, cp, int(strike_raw))}


def expiry_days(ymd: str, base) -> int | None:
    """Whole calendar days from `base` (a date) to a YYMMDD expiry. None if unusable."""
    if not isinstance(ymd, str) or len(ymd) != 6 or not ymd.isdigit():
        return None
    try:
        exp = datetime.strptime(ymd, "%y%m%d").date()
    except ValueError:
        return None
    return (exp - base).days


def _num(value, default=None):
    return float(value) if is_number(value) else default


def later_dated_option(row: dict, et) -> bool:
    """True only when the row is PROVABLY an option that does not expire on `et`'s ET trading day.

    The one-per-day fly cap asks this because a bare OSI test also matched the desk's overnight hedge put,
    which the hedge branch of `check()` requires at 7-45 DTE (guard.py:1315). That row is not a fly leg, and
    counting it meant the hedge vetoed the day's one fly using ruling 1's own words. A fly is `structure.dte`
    0, so its own legs answer "expires today" and stay counted; a 1-5 DTE debit option (sleeve C) is provably
    later-dated and is not. An OSI code whose expiry will not parse is NOT provably later-dated, so it stays
    counted: like an unreadable qty, the cap fails closed rather than guessing.
    """
    o = parse_osi(row.get("symbol") or row.get("code") or "")
    if o is None:
        return False
    d = expiry_days(o["expiry"], et.date())
    return d is not None and d != 0


def qty_is_open(row: dict) -> bool:
    """True unless the row is PROVABLY not an open structure.

    A qty that parses to zero is a row the broker closed and kept, so it is not open. A qty that parses to a
    negative is refused too, per the owner's "qty > 0": this broker has never been observed sending a negative
    position qty (book.py:218 records that a bought wing read `qty "1"`), so a negative is not a direction,
    it is a row this file cannot read as open. A qty that does not parse at all proves nothing, so it STAYS
    counted and the cap fails closed.
    """
    q = _num(row.get("qty"), None)
    return q is None or q > 0.0


def _fly_leg_sign(side) -> int:
    """+1 long / -1 short from the leg's own side encoding, 0 when unrecognised.

    The accepted vocabulary is wider than this desk's on purpose, because the failure mode of a
    narrow one is a false flat: moomoo's combo request takes BUY/SELL, an order ticket takes 1/2, and
    a leg recorded SELL that this read as neither would pass validation instead of being refused.
    Unrecognised is refused, never defaulted.
    """
    if isinstance(side, bool):
        return 0
    if isinstance(side, (int, float)):
        return {1: 1, 2: -1}.get(int(side), 0)
    token = str(side or "").strip().upper()
    if token in ("BUY", "BUY_TO_OPEN", "LONG", "B"):
        return 1
    if token in ("SELL", "SELL_TO_OPEN", "SHORT", "S"):
        return -1
    return 0


def fee_per_option_order(rules: dict, contracts: int) -> float:
    """One side of one order, per the moomoo fee page (rules-source-of-truth section 2.3).

    commission max(1.99, 0.65n) + platform 0.30n + activity 0.00279n + regulatory 0.015n, all
    folded into the two numbers in rules.json. option_round_trip_fee below is the legacy 2 x
    (1.99 + 0.30n) shape, exact only for n <= 3; a four-leg structure is where that shows.
    """
    f = rules["fees"]
    n = max(int(contracts), 0)
    return max(f["option_min_commission"], f["option_per_contract_commission"] * n) \
        + f["option_fee_per_contract_other"] * n


def fly_structure_key(legs) -> str:
    """Mirror of option-adapter's `structure_key`: "fly:" + sorted "<CODE>x<qty>", US. prefix stripped.

    The identity of a fly is what makes one approval, four leg orders and one journal `close` record the
    same trade, and it cannot be derived from prices. Two implementations of one key is exactly the
    failure mode this desk keeps hitting, so parity with the adapter's own function is asserted in
    c2/test_credit.py group d rather than assumed, and an unparseable leg returns None here too: no key
    may be invented for a structure the legs do not describe. Deliberately not a hash - an auditor reads
    a key off a ticket without a calculator.

    The key is a function of the LEGS ONLY, so it is size-independent by construction: two lots and
    twenty lots of the same four strikes share one key. That is the branch both sides settled on
    (adapter branch 2, no lots argument) after a size-bearing key made every multi-lot fly read as
    "a leg was amended" against this mirror. It is honest about the limit: re-sizing a fly without
    changing a leg is invisible here, which is why the size travels as `qty`/`lots` and the contracts
    as `order.contracts_per_leg_order` in the verdict, not inside the identity. Under the leg convention
    enforced in fly_leg_rows every `legs[].qty` is 1, so the suffix is always "x1"; it stays in the
    format because the adapter emits it and the key must be byte-equal, not merely equivalent.
    """
    parts = []
    for leg in legs or []:
        if not isinstance(leg, dict):
            return None
        parsed = parse_osi(leg.get("code") or "")
        if not parsed:
            return None
        qty = _num(leg.get("qty"), 1)
        if qty is None or int(qty) < 1:
            return None
        parts.append("%sx%d" % (parsed["osi"].split(".", 1)[1], int(qty)))
    if not parts:
        return None
    return "fly:" + "|".join(sorted(parts))


def legs_per_lot(qtys) -> int:
    """Contracts per leg per lot. The producer's own arithmetic (max over the legs), reused verbatim so
    the guard and the adapter cannot disagree about what one lot is."""
    vals = [int(q) for q in (qtys or []) if q is not None]
    return max(vals) if vals else 1


def fly_leg_rows(proposal: dict, rules: dict, reasons: list) -> list | None:
    """The proposal's legs, cross-checked against their own OSI codes, or None.

    Every check re-derives from the code string rather than trusting the sibling field: a fly whose
    legs say one thing and encode another is a mis-price, not a rounding difference, and it is the
    class of bug that turns a defined-loss structure into undefined loss.
    """
    legs = proposal.get("legs")
    if not isinstance(legs, list):
        reasons.append("iron_fly: legs missing or not a list")
        return None
    if len(legs) != FLY_LEGS:
        reasons.append("iron_fly: %d legs - a fly is exactly 4 (2 short, 2 long wing)" % len(legs))
        return None
    st = rules.get("structure") or {}
    venues = st.get("venues") or {}
    venue = proposal.get("venue")
    if venue not in venues:
        reasons.append("iron_fly: venue %r is not one of %s in rules.json structure.venues"
                       % (venue, sorted(venues)))
        return None
    # The venue must also be in the approved option universe, or the XSP -> SPXW edit in
    # universe.option_underlyings would be prose the gate never reads.
    allowed = ((rules.get("universe") or {}).get("option_underlyings")) or []
    if venue not in allowed:
        reasons.append("iron_fly: venue %s is not in universe.option_underlyings %s" % (venue, allowed))
        return None
    root = (venues.get(venue) or {}).get("osi_root")
    rows, seqs, codes, exps, qtys, roots = [], [], [], [], [], []
    for idx, leg in enumerate(legs):
        tag = "iron_fly: leg %d" % (idx + 1)
        if not isinstance(leg, dict):
            reasons.append("%s is not an object" % tag)
            continue
        seq = leg.get("seq")
        if isinstance(seq, bool) or not isinstance(seq, int):
            reasons.append("%s has no integer seq" % tag)
        else:
            seqs.append(seq)
        code = leg.get("code")
        if not isinstance(code, str) or not code:
            reasons.append("%s has no OSI code string" % tag)
            continue
        parsed = parse_osi(code)
        if parsed is None:
            reasons.append("%s code %s is not a US OSI option" % (tag, code))
            continue
        right = leg.get("right")
        norm = {"CALL": "C", "PUT": "P"}.get(str(right).upper(), str(right).upper())
        if norm not in ("C", "P"):
            reasons.append("%s right %r is neither C nor P" % (tag, right))
        elif parsed["right"] != norm:
            reasons.append("%s right %s contradicts its own code %s (%s)"
                           % (tag, right, code, parsed["right"]))
        else:
            right = norm
        strike = _num(leg.get("strike"))
        if strike is None or strike <= 0:
            reasons.append("%s strike missing, non-numeric or not positive" % tag)
        elif abs(strike - parsed["strike"]) > 1e-6:
            reasons.append("%s strike %s is not the strike its code carries (%s)"
                           % (tag, strike, parsed["strike"]))
        qty = _num(leg.get("qty"))
        if qty is None or int(qty) < 1:
            reasons.append("%s qty missing or below 1" % tag)
        else:
            qtys.append(int(qty))
        # A crossed quote is a broken feed, not a wide market: an ask below its own bid makes every
        # credit built from it meaningless, including the crossed one this branch now checks instead
        # of comparing credit against debit_at_ask.
        bid, ask = _num(leg.get("bid")), _num(leg.get("ask"))
        if None not in (bid, ask) and ask < bid:
            reasons.append("%s ask %s is below its own bid %s on %s - that is not a market, and a credit "
                           "computed from a crossed book cannot be collected" % (tag, ask, bid, code))
        sign = _fly_leg_sign(leg.get("side"))
        if sign == 0:
            reasons.append("%s side %r is not a recognised buy- or sell-to-open" % (tag, leg.get("side")))
        codes.append(code)
        exps.append(parsed["expiry"])
        roots.append(parsed["ticker"])
        rows.append({"seq": seq, "code": code, "right": right, "strike": strike,
                     "side": leg.get("side"), "sign": sign, "qty": int(qty) if qty is not None else 0,
                     "expiry": parsed["expiry"]})
    if reasons:
        return None
    if sorted(seqs) != FLY_SEQS:
        reasons.append("iron_fly: seq must be exactly 1,2,3,4, got %s" % sorted(seqs))
        return None
    if len(set(codes)) != FLY_LEGS:
        reasons.append("iron_fly: two legs share a code - one fly is four distinct contracts")
        return None
    if len(set(exps)) != 1:
        reasons.append("iron_fly: legs expire on %s - one fly is one expiry" % sorted(set(exps)))
        return None
    # The declared expiry is checked against the codes, not used: an adapter that keeps yesterday's
    # `expiry` while filling today's contracts is exactly the stale structure the DTE re-derivation
    # is here to catch, and the two fields must not be allowed to disagree quietly.
    stated = proposal.get("expiry")
    if isinstance(stated, str) and stated.replace("-", "")[-6:] != exps[0]:
        reasons.append("iron_fly: expiry %s is not the expiry the leg codes carry (%s)" % (stated, exps[0]))
        return None
    if len(set(qtys)) != 1:
        reasons.append("iron_fly: leg quantities differ (%s) - wings and shorts equal is what bounds the loss" % qtys)
        return None
    # UNIT, and it is a rule rather than an inference: the convention settled with the adapter on
    # 2026-11-21 is that a fly's legs describe ONE lot - every `legs[].qty` is 1 - and the size travels
    # only as the top-level `qty` in lots. That is the single shape in which `max_loss_per_lot`,
    # `max_loss_usd` and the size-free `structure_key` the adapter stamps can all be true at once. A leg
    # carrying 2 contracts halves the declared per-lot loss and makes one key describe two sizes, so it
    # is vetoed here instead of being divided away: a heuristic divisor would let that shape approve.
    if legs_per_lot(qtys) != 1:
        reasons.append("iron_fly: every leg carries %d contracts, but legs describe one lot at 1 contract "
                       "each - size belongs in the top-level qty, because a multi-contract leg makes "
                       "max_loss_per_lot and max_loss_usd collapse into each other" % legs_per_lot(qtys))
        return None
    if set(roots) != {root}:
        reasons.append("iron_fly: the codes read %s while venue %s writes %s - a structure mixed across venues has no single multiplier or settlement"
                       % (sorted(set(roots)), venue, root))
        return None
    shorts = [row for row in rows if row["sign"] < 0]
    longs = [row for row in rows if row["sign"] > 0]
    if len(shorts) != 2 or len(longs) != 2:
        reasons.append("iron_fly: %d short and %d long legs - a fly is 2 and 2" % (len(shorts), len(longs)))
        return None
    # The geometry is checked against the proposal's own atm_strike and width, because D3's
    # max_loss = (width - credit) x 100 is only true on both sides for a body at the money: shorts
    # one call and one put at atm_strike, wings at atm_strike +/- width. A strangle body, an
    # asymmetric wing, or a wing offset that is not `width` is a different trade with a different
    # worst case, and sizing it with this formula would understate the loss.
    atm, width = _num(proposal.get("atm_strike")), _num(proposal.get("width"))
    if atm is None or width is None or width <= 0:
        reasons.append("iron_fly: atm_strike or width missing, or width not positive - the geometry cannot be checked")
        return None
    # The exchange only lists strikes on its own ladder, so an off-grid strike is not a worse price, it
    # is a contract that does not exist: the ticket would be rejected at the broker and the structure
    # would be naked on one side. The grid comes from the venue entry in rules.json, which is also the
    # reason SPXW and SPY cannot share one width constant.
    grid = _num((venues.get(venue) or {}).get("strike_grid"))
    if grid is None or grid <= 0:
        reasons.append("iron_fly: venue %s has no usable strike_grid in rules.json" % venue)
    else:
        off = [row["strike"] for row in rows if row["strike"] is not None
               and abs(row["strike"] / grid - round(row["strike"] / grid)) > 1e-9]
        if atm is not None and abs(atm / grid - round(atm / grid)) > 1e-9:
            off.append(atm)
        if off:
            reasons.append("iron_fly: strike(s) %s off the %s grid of %s for %s - that contract is not listed"
                           % (sorted(set(off)), venue, grid, "atm_strike or a leg"))
    if not all(_close(row["strike"], atm) for row in shorts):
        reasons.append("iron_fly: the short legs are at %s but atm_strike is %s - with a strangle body the loss is not (width - credit) on both sides"
                       % (sorted(row["strike"] for row in shorts), atm))
    if {row["right"] for row in shorts} != {"C", "P"}:
        reasons.append("iron_fly: the ATM body is not one call and one put")
    want_long = sorted([atm - width, atm + width])
    got_long = sorted(row["strike"] for row in longs)
    if not all(_close(a, b) for a, b in zip(got_long, want_long)):
        reasons.append("iron_fly: long wings at %s, expected %s (atm_strike +/- width %s)" % (got_long, want_long, width))
    if {row["right"] for row in longs} != {"C", "P"}:
        reasons.append("iron_fly: the two wings are not one call and one put")
    # The key is re-derived from the legs that survived every check above, so a ticket cannot carry an
    # identity from one structure and contracts from another. Size is deliberately NOT part of it (see
    # fly_structure_key): this catches a changed contract, not a changed lot count. A proposal that
    # never stamped one is not a mismatch: it is approved against the key derived here and warned about,
    # because the executor's tickets and the journal's close record have to agree on which fly this was.
    claimed = proposal.get("structure_key")
    now_key = fly_structure_key([{"code": row["code"], "qty": row["qty"]} for row in rows])
    if claimed and now_key and str(claimed) != now_key:
        reasons.append("iron_fly: structure_key %s is not what these legs add up to (%s) - a leg was "
                       "amended, so this is not the structure that was keyed" % (claimed, now_key))
        return None
    if reasons:
        return None
    return rows


def _close(a, b) -> bool:
    return a is not None and b is not None and abs(float(a) - float(b)) < 1e-6


def open_risk_total(positions: list):
    """(usd, unpriced) -- what `risk.max_open_risk_pct` charges the book, and what it cannot price.

    A legged group cannot be priced by summing its rows: the auditor writes `open_risk` as
    `(cost - stop_level) x qty` and a four-leg structure has no `stop_level`, so the recorded live shape
    carries 0.0 on all four fly rows (ab/pf_live_shape.json) and the cap reads an open fly as free.
    Writing the structure's max loss per row instead charges it four times. So the group is priced from
    the contracts and marks, and the per-row alias is dropped for those rows. A non-empty `unpriced`
    means the cap is not evaluable and the caller must refuse new risk: an open structure whose worst
    case cannot be derived is never treated as zero.

    Only a group of two or more OSI rows is a structure; a lone row (hedge, single leg) keeps the
    per-row figure, so books with no legged structure behave exactly as before.
    """
    groups: dict = {}
    legged_row: set = set()
    for idx, p in enumerate(positions or []):
        parsed = parse_osi(p.get("symbol") or p.get("code") or "")
        if parsed is None:
            continue
        qty = _num(p.get("qty"))
        if qty is None or abs(qty) < 1e-9:
            # A closed position keeps its row at qty 0, so a zero-quantity row is not risk left open.
            continue
        groups.setdefault((parsed["ticker"], parsed["expiry"]), []).append((idx, parsed, int(abs(qty)), p))

    usd = 0.0
    unpriced = []
    for (root, exp), rows in sorted(groups.items()):
        if len(rows) < 2:
            continue
        span = "%s %s" % (root, exp)
        for idx2, _, _, _ in rows:
            legged_row.add(idx2)
        codes = sorted(parsed["osi"].split(".", 1)[1] for _, parsed, _, _ in rows)
        lots = {q for _, _, q, _ in rows}
        by_strike: dict = {}
        for _, parsed, _, p in rows:
            by_strike.setdefault(parsed["strike"], []).append((parsed["right"], p))
        body = [s for s, side in by_strike.items() if len(side) == 2]
        wings = sorted(s for s, side in by_strike.items() if len(side) == 1)
        priced = None
        if len(rows) != FLY_LEGS or len(lots) != 1 or len(body) != 1 or len(wings) != 2:
            # 4 rows, equal quantity, one strike twice and one on each side of it: that is the only
            # legged shape this desk is allowed to open (fly_leg_rows enforces exactly that on entry).
            # Anything else on the book is a partial fill, a second structure sharing the expiry, or a
            # spread this file has no bounded-loss formula for -- precisely when the cap must not guess.
            detail = "%d leg rows %s" % (len(rows), codes)
        elif len({r for r, _ in by_strike[body[0]]}) != 2:
            detail = "body %s is not one call and one put (%s)" % (body[0], codes)
        elif not (wings[0] < body[0] < wings[1]):
            detail = "wings %s do not straddle the body %s" % (wings, body[0])
        else:
            marks, gap = {}, None
            for strike, sides in by_strike.items():
                for right, p in sides:
                    mv = _num(p.get("market_value"))
                    if mv is None:
                        mv = _num(p.get("cost"))
                    if mv is None:
                        gap = "no numeric market_value or cost on %s" % right
                    else:
                        marks[(right, strike)] = mv
            if gap:
                detail = gap
            elif len(marks) != FLY_LEGS:
                detail = "legs repeat a contract: %s" % codes
            else:
                credit = (marks[("P", body[0])] + marks[("C", body[0])]) \
                    - (marks[("P", wings[0])] + marks[("C", wings[1])])
                gross = max(body[0] - wings[0], wings[1] - body[0]) * CONTRACT_MULTIPLIER * lots.pop()
                if credit >= gross:
                    # No fly is paid more than the width it is short, so a credit at or above the wing
                    # width is not a bounded loss but a bad mark: the same book that charges a real
                    # structure at zero. `max(gross - credit, 0)` would silently hand back the free room.
                    detail = "credit $%.0f is at or above the $%.0f wing width - not a possible fly, so "                              "the marks are unusable as a risk basis: %s" % (credit, gross, codes)
                else:
                    # A net debit (credit below zero) is charged at the gross width: that is the ceiling
                    # for a short structure under water, so the ambiguity costs room, never fabricates it.
                    priced = max(gross - max(credit, 0.0), 0.0)
        if priced is None:
            unpriced.append("%s: %s - open risk not derivable" % (span, detail))
            continue
        usd += priced

    # Rows outside a legged group keep the old per-row treatment, with one exception: an `open_risk`
    # that is PRESENT and not a number is refused instead of becoming 0, because a sum over it raised on
    # the share path before it reached a verdict at all. An absent key still contributes nothing -- that
    # is the documented default every sleeve-A book this week relies on.
    total = usd
    for idx, p in enumerate(positions or []):
        if idx in legged_row:
            continue
        raw = p.get("open_risk")
        if raw is not None and not is_number(raw):
            unpriced.append("%s: open_risk %r is not a number"
                            % (p.get("symbol") or p.get("code") or p.get("ticker") or "row %d" % idx, raw))
            continue
        total += _num(raw, 0.0) or 0.0
    unpriced.sort()
    return total, unpriced


def fly_structure(proposal: dict, portfolio: dict, positions: list, rules: dict, mult: float,
                  et, day: dict, reasons: list, warnings: list):
    """Size a fly on max loss, fee it per order, gate it on the credit it is paid.

    Nothing here divides by a premium, because a credit structure has none: the denominator is
    (width - credit) x 100 per lot, the fee gate's is the credit received, and the verdict's risk_usd
    is the max loss rather than the money deployed, which is the only way this sleeve's exposure
    reaches an audit surface that has always read risk_usd.
    """
    rk, rfee, st = rules["risk"], rules["fees"], rules.get("structure") or {}
    if proposal.get("fee_model") not in FEE_MODELS:
        reasons.append("iron_fly: fee_model %r is not one of %s" % (proposal.get("fee_model"), sorted(FEE_MODELS)))
    if proposal.get("size_basis") != "max_loss":
        reasons.append("iron_fly: size_basis %r is not 'max_loss' - a credit structure must not be sized on premium"
                       % proposal.get("size_basis"))
    width, credit = _num(proposal.get("width")), _num(proposal.get("credit"))
    # `legs_per_lot` is the adapter's declared count of contracts per leg per lot. fly_leg_rows already
    # vetoes a leg carrying more than 1, so this only catches the producer lying about it: if the field
    # and the contracts disagree, the loss identity below has no agreed denominator.
    leg_contracts = legs_per_lot([_num(leg.get("qty"), 1) for leg in (proposal.get("legs") or [])
                                  if isinstance(leg, dict)])
    declared_lpl = _num(proposal.get("legs_per_lot"))
    if declared_lpl is not None and int(declared_lpl) != leg_contracts:
        reasons.append("iron_fly: legs_per_lot %s but the legs carry up to %d contracts each - the field "
                       "and the contracts disagree about what one lot is" % (int(declared_lpl), leg_contracts))
    debit_ask, loss1, iv = _num(proposal.get("debit_at_ask")), _num(proposal.get("max_loss_per_lot")), _num(proposal.get("iv"))
    crossed = _num(proposal.get("credit_crossed"))
    claimed_loss1 = loss1
    for name, value in (("width", width), ("credit", credit), ("debit_at_ask", debit_ask),
                        ("max_loss_per_lot", loss1), ("iv", iv)):
        if value is None:
            reasons.append("iron_fly: %s missing or not numeric" % name)
    if reasons:
        return 0, None
    spot = _num(proposal.get("spot"))
    if spot and max(v for v in (credit, debit_ask, crossed) if v is not None) > spot:
        # C1's combo payload prices in 1e9-scaled units (5550000000 = $5.55/share). A credit is a few
        # dollars on a few-hundred-dollar ETF and can never exceed the underlying, so a number that big
        # is the wrong unit arriving, not a fat premium: it would size 6 orders at 5.55 billion of credit.
        reasons.append("iron_fly: credit %s / debit_at_ask %s exceeds the underlying at %s - that is a "
                       "unit error (1e9-scaled prices belong in the combo payload, not here), not a price"
                       % (credit, debit_ask, spot))
    if credit <= 0:
        reasons.append("iron_fly: credit %s is not positive - the desk is not being paid to write this" % credit)
    # The check that replaces the credit-versus-debit ordering. credit, debit_at_ask and credit_crossed
    # are three different books (bid-bid, ask-ask, bid-ask), so their order says nothing about
    # tradability - a wide wing market legitimately puts credit above the ask-based debit. What matters
    # is the crossed book: the price the desk would actually pay to lift its own wings.
    if crossed is None:
        warnings.append("iron_fly: no credit_crossed in the proposal - the executable-credit check could not run")
    elif crossed <= 0:
        reasons.append("iron_fly: credit_crossed %s is not positive - lifting both wings at the ask leaves "
                       "no credit, so there is nothing to collect for the risk" % crossed)
    elif credit is not None and crossed > credit:
        warnings.append("iron_fly: credit_crossed %s exceeds credit %s - buying at asks cannot pay more "
                        "than selling at bids, so one of the two books is stale" % (crossed, credit))
    if loss1 is not None and loss1 <= 0:
        reasons.append("iron_fly: max_loss_per_lot %s is not positive - width %s less credit %s cannot lose, so it is mis-priced"
                       % (loss1, width, credit))
    if iv is not None and iv <= 0:
        reasons.append("iron_fly: iv is not positive, so no width could have been derived - refusing to size on a made-up one")
    if None not in (width, credit, loss1):
        # The identity is re-derived and then USED: sizing on the adapter's figure would let a loss
        # understated inside the tolerance buy more lots than the cap allows. The declared number stays
        # in the verdict as `max_loss_per_lot_claimed` so a judge can see the difference. One contract
        # per leg is one lot (fly_leg_rows vetoes anything else), so the denominator is flat x 100.
        derived = round((width - credit) * CONTRACT_MULTIPLIER, 2)
        if abs(loss1 - derived) > max(0.5, 0.02 * abs(derived)):
            reasons.append("iron_fly: max_loss_per_lot %s is not (width %s - credit %s) x %s per lot = %.2f"
                           % (loss1, width, credit, CONTRACT_MULTIPLIER, derived))
            return 0, None
        if abs(loss1 - derived) > 1e-9:
            warnings.append("iron_fly: sized on the derived (width - credit) x 100 = %.2f rather than the "
                            "proposal's %s" % (derived, loss1))
            claimed_loss1 = loss1
        loss1 = derived
        # Second identity, on the other side of the multiplication: `max_loss_per_lot` x lots must be
        # the number the auditor's risk_usd and the executor's tickets are read against. A producer that
        # scales the structure but not the loss (or per-lot loss into the structure field) is caught
        # here rather than by an inside-tolerance per-lot figure that sizes the wrong position.
        declared_usd = _num(proposal.get("max_loss_usd"))
        declared_lots = int(_num(proposal.get("qty"), 0) or 0)
        if declared_usd is None:
            warnings.append("iron_fly: no max_loss_usd in the proposal - the structure-level risk could not "
                            "be cross-checked against %d lot(s) x %.2f" % (max(declared_lots, 1), derived))
        elif declared_lots >= 1:
            want = derived * declared_lots
            if abs(declared_usd - want) > max(0.5, 0.02 * abs(want)):
                reasons.append("iron_fly: max_loss_usd %s is not max_loss_per_lot %.2f x %d lots = %.2f - "
                               "the structure's risk and its size do not describe the same trade"
                               % (declared_usd, derived, declared_lots, want))
                return 0, None
    # DTE is re-derived from the codes against --now, not read from the proposal: a stale structure
    # for yesterday's expiry arrives with a plausible dte and an impossible calendar.
    want_dte = _num(st.get("dte"), 0)
    got = expiry_days(rows_expiry(proposal), et.date()) if legs_codes(proposal) else None
    if got is None:
        reasons.append("iron_fly: the legs' expiry cannot be read against --now")
    elif got != int(want_dte):
        reasons.append("iron_fly: the legs expire in %d day(s) while structure.dte is %s - this desk holds the fly to its flat-by time only"
                       % (got, want_dte))
    # The proposal's own dte is a claim, not an input: an adapter that says 0DTE while writing next
    # week's codes has either a stale chain or a different sleeve in mind, and neither is approvable.
    claim = _num(proposal.get("dte"))
    if claim is not None and got is not None and int(claim) != int(got):
        reasons.append("iron_fly: the proposal declares dte %s but its leg codes expire in %d day(s) - one of the two is wrong"
                       % (claim, got))
    # Age of the numbers. `--now` is the authority (contract section 2), and a 0DTE structure priced on
    # a previous session cannot be re-priced by the guard, so a different ET date is a veto. Sub-hour
    # age is only reported: the measured SCAN round trip is 21m47s, so a threshold tighter than that
    # would refuse every signal this desk is physically capable of producing, and that decision belongs
    # to the owner, not to a constant I invented here.
    pnow = proposal.get("now")
    if isinstance(pnow, str):
        try:
            pstamp = to_et(datetime.fromisoformat(pnow))
            if pstamp.date() != et.date():
                reasons.append("iron_fly: the proposal was built for %s but --now is %s - a 0DTE structure is not reusable across sessions"
                              % (pstamp.date(), et.date()))
            else:
                age = (et - pstamp).total_seconds() / 60.0
                if age > 60:
                    warnings.append("iron_fly: the proposal is %d minutes old at check time - re-quote before sending" % int(age))
        except ValueError:
            reasons.append("iron_fly: proposal.now %r is not an ISO-8601 timestamp" % pnow)
    cap_pct = _num(st.get("max_loss_pct_of_nav"))
    if cap_pct is None or cap_pct <= 0:
        reasons.append("iron_fly: rules.json structure.max_loss_pct_of_nav absent or not positive")
    if day.get("fly_off"):
        reasons.append("iron_fly: the fly is off today - %s" % day["fly_off"])
    # The release veto is the desk-wide rule, not the withdrawn Wed-25 conditional: calendar_rules.py
    # records why no staged Nov-25 release can reach this window. FLY_OFF is the only per-day switch.
    for name, hhmm in day.get("releases") or []:
        window = st.get("release_window_et") or []
        if len(window) == 2 and mins(window[0]) <= mins(hhmm) <= mins(window[1]):
            reasons.append("iron_fly: %s releases at %s ET, inside the structure's holding window (%s-%s)"
                           % (name, hhmm, window[0], window[1]))
    gate = proposal.get("regime_gate")
    if not isinstance(gate, dict):
        reasons.append("iron_fly: no regime_gate in the proposal - D4 is not optional")
    elif gate.get("pass") is not True:
        reasons.append("iron_fly: regime gate did not pass: %s" % gate.get("reason", "pass is not true"))
    else:
        # `pass` is the adapter's conclusion and the numbers it came from travel in the same object, so
        # the conclusion is re-derived here. A gate that reports true on numbers that fail
        # its own rule is a bug one level up, and this is the last deterministic place that can see it.
        # D4, owner-confirmed 2026-11-22: a quiet AND tight first half hour - both legs are CEILINGS,
        # `abs(move) < move_max_frac_of_em x em` AND `range < range_max_frac_of_em x em`, measured over
        # structure.regime_window_et (NOT the entry window). The range leg used to be a FLOOR
        # (`rng >= 0.39 x em`), which asked the open to be wide and then traded the breakout it had just
        # measured, and both legs shared one fraction. The window name is taken from the rules, never
        # spelled out here, so the stamped keys below cannot quietly disagree with the band.
        gw = gate.get("window_et")
        rw = st.get("regime_window_et")
        rw_ok = isinstance(rw, (list, tuple)) and len(rw) == 2
        if rw_ok:
            if gw is None:
                warnings.append("iron_fly: regime_gate does not name the window it measured, so this "
                                "check cannot confirm it is structure.regime_window_et %s-%s ET"
                                % (rw[0], rw[1]))
            elif [str(x) for x in gw] != [str(x) for x in rw]:
                reasons.append("iron_fly: the gate measured %s-%s ET but rules.json says D4's window is "
                               "%s-%s ET - a gate over a different window is not this desk's D4"
                               % (gw[0], gw[1], rw[0], rw[1]))
        elif gw is not None:
            reasons.append("iron_fly: regime_gate names window %s-%s ET but rules.json carries no "
                           "structure.regime_window_et pair to agree with - D4's window is not a number "
                           "the auditor may invent" % (gw[0], gw[1]))
        # Coverage. moomoo stamps a 5-minute bar at its CLOSE, so lo..hi is covered by the rows stamped
        # lo+5 .. hi - that is (hi-lo)/5 bars - and the builder now says how many it used and which stamps
        # bound them. This check exists because the old filter kept five of six, measured 09:30-09:55, and
        # PASSED while printing 09:30-10:00: a mislabelled measurement never gets questioned downstream.
        # Absent coverage is a warning, not a veto: the field lives in the staged builder, and refusing a
        # real structure because two publishes slipped past each other is this desk's other failure mode.
        if rw_ok:
            need = (mins(rw[1]) - mins(rw[0])) // 5
            got_n = _num(gate.get("bars_required"))
            used = gate.get("stamps")
            conv = gate.get("stamp_convention")
            if conv not in (None, "close"):
                reasons.append("iron_fly: the gate reports %r bar stamping, but D4's window is defined on "
                               "close-stamped bars, so its span is not the window it names" % (conv,))
            if got_n is None and not used:
                warnings.append("iron_fly: regime_gate reports no coverage (bars_required / stamps), so "
                                "this check cannot tell whether it measured the whole %s-%s ET window or "
                                "the first %d of its 5-minute bars" % (rw[0], rw[1], need - 1))
            else:
                if got_n is not None and got_n != need:
                    reasons.append("iron_fly: the gate covered %s bars for a %s-%s ET window, which needs "
                                   "%s five-minute bars - a short span is a different measurement, not a "
                                   "conservative one" % (got_n, rw[0], rw[1], need))
                if isinstance(used, (list, tuple)) and len(used) == 2 and str(used[1]) != str(rw[1]):
                    reasons.append("iron_fly: the gate's last bar is stamped %s but its window ends at %s - "
                                   "under close-stamping the bar that ends the window carries the window's "
                                   "end stamp" % (used[1], rw[1]))
        stag = ("%s_%s" % (str(rw[0]).replace(":", ""), str(rw[1]).replace(":", ""))) if rw_ok else None
        move = _num(gate.get("move_" + stag) if stag else None, gate.get("move"))
        rng = _num(gate.get("range_" + stag) if stag else None, gate.get("range"))
        em = _num(gate.get("em_basis", gate.get("em")))
        f_move = _num(st.get("move_max_frac_of_em"))
        f_range = _num(st.get("range_max_frac_of_em"))
        if None in (move, rng, em, f_move, f_range) or em <= 0:
            warnings.append("iron_fly: regime_gate.pass could not be re-derived from the gate's own "
                            "numbers (move/range/em_basis or one of structure.move_max_frac_of_em / "
                            "range_max_frac_of_em missing)")
        else:
            cap_move, cap_range = f_move * em, f_range * em
            if not (abs(move) < cap_move and rng < cap_range):
                reasons.append("iron_fly: regime_gate.pass is true but D4 is not satisfied: |move| %.2f "
                               "against a %.2f cap (%s x em %.2f) and range %.2f against a %.2f cap "
                               "(%s x em)"
                               % (abs(move), cap_move, f_move, em, rng, cap_range, f_range))
            for k, frac, want in (("threshold", f_move, cap_move),
                                  ("range_threshold", f_range, cap_range)):
                stated = _num(gate.get(k))
                if stated is not None and abs(stated - want) > 0.01:
                    warnings.append("iron_fly: the gate's %s %s is not %.2f (= %s x em %.2f)"
                                    % (k, stated, want, frac, em))

    book = proposal.get("book")
    if not isinstance(book, dict) or book.get("all_legs_two_sided") is not True:
        empty = "" if not isinstance(book, dict) else " [%s]" % ", ".join(str(x) for x in (book.get("empty_legs") or []))
        reasons.append("iron_fly: the books are not two-sided on all 4 legs" + empty)
    if reasons:
        return 0, None

    # THE SINGLE CUT-OFF AUTHORITY: rules.json `structure.entry_window_et[1]`, checked here and nowhere
    # else. Owner decision B7 (2026-11-22) moved the fly's entry cut-off from 10:30 to 11:00 ET; the
    # adapter does not enforce a time-of-day cut-off at all (it has no `--now` gate on entry), so this
    # branch is the only place the number is applied - a second copy in the builder would be a second
    # authority able to drift. D4's measurement window is the separate `regime_window_et` (09:30-10:00).
    # This window is narrower than the desk's own trading window, and the shared calendar check above
    # cannot express it: `timing.entry_end_et` is 15:00 for every non-hedge sleeve. Without this
    # the fly could be opened at 14:55 with nine minutes of theta left and every rule in this file
    # satisfied, which is the same self-inflicted handicap the 1-5 DTE band was.
    win = st.get("entry_window_et") or []
    if len(win) != 2:
        reasons.append("iron_fly: rules.json structure.entry_window_et is not a pair of ET times")
    else:
        now_m = et.hour * 60 + et.minute
        if now_m < mins(win[0]) or now_m >= mins(win[1]):
            reasons.append("iron_fly: %s ET is outside the entry window %s-%s ET (D4)"
                           % (et.strftime("%H:%M"), win[0], win[1]))
    floor = _num(st.get("iv_floor"))
    if floor is None:
        reasons.append("iron_fly: rules.json structure.iv_floor absent - no width can be trusted without it")
    elif iv is not None and iv < floor:
        reasons.append("iron_fly: iv %s is below structure.iv_floor %s - a width derived from that vol is noise, not an expected move"
                       % (iv, floor))
    spot = _num(proposal.get("spot"))
    if spot is not None and spot < rules["competition"]["min_price"]:
        reasons.append("iron_fly: underlying spot %s is below the %s competition minimum - this is the fly's share-price floor, kept in the fly's own reason namespace"
                       % (spot, rules["competition"]["min_price"]))
    if reasons:
        return 0, None

    nav = float(portfolio["nav"])
    # One structure per day (spec section "Size": one position per day). Owner ruling, verbatim: "One per day:
    # count only open flies." The veto that follows from the ruling is a fly leg open RIGHT NOW. The second
    # today-scoped veto below (`fly_structures_today` >= 1) is kept as found and is deliberately NOT widened to
    # a lifetime veto; the journal's sleeve-B closed-trade stats are not summed into either veto - they answer a
    # different question (what was realised) and the day-scope of `stats` is not this function's to assume.
    # What is NOT a signal: a close with no marker. A day whose one fly is already closed therefore has an OPEN
    # SLOT, and approving it is the RULED behaviour, not a bypass. What a close does not do is prove the count,
    # so the absence of the marker is reported as UNVERIFIED whether or not a close was recorded - that is the
    # whole point of the warning, and why it is keyed on one condition and says only what that condition proves.
    # Named by shape, not by letter, because "World A/B" carries two incompatible definitions in this package
    # (the sibling's fixtures and the leader's ruling do not agree):
    #   marker-absent (the shipping state - `fly_structures_today` has no producer in the mounted skill set as of
    #     2026-11-23, so the marker veto can never fire and every fly carries the unverified warning);
    #   marker-present (the veto fires from the first fly opened that day);
    #   retained-at-qty-0 (rows the broker closed and kept: not an open structure, so the slot is open);
    #   unreadable-qty (not proof of anything, so the row still counts and the cap fails closed);
    #   later-dated-option (a hedge put or a 1-5 DTE debit leg: an OSI row this sleeve did not write, so it
    #     must not consume the slot - this is the row that, until v8, vetoed every fly on a hedged day).
    # The same row-key convention book.py:160 and levels.py:74 already use: a position's contract is
    # `symbol`, falling back to `code`. A share row never parses as OSI, but an OSI row is NOT automatically
    # this sleeve's structure - the hedge is an OSI row too - so the shape test is expiry-scoped, not bare.
    fly_rows = [p for p in positions if not later_dated_option(p, et)
                and (p.get("sleeve") == "B" or p.get("kind") == "iron_fly"
                     or parse_osi(p.get("symbol") or p.get("code") or "") is not None)]
    # Open-or-unreadable, per `qty_is_open`. Only this one reader is filtered here: `open_risk`,
    # `max_positions`, `invested` and the share-branch readers below are shared with sleeves A and C and keep
    # today's behaviour, deliberately.
    open_fly = [p for p in fly_rows if qty_is_open(p)]
    already = int(_num(portfolio.get("fly_structures_today"), None) or 0)
    if open_fly:
        reasons.append("iron_fly: %d fly leg(s) already open (%s) - one structure per day"
                       % (len(open_fly), ", ".join(sorted({str(p.get("code") or p.get("ticker")) for p in open_fly}))))
    elif already >= 1:
        reasons.append("iron_fly: %d fly structure(s) already opened today - one per day" % already)
    elif _num(portfolio.get("fly_structures_today"), None) is None:
        # Keyed on ONE condition and says only what that condition guarantees: no leg is open (the branches
        # above were skipped) and the marker gives no count. A close recorded in closed_trades proves nothing
        # about today's fly count, so it no longer suppresses this - and a `[]`/`null` marker is not a count
        # either, so it warns. A readable 0 does NOT warn: the marker then says nothing is open today.
        warnings.append("iron_fly: one-per-day unverified - portfolio.json has no readable "
                        "fly_structures_today count (key absent, or not a number)")
    if reasons:
        return 0, None
    # The day's size_mult and the ladder's half_size scale the loss budget, and the product is capped
    # at 1.0: a fly's risk is bounded by its wings, so a regime multiplier is a reason to write fewer
    # lots, never a licence to write more than structure.max_loss_pct_of_nav of NAV.
    loss_mult = min(1.0, max(mult, 0.0))
    budget = nav * cap_pct / 100.0 * loss_mult
    qty = math.floor(max(budget, 0) / loss1)
    if qty < 1:
        reasons.append("iron_fly: %s%% of NAV is $%.0f and one lot risks $%.0f - size rounds to zero, the structure is too wide for the account"
                       % (cap_pct, budget, loss1))
        return 0, None
    open_risk, unpriced = open_risk_total(positions)
    if unpriced:
        reasons.append("iron_fly: open risk not evaluable (%s) - the %s%% cap cannot be measured against a "
                       "book this file cannot price, so no new structure is sized"
                       % ("; ".join(unpriced), rk["max_open_risk_pct"]))
        return 0, None
    room = nav * rk["max_open_risk_pct"] / 100.0 - open_risk
    if qty * loss1 > room:
        reasons.append("iron_fly: %d lots risk $%.0f against $%.0f of open-risk room (%s%% of NAV, already committed $%.0f)"
                       % (qty, qty * loss1, room, rk["max_open_risk_pct"], open_risk))
        return 0, None
    orders = _num(proposal.get("orders_planned"))
    if orders is None or int(orders) < 1:
        reasons.append("iron_fly: orders_planned missing - fees are charged per order and the daily order budget needs the count")
        return 0, None
    orders = int(orders)
    stopped = _num(proposal.get("orders_if_stopped"))
    if stopped is None or int(stopped) < orders:
        reasons.append("iron_fly: orders_if_stopped %r is missing or below orders_planned %d - a stop-out is the worst case the order budget must fit"
                       % (proposal.get("orders_if_stopped"), orders))
        return 0, None
    stopped = int(stopped)
    declared = _num(proposal.get("qty"))
    if declared is not None and int(declared) > qty:
        # Reduced, not refused, and said out loud: the guard is the sizing authority (contract section 3)
        # and a day whose size_mult is below 1 will disagree with any static adapter size. The number that
        # reaches the executor is this verdict's qty, which is the smaller of the two.
        warnings.append("iron_fly: the proposal sizes %d lots but %s%% of NAV at risk $%.0f allows %d - "
                        "the verdict's qty is authoritative and the adapter's sizing is wrong"
                        % (int(declared), cap_pct, budget, qty))
    elif declared is not None and int(declared) < qty:
        warnings.append("iron_fly: the proposal sizes %d lots where the budget allows %d - taking the smaller" % (int(declared), qty))
        qty = int(declared)
    # One contract per leg per lot is enforced above, so a leg order is exactly `qty` contracts and the
    # fee's n is the lot count - not lots x leg qty, which squared the size on a 2-lot ticket.
    fee_per = fee_per_option_order(rules, qty)
    fees = fee_per * orders
    credit_usd = credit * CONTRACT_MULTIPLIER * qty
    fee_pct = 100.0 * fees / credit_usd
    # The fly's fee ceiling is its OWN key. `fees.option_fee_max_pct_of_premium` (3.0) is the single-leg debit
    # option's cap, and a four-leg structure on a small credit cannot clear it: at 1 lot and 4 leg-orders the
    # fees are $9.23, which is 3.1% of a $3.00 credit but only 1.5% of a $6.00 one - the same desk and the same
    # risk, gated by the size of the credit rather than by anything it measures. Owner ruling 2026-11-23 gives
    # the fly `structure.fee_max_pct_of_credit` = 10.0 and leaves 3.0 for every other reader of the old key
    # (the single-leg option branch below, and option-adapter's sleeve_b.py). Absent the key the stricter legacy
    # number governs: a typo that deletes it must not silently buy seven extra points of slack.
    fly_fee_cap = _num(st.get("fee_max_pct_of_credit"), rfee["option_fee_max_pct_of_premium"])
    if fee_pct > fly_fee_cap:
        reasons.append("iron_fly: fees $%.2f (%d orders x $%.2f) are %.1f%% of the $%.0f credit, over %s%%"
                       % (fees, orders, fee_per, fee_pct, credit_usd, fly_fee_cap))
        return 0, None
    # The engine cap is 150/day (competition allows 200). The desk's planner charges
    # `planned_orders_per_trade` = 3 per trade, which is a share's entry/stop/close and is not this:
    # a fly is 4 orders to open and up to 4 more to close, so the count comes from the proposal. Budget
    # against the stopped number, because a stopping fly is exactly when the remaining orders still
    # have to be sent.
    placed = int(_num(portfolio.get("orders_today"), 0) or 0)
    cap = rules["competition"]["engine_orders_per_day_cap"]
    if placed + stopped > cap:
        reasons.append("iron_fly: %d orders today plus %d for this structure's worst case exceeds the engine cap of %d"
                       % (placed, stopped, cap))
        return 0, None
    if placed + stopped > 0.9 * cap:
        warnings.append("iron_fly: %d more orders on top of %d placed today - within 10%% of the engine cap" % (stopped, placed))
    if stopped != orders:
        warnings.append("iron_fly: fees gated on %d orders; the plan says a stop-out is %d, so a stopped day costs more than %s%% of the credit"
                        % (orders, stopped, round(fee_pct * stopped / orders, 1)))
    if width < _num(proposal.get("em"), width):
        warnings.append("iron_fly: wings narrower than the expected move - the shorts are expected to finish outside them")
    if loss_mult < 1.0:
        warnings.append("iron_fly: loss budget scaled to %.3f by the day's size_mult and the drawdown ladder" % loss_mult)
    if qty == 1:
        warnings.append("iron_fly: one lot - the fly is non-divisible, so one of the two shorts cannot be bought back on its own")
    ex_want = fly_exit_rules(proposal, st, loss1)
    extra = {"max_loss_per_lot": loss1}
    if claimed_loss1 is not None and abs(claimed_loss1 - loss1) > 1e-9:
        extra["max_loss_per_lot_claimed"] = claimed_loss1
    return qty, {"max_loss_usd": round(qty * loss1, 2), "credit_usd": round(credit_usd, 2),
                 "fee_per_order": round(fee_per, 2), "fees_usd": round(fees, 2),
                 "fee_pct_of_credit": round(fee_pct, 2), "orders_planned": orders,
                 "orders_if_stopped": stopped, "orders_worst_case_today": placed + stopped,
                 "max_loss_pct_of_nav": round(100.0 * qty * loss1 / nav, 3),
                 "exit": ex_want, **extra}


def fly_exit_rules(proposal: dict, st: dict, loss_per_lot=None) -> dict:
    """The exit thresholds this structure will actually be managed against, and their venue truth.

    rules.json `structure.exit` is the authority (the owner edits the skill, not the proposal), and a
    proposal that carries its own `exit_policy` is refused when it disagrees -- an adapter that quietly
    loosened the stop is the failure this desk cannot see from the account, because no option P&L comes
    back from it. The American-only rules are echoed with their applicability stated rather than
    dropped for SPXW: a judge reading the verdict has to see that they were considered and are vacuous,
    not that they went missing.
    """
    ex = dict(st.get("exit") or {})
    theirs = proposal.get("exit_policy")
    if isinstance(theirs, dict):
        for key, want in sorted(ex.items()):
            if key in theirs and theirs[key] != want:
                ex["disagreements"] = (ex.get("disagreements") or []) + [
                    "%s: proposal %r vs rules %r" % (key, theirs[key], want)]
    width = _num(proposal.get("width"))
    breach = _num(ex.get("stop_on_strike_breach_beyond"))
    american = bool(((st.get("venues") or {}).get(proposal.get("venue")) or {}).get("american"))
    # Both thresholds in USD per lot, because the spec defines them on two different bases: the target
    # is 25% of the credit and the stop is 50% of the max loss. Per-share next to per-lot here is how a
    # 100x error gets into an exit order, so the unit is in the key name and the multiplier is explicit.
    ex.setdefault("target_credit_usd_per_lot",
                  round(_num(proposal.get("credit"), 0.0) * (ex.get("target_credit_pct", 0) / 100.0) * CONTRACT_MULTIPLIER, 2))
    ex.setdefault("stop_loss_usd_per_lot",
                  round((loss_per_lot if loss_per_lot is not None
                         else _num(proposal.get("max_loss_per_lot"), 0.0)) * (ex.get("stop_credit_pct", 0) / 100.0), 2))
    ex["strike_breach_points"] = round(width * breach, 4) if width is not None and breach is not None else None
    ex["american"] = american
    ex["assignment_rules_apply"] = american
    if not american:
        ex["assignment_note"] = "European and cash-settled: no assignment, no early-exercise and nothing to close before the pin"
    return ex


def legs_codes(proposal: dict) -> list:
    return [leg.get("code") for leg in (proposal.get("legs") or []) if isinstance(leg, dict)]


def rows_expiry(proposal: dict):
    for code in legs_codes(proposal):
        parsed = parse_osi(code) if isinstance(code, str) else None
        if parsed:
            return parsed["expiry"]
    return None


def fly_verdict_fields(proposal: dict, rules: dict, qty: int, sized: dict, day: dict, phase: str,
                       warnings: list) -> dict:
    """What guard records about a fly it approved. The executable tickets stay the adapter's output."""
    ex = (rules.get("structure") or {}).get("exit") or {}
    out = dict(sized)
    # `qty` is lots, and because fly_leg_rows vetoed any leg carrying more than one contract, an
    # executor's leg order is exactly `qty` contracts. The product is stated rather than left to be
    # inferred: copying `legs[].qty` alone would under-trade a 2-lot structure by half, which is the
    # arithmetic error this convention was settled to remove.
    contracts = qty
    key_now = fly_structure_key(proposal.get("legs"))
    key_claim = str(proposal.get("structure_key")) if proposal.get("structure_key") else key_now
    if not proposal.get("structure_key") and key_now:
        warnings.append("iron_fly: the adapter stamped no structure_key - the verdict derived %s from these "
                        "legs and the executor's tickets must carry that same string" % key_now)
    out.update({
        "sleeve": "B", "kind": "iron_fly", "qty": qty, "lots": qty,
        "structure_key": key_claim, "structure_key_now": key_now,
        "underlying": proposal.get("underlying"), "venue": proposal.get("venue"),
        "expiry": proposal.get("expiry"), "dte": proposal.get("dte"),
        "width": proposal.get("width"), "em": proposal.get("em"), "iv": proposal.get("iv"),
        "atm_strike": proposal.get("atm_strike"), "credit": proposal.get("credit"),
        "debit_at_ask": proposal.get("debit_at_ask"),
        "size_basis": "max_loss", "fee_model": proposal.get("fee_model"),
        "regime_gate": proposal.get("regime_gate"),
        "legs": proposal.get("legs"),
        "order": {
            "type": "LEGGED_IRON_FLY", "legs": proposal.get("legs"),
            "contracts_per_leg_order": contracts,   # approved lots x contracts-per-lot; the fee n
            "structure_key": key_claim,             # the ticket carries the identity, it does not re-derive it
            "limit_rule": "sell the short leg at its bid, buy the long leg at its ask, one re-price after 60s",
            "order_side_note": "1 = buy, 2 = sell; SELL_TO_OPEN is DOCUMENTED (owner attestation "
                               "2026-11-22) but never OBSERVED on 5830104 - if the broker refuses a short "
                               "leg the executor runs `sleeve_b.py abort`, never a retry",
            "flat_by_et": ex.get("shorts_flat_by_et"),
        },
        "protection": {
            "max_loss_per_lot": sized["max_loss_per_lot"],
            "max_loss_usd": sized["max_loss_usd"],
            "mechanism": "monitored",
            "no_resting_stop": "a paper account takes LIMIT and MARKET only, DAY validity, and a sell "
                               "limit below the last price fills at once - a fly has no resting order. Its "
                               "loss bound is the wings; the scheduled checks watch the credit.",
            "exit_targets": {"target_credit_pct": ex.get("target_credit_pct"),
                             "stop_credit_pct": ex.get("stop_credit_pct"),
                             "shorts_flat_by_et": ex.get("shorts_flat_by_et"),
                             "checks_every_min": ex.get("checks_every_min"),
                             "wing_min_bid": ex.get("wing_min_bid"),
                             "stop_on_strike_breach_beyond": ex.get("stop_on_strike_breach_beyond")},
            "enforcement_lag_min": ex.get("enforcement_lag_min"),
            "backstop": "max_loss",
        },
        "needs_human_approval": phase == "approval",
        "notes": day["notes"],
    })
    return out


def option_round_trip_fee(rules: dict, contracts: int) -> float:
    f = rules["fees"]
    return 2 * (f["option_min_commission"] + f["option_platform_per_contract"] * contracts)

def stock_round_trip_fee(rules: dict, qty: int) -> float:
    f = rules["fees"]
    per_side = f["stock_platform_fee_per_order"] + min(f["stock_transaction_fee_per_share"] * qty, f["stock_transaction_fee_cap"])
    return 2 * per_side  # buy + sell


def _verdict(approved, reasons, warnings, **extra) -> dict:
    out = {"approved": approved, "reasons": reasons or ["ok"], "warnings": warnings}
    out.update(extra)
    return out


def is_number(value) -> bool:
    """Whether a portfolio.json figure can be used as a number: finite int/float or numeric string, not a bool."""
    if isinstance(value, bool):
        return False
    if isinstance(value, (int, float)):
        return math.isfinite(value)
    try:
        return math.isfinite(float(value))
    except (TypeError, ValueError):
        return False


def check(proposal: dict, portfolio: dict, now: datetime, rules: dict, phase: str = "bounded",
          allow_unknown_cash: bool = False) -> dict:
    reasons: list[str] = []
    warnings: list[str] = []
    r, comp, rk = rules, rules["competition"], rules["risk"]
    nav = float(portfolio["nav"]) if is_number(portfolio.get("nav", None)) else math.nan  # numeric-string NAV is an expected shape, not a data gap

    # cash is the one rule input with no fallback upstream -- the auditor pastes it out of a tool result
    # into portfolio.json, and unread account data has landed there as a string sentinel before. A gap is
    # a gap, so record it in the shared reasons list and let the existing gate below decline alongside
    # every other problem. Guessing 0 instead would bind size to the 10% cash floor and report a reason
    # that is not true. cash is poisoned to NaN so it cannot silently reach sizing if the gate changes.
    cash_raw = portfolio.get("cash", None)
    if is_number(cash_raw):
        cash = float(cash_raw)
    elif allow_unknown_cash:
        cash = 0.9 * nav
        warnings.append("cash unread in portfolio.json: --allow-unknown-cash assumed 90% of NAV, the most the 10% cash floor itself permits; other caps still applied")
    else:
        cash = math.nan
        reasons.append(("cash missing from portfolio.json" if "cash" not in portfolio else
                        f"cash is not numeric in portfolio.json: {cash_raw!r}") +
                       ": read it from the moomoo account summary and rebuild portfolio.json, or pass --allow-unknown-cash")

    et = to_et(now)
    state, dd, day_loss = drawdown_state(r, portfolio)
    kind = proposal.get("kind", "share")   # share | option | iron_fly - the branch driver
    sleeve = proposal["sleeve"]            # trend | option | hedge | B; an iron_fly is sleeve B
    ticker = proposal["ticker"]            # stays a hard requirement: every branch reads it
    info = {"state": state, "drawdown_pct": dd, "day_loss_pct": day_loss, "time_et": et.strftime("%Y-%m-%d %H:%M")}

    # 0. Closing orders are always allowed: they only reduce risk.
    if proposal.get("is_close"):
        return _verdict(True, ["closing order: always allowed"], [], size_mult=1.0, **info)

    # 0b. Every size rule below divides by an account figure, so an unread portfolio cannot be evaluated
    # at all. Decline with a reason rather than raising: a traceback leaves the coordinator with no
    # verdict to act on, and this is the same refusal the cash rule makes two blocks down. Closes stay
    # exempt above, so FLAT remains reachable when the account read is the thing that failed.
    if state == "state_unavailable":
        unread = [k for k in ("nav", "peak_nav", "day_start_nav") if not is_number(portfolio.get(k, None))]
        return _verdict(False, ["portfolio not read from a live account: " + ", ".join(unread)
                                + " missing or non-numeric in portfolio.json"], warnings, size_mult=0.0, **info)

    # 0c. Three more portfolio fields are consumed as a number or a container further down (orders_today in
    # the 150/day cap, positions in the position-count cap and every aggregate sum, closed_trades in the
    # disable flag and the expectancy gate). A recorded real portfolio carried the string "UNVERIFIED" in all
    # three -- the auditor's honest marker for "I could not read the account" (2026-11-17 SOXS) -- and each
    # one raised instead of declining: str + int at orders_today, AttributeError at closed_trades. A traceback
    # leaves the coordinator with no verdict to act on, and it aborts every sleeve, not just the one asked
    # about. Only a value that is PRESENT and unusable is refused here; an absent one keeps its documented
    # default, because refusing absent keys would veto books that simply do not carry the field.
    mag = []
    _ot = portfolio.get("orders_today", 0)
    if not is_number(_ot) or float(_ot) < 0:
        mag.append(f"portfolio.orders_today is not usable ({_ot!r}): it is what the engine's 150/day order "
                   "cap is compared against - expected a non-negative number")
    _pos = portfolio.get("positions", [])
    if not isinstance(_pos, list):
        mag.append(f"portfolio.positions is not usable ({_pos!r}): it is the held book the position-count "
                   "limit counts and every aggregate cap sums over - expected a list, empty if flat")
    _ct = portfolio.get("closed_trades")
    if _ct is not None and not isinstance(_ct, dict):
        mag.append(f"portfolio.closed_trades is not usable ({_ct!r}): it is the per-sleeve map the U1 disable "
                   "flag and the expectancy gate read - expected a mapping of sleeve to row, or absent")
    if mag:
        return _verdict(False, ["magnitude_field_missing: " + "; ".join(mag)], warnings, size_mult=0.0, **info)

    # 0d. The proposal-side equivalent of 0c. Three of these paths were measured against the live guard with
    # the recorded corpus (2026-11-22-guard-magnitude/tools/probe_defaults.py), not assumed: a share ticket
    # with no `stop` RAISED at `entry - stop` below, a fly-shaped proposal with no `kind` was refused with
    # "price below $1.00 competition minimum" because the default routed a premium through share math, and an
    # absent `regime_mult` costs 2x risk on the SPY ticket the auditor really wrote without the key on
    # 2026-11-18 (47 shares / $347.45 against 23 / $171.04 at 0.5), nothing on the SOXS ticket because the
    # single-asset cap binds first, and structurally nothing on a fly, whose multiplier is capped at 1.0 at
    # loss_mult below -- and a fly is left out of that warning entirely because `sleeve_b_fly.py` never emits
    # the key: the fly's regime control is the D4 `regime_gate`, re-derived from the gate's own bars at line
    # 502, not a size multiplier. So the ceiling is refused nowhere -- it is warned, because vetoing an absent
    # `regime_mult` would block sleeve-A tickets the desk has accepted every day this week, and the prompt
    # that supplies the key is not in this ET day's write budget. A refusal here is only for the shapes that
    # were never legitimate: two crashes and a mis-routed structure. The crash axis was measured over the
    # value types a real ticket can actually carry (absent, None, a string, a list, a dict) rather than
    # reasoned about, because reasoning about it first got it wrong: `probe_defaults.py --candidate` showed
    # that a `stop` of `0` or `None` does not raise (it is refused above by `magnitude_gaps`), while an
    # `entry` of `None` does, and the guard's own entry refusal sits BELOW the line that raises.
    if "kind" not in proposal:
        if "legs" in proposal or "option" in proposal:
            reasons.append("proposal.kind is absent while the ticket carries `%s`: `kind` is the branch "
                           "driver, and with the key missing this was read as 'share' and sized with share "
                           "math - send the whole contract shape, including `kind`"
                           % ("legs" if "legs" in proposal else "option"))
    elif proposal["kind"] not in ("share", "option", "iron_fly"):
        reasons.append("proposal.kind %r is not share, option or iron_fly: the branch driver is a closed "
                       "set, and a value outside it would be priced by whichever branch a typo matched"
                       % (proposal["kind"],))
    # Both of these are refused and returned, not appended: an unusable price or an unusable stop makes the
    # arithmetic below unevaluable, and the guard already has that shape at 0c for an unread portfolio. v3
    # reached the `$1.00 competition minimum` comparison with a string or None entry and raised there, and
    # raised at the `entry - stop` subscript with no stop -- two crashes, measured, not assumed. The entry
    # refusal that v3 already owns further down ("entry is not a number", the same words the size rule uses)
    # is dead code for exactly that reason: the comparison that crashes sits above it.
    #
    # The validation is gated on the ticket actually being share-SHAPED, not just on `kind` defaulting to
    # share: a fly legitimately carries `stop: null` because the engine derives the level from the legs, and
    # an option proposal legitimately carries no stop at all. Running share arithmetic over those would have
    # invented a defect on the two shapes this desk is about to start trading, which the frozen contract
    # example proves (`proposal_mut()["stop"] is None`).
    unread_ticket = []
    if kind == "share" and "legs" not in proposal and "option" not in proposal:
        for key, how in (("stop", "nav x trade_risk_pct x mult / (entry - stop), so with no stop there is no "
                                 "risk unit to size against and no level for the monitored stop to enforce"),
                         ("entry", "the same line's denominator, and the first check that touches it compares "
                                  "it against the $1.00 competition minimum")):
            _v = proposal.get(key)
            if _v is None or not is_number(_v) or float(_v) <= 0:
                unread_ticket.append(f"proposal.{key} is missing or not a positive number ({_v!r}): the share "
                                     f"size is {how}")
    if unread_ticket:
        # `reasons` is kept: the `kind` diagnosis two blocks up is the more important sentence when a
        # structure arrives without its branch driver, and returning only this block would drop it.
        return _verdict(False, reasons + unread_ticket, warnings, size_mult=0.0, **info)
    if kind in ("share", "option") and sleeve != "hedge" and "regime_mult" not in proposal:
        warnings.append("proposal.regime_mult absent: the guard defaults it to 1.0, which is the regime "
                        "table's `normal` ceiling, so a caution or bear day is traded at full size - the "
                        "number is produced by trend-signal's own output, so pass it through instead of "
                        "letting the default answer")
    if sleeve == "hedge" and "regime_hedge_mult" not in proposal:
        warnings.append("proposal.regime_hedge_mult absent: the hedge budget multiplies a default of 1.0 "
                        "before capping at hedge_max_multiplier, so in the regimes whose table row says 1.5 "
                        "the desk is under-hedged by a field nobody filled in")

    # 1. Right account only.
    name = portfolio.get("account_name", "")
    if not any(s.lower() in name.lower() for s in r["account"]["name_contains"]):
        reasons.append(f"account '{name}' is not the competition account")
    if r["account"]["account_id"] and str(portfolio.get("account_id")) != str(r["account"]["account_id"]):
        reasons.append("account id mismatch")
    if portfolio.get("account_mode", "SIMULATE") != "SIMULATE":
        reasons.append("account is not SIMULATE")

    # 2. Calendar and clock.
    day = cal.day_rules(et.date(), r["timing"])
    if day["status"] == "closed":
        reasons.append("market closed today")
        return _verdict(False, reasons, warnings, size_mult=0.0, notes=day["notes"], **info)
    now_m = et.hour * 60 + et.minute
    if sleeve != "hedge":
        if now_m < mins(day["entry_start"]):
            reasons.append(f"before entry window ({day['entry_start']} ET)")
        if now_m >= mins(day["entry_end"]):
            reasons.append(f"after entry window ({day['entry_end']} ET)")
        for a, b in day["no_entry"]:
            if mins(a) <= now_m < mins(b):
                reasons.append(f"event blackout {a}-{b} ET")
    elif now_m < mins("09:35") or now_m >= mins("15:55"):
        reasons.append("hedges are placed during the regular session only")

    # 3. Drawdown ladder (permanent: the competition has no reset card).
    if state in ("kill_switch", "hedges_and_closes_only", "daily_halt") and sleeve != "hedge":
        reasons.append(f"state={state}: no new risk")
    mult = day["size_mult"] * (0.5 if state == "half_size" else 1.0) * proposal.get("regime_mult", 1.0)

    # 3a. `closed_trades` is read twice below, once for the disable flag and once for the expectancy gate.
    # Step 0c already refused a value that is present and not a mapping, so the only shapes left here are a
    # real per-sleeve map and an absent key.
    _ct = portfolio.get("closed_trades") or {}

    # 3b. A sleeve the desk had to stop for a reason that is not a number: U1 (can this account sell to
    # open?) is DOCUMENTED by owner attestation and still not OBSERVED on 5830104, so if the broker ever
    # refuses a short leg the executor's abort journals it and this row retires the sleeve for the rest of
    # the contest. It rides `closed_trades[sleeve]` -- the same channel as the expectancy gate below --
    # because that is the only sleeve-scoped, journal-sourced, guard-enforced one here: `state` cannot say
    # it (the ladder is NAV-derived and resets), and rules.json would need a publish per incident. Closes
    # never reach here: step 0 returns for them, so a disabled sleeve can still be unwound.
    _srow = _ct.get(sleeve)
    _stop = _srow.get("disabled") if isinstance(_srow, dict) else None
    if _stop:
        reasons.append("sleeve %s disabled by the desk: %s - journaled, and only the human owner clears it"
                       % (sleeve, _srow.get("disabled_reason") or _stop))

    # 4. Expectancy gate: stop feeding a sleeve that is losing money after costs.
    st = _ct.get(sleeve)
    if st and sleeve != "hedge":
        g = r["expectancy_gate"]
        # `n` is what decision-journal `stats` emits; `qty` is what the auditor has been seen to write by
        # hand. Read both aliases, and never index a row blindly: the old `st["n"]` raised KeyError on a
        # differently-named row and aborted the whole check, not just this gate. Evidence that cannot be
        # read is a veto, not a silent pass.
        n = _num(st.get("n"), None) if isinstance(st, dict) else None
        if n is None and isinstance(st, dict):
            n = _num(st.get("qty"), None)
        exp = _num(st.get("expectancy"), None) if isinstance(st, dict) else None
        if n is None or exp is None:
            reasons.append(f"sleeve {sleeve} blocked: closed_trades[{sleeve}] is {type(st).__name__} with no "
                           f"usable trade count or expectancy - the expectancy gate cannot be evaluated, "
                           "so no new risk")
        elif n >= g["min_trades_disable"] and exp < 0:
            reasons.append(f"sleeve {sleeve} disabled: expectancy {exp:.2f}/trade after {n:.0f} trades")
        elif n >= g["min_trades_half_size"] and exp < 0:
            mult *= 0.5
            warnings.append(f"sleeve {sleeve} half size: negative expectancy after {n:.0f} trades")

    # 5. Order budget.
    if portfolio.get("orders_today", 0) + comp["planned_orders_per_trade"] > comp["engine_orders_per_day_cap"]:
        reasons.append("daily order cap reached (competition limit 200, engine cap 150)")
    if len(portfolio.get("positions", [])) >= comp["max_positions"]:
        reasons.append("position count limit")

    # 6. Universe.
    uni = r["universe"]
    if kind in ("share", "iron_fly"):
        if ticker not in uni["shares"]:
            reasons.append(f"{ticker} not in the approved share universe")
        # The $1.00 competition minimum is a price-per-share rule. A fly's own price is a per-contract
        # premium, and its proposal carries no `entry` at all, so applying it here vetoed every iron fly
        # with a reason that is not prefixed `iron_fly:` -- which section 2 of the contract forbids,
        # because the coordinator then cannot tell a malformed structure from a market condition. The
        # equivalent floor (underlying spot above $1) is checked inside fly_leg_rows, in the fly's own
        # namespace.
        if kind == "share" and proposal.get("entry", 0) < comp["min_price"]:
            reasons.append("price below $1.00 competition minimum")
    else:
        und = proposal.get("underlying", ticker)
        if und not in uni["option_underlyings"]:
            reasons.append(f"{und} not in the approved option underlyings")

    if reasons:
        return _verdict(False, reasons, warnings, size_mult=round(mult, 3), notes=day["notes"], **info)

    positions = portfolio.get("positions", [])
    share_pos = [p for p in positions if p.get("kind", "share") == "share"]
    lev = uni["leverage"].get(ticker, 1)

    if kind == "iron_fly":
        fly_reasons: list[str] = []
        if sleeve != "B":
            fly_reasons.append(f"iron_fly: sleeve {sleeve!r} is not B - a fly is its own sleeve, not an option premium")
        rows = fly_leg_rows(proposal, r, fly_reasons)
        fly_qty, sized = (0, None) if rows is None else fly_structure(
            proposal, portfolio, positions, r, mult, et, day, fly_reasons, warnings)
        if sized is None:
            return _verdict(False, fly_reasons, warnings, size_mult=round(mult, 3),
                            notes=day["notes"], **info)
        return _verdict(True, ["ok"], warnings, size_mult=round(mult, 3),
                        risk_usd=sized["max_loss_usd"],
                        **fly_verdict_fields(proposal, r, fly_qty, sized, day, phase, warnings), **info)

    if kind == "share":
        entry, stop = proposal["entry"], proposal["stop"]
        dist = entry - stop
        if dist <= 0:
            return _verdict(False, ["stop must be below entry for a BUY (bearish ideas use inverse ETFs)"], warnings, **info)
        qty = math.floor(nav * rk["trade_risk_pct"] / 100 * mult / dist)
        cap = nav * comp["single_asset_target_pct"] / 100
        cur = sum(p["market_value"] for p in share_pos if p["ticker"] == ticker)
        q_cap = math.floor(max(cap - cur, 0) / entry)
        eff_now = sum(p["market_value"] * uni["leverage"].get(p["ticker"], 1) for p in share_pos)
        q_gross = math.floor(max(nav * rk["max_effective_gross_pct"] / 100 - eff_now, 0) / (entry * lev))
        cash_room = cash - nav * rk["min_cash_pct"] / 100
        q_cash = math.floor(max(cash_room, 0) / entry)
        open_risk, unpriced = open_risk_total(positions)
        if unpriced:
            return _verdict(False, [f"open risk not evaluable ({'; '.join(unpriced)}): the "
                                    f"{rk['max_open_risk_pct']}% cap cannot be measured against a book the "
                                    "guard cannot price, so no new risk is sized. Read the legs and rebuild "
                                    "portfolio.json, or close the structure."],
                            warnings, size_mult=round(mult, 3), **info)
        risk_room = nav * rk["max_open_risk_pct"] / 100 - open_risk
        q_risk = math.floor(max(risk_room, 0) / dist)
        binding = min((qty, "risk per trade"), (q_cap, "35% single-asset target"), (q_gross, "effective gross cap"),
                      (q_cash, "10% cash floor"), (q_risk, "open risk cap"))
        qty = binding[0]
        if qty < 1:
            return _verdict(False, [f"size rounds to zero (binding: {binding[1]})"], warnings, size_mult=round(mult, 3), **info)
        if binding[1] != "risk per trade":
            warnings.append(f"size limited by {binding[1]}")
        invested = (sum(p["market_value"] for p in positions) + qty * entry) / nav * 100
        tickers = {p["ticker"] for p in share_pos} | {ticker}
        if invested > comp["min_tickers_when_invested_pct"] and len(tickers) < comp["min_distinct_tickers"]:
            warnings.append("ASSUMPTION to confirm with organisers: competition asks for 3+ distinct tickers; add another ticker")
        order = {"type": "LIMIT", "limit_price": round(entry, 2), "ladder": "+0.01 every 60s, never above entry*1.002",
                 "take_profit": proposal.get("target"), "flat_by_et": day["flat_by"]}
        fee = stock_round_trip_fee(r, qty)
        risk_amt = qty * dist + fee
    else:
        o = proposal["option"]
        cost1 = o["premium"] * 100
        if sleeve == "hedge":
            hmult = min(proposal.get("regime_hedge_mult", 1.0), rk["hedge_max_multiplier"])
            if not 7 <= o.get("dte", 0) <= 45:
                return _verdict(False, ["hedge DTE must be 7-45"], warnings, **info)
            held = sum(p.get("cost", 0) for p in positions if p.get("sleeve") == "hedge")
            budget = nav * rk["hedge_premium_pct"] / 100 * hmult - held
        else:
            budget = nav * rk["option_trade_risk_pct"] / 100 * mult
            held = sum(p.get("cost", 0) for p in positions if p.get("kind") == "option" and p.get("sleeve") != "hedge")
            budget = min(budget, nav * rk["max_open_option_premium_pct"] / 100 - held)
        qty = math.floor(max(budget, 0) / cost1)
        if qty < 1:
            return _verdict(False, ["option premium exceeds the sleeve budget"], warnings, size_mult=round(mult, 3), **info)
        fee = option_round_trip_fee(r, qty)
        if fee > r["fees"]["option_fee_max_pct_of_premium"] / 100 * qty * cost1:
            return _verdict(False, [f"round-trip fees ${fee:.2f} are over {r['fees']['option_fee_max_pct_of_premium']}% of premium ${qty * cost1:.0f}"],
                            warnings, **info)
        order = {"type": "LIMIT", "limit_price": round(o["premium"], 2), "note": "options accept limit orders only; no resting stop possible",
                 "flat_by_et": None if sleeve == "hedge" else day["flat_by"]}
        risk_amt = qty * cost1
        if sleeve != "hedge" and o.get("dte", 1) == 0:
            if str(ticker).upper().startswith("SPXW"):
                warnings.append("0DTE SPXW: European and cash-settled at the close - nothing to exercise and nothing to assign")
            else:
                warnings.append("0DTE ETF option: American, so it can be assigned; the desk is flat by %s regardless" % day["flat_by"])

    # Kept byte-identical to live for both debit paths: `stop_level` is what the auditor's monitored-stop
    # check reads, and an option proposal's stop is proposal["stop"]. A fly never reaches here -- it
    # returns from the iron_fly branch above, whose protection block (fly_verdict_fields) deliberately
    # carries no stop_level, because one level would be read as "the stop" of a four-leg structure.
    protection = {"stop_level": (round(stop, 2) if kind == "share" else proposal.get("stop")),
                  "mechanism": "monitored",
                  "note": "no STOP order type exists on a paper account (LIMIT and MARKET only, DAY validity); a sell limit below the last price fills at once, so this level is enforced by the next scheduled check rather than resting"}
    approvals = phase == "approval"
    return _verdict(True, ["ok"], warnings, qty=qty, risk_usd=round(risk_amt, 2), size_mult=round(mult, 3), order=order, protection=protection,
                    needs_human_approval=approvals, notes=day["notes"], **info)


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check")
    c.add_argument("--proposal", required=True)
    c.add_argument("--portfolio", required=True)
    c.add_argument("--now", required=True)
    c.add_argument("--phase", default="approval", choices=["approval", "bounded"])
    c.add_argument("--allow-unknown-cash", action="store_true",
                   help="size a proposal when portfolio.json has no numeric cash, assuming 90% of NAV and recording a warning")
    c.add_argument("--rules")
    d = sub.add_parser("day")
    d.add_argument("--now", required=True)
    d.add_argument("--rules")
    f = sub.add_parser("fee")
    f.add_argument("--kind", required=True, choices=["share", "option"])
    f.add_argument("--qty", required=True, type=int)
    f.add_argument("--rules")
    a = ap.parse_args()
    rules = load_rules(a.rules)
    if a.cmd == "fee":
        fn = stock_round_trip_fee if a.kind == "share" else option_round_trip_fee
        out = {"kind": a.kind, "qty": a.qty, "fee": round(fn(rules, a.qty), 2)}
    else:
        now = datetime.fromisoformat(a.now)
        if a.cmd == "day":
            out = cal.day_rules(to_et(now).date(), rules["timing"])
            out["verify"] = cal.VERIFY
        else:
            out = check(json.loads(Path(a.proposal).read_text()), json.loads(Path(a.portfolio).read_text()), now, rules, a.phase,
                        allow_unknown_cash=a.allow_unknown_cash)
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
