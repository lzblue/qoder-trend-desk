# Change-budget policy update, 2026-11-20 — DRIVER §6.4 v2: two changes per template per ET day, gated on conditions A + B

**Prepared by mailbox session `20261120T035258Z-84b7e1`** on 2026-11-20, implementing the
owner-confirmed policy update. Cloud posture for the whole task: **GET-only against
api.qoder.com** — no skill publish, no template/schedule write, no rules.json or
AUTONOMY_PHASE change, no orders, account 5830104 untouched, no moomoo calls. Every gate
test ran against fixtures or a loopback mock; nothing in this memo is evidence of a
production write, because none happened.

**Status of the deliverables:**

| deliverable | status |
|---|---|
| Gate scripts enforcing rule v2 (task 1) | **shipped and tested** — shared rule in `.scratch/proposal-a-1120/tools/budget.mjs`, SPXS adapter `.scratch/changes/2026-11-20-spxs-eligibility/tools/budget.mjs`, recorder `record-change.mjs`, wired into both SPXS `apply.sh` scripts and exercised end-to-end by `apply.sh` in the proposal-a suite |
| Sequencing re-analysis (task 2) | **re-confirmed live 05:19:03Z** — see §7: latency fix + SPXS Package A CAN land on the same Nov-20 ET day, latency applied + recorded first. Staged runbook replacement at `.scratch/budget-84b7e1/staged/runbook-accelerated.md` (d20f3e's runbook not edited in place) |
| This memo (task 3) | this file |
| DRIVER.md §6.4 replacement | **STAGED, not applied** — `.scratch/budget-84b7e1/staged/DRIVER-6.4-rule.md` (source `.scratch/mailbox/DRIVER.md` sha256 `c2e48f33…`, re-verified unchanged twice) |

## 1. The rule, old and new

**OLD** — DRIVER.md §6.4, verbatim at the captured sha:

```text
**Apply in the change window only.** One change per template per day so effects can be attributed. Pin skill versions; no binding may resolve to `latest`.
```

**NEW** — staged replacement (full text in the staged file; the operative parts):

> Up to two changes per template per ET calendar day (America/New_York; during EST the ET day rolls at 05:00Z …). The second change on a template on the same ET day is allowed only when BOTH conditions hold:
> **(A)** the first change of that ET day on that template is applied and re-verified live — the write landed and a live read-back matched the intended bytes/binding, and a real downstream run behaved as expected; if no run has happened yet, at minimum a direct live-read verification of the new bytes plus a synthetic/replay check against them. A rolled-back change never satisfies (A), though it still counts toward the cap.
> **(B)** the two changes touch non-overlapping artifacts on that template: a `system` prompt edit and a skill-version rebind are different artifacts; two edits to the same artifact, or two rebinds of the same skill, are not, and stay on separate ET days.
> The first change of an ET day on a template that carries an unledgered same-day write is refused (condition A cannot be shown for an unattributed write).

Two definitions the new text fixes that the old text left implicit:

- **"day" now means the America/New_York calendar day**, not UTC and not the 16:45→08:30 ET
  change window (which crosses ET midnight and would make "per day" ill-posed). During EST
  the ET day rolls at 05:00Z. Reasons recorded in `tonight-release-sequence-nov20.md` §3:
  the same rule's change window is defined in ET, every desk schedule is
  `America/New_York`, and the stated purpose of §6.4 — attribution — has one US session as
  its natural unit. The known counter-reading (§9.2 of that memo: no second researcher
  write before 21:45Z) is acknowledged there and was settled by the owner for these
  releases; the gate prints both the ET-day and the same-window facts on every run so a
  future disagreement is visible, not buried.
- **"change" now means one artifact-set mutation on one template**, with artifacts drawn
  from `system` and `skill/<skill_id>` (grammar below). One POST that carries both `system`
  and `skills` counts as ONE change touching two artifacts (this is how night 3's
  single-POST plan stays legal); two POSTs to the same template are two changes.

## 2. Why the conditions are what they are

- **A (applied + re-verified live + downstream proof).** A second same-day change is only
  attributable if the first one demonstrably landed and demonstrably behaves. Mock/offline
  tests prove the *tooling*, never the *cloud*, so the owner's text excludes them: A
  requires a live read-back plus either a real run or (before any run exists) a live-read
  verification plus a synthetic/replay check against the new live bytes. The proposal-a
  recorder's `--live-check` implements exactly that fallback: it re-GETs the template,
  hashes the live `system`, compares against `after/manifest.json`, and asserts the insert
  appears exactly once — then writes the proof under `verify/` and records it as the
  downstream entry with kind `replay`.
- **B (artifact disjointness).** Attribution survives two same-day changes only if they
  cannot have interfered. A prompt edit and a skill rebind touch disjoint fields of the
  template (and the SPXS repin POSTs `{skills: …}` only), so they are non-overlapping by
  construction. Two edits to the same `system`, or two rebinds of the same skill, cannot
  be separated after the fact — refused, separate ET days.
- **Rolled-back changes still count.** A rollback is itself an write with effects; letting
  it free the slot would allow unbounded writes per day as long as each was undone.
- **Unledgered same-day writes block change #1-of-day-2.** If a template was written today
  but no ledger record exists, condition A is *unshowable*, not merely unmet — so the gate
  refuses the next write that day (fail-closed, same posture as v1's "spent" verdict). This
  is what catches a session that writes without recording.
- **Accepted trade-off.** With both researcher changes landing in the same window before
  BRIEF, run-level attribution is partially conceded for that day; artifact-level attribution
  (the `artifacts` field of each ledger entry) is preserved, and the owner accepted this
  when confirming the policy (staged runbook §5 states it explicitly).

## 3. Exact gate logic

One implementation: `runGate({scope, ledgerPath, base, log})` exported from
[.scratch/proposal-a-1120/tools/budget.mjs](C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/tools/budget.mjs).
Callers: the proposal-a CLI (`node --env-file=.env …/budget.mjs`, scope from `--change` /
`BUDGET_CHANGE`, else derived from `after/manifest.json` = `["system"]` on
researcher+coordinator, else audit mode over the four production templates with `["*"]`),
and the SPXS adapter
[.scratch/changes/2026-11-20-spxs-eligibility/tools/budget.mjs](C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-spxs-eligibility/tools/budget.mjs)
which derives scope from the **live bindings** (every template currently pinning any of the
three published skills, with exactly those `skill/<id>` artifacts — today researcher ×3,
risk_auditor ×2, executor ×2; coordinator and executor-gating-rehearsal bind none and are
out of scope because repin never POSTs them).

Per in-scope template, evaluated with `now` (AS_OF override allowed only against a
non-production base; refused on production):

| # | state of that template at `now` (ET day D) | verdict |
|---|---|---|
| 1 | `now` outside the 16:45–08:30 ET change window | REFUSED |
| 2 | no ledger entry today, live `updated_at` on an earlier ET day | **ALLOWED — change #1** (WARN if that write sits in the same continuous window) |
| 3 | no ledger entry today, live `updated_at` on ET day D | REFUSED — unledgered same-day write; A unshowable |
| 4 | ≥ 2 ledger entries today | REFUSED — cap of 2 |
| 5 | 1 entry today, live `updated_at` NOT on ET day D | REFUSED — ledger/state mismatch (entry claims an apply that the live bytes don't show) |
| 6 | 1 entry today, `applied.rolled_back` set | REFUSED — A unmet (rolled back) |
| 7 | 1 entry today, `readback.ok !== true` | REFUSED — A unmet |
| 8 | 1 entry today, `downstream.kind ∉ {live_run, replay}` | REFUSED — A unmet |
| 9 | 1 entry today, `downstream.outcome !== "as_expected"` | REFUSED — A unmet |
| 10 | 1 entry today, artifact sets intersect (`*` overlaps everything) | REFUSED — B unmet |
| 11 | 1 entry today, conditions A + B both satisfied | **ALLOWED — change #2** (WARN if both changes mutate the skills array) |

Refusals from rows 1/3/4/5 have a concrete next instant (the next ET day that both falls in
a change window and postdates the last write — computed with a two-probe DST-safe
conversion); refusals from rows 6–10 are calendar-independent and the gate instead says
"re-run this gate once the failed condition is met", noting that A can still be satisfied
later the same ET day while B cannot.

**Exit codes:** 0 = every in-scope template eligible; 2 = bad invocation (missing PAT, bad
scope JSON, AS_OF on production, GET failure, or an **ET self-check failure** — the gate
asserts 05:00:00Z→Nov-20 00:00 ET, 04:59:59Z→Nov-19, 12:00Z→07:00 ET before gating anything,
so an unusable `America/New_York` fails loud instead of misdating the budget); 3 = refused
(any row 1/3–10, or a corrupt ledger).

**Ledger** `.scratch/changes/budget-ledger.json`, schema 2, one entry per applied change:

```
{ seq, change_id, package, recorded_at_utc, et_day, template_id, template_name,
  artifacts: ["system" | "skill/skill_[0-9a-z]+", ...],
  applied: { go: true, at_utc, confirm, rolled_back?: { at_utc, ref } },
  readback: { at_utc, ok, detail },
  downstream: { kind: "live_run" | "replay", at_utc, ref, outcome, detail } }
```

`et_day` is computed from the **apply instant**, never wall clock. Writes are tmp-file +
rename. The recorder
([record-change.mjs](C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/tools/record-change.mjs))
refuses: duplicate `(template, ET day, artifact set)`; live bytes that do not match
`after/manifest.json` (live-state gate **before** the dup check — never record evidence
over drifted bytes); `AS_OF` on production. `mark-rolled-back <change_id> --ref` marks a
rolled-back entry (counts toward the cap, never satisfies A). `--live-check` produces the
synthetic replay proof itself; `--evidence <file>` accepts external proof (a real run log)
and copies it under `verify/`.

**What a refusal actually enforces:** the ledger is a local file and the cloud has no
budget concept, so enforcement is at the gate — every write path that matters now runs the
gate first (both SPXS `apply.sh` scripts refuse with "REFUSED by the change-budget gate"
and exit with the gate's code before any POST; proposal-a's `apply.sh` runs its own v2
gate inline). A session that bypasses the gate entirely is caught at the *next* gate run by
row 3, not prevented. That is the honest limit: the gate makes the rule checkable and the
check unavoidable at every scripted write path, but nothing stops an unscripted raw POST.

## 4. Test evidence

All tests local/loopback. No cloud write was needed or made; the one live interaction in
the whole task was the sequencing re-check (§7), which is GET-only.

### 4.1 Proposal-a suite — `bash .scratch/proposal-a-1120/tools/roundtrip.sh`

Run 3 (after the fixes below): **exit 0, 27 PASS, 0 FAIL, "ROUND TRIP: PASS"**
(`.scratch/proposal-a-1120/proof/roundtrip-run3.log`). Against a loopback mock seeded with
the real live `before/` bytes, `MOCK_NOW` pinned so ET arithmetic is deterministic:

| scenario | proves | result |
|---|---|---|
| 1, 2 | dry apply / dry rollback write nothing | PASS |
| 3 | wrong CONFIRM refused, exit 2, 0 writes | PASS |
| 4 | outside-window refused, exit 3, next slot named (21:45Z = 16:45 ET) | PASS |
| 5 | unledgered same-ET-day write refuses change #2 ("has no ledger record"), exit 3 | PASS |
| 6 | GO apply lands after/-new bytes byte-exact, other fields unchanged | PASS |
| 6b | `record-change --live-check` records researcher + coordinator with read-back + replay proof | PASS |
| 6c | duplicate record refused (rc 2), ledger stays at 2 entries | PASS |
| 7 | GO rollback restores before/ bytes **byte-for-byte** (cmp) | PASS |
| 8 | rollback idempotent (NO CHANGE, no extra writes) | PASS |
| 8b | recorder refuses when live bytes ≠ manifest target ("LIVE CHECK FAILED"), ledger untouched | PASS |
| 9 | same-ET-day re-apply of the SAME artifact refused ("condition B unmet"), 0 new writes | PASS |
| 10 | disjoint second artifact same day allowed ("condition A met … condition B met") | PASS |
| 10b | third same-day change refused ("budget exhausted") | PASS |
| 10c | condition A without downstream proof refuses | PASS |
| 10d | rolled-back change #1 refuses change #2 | PASS |
| 10e | `mark-rolled-back` marks the entry (counts toward cap, no longer satisfies A) | PASS |
| 11 | next-ET-day re-apply allowed (budget resets), re-apply deterministic | PASS |

### 4.2 SPXS suite — `PORT=4198 bash .scratch/changes/2026-11-20-spxs-eligibility/tools/roundtrip-test.sh`

Run 2: **55 passed, 5 failed** — and all five failures were defects in the *test harness*,
not in the gate: `run_gate` ends with `echo $?`, so call sites written as `run_gate; rc=$?`
captured echo's status (0) instead of the gate's exit code (G2/G3/G6/G7/G9 — the paired
"refusal names the …" checks all passed, proving the gate verdicts themselves were
correct), and G11's POST count included the `stamp_researcher` setup POST. Fixed to
`rc=$(run_gate)` and a before/after POST delta; run 3 (after the fixes): **suite-exit 0,
60 passed, 0 failed**
([.scratch/changes/2026-11-20-spxs-eligibility/roundtrip/run3.log](C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-spxs-eligibility/roundtrip/run3.log))

Full scenario set, both packages A and B plus the gate scenarios (G-numbers from the
suite): refusals with no CONFIRM (exit 2), no PORTFOLIO_JSON (exit 1), an open SPXS
position (exit 1), zero POSTs after all refusals; dry run sends no write and the gate
reports change #1 on all three templates; GO apply = exactly 6 POSTs (3 versions + 3
templates) with publish record + forward map written; rollback leaves every template's
`skills` array byte-identical to `before/`; non-loopback `FORWARD_BASE` refused. Gate:
G0 change #1 allowed ×3; G1 outside window refused (exit 3); G2 unledgered same-day write
refuses; G3 change #2 allowed with A + B named; G6 no downstream proof refuses; G7
rolled-back refuses; G9 ledger/state mismatch refuses; G10 corrupt ledger fails closed
(exit 3); G8a one minute before ET midnight refuses / G8b one minute after allows with the
new ET day named; G11 the apply propagates the gate refusal (exit 3) and sends zero POSTs.

## 5. Premise corrections (recorded because the task's premises partially mis-describe the repo)

1. **CONTRACT.md has no budget rule.** `.scratch/mailbox/CONTRACT.md` (sha256 `77e944ab…`,
   read in full and grepped) contains mailbox protocol only — no per-day change limit, no
   change window. Nothing to replace there; no CONTRACT staged file exists.
2. **"b4d721's assert-behaviour tooling" was not a budget gate.** The SPXS packages had **no
   change-budget gate at all** before this task (confirmed by reading
   `A-remove-spxs/apply.sh` — its gates were CONFIRM, an open-SPXS-position check, and
   show-pins). `assert-behaviour` in that family is a behaviour-verification harness, and
   the "budget.py" in `.scratch/sleeveb/golive/` is an options-sizing calculator
   (premium→qty from a risk budget), unrelated to §6.4. The gate that this task ships is
   new code, not a repair of existing tooling.
3. **budget.mjs v1 was itself over-strict** (ANDed all four templates regardless of the
   release's scope — demonstrated offline in `tonight-release-sequence-nov20.md` §3, defect
   2). v2 scopes per release; the audit-mode `["*"]` overlap semantics reproduce v1's
   posture when no scope is given.

## 6. Bugs found and fixed while testing (both suites, for the record)

1. `record-change.mjs` never pushed the entry to the ledger while printing "recorded #N"
   (saved the untouched array) — caught by scenario 6b asserting ledger content.
2. `record-change.mjs` required `--evidence` even with `--live-check` — caught by 6b/6c/8b.
3. `record-change.mjs` ran the duplicate check before the live-state verification, so a
   mismatched-live negative test hit the wrong refusal — reordered (live-state gate first;
   the safer order: never record anything about bytes that were not verified).
4. proposal-a `budget.mjs` resolved ROOT one level too high, so CLI runs without
   `--change` silently fell into audit mode (`["*"]`), and `*` was treated as a literal
   artifact in the B check (so audit scope looked disjoint from `["system"]`). Both
   caught by run 2's scenario 9 wrongly allowing a same-artifact re-apply; fixed
   (`ROOT = HERE/..`; `*` expands to overlap everything).
5. Suite exit codes were masked by `| tail` pipes (pipeline exit = tail's 0) — later runs
   redirect to a log and print `suite-exit=$?` explicitly.
6. SPXS harness exit-capture defect (§4.2 run 2's five failures).

## 7. Sequencing verdict (task 2) — re-confirmed against live GETs at 2026-11-20T05:19:03Z

**SAME-NIGHT OK.** At the check, every template's last write was on ET-day 2026-11-19
(researcher / executor / risk_auditor `2026-11-20T01:29:44Z` = 20:29 ET Nov-19;
coordinator `2026-11-19T14:05:04Z` = 09:05 ET; executor-gating-rehearsal `01:22:41Z`), so
the Nov-20 ET day is unspent everywhere. On that state:

- **Latency fix** (proposal-a: researcher + coordinator `system`) = change #1 on both —
  allowed from `2026-11-20T05:00:00Z`, with the same-window WARN (the 01:29:44Z release
  sits in the same continuous window) which is exit 4 / a journalled human decision, not a
  refusal.
- **SPXS Package A** (3 publishes + 3 repins) immediately after the latency fix is
  recorded: change #2 on **researcher** (A: the recorded latency-fix entries; B:
  `{skill/guard, skill/trend-signal, skill/vwap-chop} ∩ {system} = ∅`) and change #1 on
  **risk_auditor** and **executor**. Coordinator untouched by package A.
- **Hard deadline:** both packages must complete before the window closes
  `2026-11-20T13:30:00Z` (08:30 ET); if either slips, the next slot is
  `2026-11-20T21:45:00Z` (16:45 ET) and the remaining release moves to the following ET
  day — the gate names the instant; do not double-dip to catch up.

The staged runbook replacement
([.scratch/budget-84b7e1/staged/runbook-accelerated.md](C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/budget-84b7e1/staged/runbook-accelerated.md))
puts both on the same night with a new §4e recording step (two `record-change --live-check`
commands — the live replay proof satisfies condition A) and re-states §5 with the
per-template condition analysis and the deadline.

## 8. What this change does not include

- **No DRIVER.md edit.** The replacement paragraph is staged; applying it is a separate,
  owned step (re-read + re-verify sha first — sibling sessions hold these docs).
- **No cloud-side enforcement.** The rule is enforced by gate scripts at scripted write
  paths plus the recorder; the cloud has no budget field and the ledger is local. The
  residual risk (an unscripted POST that skips every gate) is caught only retroactively,
  at the next gate run, as row 3.
- **No change to the change window itself**, to the pin rule, or to any schedule /
  AUTONOMY_PHASE / account setting.
