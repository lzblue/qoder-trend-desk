// Sleeve B (options) presentation logic for the trend desk dashboard.
//
// UMD on purpose: the browser loads it as a plain script (window.SleeveB) and the
// offline fixture test requires it from Node, so the page and the test exercise the
// same code. No DOM, no fetch, no Node builtins.
//
// Everything here is field-tolerant. One populated option position row has been observed on this
// platform (.scratch/sleeveb/probe/run-2026-11-20/positions_after_open_fill.json, account
// 3732983, a long put): it carries cost_price / cur_price / mv / profit and NULL
// unrealized_profit / realized_profit, and qty x cost_price != mv because the x100 multiplier is
// not a field on the row. A SHORT option row, and any option row at all on the desk's account
// 5830104, has never been observed, so each extractor still records which candidate field names
// matched and keeps the untouched row for a raw-JSON fallback instead of guessing.

(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) root.SleeveB = api;
})(typeof self !== 'undefined' ? self : globalThis, function () {
  'use strict';

  var MULTIPLIER = 100;
  // The sim statuses that have an observed meaning (docs/sleeve-b-findings-nov19.md).
  // Anything else is STATE_UNAVAILABLE — never mapped onto Futu's real-account enum.
  // Moomoo answers `sim_trade_history_order_list` rows with a decorated status (`"5 cancelled"`)
  // while `sim_trade_order_list` rows carry the bare integer. Both mean the same code, so decode
  // the leading integer and treat the trailing word as corroboration, not as a second state.
  // Only 2/4/5 have ever been observed here, and 4 is corroborated by `cum_qty == qty` on every
  // row that carries it, so the other codes stay unmapped rather than guessed.
  var ORDER_STATUS = { 2: 'resting', 4: 'filled', 5: 'cancelled' };

  // See the note above: `status` arrives either as an integer or as `"<int> <word>"`.
  function orderStatusCode(v) {
    if (typeof v === 'number' && Number.isFinite(v)) return v;
    if (typeof v === 'string') {
      const m = v.match(/^\s*(-?\d+)(?:\s+(\S+))?\s*$/);
      if (!m) return null;
      const word = m[2];
      const known = ORDER_STATUS[Number(m[1])];
      if (word && known && known !== word) return null;
      return Number(m[1]);
    }
    return null;
  }
  // Two different risk currencies, two caps. `premium` is what a DEBIT option costs to put on;
  // `max loss` is what a CREDIT structure (the 0DTE iron fly) can lose. A fly has no premium to
  // cap: its short legs receive money, so a premium ceiling is not a risk ceiling for it.
  var DEFAULT_PREMIUM_CAP_PCT = 1.5;
  var DEFAULT_MAX_LOSS_CAP_PCT = 1.5; // fallback only — /api/sleeveb sends the live constant
  // The fly structure vocabulary, from the frozen contract
  // docs/decisions/sleeve-b-fly-contract-nov21.md §2/§4.
  var STRUCTURE_KIND = 'iron_fly';
  // The mark C1 recomputes on every exit check: same four legs, priced (sleeve_b_fly.py:791). It is a
  // record about the structure, not a fifth position, so it is claimed by the same rule.
  var MARK_KIND = 'iron_fly_mark';

  function num(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  }

  function isObj(v) {
    return Boolean(v) && typeof v === 'object' && !Array.isArray(v);
  }

  function pick(row, names) {
    for (let i = 0; i < names.length; i++) {
      const v = num(row[names[i]]);
      if (v !== null) return { value: v, field: names[i] };
    }
    return null;
  }

  function bareSymbol(symbol) {
    if (typeof symbol !== 'string') return '';
    return symbol.trim().replace(/^US\.\.?/i, '').toUpperCase();
  }

  // OSI: {TICKER}{YYMMDD}{C|P}{strike x 1000}. Returns null when the tail does not
  // decode to a real date — an unreadable expiry must not become a wrong one.
  function parseOcc(symbol) {
    const raw = typeof symbol === 'string' ? symbol.trim() : '';
    const code = bareSymbol(raw);
    const m = code.match(/^([A-Z][A-Z0-9.\-]*?)(\d{6})([CP])(\d{3,8})$/);
    if (!m) return null;
    const ymd = m[2];
    const yy = Number(ymd.slice(0, 2));
    const mo = Number(ymd.slice(2, 4));
    const dd = Number(ymd.slice(4, 6));
    if (mo < 1 || mo > 12 || dd < 1 || dd > 31) return null;
    const nowY = new Date().getUTCFullYear();
    const century = Math.floor(nowY / 100) * 100;
    const year = century + yy > nowY + 50 ? century - 100 + yy : century + yy;
    const strike = Number(m[4]) / 1000;
    if (!Number.isFinite(strike) || strike <= 0) return null;
    return {
      osi: m[1] + ymd + m[3] + m[4],
      raw: raw,
      underlying: m[1],
      expiry: year + '-' + String(mo).padStart(2, '0') + '-' + String(dd).padStart(2, '0'),
      right: m[3] === 'C' ? 'CALL' : 'PUT',
      strike: strike,
      multiplier: MULTIPLIER,
    };
  }

  function dte(expiry, today) {
    if (!expiry) return null;
    const a = Date.parse(String(expiry) + 'T00:00:00Z');
    if (Number.isNaN(a)) return null;
    const b = today ? Date.parse(String(today) + 'T00:00:00Z') : Date.now();
    if (Number.isNaN(b)) return null;
    return Math.round((a - b) / 86400000);
  }

  // A moomoo order row: order_id + status + cum_qty is the shape observed on both
  // paper accounts. Position and quote rows do not carry all three.
  function looksLikeOrderRow(row) {
    return isObj(row) && 'status' in row && 'cum_qty' in row && ('order_id' in row || 'symbol' in row || 'code' in row);
  }

  // Quote rows, guard proposals and journal records all carry a `qty` or a `symbol`, so a
  // row that also speaks like an agent record is not a broker position. The marker list is
  // an exclusion, not a whitelist: a position row arriving with field names nobody has
  // seen yet still gets collected and shown as raw JSON, which is the point of the panel.
  var AGENT_RECORD_MARKERS = ['kind', 'action', 'reason', 'dashboard_label', 'exposures',
    'allow_new_entries', 'approved', 'regime', 'warnings'];

  // Field names seen on real moomoo broker rows (order and position families). A row that
  // is not a decodable option must show one of these before it counts as a position,
  // otherwise an agent-authored {symbol, qty, cost, stop} ticket reads as live exposure —
  // which is exactly what the first live run of this panel did before the rule existed.
  var POSITION_HINTS = ['cost_price', 'avg_price', 'average_price', 'cost_basis', 'nominal_price',
    'nominal_cost', 'market_val', 'market_value', 'position_id', 'eodd_type', 'can_sell_qty',
    'unrealized_pl', 'pl_and_loss', 'position_qty', 'acc_id', 'holding_type', 'pl_ratio'];

  // A sleeve-B *ticket* (contract §4 `tickets[]`, and the executor's per-leg submission) carries
  // the submit vocabulary — order_type / order_side / order_trade_time_type / price — but no
  // status and no cum_qty, so it is neither an order row nor a position row. It must not pass
  // the position test: a fly emits four of these, each with a decodable OSI `symbol` and a
  // `qty`, so all four would otherwise land in the exposure list for a trade that has not
  // happened yet. `acc_id` is in POSITION_HINTS, so without this exclusion the hint matches.
  var SUBMIT_MARKERS = ['order_type', 'order_side', 'order_trade_time_type', 'seq'];
  // Combo-quote-level prices (schema/fly-combo.example.json). Scale is 1e9, so these are never
  // rendered as dollars; they are only used to identify the object.
  var COMBO_PRICE_KEYS = ['bid_price', 'ask_price', 'last_close_price', 'turnover'];

  function looksLikeSubmitRow(row) {
    if (!isObj(row)) return false;
    for (let i = 0; i < SUBMIT_MARKERS.length; i++) {
      if (row[SUBMIT_MARKERS[i]] !== undefined) return true;
    }
    return false;
  }

  function looksLikePositionRow(row) {
    if (!isObj(row) || !('qty' in row) || 'cum_qty' in row) return false;
    if (looksLikeSubmitRow(row)) return false;
    const symbol = row.symbol || row.code;
    if (!symbol) return false;
    for (let i = 0; i < AGENT_RECORD_MARKERS.length; i++) {
      if (row[AGENT_RECORD_MARKERS[i]] !== undefined) return false;
    }
    if (parseOcc(symbol) !== null) return true;
    for (let i = 0; i < POSITION_HINTS.length; i++) {
      if (row[POSITION_HINTS[i]] !== undefined) return true;
    }
    return false;
  }

  // ---------- the four-leg structure ----------
  // A fly is ONE trade with FOUR legs, and this decides which blobs are allowed to say that. The
  // identity itself comes from the producer's `structure_key` when present (CCR-3); these predicates
  // only claim the blob, which is what keeps `collectFromEvents` from walking its leg arrays into the
  // exposure list, and the derived leg set (sorted unique OSI codes) is the fallback for records that
  // predate the field.
  function structureLegs(blob) {
    if (!isObj(blob)) return null;
    // Spellings of the same trade, all frozen in docs/decisions/sleeve-b-fly-contract-nov21.md: the
    // §2 proposal C1 prints standalone is {kind: "iron_fly", legs: [...]} (:38); the §4 envelope wraps
    // that object as {structure: {kind: ..., legs: [...]}, tickets: [...]} (:143); the §4 `mark` is
    // {kind: "iron_fly_mark", legs: [...]} (sleeve_b_fly.py:791); a producer that spelled the
    // discriminator `structure` instead of `kind` is tolerated. Any of them is ONE record about FOUR
    // legs.
    if ((blob.kind === STRUCTURE_KIND || blob.kind === MARK_KIND) && Array.isArray(blob.legs)) return blob;
    if (blob.structure === STRUCTURE_KIND && Array.isArray(blob.legs)) return blob;
    if (isObj(blob.structure)
      && (blob.structure.kind === STRUCTURE_KIND || blob.structure.kind === MARK_KIND)
      && Array.isArray(blob.structure.legs)) {
      return blob.structure;
    }
    // §4 :148 `combo_request` and the combo nesting in schema/fly-combo.example.json (see the
    // request-vs-reply key note below): the combo object carries no discriminator at all, only legs
    // of {code, side, quantity}. Claiming it keeps the
    // whole blob out of the unknown-blob path, where a producer that writes `qty` instead of the
    // API's `quantity` would hand the collector four objects with a decodable contract code and a
    // quantity — one step from looksLikePositionRow, which is what turns a leg into an exposure.
    // OBSERVED on the shipped schema file: as written, its legs are NOT position rows (they say
    // `quantity`), so this is defence against the next producer, not a live double count.
    if (looksLikeCombo(blob)) return blob;
    // OBSERVED 2026-11-21, and recorded in the schema file as `_key_names`: `combo_list` is the REQUEST
    // key, while a `quote_combo_option_quote` REPLY nests its rows under `data.quote_list` - the same key
    // `quote_stock_quote` uses. The `first.legs` test below is what keeps an ordinary quote reply out of
    // this path: a quote row has no legs array.
    // OBSERVED 2026-11-25: a broker REPLY envelope is market data, not a desk record. The
    // `quote_combo_option_quote` answer nests its legs under data.quote_list[0], so the
    // combo-list test below claimed a live quote as an opened structure and the Structures
    // panel rendered a -72.70 "price" for a fly the guard had just vetoed. A combo REQUEST
    // carries no ret_code, so this only blocks replies.
    if (blob.ret_code !== undefined || blob.ret_msg !== undefined) return null;
    const comboList = Array.isArray(blob.combo_list) ? blob.combo_list
      : (isObj(blob.data) && Array.isArray(blob.data.combo_list) ? blob.data.combo_list
        : (isObj(blob.data) && Array.isArray(blob.data.quote_list) ? blob.data.quote_list : null));
    if (comboList) {
      const first = comboList.filter(isObj)[0] || null;
      if (first && Array.isArray(first.legs)) return first;
    }
    return null;
  }

  // A combo quote: legs plus a combo-level price, and nothing else to go on.
  function looksLikeCombo(blob) {
    if (!isObj(blob) || !Array.isArray(blob.legs)) return false;
    for (let i = 0; i < COMBO_PRICE_KEYS.length; i++) {
      if (blob[COMBO_PRICE_KEYS[i]] !== undefined) return true;
    }
    return false;
  }

  function looksLikeStructure(blob) {
    return structureLegs(blob) !== null;
  }

  // Canonical contract code for a leg/row symbol; falls back to the bare symbol when the code
  // does not decode, so an unparseable leg still groups with its own copies.
  function legKey(code) {
    const occ = parseOcc(code);
    if (occ) return occ.osi;
    return bareSymbol(code);
  }

  function normalizeStructure(blob, at) {
    const body = structureLegs(blob) || {};
    const envelope = body === blob ? null : blob;
    const verdict = isObj(envelope && envelope.guard_verdict) ? envelope.guard_verdict : null;
    const legs = arr(body.legs).filter(isObj).map(function (l, i) {
      const occ = parseOcc(l.code || l.symbol);
      return {
        seq: num(l.seq) === null ? i + 1 : num(l.seq),
        code: l.code || l.symbol || null,
        key: legKey(l.code || l.symbol),
        osi: occ ? occ.osi : null,
        right: l.right || (occ ? (occ.right === 'CALL' ? 'C' : 'P') : null),
        strike: num(l.strike) !== null ? num(l.strike) : (occ ? occ.strike : null),
        side: l.side || null,
        // The desk record says `qty`, moomoo's combo request says `quantity` (:148 of the contract).
        qty: num(l.qty !== undefined && l.qty !== null ? l.qty : l.quantity),
        bid: num(l.bid),
        ask: num(l.ask),
        // Not an order offset: signed strike minus atm_strike, so 0.0 on both body shorts and
        // +/-width on the wings (contract :75). Rendered as text, never money(), because it is a
        // distance in points and a producer may put a word in this field.
        offset: l.offset === undefined || l.offset === null || l.offset === '' ? null : String(l.offset),
      };
    });
    const keys = [];
    for (const l of legs) {
      if (l.key && keys.indexOf(l.key) < 0) keys.push(l.key);
    }
    keys.sort();
    const derivedKey = keys.length ? keys.join('+') : null;
    // Structure identity, in order of authority. `structure_key` is emitted by option-adapter
    // (sleeve_b_fly.py:103, stamped on the proposal at :549): "fly:" + sorted leg codes with each
    // leg's qty. It beats my derived leg set because the leg set cannot tell a 2-lot fly from a
    // 3-lot one and would merge them into one trade. The derived set stays as the fallback for rows
    // that predate the field, and is kept in `derived_key` alongside so the two can be compared.
    const markBody = body.kind === MARK_KIND ? body : null;
    const markObj = markBody || (isObj(envelope && envelope.mark) ? envelope.mark : null);
    const emittedKey = [body.structure_key, verdict && verdict.structure_key,
      envelope && envelope.structure_key, markObj && markObj.structure_key]
        .filter(function (s) { return typeof s === 'string' && s.length > 0; })[0] || null;
    // A mark re-derives the key from the legs it is actually pricing (sleeve_b_fly.py:785-793) and
    // warns when the two disagree. Claimed != now means a leg was amended or re-sized, i.e. the
    // ticket in front of the desk is not the structure the auditor approved. That is a risk fact, so
    // it is a field here and not something a reader has to find in a raw JSON blob.
    const keyNow = markObj && typeof markObj.structure_key_now === 'string' ? markObj.structure_key_now : null;
    const keyMismatch = Boolean(emittedKey && keyNow && emittedKey !== keyNow);
    const keyWarnings = arr(markObj && markObj.warnings).concat(arr(envelope && envelope.warnings))
      .filter(function (w) { return typeof w === 'string' && /structure_key/.test(w); });
    const lots = num(body.qty);
    const lossPerLot = num(body.max_loss_per_lot);
    // The verdict is the desk's own risk number and wins over the proposal's arithmetic; a
    // structure with no verdict yet is only a plan, so it is labelled as one. Which of the two
    // produced the figure is recorded too, because the panel quotes it as the numerator of the
    // max-loss cap and the reader is entitled to know whether it came from the guard or from
    // multiplying the record's own per-lot number.
    const verdictLoss = num(verdict && verdict.max_loss_usd);
    // A mark states the structure-level number directly (`max_loss_usd`, sleeve_b_fly.py:806) and
    // carries no per-lot figure, so without this a re-mark would render "max loss —".
    const markLoss = markObj ? num(markObj.max_loss_usd) : null;
    const derivedLoss = lossPerLot !== null && lots !== null ? lossPerLot * lots : null;
    const maxLoss = verdictLoss !== null ? verdictLoss : (markLoss !== null ? markLoss : derivedLoss);
    const maxLossSource = verdictLoss !== null ? 'guard verdict max_loss_usd'
      : markLoss !== null ? 'mark max_loss_usd'
      : derivedLoss !== null ? 'max_loss_per_lot x qty on the record' : null;
    const credit = num(body.credit);
    return {
      at: at || body.now || envelope && (envelope.ts || envelope.at) || null,
      key: emittedKey || derivedKey,
      derived_key: derivedKey,
      key_source: emittedKey ? 'emitted structure_key (option-adapter)'
        : derivedKey ? 'derived leg set (no structure_key on this record)' : null,
      structure_key_now: keyNow,
      key_mismatch: keyMismatch,
      key_warnings: keyWarnings,
      leg_count: legs.length,
      legs: legs,
      leg_keys: keys,
      sleeve: body.sleeve || null,
      kind: body.kind || (typeof body.structure === 'string' ? body.structure : null),
      ticker: body.ticker || null,
      underlying: body.underlying || null,
      venue: body.venue || null,
      expiry: body.expiry || null,
      dte: num(body.dte),
      atm_strike: num(body.atm_strike),
      width: num(body.width),
      em: num(body.em),
      iv: num(body.iv),
      spot: num(body.spot),
      credit: credit,
      credit_usd: num(verdict && verdict.credit_usd) !== null ? num(verdict.credit_usd)
        : (credit !== null && lots !== null ? credit * MULTIPLIER * lots : null),
      debit_at_ask: num(body.debit_at_ask),
      max_loss_per_lot: lossPerLot,
      qty: lots,
      max_loss_usd: maxLoss,
      max_loss_source: maxLossSource,
      orders_planned: num(body.orders_planned),
      orders_if_stopped: num(body.orders_if_stopped),
      size_basis: body.size_basis || null,
      fee_model: body.fee_model || null,
      regime_gate: isObj(body.regime_gate) ? body.regime_gate : null,
      book: isObj(body.book) ? body.book : null,
      // The envelope's own `action` is the actionable decision ("NONE" when the guard vetoed the
      // plan inside it), so it wins; a bare §2 proposal only has its own.
      action: (envelope && envelope.action) || body.action || null,
      approved: verdict ? verdict.approved === true : null,
      verdict: verdict,
      mark: markObj,
      from_envelope: Boolean(envelope),
      raw: blob,
    };
  }

  // Positive-only match, mirroring option-adapter's classify_fill: a 4 that is not
  // cum_qty == qty with a positive avg_fill_price is unknown, not "filled".
  function classifyOrderRow(row) {
    if (!isObj(row)) return { state: 'state_unavailable', reason: 'row is not an object' };
    const out = { state: 'state_unavailable', reason: null, warnings: [] };
    for (const k of ['status', 'qty', 'cum_qty']) {
      if (!(k in row)) {
        out.reason = 'required field ' + k + ' absent';
        return out;
      }
    }
    const status = orderStatusCode(row.status);
    out.status = status;
    out.status_raw = row.status;
    out.qty = num(row.qty);
    out.cum_qty = num(row.cum_qty);
    out.avg_fill_price = num(row.avg_fill_price);
    out.limit_price = num(row.price);
    out.symbol = bareSymbol(row.symbol || row.code);
    out.order_id = row.order_id === undefined ? null : String(row.order_id);
    out.side = num(row.side);
    out.create_time = row.create_time === undefined ? null : row.create_time;
    out.update_time = row.update_time === undefined ? null : row.update_time;
    out.text = typeof row.text === 'string' ? row.text : null;
    // The last clock available: `sim_trade_history_order_list` rows carry no
    // create_time/update_time, so without the event timestamp the row renders "no time" while
    // the same order read from `sim_trade_order_list` renders at a real minute.
    out.event_at = row.at === undefined ? null : row.at;
    out.is_option = parseOcc(out.symbol) !== null;
    if (status === null || !ORDER_STATUS[status]) {
      out.state = 'state_unavailable';
      out.reason = 'order status ' + JSON.stringify(row.status) + ' is outside the codes this panel maps'
        + ' (2 resting, 4 filled, 5 cancelled — the meanings observed on this account); neither a fill'
        + ' nor a cancel is claimed for it';
      return out;
    }
    if (out.qty === null || out.cum_qty === null || out.qty < 0 || out.cum_qty < 0) {
      out.state = 'state_unavailable';
      out.reason = 'qty/cum_qty not non-negative numbers';
      return out;
    }
    const state = ORDER_STATUS[status];
    if (state === 'filled') {
      if (out.cum_qty !== out.qty) {
        out.state = 'state_unavailable';
        out.reason = 'status 4 but cum_qty ' + out.cum_qty + ' != qty ' + out.qty;
        return out;
      }
      if (out.avg_fill_price === null || out.avg_fill_price <= 0) {
        out.state = 'state_unavailable';
        out.reason = 'status 4 without a positive avg_fill_price';
        return out;
      }
      out.state = 'filled';
      return out;
    }
    if (out.cum_qty > 0) {
      out.state = 'state_unavailable';
      out.reason = state + ' order carrying cum_qty ' + out.cum_qty + ' (a partial ' + state + ' has not been observed)';
      return out;
    }
    out.state = state;
    return out;
  }

  // Only one option position row has ever been recorded, and no short-option row has, so
  // candidate field names are still tried in order and the match set is reported with the raw row.
  function readPositionRow(row) {
    const out = { matched: {}, missing: [], raw: row, symbol: '', state: 'unknown' };
    if (!isObj(row)) {
      out.state = 'unreadable';
      out.reason = 'position row is not an object';
      return out;
    }
    out.symbol = bareSymbol(row.symbol || row.code);
    out.occ = parseOcc(out.symbol);
    const qtyHit = pick(row, ['qty', 'position_qty', 'can_sell_qty']);
    if (qtyHit) {
      out.matched.qty = qtyHit.field;
      out.qty = qtyHit.value;
    }
    const cost = pick(row, ['cost_price', 'avg_price', 'average_price', 'cost_basis', 'avg_fill_price', 'nominal_cost']);
    if (cost) {
      out.matched.cost = cost.field;
      out.cost = cost.value;
    }
    const last = pick(row, ['nominal_price', 'last_price', 'market_price', 'cur_price', 'price']);
    if (last) {
      out.matched.last = last.field;
      out.last = last.value;
    }
    const mv = pick(row, ['market_val', 'market_value', 'mv', 'position_value']);
    if (mv) {
      out.matched.market_value = mv.field;
      out.market_value = mv.value;
    }
    const pnl = pick(row, ['pl_and_loss', 'unrealized_pl', 'unpl', 'position_pnl', 'pnl', 'profit']);
    if (pnl) {
      out.matched.pnl = pnl.field;
      out.pnl = pnl.value;
    }
    const pnlPct = pick(row, ['pl_ratio', 'pnl_ratio', 'position_pnl_ratio', 'yield_ratio']);
    if (pnlPct) {
      out.matched.pnl_pct = pnlPct.field;
      out.pnl_pct = pnlPct.value;
    }
    // The option position row captured on 2026-11-20 (.scratch/sleeveb/probe/run-2026-11-20/)
    // carries `unrealized_profit` and `realized_profit` as NULL — the latter even after the
    // position was fully closed — and puts the money in `profit`. Listing those names in the
    // extractor would read as a match and yield a silent null, so record them as present-but-null
    // instead: the panel then says the broker gave nothing, rather than implying zero.
    out.null_fields = [];
    for (const k of ['unrealized_profit', 'realized_profit', 'today_profit', 'today_buy_avg_price', 'today_sell_avg_price']) {
      if (k in row && row[k] === null) out.null_fields.push(k);
    }
    const side = num(row.side);
    if (side !== null) out.side = side;
    for (const k of ['qty', 'cost', 'last', 'market_value', 'pnl', 'pnl_pct']) {
      if (!out.matched[k]) out.missing.push(k);
    }
    if (out.qty === undefined) {
      out.state = 'unreadable';
      out.reason = 'no numeric qty field on the row';
    } else if (out.qty !== 0) {
      // Sign is direction, not closure. The two short legs of a credit fly sit at negative qty, so
      // reading qty < 0 as "closed" would drop the only legs that carry risk. What HAS been
      // observed on this platform is a closed row that persists at qty "0"
      // (.scratch/sleeveb/probe/run-2026-11-20/CAPTURE.md); the negative row is documented in
      // docs/decisions/sleeve-b-fly-build-nov22.md §8 and not yet observed, so the shape this
      // branch is written against is the memo's, not a capture.
      out.state = 'open';
      out.direction = out.qty > 0 ? 'long' : 'short';
    } else {
      out.state = 'closed';
      out.reason = 'qty ' + out.qty + ': a closed position row persists, it is not an exposure';
    }
    return out;
  }

  // Which mined blob is which sleeve-B record. Predicate sets stay narrow: an unknown
  // blob with a plausible option field still surfaces as raw, never as a parsed row.
  function blobKind(blob) {
    if (!isObj(blob)) return null;
    // First, and before any row test: a fly is one record holding four leg objects that each
    // look exactly like a position row (qty + decodable code, no agent marker). Claiming the
    // blob is what keeps `collectFromEvents` from walking its arrays into the exposure list.
    if (looksLikeStructure(blob)) return 'structure';
    if (Array.isArray(blob.exposures) && 'allow_new_entries' in blob) return 'reconcile';
    if (blob.sleeve === 'B' && typeof blob.action === 'string'
      && ['FILLED', 'RESTING', 'CANCELLED', 'STATE_UNAVAILABLE'].indexOf(blob.action) >= 0) return 'classify';
    if (typeof blob.dashboard_label === 'string' || (blob.sleeve === 'B' && blob.tp_limit !== undefined)) return 'ticket';
    if (typeof blob.kind === 'string' && blob.ts) return 'journal';
    if (looksLikeOrderRow(blob)) return 'order_row';
    if (looksLikePositionRow(blob)) return 'position_row';
    return null;
  }

  function money(v) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return '—';
    const n = Number(v);
    return (n < 0 ? '-$' : '$') + Math.abs(n).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  }

  function pct(v, digits) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return '—';
    return Number(v).toFixed(digits === undefined ? 2 : digits) + '%';
  }

  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function rawJson(v) {
    try {
      return JSON.stringify(v, null, 1);
    } catch (_) {
      return String(v);
    }
  }

  // The desk's calendar day is America/New_York. Intl is available in Node 24 and in
  // every browser this page runs in; the -5h fallback exists only so a missing tz
  // database degrades to the same answer the journal skill's own fallback gives.
  function toEtDate(d) {
    try {
      const s = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
      }).format(d);
      if (/^\d{4}-\d{2}-\d{2}$/.test(s)) return s;
    } catch (_) {
      /* fall through to the fixed offset */
    }
    return new Date(d.getTime() - 5 * 3600000).toISOString().slice(0, 10);
  }

  // Every timestamp on this page is rendered through the desk's own clock, not the viewer's:
  // the machine serving it runs UTC+8, so a local formatter put a 10:08 ET veto on screen as
  // 11:08 PM and a 16:15 ET report as 5:15 AM — twice a day apart from the truth.
  // Output: "2026-11-25 10:08:33 ET".
  function fmtEt(v) {
    const iso = isoOf(v);
    if (!iso) return '';
    let s;
    try {
      s = new Intl.DateTimeFormat('en-CA', {
        timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
      }).format(new Date(iso));
    } catch (_) {
      return iso.slice(0, 19).replace('T', ' ') + ' ET';
    }
    return /^\d{4}/.test(s) ? s.replace(',', '') + ' ET' : iso.slice(0, 19).replace('T', ' ') + ' ET';
  }

  function sameDay(ts, etDay) {
    if (!ts) return false;
    const t = typeof ts === 'number' ? ts : Date.parse(String(ts));
    if (Number.isNaN(t)) return false;
    const iso = toEtDate(new Date(t));
    return !etDay || iso === String(etDay);
  }

  function etDayNow() {
    return toEtDate(new Date());
  }

  function normalizeTicket(blob) {
    const sym = blob.occ || blob.occ_symbol || blob.symbol || blob.code || blob.contract || null;
    const occ = parseOcc(sym);
    return {
      at: blob.ts || blob.at || null,
      action: blob.action || null,
      dashboard_label: typeof blob.dashboard_label === 'string' ? blob.dashboard_label : null,
      reason: typeof blob.reason === 'string' ? blob.reason : null,
      qty: num(blob.qty),
      limit: num(blob.limit),
      tp_limit: num(blob.tp_limit),
      side: blob.side === undefined ? null : blob.side,
      symbol: occ ? occ.osi : bareSymbol(sym || ''),
      underlying: occ ? occ.underlying : null,
      expiry: occ ? occ.expiry : null,
      right: occ ? occ.right : null,
      strike: occ ? occ.strike : null,
      parsed: Boolean(occ),
      raw: blob,
    };
  }

  function arr(v) {
    return Array.isArray(v) ? v : [];
  }

  // Grouping identity is (structure_key, size), NOT the key alone. The producer makes the key
  // deliberately size-INDEPENDENT: c1/adapter-tree/option-adapter/scripts/sleeve_b_fly.py:115-119
  // records that a size-bearing key is vetoed by guard.py:321/:666, which mirror the key from the legs
  // alone, so every 2-lot fly would fail as "a leg was amended or re-sized". Two sizes of one leg set
  // therefore share a key legitimately and must still count as two trades.
  //
  // A record that states no size — C1's `mark` carries no top-level qty, only `max_loss_usd`
  // (= per-lot x lots) — folds into the single stated lane of its key, which is what keeps a proposal
  // and its own mark ONE row. If the key has two stated sizes and the record states none, it gets its
  // own lane instead of a guess: picking 2 or 3 would invent a number the record does not carry.
  var LANE_SEP = '§';
  function laneFolder(records, keyOf, sizeOf) {
    const stated = {};
    for (const r of records) {
      const k = keyOf(r);
      const q = sizeOf(r);
      if (!k || q === null || q === undefined) continue;
      if (!stated[k]) stated[k] = {};
      stated[k][String(q)] = true;
    }
    return function (r) {
      const k = keyOf(r);
      if (!k) return null;
      const q = sizeOf(r);
      const lanes = stated[k] ? Object.keys(stated[k]) : [];
      if (q !== null && q !== undefined) return k + LANE_SEP + String(q);
      if (lanes.length === 1) return k + LANE_SEP + lanes[0];
      return k + LANE_SEP + '?';
    };
  }

  function buildPanel(snap) {
    const s = isObj(snap) ? snap : {};
    const today = s.et_day || etDayNow();
    const nav = num(s.nav);
    const capPct = num(s.premium_cap_pct) === null ? DEFAULT_PREMIUM_CAP_PCT : num(s.premium_cap_pct);
    const capUsd = nav === null ? null : (nav * capPct) / 100;
    const lossCapPct = num(s.max_loss_cap_pct) === null ? DEFAULT_MAX_LOSS_CAP_PCT : num(s.max_loss_cap_pct);
    const lossCapUsd = nav === null ? null : (nav * lossCapPct) / 100;

    const structures = arr(s.structures).filter(looksLikeStructure).map(function (b) {
      return normalizeStructure(b, b.at || b.ts || b.now);
    });
    // Collapse by leg set. The proposal is printed by C1, echoed inside C1's own select envelope,
    // and echoed again in the verdict, so the same four legs can easily reach the panel three
    // times; summing them would report the same risk twice. The richest record wins (one that
    // carries a guard verdict beats a bare proposal), then the latest timestamp.
    const byKey = {};
    // A record that predates `structure_key` carries only the derived leg set, which is the weaker
    // identity: the same fly would then land under two keys and its max loss would be counted twice.
    // So a derived-only record is folded under the emitted key of any structure with the same leg set.
    // Two DIFFERENT emitted keys are never merged — that is a roll or an amended wing, which the
    // producer deliberately makes a different trade (sleeve_b_fly.py:112-116).
    const emittedByDerived = {};
    for (const st of structures) {
      if (st.key && st.derived_key && st.key !== st.derived_key) emittedByDerived[st.derived_key] = st.key;
    }
    for (const st of structures) {
      const derivedOnly = st.key && st.key === st.derived_key && emittedByDerived[st.derived_key];
      const k = derivedOnly ? emittedByDerived[st.derived_key]
        : (st.key || ('unkeyed:' + (st.at || '') + ':' + st.leg_count));
      if (derivedOnly) {
        st.key = k;
        st.key_folded = true;
        st.key_source = 'derived leg set, folded under an emitted structure_key for the same legs';
      }
      st.identity = k;
    }
    // A lane is one trade: the key plus the size the record states. `st.lane` is what the collapse
    // groups by, and `st.identity` is the bare key it was folded onto.
    const laneOf = laneFolder(structures, (st) => st.identity, (st) => st.qty);
    for (const st of structures) st.lane = laneOf(st);
    for (const st of structures) {
      const hit = byKey[st.lane];
      if (!hit) { byKey[st.lane] = st; continue; }
      // Richest record wins, then the latest timestamp. A bare re-mark prices four legs but knows no
      // qty, width or gate, so letting the newest blob win would erase the proposal's facts from a
      // structure the desk still has open.
      const score = function (x) {
        return (x.verdict ? 8 : 0) + (x.qty !== null ? 4 : 0) + (x.max_loss_per_lot !== null ? 2 : 0)
          + (x.regime_gate ? 1 : 0) + ((Date.parse(x.at || 0) || 0) / 1e12);
      };
      if (score(st) > score(hit)) byKey[st.lane] = st;
    }
    const unique = [];
    for (const k of Object.keys(byKey)) unique.push(byKey[k]);
    unique.sort(function (a, b) { return (Date.parse(b.at || 0) || 0) - (Date.parse(a.at || 0) || 0); });
    const collapsedDuplicates = structures.length - unique.length;
    // One key, several lanes: the size-independent key means these are the same STRUCTURE at
    // different sizes, so say it out loud rather than leaving two identical keys on screen.
    const lanesByKey = {};
    for (const st of unique) {
      if (!st.key) continue;
      (lanesByKey[st.key] = lanesByKey[st.key] || []).push(st.lane.split(LANE_SEP)[1] || '?');
    }
    for (const st of unique) {
      const lanes = st.key ? lanesByKey[st.key] : null;
      // Sizes ascending, the unattributed lane last: '?,2,3' reads like an error, '2,3,?' reads like
      // two trades and one record that could not be placed.
      st.key_lanes = lanes ? lanes.slice().sort(function (a, b) {
        if (a === '?' || b === '?') return a === b ? 0 : (a === '?' ? 1 : -1);
        return Number(a) - Number(b);
      }) : null;
      // '?' is not a size — it is a record of this key that states none. Counting it as a third size
      // would report three trades where the desk has two sizes and one orphaned mark.
      const sizes = st.key_lanes ? st.key_lanes.filter((l) => l !== '?') : [];
      st.key_unsized_lanes = st.key_lanes ? st.key_lanes.length - sizes.length : 0;
      st.key_carries_sizes = sizes.length > 1 ? sizes.length : null;
    }
    structures.length = 0;
    for (const st of unique) structures.push(st);
    // Which structure each contract belongs to. One entry per leg code, so four legs resolve to
    // one trade everywhere they are counted.
    const legOwner = {};
    for (const st of structures) {
      if (!st.key) continue;
      for (const k of st.leg_keys) {
        if (!legOwner[k]) legOwner[k] = st.key;
      }
    }
    const legsInKey = {};
    for (const st of structures) if (st.key) legsInKey[st.key] = st.leg_keys.length;

    const positions = arr(s.positions).map(readPositionRow);
    const open = positions.filter((p) => p.state === 'open');
    const closed = positions.filter((p) => p.state === 'closed');
    const unreadable = positions.filter((p) => p.state === 'unreadable' || p.state === 'unknown');

    let premiumAtRisk = 0;
    let premiumKnown = true;
    let legsInStructures = 0;
    for (const p of open) {
      if (!p.occ) continue;
      p.structure_key = legOwner[p.occ.osi] || null;
      if (p.structure_key) {
        p.structure_legs = legsInKey[p.structure_key] || null;
        // Counted once, in `max_loss_at_risk`, as part of its structure. A short leg's premium is
        // money received and a long leg's is the cost of the wing; neither is the fly's risk.
        legsInStructures += 1;
        continue;
      }
      if (p.qty === undefined || p.qty <= 0) continue;
      const unit = p.cost !== undefined ? p.cost : p.last;
      if (unit === undefined) {
        premiumKnown = false;
        continue;
      }
      premiumAtRisk += p.qty * MULTIPLIER * unit;
    }
    for (const p of positions) {
      if (!p.structure_key) p.structure_key = legOwner[p.occ ? p.occ.osi : bareSymbol(p.symbol)] || null;
      if (p.structure_key && !p.structure_legs) p.structure_legs = legsInKey[p.structure_key] || null;
    }

    let maxLossAtRisk = 0;
    let maxLossKnown = structures.length > 0;
    let structuresTaken = 0;
    const rowsPerStructure = {};
    for (const p of open) {
      if (p.structure_key) rowsPerStructure[p.structure_key] = (rowsPerStructure[p.structure_key] || 0) + 1;
    }
    for (const st of structures) {
      st.rows_seen = rowsPerStructure[st.key] || 0;
      // What the risk number for this structure is standing on. A plan with no verdict and no
      // broker row is not exposure, so it is listed but not summed; saying which of the three it
      // is beats a figure the reader has to trust.
      const vetoed = st.approved === false || String(st.action || '') === 'NONE';
      st.risk_counted = !vetoed && (st.approved === true || st.rows_seen > 0);
      st.exposure_basis = vetoed ? 'vetoed, no risk taken'
        : st.rows_seen > 0 ? 'broker rows'
        : st.approved === true ? 'guard-approved, no broker row mined yet'
        : 'proposed only, no guard verdict';
      if (!st.risk_counted) continue;
      structuresTaken += 1;
      if (st.max_loss_usd === null) maxLossKnown = false;
      else maxLossAtRisk += st.max_loss_usd;
    }

    const orders = arr(s.orders).map(classifyOrderRow);
    const tickets = arr(s.tickets).filter(isObj).map(normalizeTicket);
    const journalRecords = arr(s.journal).filter(isObj);

    // A resting SELL on the same contract as a filled BUY is the take-profit leg.
    const filledBySymbol = {};
    for (const o of orders) {
      if (o.state === 'filled' && o.is_option) filledBySymbol[o.symbol] = o;
    }
    for (const p of open) {
      const key = p.symbol;
      p.entry = p.cost !== undefined ? p.cost : (filledBySymbol[key] ? filledBySymbol[key].avg_fill_price : null);
      if (p.entry === null && p.last === undefined) p.entry = null;
      if (p.entry !== null && p.last !== undefined && p.qty > 0 && p.occ) {
        p.pnl = (p.last - p.entry) * p.qty * MULTIPLIER;
        p.pnl_basis = 'computed from entry and last';
      } else if (p.pnl !== undefined) {
        p.pnl_basis = 'reported by the broker row';
      } else {
        p.pnl = null;
        p.pnl_basis = null;
      }
      if (p.structure_key && p.pnl_basis) {
        // A leg marked to market is not the trade marked to market: the structure's own P&L is the
        // credit against the cost to close all four legs, and the broker's option P&L fields
        // (`unrealized_profit`, `realized_profit`) come back NULL on this platform, so there is
        // nothing to reconcile this against. Say so rather than implying the leg is the position.
        p.pnl_basis += ' · one leg of a ' + (p.structure_legs || '?') + '-leg structure, not its P&L';
      }
      const costNotional = p.entry === null ? null : p.entry * (p.qty || 0) * MULTIPLIER;
      p.pnl_pct = costNotional ? (p.pnl === null ? null : (p.pnl / costNotional) * 100) : null;
      const tp = orders.filter((o) => o.symbol === key && o.state === 'resting' && o.side === 2)[0];
      if (tp) {
        p.take_profit = { price: tp.limit_price, qty: tp.qty, source: 'resting sell order ' + tp.order_id };
      } else {
        const t = tickets.filter((x) => x.symbol === key && x.tp_limit !== null).pop();
        p.take_profit = t ? { price: t.tp_limit, qty: t.qty, source: 'sleeve B ticket (no resting order row seen)' } : null;
      }
    }

    const realised = journalRecords.filter(function (r) {
      return r.kind === 'close' && String(r.sleeve || '').toUpperCase() === 'B' && sameDay(r.ts || r.at, today);
    });
    let realisedToday = 0;
    let realisedKnown = realised.length > 0;
    // Net P&L is additive, so summing per-leg closes is arithmetically right; the COUNT is not.
    // Attribute each close to its structure (an explicit id if the desk wrote one, else the leg
    // set) so "4 closes" can be shown as what it is: one structure closed over four legs.
    const realisedStructures = new Set();
    for (const r of realised) {
      const net = (num(r.realized_pnl) || 0) - (num(r.fees) || 0);
      realisedToday += net;
      const key = r.structure_id || r.structure_key
        || legOwner[legKey(r.symbol || r.ticker || '')] || null;
      realisedStructures.add(key || 'unattributed:' + String(r.ts || r.at) + '|' + String(r.ticker || r.symbol || ''));
    }

    const timeline = [];
    for (const st of structures) {
      timeline.push({
        at: isoOf(st.at),
        source: 'sleeve B structure (' + st.kind + ', ' + st.leg_count + ' legs)',
        state: st.approved === true ? 'approved'
          : st.approved === false ? 'vetoed'
          : String(st.action || '') === 'NONE' ? 'none' : 'proposed',
        symbol: (st.venue || st.ticker || '') + ' ' + (st.expiry || ''),
        qty: st.qty,
        price: st.credit,
        note: st.leg_keys.length + ' legs, max loss ' + money(st.max_loss_usd)
          + (st.size_basis ? ' (' + st.size_basis + ')' : '')
          + (st.regime_gate ? ', gate ' + (st.regime_gate.pass ? 'pass' : 'fail') : ''),
        structure_key: st.key,
        raw: st.raw,
      });
    }
    for (const o of orders) {
      if (!o.is_option && o.state !== 'state_unavailable') continue;
      timeline.push({
        at: isoOf(o.update_time || o.create_time || o.event_at),
        source: 'order row',
        state: o.state,
        symbol: o.symbol,
        qty: o.cum_qty !== null && o.cum_qty > 0 ? o.cum_qty : o.qty,
        price: o.state === 'filled' ? o.avg_fill_price : o.limit_price,
        note: o.reason || o.text || '',
        raw: o.raw,
      });
    }
    for (const t of tickets) {
      timeline.push({
        at: isoOf(t.at),
        source: 'sleeve B ticket',
        state: t.action === 'NONE' || t.action === 'STATE_UNAVAILABLE' ? String(t.action).toLowerCase() : 'ticket',
        symbol: t.symbol,
        qty: t.qty,
        price: t.limit,
        note: t.dashboard_label || t.reason || '',
        raw: t.raw,
      });
    }
    for (const r of journalRecords) {
      if (['order', 'fill', 'close', 'skip', 'verdict', 'error'].indexOf(r.kind) < 0) continue;
      if (!sameDay(r.ts || r.at, today)) continue;
      if (r.sleeve !== undefined && String(r.sleeve).toUpperCase() !== 'B' && String(r.sleeve).toLowerCase() !== 'option') continue;
      if (r.sleeve === undefined && !hasOptionHint(r)) continue;
      timeline.push({
        at: isoOf(r.ts),
        source: 'journal ' + r.kind,
        state: r.kind === 'verdict' ? (r.approved ? 'approved' : 'vetoed') : r.kind,
        symbol: bareSymbol(r.symbol || r.ticker || ''),
        qty: num(r.qty),
        price: num(r.price || r.limit || r.avg_fill_price),
        note: r.reason || r.detail || r.dashboard_label || '',
        raw: r,
      });
    }
    timeline.sort(function (a, b) {
      return (Date.parse(a.at || 0) || 0) - (Date.parse(b.at || 0) || 0);
    });

    const activity = isObj(s.activity) ? s.activity : null;
    const stateRecords = arr(s.state_records).filter(isObj).map(function (r) {
      return { at: isoOf(r.at), source: r.source, action: r.action, reason: r.reason, raw: r.raw };
    });

    return {
      today: today,
      nav: nav,
      // PREMIUM view (unchanged meaning): the legacy single-leg debit path, capped by
      // rules.json risk.max_open_option_premium_pct. Legs of a recognised structure are excluded
      // from this sum because a short leg's premium is money received, not money at risk.
      cap_pct: capPct,
      cap_usd: capUsd,
      premium_cap_source: typeof s.premium_cap_source === 'string' ? s.premium_cap_source : null,
      premium_at_risk: premiumKnown ? premiumAtRisk : null,
      premium_pct_of_nav: nav && premiumKnown ? (premiumAtRisk / nav) * 100 : null,
      cap_headroom_usd: capUsd === null || !premiumKnown ? null : capUsd - premiumAtRisk,
      premium_legs_excluded: legsInStructures,
      // MAX-LOSS view (new): the credit structure's risk is (width - credit) x 100 x lots, capped
      // by rules.json structure.max_loss_pct_of_nav — 1.5 in the pinned desk-risk-guard
      // (owner brief D3 set 0.75; a rules-only publish raised it on 2026-11-25).
      max_loss_cap_pct: lossCapPct,
      max_loss_cap_source: typeof s.max_loss_cap_source === 'string' ? s.max_loss_cap_source : null,
      max_loss_cap_usd: lossCapUsd,
      max_loss_at_risk: maxLossKnown ? maxLossAtRisk : null,
      max_loss_pct_of_nav: nav && maxLossKnown ? (maxLossAtRisk / nav) * 100 : null,
      max_loss_headroom_usd: lossCapUsd === null || !maxLossKnown ? null : lossCapUsd - maxLossAtRisk,
      structures: structures,
      structure_count: structures.length,
      structures_taken: structuresTaken,
      structure_duplicates_collapsed: collapsedDuplicates,
      legs_in_structures: legsInStructures,
      open: open,
      closed: closed,
      unreadable: unreadable,
      orders: orders,
      tickets: tickets,
      realised_today: realisedKnown ? realisedToday : null,
      realised_count: realised.length,
      realised_structure_count: realisedStructures.size,
      timeline: timeline.slice().reverse(),
      state_records: stateRecords,
      activity: activity,
      freshness: isObj(s.freshness) ? s.freshness : null,
      sources: isObj(s.sources) ? s.sources : null,
    };
  }

  function hasOptionHint(rec) {
    const sym = String(rec.symbol || rec.ticker || '');
    return parseOcc(sym) !== null || Boolean(rec.dashboard_label);
  }

  // moomoo row timestamps arrive as microsecond-epoch strings or ISO; journal records use ISO.
  function isoOf(v) {
    if (v === null || v === undefined) return null;
    if (typeof v === 'number' || /^\d+$/.test(String(v))) {
      const n = Number(v);
      const ms = n > 1e14 ? n / 1000 : n > 1e11 ? n : n * 1000;
      const d = new Date(ms);
      return Number.isNaN(d.getTime()) ? String(v) : d.toISOString();
    }
    const t = Date.parse(String(v));
    return Number.isNaN(t) ? String(v) : new Date(t).toISOString();
  }

  // ---------- rendering (HTML strings; app.js assigns them to innerHTML) ----------

  function row(cells) {
    return '<div class="sbb-row">' + cells.join('') + '</div>';
  }
  function cell(v, cls) {
    return '<span class="sbb-cell' + (cls ? ' ' + cls : '') + '">' + v + '</span>';
  }

  function renderPositions(p) {
    if (!p.open.length && !p.unreadable.length && !p.closed.length) {
      return '<div class="empty">No option position row in the mined sessions yet. The sleeve reads as flat — that is not proof of no exposure, because the broker row itself has not been seen.</div>';
    }
    const head = row([cell('Contract', 'h'), cell('Qty'), cell('Entry'), cell('Last'), cell('P&L'), cell('TP resting'), cell('DTE')]);
    const line = function (pos, cls) {
      const o = pos.occ;
      const tag = pos.structure_key
        ? ' <span class="meta">leg of a ' + esc(String(pos.structure_legs || '?')) + '-leg structure (see Structures)</span>'
        : '';
      const sym = o
        ? '<span class="sbb-sym">' + esc(o.underlying) + ' ' + esc(o.expiry) + ' ' + esc(String(o.strike)) + ' ' + esc(o.right) + '</span>' + tag
        : '<span class="sbb-sym">' + esc(pos.symbol || '(unparsed)') + '</span>';
      return row([
        cell(sym + (o ? '' : ' <span class="warn">raw</span>'), cls),
        cell(pos.qty === undefined ? '—' : esc(pos.qty)),
        cell(pos.entry !== null && pos.entry !== undefined ? money(pos.entry) : (pos.cost === undefined ? '—' : money(pos.cost))),
        cell(pos.last === undefined ? '—' : money(pos.last)),
        cell((pos.pnl === null || pos.pnl === undefined ? '—' : money(pos.pnl) + (pos.pnl_pct === null || pos.pnl_pct === undefined ? '' : ' (' + pct(pos.pnl_pct) + ')'))
          + (pos.pnl_basis ? ' <span class="meta">' + esc(pos.pnl_basis) + '</span>' : ''),
          pos.pnl > 0 ? 'pos' : pos.pnl < 0 ? 'neg' : ''),
        cell(pos.take_profit ? money(pos.take_profit.price) + ' <span class="meta">' + esc(pos.take_profit.qty === null ? '' : 'x' + pos.take_profit.qty) + '</span>' : '—'),
        cell(o ? esc(String(dte(o.expiry, p.today))) : '—'),
      ]);
    };
    let html = '<div class="sbb-table">' + head + p.open.map(function (x) {
      const lineHtml = line(x, '');
      if (x.occ) return lineHtml;
      return lineHtml + '<details class="raw"><summary>contract symbol did not parse as OSI — row as received</summary><pre>'
        + esc(rawJson(x.raw)) + '</pre></details>';
    }).join('');
    for (const u of p.unreadable) {
      html += row([cell('<span class="warn">unknown row shape</span>'), cell(esc(u.symbol || '—')), cell('<button class="disclose">raw</button>'), cell(''), cell(''), cell(''), cell('')]);
      html += '<details class="raw"><summary>row as received</summary><pre>' + esc(rawJson(u.raw)) + '</pre></details>';
    }
    html += '</div>';
    if (p.closed.length) {
      html += '<details class="raw"><summary>' + p.closed.length + ' closed row(s) (qty 0) — filtered out of exposure</summary><pre>'
        + esc(p.closed.map(function (c) { return rawJson(c.raw); }).join('\n')) + '</pre></details>';
    }
    const missing = [];
    for (const x of p.open) if (x.missing.length) missing.push(x.symbol + ': ' + x.missing.join(', '));
    if (missing.length) html += '<div class="meta">field(s) not present on the broker row — ' + esc(missing.join(' · ')) + '</div>';
    return html;
  }

  function renderRisk(p) {
    const line = function (k, v, cls) {
      return '<div class="kv"><span class="k">' + k + '</span><span class="' + (cls || '') + '">' + v + '</span></div>';
    };
    const head = function (t) {
      return '<div class="sbb-head">' + t + '</div>';
    };
    // The server names the authority behind each cap. The dashboard constant is only the carrier,
    // so the note shows the authority clause rather than the whole provenance sentence, and the
    // value's own status ("staged, not live") comes from the server instead of being hardcoded
    // here — a hardcoded status is how this line went stale on 2026-11-25.
    const capNote = function (src) {
      if (!src) return '';
      const lead = 'authority is ';
      const i = src.indexOf(lead);
      const text = i < 0 ? src : src.slice(i + lead.length);
      return ' <span class="meta">' + esc(text) + '</span>';
    };
    const used = p.premium_pct_of_nav;
    const over = used !== null && p.cap_pct !== null && used > p.cap_pct;
    const lossUsed = p.max_loss_pct_of_nav;
    // A dash here read as a missing number. The reason is a state of the book, so say it:
    // either nothing is open on the credit path, or a structure is open and carries no
    // max_loss_usd for the panel to divide by NAV.
    const noLossNote = p.structures_taken
      ? 'no max_loss_usd on the structure counted as risk'
      : 'no credit structure open';
    const noPremiumNote = p.premium_at_risk === null
      ? 'no cost or last on the open option rows'
      : 'no nav to divide by';
    const lossOver = lossUsed !== null && p.max_loss_cap_pct !== null && lossUsed > p.max_loss_cap_pct;
    const legsNote = p.premium_legs_excluded
      ? ' <span class="meta">' + p.premium_legs_excluded
        + ' leg(s) of a recognised structure are not in this sum (see Credit structure)</span>'
      : '';
    return line('NAV', p.nav === null ? 'no equity row mined yet' : money(p.nav))
      + head('Debit path — premium deployed')
      + line('Premium at risk', (p.premium_at_risk === null ? 'not computable (cost/last absent)' : money(p.premium_at_risk)) + legsNote)
      + line('Premium cap', pct(p.cap_pct) + (p.cap_usd === null ? '' : ' = ' + money(p.cap_usd)) + capNote(p.premium_cap_source))
      + line('Premium used', used === null ? noPremiumNote : pct(used, 3), over ? 'neg' : 'pos')
      + line('Premium headroom', p.cap_headroom_usd === null ? noPremiumNote : money(p.cap_headroom_usd), p.cap_headroom_usd !== null && p.cap_headroom_usd < 0 ? 'neg' : '')
      + head('Credit structure — max loss at risk')
      + line('Structures', p.structure_count + ' recognised, ' + p.structures_taken + ' counted as risk'
        + ' <span class="meta">' + p.legs_in_structures + ' of them backed by a broker row; '
        + p.structure_duplicates_collapsed + ' duplicate echo(es) collapsed by leg set</span>')
      + line('Max loss at risk', p.max_loss_at_risk === null ? (p.structure_count ? 'a structure counted as risk carries no max_loss_usd' : 'none') : money(p.max_loss_at_risk) + ' <span class="meta">sum of max_loss_usd over the structures counted as risk, each labelled with where its number came from</span>')
      + line('Max-loss cap', pct(p.max_loss_cap_pct) + (p.max_loss_cap_usd === null ? '' : ' = ' + money(p.max_loss_cap_usd)) + capNote(p.max_loss_cap_source))
      + line('Max loss used', lossUsed === null ? noLossNote : pct(lossUsed, 3), lossOver ? 'neg' : 'pos')
      + line('Max-loss headroom', p.max_loss_headroom_usd === null ? noLossNote : money(p.max_loss_headroom_usd), p.max_loss_headroom_usd !== null && p.max_loss_headroom_usd < 0 ? 'neg' : '')
      + line('Realised today (B)', p.realised_today === null ? 'no close record yet' : money(p.realised_today) + ' <span class="meta">' + p.realised_count + ' close record(s) over ' + p.realised_structure_count + ' structure(s)/trade(s)</span>',
        p.realised_today !== null && p.realised_today < 0 ? 'neg' : 'pos');
  }

  // One card per structure, with its legs underneath: the point is that the desk reads four rows
  // as one trade. A leg that has no broker row is still listed, marked, because the structure was
  // printed — the absence of a row is stated, not hidden.
  function renderStructures(p) {
    if (!p.structures.length) {
      return '<div class="empty">No sleeve B structure record mined yet — a record naming an '
        + 'iron fly and carrying its leg set. A single-leg option does not appear here; this empty '
        + 'state is not proof that no structure was proposed. A proposal the guard refused never '
        + 'reaches this panel: it stays a veto row in the Decision Log.</div>';
    }
    const openByCode = {};
    for (const pos of p.open) if (pos.occ) openByCode[pos.occ.osi] = pos;
    return p.structures.map(function (st) {
      // Three-way, never a guess: a gate object that does not carry `pass` is not a failed gate.
      const gate = st.regime_gate
        ? ' · gate ' + (st.regime_gate.pass === true ? '<span class="pos">pass</span>'
            : st.regime_gate.pass === false ? '<span class="neg">fail</span>' : 'not stated')
        : '';
      const book = st.book ? (st.book.all_legs_two_sided ? ' · book two-sided' : ' · <span class="neg">book not two-sided</span>') : '';
      // Identity, stated rather than assumed: an emitted `structure_key` is the producer's word, a
      // derived leg set is my fallback for older records. A disagreement between the key a proposal
      // claims and the key the legs actually form means one leg was amended or re-sized, so what is on
      // the ticket is NOT the structure the auditor approved. That belongs above the fold.
      const warnText = st.key_warnings && st.key_warnings.length ? st.key_warnings.join(' | ')
        : (st.key_mismatch ? 'structure_key mismatch: this record claims ' + st.key
          + ' but its legs are ' + st.structure_key_now : null);
      const laneSize = st.lane ? st.lane.split(LANE_SEP)[1] : null;
      const sizesList = st.key_lanes ? st.key_lanes.filter((l) => l !== '?').join(' / ') : '';
      const sizeNote = st.key_carries_sizes
        ? '<div class="warn">one structure_key, ' + st.key_carries_sizes
          + ' sizes (' + esc(sizesList) + ' lots) — the key is size-independent by contract'
          + ' (sleeve_b_fly.py:115-119), so these are separate trades, not a duplicate</div>'
        : '';
      const orphanNote = st.key_carries_sizes && laneSize === '?'
        ? '<div class="warn">no size on this record and its key already has ' + st.key_carries_sizes
          + ' sized lanes (' + esc(sizesList) + '), so it is shown on its own rather than guessed'
          + ' onto one of them</div>'
        : '';
      const ident = '<div class="meta">' + esc(st.key_source || 'no structure identity')
        + (st.key ? ' · key ' + esc(st.key) : '') + '</div>'
        + sizeNote + orphanNote
        + (warnText ? '<div class="warn">' + esc(warnText) + '</div>' : '');
      return '<div class="log-row"><div class="meta">' + esc(isoOf(st.at) || 'no time') + ' · '
        + esc(st.kind || 'structure') + ' · ' + esc(st.venue || st.ticker || '') + ' ' + esc(st.expiry || '')
        + ' · DTE ' + esc(String(st.dte === null ? '—' : st.dte)) + '</div>'
        + '<div><span class="' + (st.approved === false ? 'blocked' : 'approved') + '">'
        + esc(String(st.approved === true ? 'APPROVED' : st.approved === false ? 'VETOED' : 'PROPOSED')) + '</span> '
        + esc(st.qty === null ? '?' : st.qty) + ' lot(s) · credit ' + money(st.credit)
        + ' · max loss ' + money(st.max_loss_usd)
        + ' (' + money(st.max_loss_per_lot) + '/lot)'
        + (st.max_loss_source ? ' <span class="meta">[' + esc(st.max_loss_source) + ']</span>' : '')
        + gate + book + '</div>'
        + '<div class="meta">' + esc(st.leg_count) + ' legs = ' + esc(st.key ? st.leg_keys.length : 0)
        + ' distinct contract(s) · ' + esc(String(st.rows_seen)) + ' of them seen as broker rows · basis: '
        + esc(st.exposure_basis) + (st.size_basis ? ' · size basis ' + esc(st.size_basis) : '')
        + (st.fee_model ? ' · fees ' + esc(st.fee_model) : '') + '</div>'
        + ident
        + '<div class="sbb-table sbb-legs">' + row([cell('Seq', 'h'), cell('Contract', 'h'), cell('Side'), cell('Qty'), cell('Strike'), cell('Bid'), cell('Ask'), cell('Offset'), cell('Broker row')])
        + st.legs.map(function (l) {
            const seen = openByCode[l.osi || l.key];
            return row([
              cell(esc(String(l.seq))),
              cell('<span class="sbb-sym">' + esc(l.code || '(no code)') + '</span>' + (l.osi ? '' : ' <span class="warn">raw</span>')),
              // Full word, not BUY/SELL: an opening leg and a closing leg are different facts, and a
              // mark's whole job is to say these four legs are being bought back.
              cell(/^(BUY|SELL)(_TO_(OPEN|CLOSE))?$/.test(String(l.side || ''))
                ? '<span class="' + (String(l.side).indexOf('BUY') === 0 ? 'pos' : 'neg') + '">' + esc(l.side) + '</span>'
                : esc(String(l.side || '—'))),
              cell(esc(String(l.qty === null ? '—' : l.qty))),
              cell(esc(String(l.strike === null ? '—' : l.strike)) + ' ' + esc(l.right || '')),
              cell(l.bid === null ? '—' : money(l.bid)),
              cell(l.ask === null ? '—' : money(l.ask)),
              cell(l.offset === null ? '—' : esc(l.offset)),
              cell(seen ? '<span class="pos">x' + esc(String(seen.qty)) + '</span>' : '<span class="meta">none mined</span>'),
            ]);
          }).join('')
        + '</div>'
        + (st.verdict || st.mark ? '<details class="raw"><summary>guard verdict / mark as printed</summary><pre>'
            + esc(rawJson({ verdict: st.verdict, mark: st.mark })) + '</pre></details>' : '')
        + '</div>';
    }).join('');
  }

  function renderTimeline(p) {
    if (!p.timeline.length) return '<div class="empty">No sleeve B order row, ticket or journal record mined yet.</div>';
    const rows = p.timeline.slice(0, 40).map(function (t) {
      const cls = t.state === 'filled' || t.state === 'approved' ? 'approved'
        : ['vetoed', 'cancelled', 'none', 'state_unavailable', 'error'].indexOf(t.state) >= 0 ? 'blocked' : '';
      return '<div class="log-row">'
        + '<div class="meta">' + esc(fmtEt(t.at) || 'no time') + ' · ' + esc(t.source) + '</div>'
        + '<div><span class="' + cls + '">' + esc(String(t.state || '—').toUpperCase()) + '</span> '
        + esc(t.symbol || '') + (t.qty ? ' x' + esc(t.qty) : '') + (t.price ? ' @ ' + money(t.price) : '') + '</div>'
        + (t.note ? '<div class="meta">' + esc(t.note) + '</div>' : '')
        + '<details class="raw"><summary>raw</summary><pre>' + esc(rawJson(t.raw)) + '</pre></details>'
        + '</div>';
    }).join('');
    return '<div class="scroll-box">' + rows + '</div>';
  }

  function renderStateRecords(p) {
    if (!p.state_records.length) return '';
    return '<details class="raw"><summary>' + p.state_records.length + ' option-adapter state record(s)</summary>'
      + p.state_records.map(function (r) {
        return '<div class="log-row"><div class="meta">' + esc(fmtEt(r.at) || 'no time') + ' · ' + esc(r.source) + '</div>'
          + '<div>' + esc(r.action || '—') + (r.reason ? ' — ' + esc(r.reason) : '') + '</div>'
          + '<pre>' + esc(rawJson(r.raw)) + '</pre></div>';
      }).join('') + '</details>';
  }

  function renderActivity(a) {
    if (!a) return '<div class="empty">Activity unavailable.</div>';
    const sleeves = a.sleeves || {};
    const chip = function (name) {
      const s = sleeves[name] || { entries: 0, exits: 0, rejections: 0 };
      // "in 1" with four leg fills is only honest if the reader can see the collapse.
      const legIn = s.entry_legs !== undefined && s.entry_legs !== s.entries
        ? ' <span class="meta">(' + s.entry_legs + ' fills)</span>' : '';
      const legOut = s.exit_legs !== undefined && s.exit_legs !== s.exits
        ? ' <span class="meta">(' + s.exit_legs + ' closes)</span>' : '';
      const stNote = s.structures ? ' <span class="meta">[' + s.structures + ' structure'
        + (s.structures === 1 ? '' : 's') + ']</span>' : '';
      return '<div class="act-sleeve"><span class="act-name">' + name + '</span>'
        + '<span class="act-n act-in">in ' + (s.entries || 0) + '</span>' + legIn
        + '<span class="act-n act-out">out ' + (s.exits || 0) + '</span>' + legOut
        + '<span class="act-n act-no">no ' + (s.rejections || 0) + '</span>' + stNote + '</div>';
    };
    let last = 'none mined';
    if (a.last_action_at) {
      // fmtEt, never toLocaleString: the desk runs on Eastern time and this page is served
      // from a machine on UTC+8, so a 16:15 ET report printed as 5:15 AM the next day.
      last = fmtEt(a.last_action_at) || String(a.last_action_at);
    }
    const live = a.running_sessions
      ? ' <span class="act-live">' + esc(a.running_sessions) + ' session(s) running now</span>'
      : '';
    // The unattributed lane is shown only when it actually carries a count; a fourth "in 0
    // out 0 no 0" chip reads as a sleeve the desk forgot to label.
    const unk = sleeves.unknown && (sleeves.unknown.entries || sleeves.unknown.exits || sleeves.unknown.rejections)
      ? chip('unknown') : '';
    return '<div class="act-strip">' + chip('A') + chip('B') + chip('C') + unk
      + '<div class="act-last"><span class="k">last agent action</span> <span>' + esc(last) + '</span>'
      + (a.last_action_kind ? ' <span class="meta">(' + esc(a.last_action_kind) + (a.last_action_agent ? ' · ' + esc(a.last_action_agent) : '') + ')</span>' : '')
      + live + '</div></div>'
      + (a.coverage_note ? '<div class="meta">' + esc(a.coverage_note) + '</div>' : '');
  }

  function renderAll(snap) {
    const p = buildPanel(snap);
    return {
      positions: renderPositions(p),
      structures: renderStructures(p),
      risk: renderRisk(p),
      timeline: renderTimeline(p),
      state: renderStateRecords(p),
      activity: renderActivity(p.activity),
      panel: p,
    };
  }

  return {
    MULTIPLIER: MULTIPLIER,
    ORDER_STATUS: ORDER_STATUS,
    DEFAULT_PREMIUM_CAP_PCT: DEFAULT_PREMIUM_CAP_PCT,
    DEFAULT_MAX_LOSS_CAP_PCT: DEFAULT_MAX_LOSS_CAP_PCT,
    STRUCTURE_KIND: STRUCTURE_KIND,
    MARK_KIND: MARK_KIND,
    num: num,
    parseOcc: parseOcc,
    dte: dte,
    bareSymbol: bareSymbol,
    legKey: legKey,
    looksLikeOrderRow: looksLikeOrderRow,
    looksLikePositionRow: looksLikePositionRow,
    looksLikeSubmitRow: looksLikeSubmitRow,
    looksLikeStructure: looksLikeStructure,
    normalizeStructure: normalizeStructure,
    laneFolder: laneFolder,
    classifyOrderRow: classifyOrderRow,
    orderStatusCode: orderStatusCode,
    readPositionRow: readPositionRow,
    blobKind: blobKind,
    normalizeTicket: normalizeTicket,
    buildPanel: buildPanel,
    sameDay: sameDay,
    toEtDate: toEtDate,
    etDayNow: etDayNow,
    isoOf: isoOf,
    renderPositions: renderPositions,
    renderStructures: renderStructures,
    renderRisk: renderRisk,
    renderTimeline: renderTimeline,
    renderActivity: renderActivity,
    renderStateRecords: renderStateRecords,
    renderAll: renderAll,
  };
});
