"""Sleeve A replayed on real 5-minute bars from four 2016-2022 windows.

Reuses .scratch/bt-1125/engine.py unchanged (the module that produced the contest-window
numbers in docs/submission section 4): signals come from the mounted trend_signal, size and
fees from the mounted rules.json arithmetic, matching and monitoring from the engine. Only two
things are supplied differently here -- the bar store (this directory's bars/) and regimes.json.

One deliberate patch: desk_sleeves_v2.INVERSE["SPY"] is SPXS in the design module, but the live
rulebook that trend_signal.py implements has PAIRS["SPY"]["short"] = None (SPXS was removed on
2026-11-20 for failing the contest's $500M eligibility floor). Pointing the engine at SPY's own
bar column therefore only feeds an `inverse_price` field that signal() never reads for SPY -- a
SPY short returns NONE before sizing. Without the patch every pre-2026 session would be dropped
for want of SPXS bars, which would be a silent sample loss.
"""
import json
import os
import sys
from collections import defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import desk_sleeves_v2 as dv2  # noqa: E402
dv2.INVERSE["SPY"] = "SPY"
import engine  # noqa: E402

WINDOWS = {"W1_2016aug": (20160801, 20160831), "W2_2018jan": (20180102, 20180131),
           "W3_2020mar": (20200302, 20200331), "W4_2022apr": (20220401, 20220429)}
LABEL = {"W1_2016aug": "sideways", "W2_2018jan": "bull",
         "W3_2020mar": "bear/crisis", "W4_2022apr": "bear"}
SIDE_KEYS = ("LONG", "SHORT")
INST_KEYS = ("SPY", "QQQ", "SMH")


def win_of(day):
    for w, (lo, hi) in WINDOWS.items():
        if lo <= day <= hi:
            return w
    return None


def new_agg():
    return defaultdict(lambda: dict(n=0, net=0.0, wins=0, fees=0.0, rs=[]))


def add(agg, key, t):
    a = agg[key]
    a["n"] += 1
    a["net"] += t.get("net", 0.0)
    a["fees"] += t.get("fees", 0.0)
    a["rs"].append(t.get("R", 0.0))
    a["wins"] += 1 if t.get("net", 0.0) > 0 else 0


def line(label, a):
    if not a or not a["n"]:
        print("%-26s   0" % label)
        return
    r = a["rs"]
    mean = sum(r) / len(r)
    sd = (sum((x - mean) ** 2 for x in r) / max(1, len(r) - 1)) ** 0.5
    se = sd / len(r) ** 0.5 if len(r) > 1 else float("nan")
    tstat = mean / se if se and se == se and se > 0 else float("nan")
    print("%-26s %4d %6.1f %9.2f %9.2f %8.3f %7.2f %6.2f" % (
        label, a["n"], 100.0 * a["wins"] / a["n"], a["net"], a["fees"], mean, tstat, sd))


HDR = "%-26s %4s %6s %9s %9s %8s %7s %6s" % (
    "group", "tr", "win%", "net$", "fees$", "avg_R", "t", "sd_R")


def main():
    store = json.load(open(os.path.join(HERE, "store_summary.json"), encoding="utf-8"))
    regs = json.load(open(os.path.join(HERE, "regimes.json"), encoding="utf-8"))
    days = sorted(int(d) for d in regs if win_of(int(d)))
    print("candidate sessions:", len(days), "store:",
          json.dumps({s: v["sessions"] for s, v in store["summary"].items()}))
    have, out = engine.run(days=days)
    print("\nsimulated sessions: %d" % len(have))
    by_var = {n: r["trades"] for n, r in out.items()}
    as_run = out[engine.AS_RUN]
    print("\n=== %s (what runs live) ===" % engine.AS_RUN)
    print(json.dumps(as_run["metrics"], indent=1))

    agg = new_agg()
    for t in as_run["trades"]:
        for key in (win_of(t["day"]), regs[str(t["day"])]["regime"]["regime"],
                    t["action"], t["instrument"], "ALL"):
            add(agg, key, t)

    # the 28 Sep-23 Nov 2026 contest window: same engine, same code path, real 5-min bars
    try:
        c = json.load(open(os.path.join(HERE, "..", "bt-1125", "sim_out.json"), encoding="utf-8"))
        ct = c["out"][engine.AS_RUN]["trades"]
        cregs = json.load(open(os.path.join(HERE, "..", "bt-1125", "regimes.json"),
                               encoding="utf-8"))
        cnet = sum(t.get("net", 0.0) for t in ct)
        print("\ncontest-window trades merged: %d trades, net $%.2f (section 4 says 41 / "
              "$704.03 -- if this differs, do not quote the pooled row)" % (len(ct), cnet))
        for t in ct:
            b = (cregs.get(str(t["day"])) or {}).get("regime", {}).get("regime", "?")
            for key in ("CONTEST_2026sep-nov", b, t["action"], t["instrument"], "ALL"):
                add(agg, key, t)
    except (OSError, ValueError, KeyError) as exc:
        print("contest window not merged:", exc)

    print("\n" + HDR)
    for w in sorted(WINDOWS):
        line("%s (%s)" % (w, LABEL[w]), agg.get(w))
    line("CONTEST 2026sep-nov", agg.get("CONTEST_2026sep-nov"))
    print("\n" + HDR.replace("group", "ladder bucket"))
    buckets = [k for k in agg if k not in WINDOWS and k not in
               SIDE_KEYS + INST_KEYS + ("CONTEST_2026sep-nov", "ALL")
               and k in ("low_vol", "normal", "caution", "bear_high_vol", "crisis", "?")]
    for b in sorted(buckets):
        line(b, agg[b])
    print("\n" + HDR.replace("group", "by side / instrument"))
    for k in SIDE_KEYS + INST_KEYS:
        line(k, agg.get(k))
    print()
    line("ALL (pooled, incl. contest)", agg.get("ALL"))
    no_c = new_agg()
    for t in as_run["trades"]:
        add(no_c, "GENERAL ONLY (2016-2022)", t)
    line("GENERAL ONLY (2016-2022)", no_c["GENERAL ONLY (2016-2022)"])

    json.dump({"sessions": have, "as_run": as_run["trades"], "design": by_var[engine.DESIGN],
               "metrics": {n: r["metrics"] for n, r in out.items()},
               "groups": {k: {kk: vv for kk, vv in v.items() if kk != "rs"}
                          for k, v in agg.items()}},
              open(os.path.join(HERE, "replay_out.json"), "w", encoding="utf-8"), indent=1)
    print("\nall variants:")
    for n, r in out.items():
        m = r["metrics"]
        print("  %-34s tr %-4d win %-5.1f%% avg_R %-7.3f net $%.2f" % (
            n, m.get("trades", 0), m.get("win_pct", 0.0), m.get("avg_R", 0.0),
            m.get("net_usd", 0.0)))


if __name__ == "__main__":
    main()
