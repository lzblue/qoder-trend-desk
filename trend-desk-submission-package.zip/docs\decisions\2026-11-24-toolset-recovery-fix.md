# Toolset gap RCA and on-the-fly recovery fix — 2026-11-24

Status: **fix applied live** (4 Forward template `system` writes, 0 other fields touched).
Evidence dir: `.scratch/changes/2026-11-24-toolbox-rca/` (baseline, patched, threads, live).
Detector: `tools/toolset-drift.mjs` (read-only, exit 1 on drift).
Supersedes the conclusion of `docs/moomoomcp-tool-definition-resolution.md` (2026-11-20) §1–§3.

## 1. What was reported

2026-11-23 scheduled desk: the researcher again reported `TOOLSET ABSENT (moomoomcp)`, and in one
cycle the toolbox appeared to disappear **mid-run**. Three cycles closed with zero entries; the
Sleeve B fly window (10:00–11:00 ET, fly-week day 1) was forfeited. Zero orders placed all day.
Day cost 160.04 credits over 30 schedule runs.

## 2. Mode question — answered

Not a managed-mode run. Every 2026-11-23 session is Forward, schedule-originated:
`source_type: "schedule"`, `metadata.schedule_id` present; on the Managed twin
`metadata.created_by: "forward"`, `forward_source_type: "schedule"`, `deployment_id: null`.
The Managed layer matters only as the compile target: the incident runs were template **v21** →
researcher `agent_00vqwo8ry3itcq8mmay7` **v41 / model `efficient`**; clean runs from 16:00Z were
**v22** → researcher **v43 / `qmodel_38max`**. Correlation, not proven causation (BRIEF was also
v41 and clean). As of 2026-11-24 the live templates are back on `efficient` for all four roles.

## 3. Root cause

The connector never dropped. **188/188** correct-path `agent.mcp_tool_use` rows succeeded across the
night, all with `mcp_server_name: "moomoomcp"`, including 3 in the risk_auditor thread at
15:38:28 / 15:38:31 / 15:38:35 — seconds around the researcher failure at 15:38:22, same session,
same environment, same vault.

The 8 failed calls are a different shape, with no overlap against the 188:

| | name | params |
|---|---|---|
| 188 successes | bare (`quote_stock_quote`) | native: `{"code_list":["US.QQQ"]}`, `{"ktype":6,"num":12}` |
| 8 failures | server-prefixed (`moomoomcp__quote_stock_quote`) | string-serialised: `{"code_list":"[\"US.QQQ\"]"}`, `{"ktype":"6","num":"14"}` |

A model that can see a JSON schema does not prefix the server name and does not serialise an array or
integer into a string. A model reconstructing a tool from memory does both. **The moomoomcp tool
definitions were not in the model's context on those turns**; the tool *stems* and values survived
because they appear as prose in the coordinator's task text.

Three researcher threads, one session (`sess_00wdhbcisny0wq187gc0`):

| thread | ET | correct calls | wrong-name calls | compaction |
|---|---|---|---|---|
| `sthr_00wdhdf48gjr4sfsutac` | 10:05 | 0 (first action) | 2 | 0 |
| `sthr_00wdi7txaw8ao432gcxm` | 10:14 | 20 (15:15:12–15:26:33) | 4 at 15:30:46 | **1 at 15:29:58** |
| `sthr_00wdkaaiom7lsr49k` | 10:35 | 0 (first action) | 2 | 0 |

The mid-run instance is the 10:14 thread: 20 working calls, then `agent.thread_context_compacted`,
then 48 s later a single batch of four wrong-shaped calls. Compaction happened exactly once all night,
in exactly that thread. The 10:05 and 10:35 threads failed on model request #1 with no compaction, so
compaction is one trigger, not the cause.

Independent corroboration of the same error class in the same session, different tool family: the
coordinator called `create_agent` with the key `agent_name` **four times**
(`create_agent requires a non-empty name.`), then retried with `name` and succeeded — identity known,
schema reconstructed.

Still undiscoverable read-only: no event anywhere lists a thread's resolved tool set, so "were the
definitions in the request" cannot be answered from the API for the two first-request cases.

## 4. Why the previous fix did not hold

The 2026-11-20 memo's §4 mitigations were deferred under rule 8 and **never shipped** — measured in the
live prompts: `TOOLSET FLAKY` 0, `moomoomcp__` 0, "bare name" 0, `dispatch` 0. What *was* shipped was
the probe plus the `TOOLSET ABSENT` halt and the coordinator rule "ABSENT from any child ⇒ no entries".
The probe conditioned on *"if the moomoo tools are not in your tool list at all"* — an unobservable state
that a deny on a name the model itself invented satisfies. The fix improved reporting fidelity of a
false condition and left the halt live, so the desk converted a naming slip into a forfeited trading
window.

It also self-propagated: the agents wrote the wrong diagnosis into durable memory
(`/data/.agent/awareness/toolset-gap-intermittent.md`: "moomoomcp can drop MID-session, so a fresh
session is not a guaranteed fix"; `desk-journal.md`: "namespace unregistered at runtime") and three
`reason=toolset_absent` journal rows. FLAT and REPORT read those files, and the coordinator's stated
"confirmed fix" — spawn a fresh researcher session — is the action that produced the two first-request
failures.

## 5. What is live now

All four prompts carry a literal dispatch contract and an R1–R4 recovery ladder; `TOOLSET ABSENT` is a
retired label in every role, replaced by `CONNECTOR DOWN` which requires a quoted bare-name failure.

| template | before | after | delta | new sha |
|---|---|---|---|---|
| coordinator | 10627 ch `efca600e7137` | 12375 ch | +1748 | `256b96987427` |
| researcher | 8490 ch `95a488f9ccdd` | 10289 ch | +1799 | `aed9d04665d2` |
| risk_auditor | 15074 ch `861bbc492449` | 16751 ch | +1677 | `af999049893b` |
| executor | 18376 ch `5a2bec32936c` | 20057 ch | +1681 | `cf09237eab4d` |

Recovery path, in order, before any cycle may close:
1. **R1** unknown-tool error → immediately re-issue on server `moomoomcp` with the bare name and native
   types. Success = continue silently.
2. **R2** still unknown-tool → `sleep 20`, repeat R1, copy the exact name string from a call that already
   worked this run.
3. **R3** a gap exists only if R1+R2 both failed, or the error is connector-class
   (`ret_code`, `Forbidden`, auth, timeout, network, or an error naming the server).
4. **R4** cache fallback: freshest `/data/desk/research/` numbers under 5 minutes old, labelled
   `SOURCE=STALE_CACHE`; else `CONNECTOR DOWN` with both error texts.
5. Coordinator: never closes a cycle on a wrong-name deny; replies with the literal call form and waits.
   Retry the child, then ask the role whose probe passed for a numeric relay (`source=relay`, numbers +
   vintage, no interpretation), then close. One extra spawn + one relay per cycle.
6. Executor: an approved ticket may never be abandoned on an unknown-tool error alone.
7. Memory hygiene: no run may record "namespace dropped/unregistered/died" unless a bare-name call failed
   with a connector-class error in the same message.

Skills, pins, `mcp_servers`, `model`, roster were untouched: single-field `system` POST preserves the
rest (verified by read-back counts — researcher 5 pins, risk_auditor 4, executor 4, coordinator roster
intact).

## 6. Rollback

`node .scratch/changes/2026-11-24-toolbox-rca/tools/rollback.mjs` re-POSTs each
`baseline/<role>.system.txt` (the 2026-11-23T23:19Z live bytes captured before this change).

## 7. Residual risk

- The ladder is prompt-level. All four templates run `permission_policy: always_allow` and the auditor's
  "read-only" is still unenforced at the tool layer, so nothing structurally prevents a halt.
- If the platform genuinely omits MCP definitions from a first request, R1 converts the loss into one
  extra call per run instead of a lost cycle; it does not remove the underlying fault. That is a
  platform bug report, not a desk change.
- `efficient` is back on all four templates. The ladder was exercised live on that model
  (`live/acceptance-sess_00werfiurbklcuqzvys7.json`, researcher template v47, 2.81 of a 3.00 credit cap):
  the forced wrong-name call was denied twice, then the same session answered `ret_code: 0` on the
  server + bare-name form at 23:42:41 and emitted no `TOOLSET ABSENT`. What that does **not** prove is
  recovery when the mcp definition is genuinely absent from the model's context — in the test the
  definition was present, so only the symptom shape was reproduced. The genuine-gap path (R3 → relay /
  `SOURCE=STALE_CACHE` / `CONNECTOR DOWN`) is still unexercised. See
  `2026-11-24-post-fix-operations.md` §2, which supersedes this section's §5 table and this bullet.

## 8. Second pass, applied 2026-11-24T07:47:53+08:00

Two defects in the text above were fixed by a second single-field `system` write per role: the
registry identifier `mcp__moomoomcp__<tool>` is now named (the acceptance session had to discover it by
trial), and the pre-existing local-skill label `TOOLSET ABSENT (option-adapter)` — which collided with
the retirement sentence in the same prompt — is renamed `SKILL BUILD ABSENT (option-adapter)`, with a
coordinator rule that reads it as a skill-pin problem (sleeve B off, A/C unaffected) rather than a
connector gap. Byte counts, shas, rollback and the regression gate's measured exit codes are in
[2026-11-24-post-fix-operations.md](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/2026-11-24-post-fix-operations.md).
