# Companion: are the diversification candidates dividend stocks, and are they liquid?

Date 2026-11-20, live reads 02:10–04:35 ET. Companion to
[ticker-diversification-nov20.md](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/ticker-diversification-nov20.md),
which answers *would the engine trade them*; this file answers the three questions that memo does
not cover: **dividend? liquid? diverse from each other?** Status: analysis only — no publish, no
template write, no order. Every moomoo call was quote-side (`quote_market_snapshot`,
`quote_corporate_actions_dividends`, `quote_owner_plate`, `quote_history_kline`).

Claim tags as in the parent memo: **[observed]** a live read or run this session,
**[documented]** a file in this repo, **[undiscoverable]** not reachable from here.

## 1. Yield and payout [observed, 02:2xZ]

moomoo `dividend_ratio_ttm` / `dividend_ttm` / `payout`. $ per 100 shares per year = `dividend_ttm` × 100.

| ticker | yield | $/100 sh/yr | payout % |
|---|---|---|---|
| VZ | 6.41 | 279 | 44.5 |
| PFE | 6.25 | 172 | 29.2 |
| CVX | 4.15 | 857 | 41.4 |
| XOM | 3.41 | 542 | 43.0 |
| JNJ | 3.21 | 664 | 82.0 |
| NEE | 2.91 | 244 | 45.3 |
| ABBV | 2.83 | 632 | 99.2 |
| MCD | 2.73 | 744 | 37.7 |
| PG | 2.69 | 452 | 57.2 |
| KO | 2.19 | 210 | 58.2 |
| BRK.B | 0.00 | 0 | n/a |
| SPY / QQQ / IWM / SMH | 1.06 / 0.48 / 1.03 / 0.25 | — | — |

**Consequence for the desk.** Trend tickets the risk gate allows are tens of shares (sizing is
`(nav × risk_pct × mults) / stop_dist`, `stop_dist ≈ 0.55 × rng_pct × price`, so notional is a
fixed fraction of NAV and *falls* as price × range widens). At 30 shares, KO's full-year dividend
is **$6.30** — smaller than one minute of noise on the position. Dividends cannot justify a trend
entry; they only become material at income-sleeve sizes.

## 2. The structural risk the parent memo does not have: ex-dividend dates [observed]

Daily OHLC with moomoo's dividend adjustment enabled, 2026-08-18..11-20, 64 sessions per name:

- **KO on 2026-11-27**: `high 98.66 / low 89.26 = 9.9%` range vs a **1.68%** median over the prior
  30 sessions — a 5.9× outlier, and the only KO session in 64 that breaks the desk's 1.5% opening
  -range ceiling. Ex-amount $0.57/sh.
- Same window flags **JNJ 2026-11-25** ($1.30) and **ABBV 2026-11-28** ($2.43).
- Gate used: `gap_frac = |open − prev_close| / prev_close ≥ 3%` **or** `gap ≥ 3 × median 5-day true range`.

An opening range that straddles an ex-date is invalid on either feed: adjusted data re-bases every
prior bar, unadjusted data shows a one-bar hole. `ex_date == today → NONE` is a one-line,
deterministic refusal and it belongs to **trend-signal** (it needs bar history), not guard.
Rule-assumption caveat: the adjustment convention on this endpoint is inferred from the price
pattern, not from a documented field. [undiscoverable] whether moomoo's `dividend_adjust` is
applied to 5-min intraday bars the same way as to daily.

## 3. Liquidity: no candidate is capacity-constrained [documented + observed]

`liquidity.mjs` [documented] computes median and 10th-percentile 5-minute dollar turnover from
`bars/*.json` (session bars, multi-day). For the single names it already covers:
NEE $6.1M median / $3.4M p10, MCD $8.1M/$4.4M, FCX $8.2M/$3.6M, CVX $10.3M/$6.1M, XOM $13.2M/$7.3M —
against a benchmark of SMH $38.9M, SOXS $34.7M, SPXS $3.2M.

A trend ticket at gate-allowed size is **$2k–$25k notional**, i.e. 0.1–1.5% of a *quiet* 5-minute
bar of any candidate. Slippage is not the constraint on this universe; the constraint is the stop
and the exposure cap. [observed, 20-session ADV cross-check 02:3xZ: NEE $84B, PFE $147B, MCD $182B,
KO $100B, ABBV $195B, XOM $6.9B daily turnover, BRK.B $3.1B — all ≥ 5 orders of magnitude above ticket size.]

Provenance note: this session also produced a full 18-row ADV + median-5-min table from a script
(`adv2.py`) whose file is **no longer on disk** (see §5). The numbers quoted above are reproducible
from `liquidity.mjs` + `bars/`; the rest should be re-run before being quoted.

## 4. Diversity: five distinct industry plates [observed, 04:25–04:33Z ET 04:2x]

`quote_owner_plate` (industry plate per symbol):

| ticker | plate |
|---|---|
| FDX | Integrated Freight & Logistics |
| NEE | Utilities – Regulated Electric (also carries the *Dividend Aristocrats* concept plate) |
| MCD | Restaurants |
| KO | Beverages – Non-Alcoholic |
| PFE | Drug Manufacturers – General |
| BRK.B | Insurance – Diversified |

Five of these (NEE, MCD, KO, PFE, BRK.B) are in the parent memo's candidate set and share **no**
plate with each other or with SMH (semis). Honest limit: **14 of the 18 candidates are also
SPY/QQQ components**, and I did not enumerate the index-holdings plates (`quote_plate_stock` needs
a `plate_code` I could not resolve for IWM's holdings), so the overlap is asserted from their
large-cap index membership, not measured. [undiscoverable without one more call set]

Spread caveat: the snapshot I pulled at 04:25 ET returns **after-hours/overnight** prints
(SPY bid 712.39/ask 712.46 vs last 715.87; FDX 309.92/318.50 = a 2.7% "spread"). Those are not
regular-session spreads and must not be used as a liquidity gate. `bidask.json` [documented] holds
in-session top-of-book for 21 symbols and is the right shape; it needs a same-session refresh at
entry time, which is where the executor's existing "price moved >0.3% from the ticket" re-check
already runs.

## 5. Two process findings worth keeping

1. **A first replay of today's scans was a look-ahead and its "18/18 pass" is void.** The opening
   range was computed from bars that existed *at* the scan time (10:05 scan → bars through 10:05)
   instead of the first six bars frozen at 10:00, and the price was by construction the top of
   that window. The parent memo's `replay.py` gets this right ("first six bars, 09:35–10:00
   close-stamped") and its fidelity check reproduces the two real 19 Nov tickets exactly — which is
   why the corrected replay, not mine, is the one to extend.
2. **This session duplicated tooling that already existed** (`replay.py`, `screen.py`,
   `liquidity.mjs`, `adv.py`, `bidask.json`) because it did not read the directory first. Any
   future pass on this question starts from `docs/decisions/ticker-diversification-nov20.md` and
   `.scratch/tickdiv/*.py`.

## 6. Recommendation

- Leave the **trend** sleeve as it is: at gate-allowed sizes a single stock adds idiosyncratic gap
  risk without adding return capacity, and the dividend is noise.
- If individual names are wanted, put them in an **income sleeve with its own rules** the trend
  gate cannot reach: no entry within N sessions of a scheduled ex-date, sized from *dollar* volume,
  held in weeks. NEE, MCD, KO, CVX, PFE are the names that survive yield + payout + plate tests.
- **Wire the ex-date refusal regardless** — it protects the existing sleeve universe too, since
  index funds and the 3x inverses have their own distributions.
