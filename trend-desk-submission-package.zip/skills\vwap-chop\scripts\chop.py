"""Sleeve C - VWAP fade on days Sleeve A rejects for a too-wide opening range.

Stdlib only, no tool calls. Proposes; never trades. Every proposal goes through
desk-risk-guard exactly like a Sleeve A signal.

Derived from desk_sleeves_v2.sleeve_c_signal() (the authoritative design). Two
deliberate differences, both required by the live desk:
  * levels are returned in INSTRUMENT price terms, using the same arithmetic as
    trend_signal.signal() (entry*(1 -/+ lev*pct)) so the executor's ladder, stop and
    take-profit are expressed in the price of the ETF actually bought;
  * entry mechanism is not chosen here at all - the desk's existing ladder chase and
    close-at-next-check cover every equity entry, per the 2026-11-19 38-session test.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

RR = 1.5
# Sleeve A's own acceptance band, verbatim from live trend_signal.signal():
#   "if not 0.15 <= rng_pct <= 1.5" -> NONE. Kept as the default so C is A's exact
# complement; callers may pass --a-band-max-pct to match a future A revision.
A_BAND_MAX_PCT = 1.5

# SPY's bearish instrument was SPXS until 2026-11-20; it was removed because its net assets sit below the
# competition's $500M eligibility floor. SPY stays a Sleeve C ticker for LONG fades only: (None, 0) means
# "no bearish ETF", and a bearish SPY fade returns NONE instead of guessing a substitute.
INVERSE = {"QQQ": ("SQQQ", 3), "SPY": (None, 0), "SMH": ("SOXS", 3)}
FAMILY = {**{t: t for t in INVERSE}, **{v[0]: t for t, v in INVERSE.items() if v[0]}}


def vwap_bands(bars):
    """Session VWAP and volume-weighted std dev of typical price around it."""
    vol = sum(b["volume"] for b in bars)
    if len(bars) < 2 or vol <= 0:
        return None, None
    tps = [(b["high"] + b["low"] + b["close"]) / 3.0 for b in bars]
    vwap = sum(tp * b["volume"] for tp, b in zip(tps, bars)) / vol
    var = sum(b["volume"] * (tp - vwap) ** 2 for tp, b in zip(tps, bars)) / vol
    return vwap, math.sqrt(var)


def running_vwap_crosses(bars, skip=6):
    """Close switches across the RUNNING session VWAP after the first `skip` bars."""
    cum_pv = cum_v = 0.0
    prev_side, crosses = None, 0
    for i, b in enumerate(bars):
        tp = (b["high"] + b["low"] + b["close"]) / 3.0
        cum_pv += tp * b["volume"]
        cum_v += b["volume"]
        if i < skip or cum_v <= 0:
            continue
        v = cum_pv / cum_v
        if b["close"] > v:
            side = 1
        elif b["close"] < v:
            side = -1
        else:
            side = prev_side
        if prev_side is not None and side is not None and side != prev_side:
            crosses += 1
        prev_side = side
    return crosses


def _mins(hhmm):
    h, m = str(hhmm).split(":")
    return int(h) * 60 + int(m)


def sleeve_c_signal(ticker, bars, or_width_pct, now_min, flat_by_min,
                    inverse_price=None, a_band_max_pct=A_BAND_MAX_PCT,
                    z_min=1.5, z_max=3.0, min_crosses=2, start_min=10 * 60 + 30):
    def none(why):
        return {"sleeve": "C", "action": "NONE", "ticker": ticker, "reason": why}

    if ticker not in INVERSE:
        return none(f"{ticker} not a Sleeve C ticker")
    for k in ("or_width_pct", "now_min", "flat_by_min"):
        v = {"or_width_pct": or_width_pct, "now_min": now_min, "flat_by_min": flat_by_min}[k]
        if not isinstance(v, (int, float)) or isinstance(v, bool) or v != v:
            return none(f"{k} missing or non-numeric - refusing to guess")
    if or_width_pct <= a_band_max_pct:
        return none("opening range %.2f%% is inside A's band - Sleeve A's territory" % or_width_pct)
    if not (start_min <= now_min <= flat_by_min - 90):
        return none("outside the C window (needs data after 10:30 ET and 90 min before flat)")
    if not bars or len(bars) < 9:
        return none("fewer than 9 bars")
    for b in bars:
        for k in ("high", "low", "close", "volume"):
            if not isinstance(b.get(k), (int, float)) or b[k] != b[k]:
                return none(f"bar field {k} missing or non-numeric")

    vwap, sigma = vwap_bands(bars)
    if not sigma:
        return none("VWAP bands unavailable")
    crosses = running_vwap_crosses(bars)
    if crosses < min_crosses:
        return none("%d VWAP cross(es) - one-sided session, likely a trend day, no fade" % crosses)

    px = bars[-1]["close"]
    z = (px - vwap) / sigma
    if not (z_min <= abs(z) <= z_max):
        return none("z=%.2f outside the fade zone [%s, %s]" % (z, z_min, z_max))

    prior = bars[-3:-1]
    if z > 0:
        stalled = bars[-1]["high"] <= max(b["high"] for b in prior)
        side, extreme = "SHORT", max(b["high"] for b in bars)
    else:
        stalled = bars[-1]["low"] >= min(b["low"] for b in prior)
        side, extreme = "LONG", min(b["low"] for b in bars)
    if not stalled:
        return none("z=%.2f but price is still extending - no stall yet" % z)

    reward = abs(px - vwap)
    stop_dist = reward / RR
    stop = px + stop_dist if side == "SHORT" else px - stop_dist
    buffer = 0.1 * sigma
    if (side == "SHORT" and stop < extreme + buffer) or (side == "LONG" and stop > extreme - buffer):
        return none("a 1.5R stop would sit inside the session extreme - noise would tag it")

    # Instrument-level levels, same convention as trend_signal.signal() (entry*(1 -/+ lev*pct)).
    if side == "SHORT":
        if INVERSE[ticker][0] is None:
            return none(f"{ticker} has no eligible bearish ETF configured - long fades only")
        if not isinstance(inverse_price, (int, float)) or not inverse_price:
            return none("SHORT fade needs inverse_price - refusing to guess the ETF quote")
        instrument, lev, entry = INVERSE[ticker][0], INVERSE[ticker][1], float(inverse_price)
        pct_stop = stop_dist / px
        pct_tgt = (px - vwap) / px
        inst_stop, inst_tgt = entry * (1 - lev * pct_stop), entry * (1 + lev * pct_tgt)
    else:
        instrument, lev, entry = ticker, 1, px
        inst_stop, inst_tgt = stop, vwap

    entry_r, stop_r, tgt_r = round(entry, 2), round(inst_stop, 2), round(inst_tgt, 2)
    if stop_r == entry_r or tgt_r == entry_r:
        return none("levels round to the entry price - ticket would have zero stop or target")
    if (stop_r - entry_r) * (tgt_r - entry_r) >= 0:
        return none("stop and target are on the same side of entry after rounding")

    return {
        "sleeve": "C", "action": side, "signal_ticker": ticker, "family": FAMILY[ticker],
        "instrument": instrument, "leverage": lev,
        "underlying": {"price": round(px, 2), "stop": round(stop, 2), "target": round(vwap, 2)},
        "entry": entry_r, "stop": stop_r, "target": tgt_r, "reward_risk": RR,
        "z": round(z, 2), "vwap_crosses": crosses, "sigma": round(sigma, 4),
        "reason": "%s fade: rotating session (%d VWAP crosses), z=%.2f, stalled; target VWAP %.2f"
                  % (side, crosses, z, vwap),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["signal"])
    ap.add_argument("--input", required=True)
    ap.add_argument("--a-band-max-pct", type=float, default=A_BAND_MAX_PCT)
    a = ap.parse_args()
    try:
        d = json.loads(Path(a.input).read_text())
    except (OSError, ValueError) as e:
        print(json.dumps({"sleeve": "C", "action": "NONE",
                          "reason": "input unreadable/invalid JSON: %s" % e}))
        return
    out = sleeve_c_signal(
        d.get("ticker"), d.get("bars") or [], d.get("or_width_pct"),
        _mins(d["time_et"]) if d.get("time_et") else None,
        _mins(d.get("flat_by_et") or "15:45"),
        inverse_price=d.get("inverse_price"), a_band_max_pct=a.a_band_max_pct)
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
