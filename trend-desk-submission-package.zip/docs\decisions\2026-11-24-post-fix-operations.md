# Closing the toolset-gap fix — what changed on 2026-11-24 after the RCA

Follows `2026-11-24-toolset-recovery-fix.md` (the RCA and the R1–R4 ladder, already live).
This file records the four follow-through items the owner approved, each with the read-back that
proves it landed. Times: local is UTC+8, so `2026-11-24T08:1x` local = `2026-11-23T23:1xZ`.

## 1. Prompt pass 2 — registry form named, colliding label renamed (live)

| template | pass 1 | pass 2 (live now) | ch | read-back |
|---|---|---|---|---|
| coordinator | `256b96987427` | `b5a8045502cd` | 12,789 | MATCH |
| researcher | `aed9d04665d2` | `d70ac3902331` | 10,534 | MATCH |
| risk_auditor | `af999049893b` | `cdddef103a27` | 16,992 | MATCH |
| executor | `cf09237eab4d` | `265761b24d97` | 20,302 | MATCH |

Applied at `2026-11-24T07:47:53+08:00`, single-field `{system}` POST with
`Idempotency-Key: toolboxfix2-<role>-20261124`, and the guard in
[patch-prompts2.mjs](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-24-toolbox-rca/tools/patch-prompts2.mjs)
refuses to write if the live bytes no longer match pass 1 (so a concurrent editor can't be clobbered).

Two content changes:
1. `mcp__moomoomcp__<tool>` is now named as an accepted form, and the text says outright that
   `moomoomcp__<tool>` with no leading `mcp__` is not a tool. The acceptance session had to discover
   the `mcp__` prefix by trial after two denies and a 20 s pause; naming it removes that search.
2. `TOOLSET ABSENT (option-adapter)` — a label that predates this fix (it is in the 2026-11-23
   baseline for researcher and executor) — collided with the sentence I added in pass 1 saying
   "`TOOLSET ABSENT` is a retired label: never emit it", in the *same prompt*. Renamed to
   `SKILL BUILD ABSENT (option-adapter)`, plus a coordinator rule: it means the option-adapter skill is
   not mounted in that child, so sleeve B is off for the cycle, sleeves A/C are unaffected, and the fix
   is the pin — not a fresh session.

Verified through two independent paths, not just the template:
- `GET /forward/templates/{id}` → `system` sha equals the intended bytes;
  re-run [verify-after2.mjs](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-24-toolbox-rca/tools/verify-after2.mjs).
- `GET /forward/identities/{idn}/templates/{id}/effective` → the compiled `agent.system` sha matches the
  template for all four (`b5a8045502cd / d70ac3902331 / cdddef103a27 / 265761b24d97`), `mcp moomoomcp`
  present on the three roles, pins 5/4/4, model `efficient`. That effective read is what a run actually
  compiles, so tomorrow's 09:00 ET BRIEF carries the fix.

## 2. Durable memory repaired (the item the RCA said was self-propagating)

The repair could not run in a hand-created session: an acceptance session on the researcher template
sees `/data/.agent` → `/data/.qoder` with no `awareness/` and `/mnt/memory/default-researcher-qca-console-admin/`
mounted **empty**. Cause established by this work: the memory store is namespaced **per template**
(`default-coordinator-qca-console-admin` = `memstore_00vred2knjpq9k09ei99`), and every schedule run is
coordinator-rooted — including its researcher/auditor/executor child threads — so the single coordinator
namespace is the whole desk's awareness. Repairing it from a coordinator session is therefore complete,
not partial.

Sent one message into the existing REPORT session `sess_00weebk8d3pc06cu0hob` (idle, not archived, no
budget cap) at `2026-11-24T00:07:16Z`; the turn ran ~7 min and cost 7.32 credits (session 1.85 → 9.17,
now idle). **22 Edit calls across 7 awareness files; 21 landed with a visible diff in their
`agent.tool_result`, 1 failed harmlessly** — at `00:12:43` it tried to re-apply the `MEMORY.md` fly-week
line that had already been corrected at `00:10:57`, so its anchor no longer existed. Verified by
`is_error` on the linked tool_result, not by text matching: the correction prose itself contains the word
"failed", which makes a string test report 14 false errors. Captured in
[memory-repair-sess_00weebk8d3pc06cu0hob.json](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-24-toolbox-rca/memory-repair-sess_00weebk8d3pc06cu0hob.json):

| file | edits | what changed |
|---|---|---|
| `toolset-gap-intermittent.md` | 5 | the "can drop MID-session" assertion replaced by the 188/188-vs-8 evidence, the 13-second auditor bracket, and "a fresh session was never the fix"; item 5b's "the outage was role-local" re-labelled as evidence separation, not a registration fault |
| `desk-journal.md` | 4 | "namespace unregistered at runtime" → wrong tool name + retired label, lesson kept (retry the bare name) |
| `fly-week-nov23-25-2026.md` | 4 | "day 1 fly lost to toolset gap / fresh session resolved it" → three cycles emitted composed names; the 14:00 clean run does not prove a session-scoped fix; "fix the registration before Tue" → "the connector needs nothing, the fix is the in-session R1 retry" |
| `MEMORY.md` | 4 | both index lines rewritten so the summary a future run reads first no longer says the gap is intermittent |
| `paper-desk-constraints.md` | 2 | appended "first move is a bare-name retry in the same session", 2026-11-17/18 bodies left as dated observations |
| `feedback_evidence_not_self_sourced.md` | 2 | label retired in the rule text, auditor behaviour unchanged |
| `market-data-feeds.md` | 1 | "toolset resolution is per-session" amended the same way |

Its own read-back: `grep -rn "unregistered|MID-session|TOOLSET ABSENT" /data/.agent/awareness/` returns 7
lines, all inside negations or the correction banner; a wider sweep for `feed gap|outage|namespace dropped|
dropped mid|session-local` returns only corrected sentences. I did not independently read those files —
nothing in this API exposes the memory store — so this rests on the agent's quoted grep. It also declined
to rename the file itself (`toolset-gap-intermittent.md`) because 7 cross-file `[[links]]` resolve through
it; that is still open if the owner wants the filename honest too.

## 3. Regression gate

[tools/toolset-drift.mjs](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/tools/toolset-drift.mjs)
(also `npm run check:toolset`) now reports **whether the ladder actually recovered**, which is the number
that matters after this fix. Per thread with any wrong-name call it prints `class=first-moomoo-call |
after-a-good-call`, `correctBefore`, and `recovered=YES(n)/NO`. Measured on the incident day:

```
threads=56 correct-path mcp_tool_use=188 (native 188 / string-typed 0) wrong-name tool_use=8 compactions=1
wrong-name threads=3 recovered=0 lost=3
THREAD - SCAN-1005/sthr_00wdhdf48gjr4sfsutac wrong=2 class=first-moomoo-call correctBefore=0 recovered=NO
THREAD - SCAN-1005/sthr_00wdi7txaw8ao432gcxm wrong=4 class=after-a-good-call correctBefore=20 recovered=NO
THREAD - SCAN-1005/sthr_00wdkaaiom7lsr49xk9k wrong=2 class=first-moomoo-call correctBefore=0 recovered=NO
```

That is the baseline: 3 threads, 0 recovered. A good day from now on is either no wrong-name thread at
all, or one with `recovered=YES` — the latter is the fault still occurring but costing nothing.

Other changes: `EMITTED-LABEL` narrowed to `TOOLSET ABSENT (moomoomcp)` so the local-skill label can't
trip it (other `TOOLSET ABSENT (` uses now show as soft `OTHER-LABEL`); new hard signal
`REGISTRY-DENIED` (a denied `mcp__moomoomcp__*` is drift, an allowed one is not); self-test sessions
(`metadata.purpose ~ toolbox-rca-acceptance`) are excluded **and the exclusion is printed**, so the
deliberate 23:42 failure cannot fail the gate forever; and exit `2` = `INCONCLUSIVE` when a day shows no
moomoo dispatch at all, because an unmeasured day is not a clean day. Measured exit codes after the
change: 2026-11-23 → 1 (12 hard), 2026-11-22 → 2, 2026-11-24 → 2.

## 4. Recurring run

Windows task `QoderDesk-ToolsetDrift`, daily 05:30 local (= 21:30Z, after the 16:15 ET REPORT, so the
UTC date the script defaults to is the trading day that just closed). It runs
[tools/daily-toolset-check.cmd](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/tools/daily-toolset-check.cmd)
→ appends to `logs/toolset-drift.log`. Test-run at 08:08 local wrote the expected INCONCLUSIVE line.
Note `Logon Mode: Interactive only` — a machine that is off or logged out skips that day, and the skip is
silent except that the log stops growing. Remove with
`schtasks /Delete /TN QoderDesk-ToolsetDrift /F`.

## 5. Platform defect

Drafted at
[docs/incidents/2026-11-24-platform-mcp-definitions-draft.md](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/incidents/2026-11-24-platform-mcp-definitions-draft.md):
reproducer, incident evidence, the two independent shape axes, the corroboration, and five asks (first-request
definitions, post-compaction re-injection, server named in the unknown-tool error, documented name forms,
resolved-tool-list visibility). **Not submitted anywhere** — no destination was named and posting for me
is the owner's call.

## 6. Still open

1. **Nothing structural.** All four templates remain `permission_policy: always_allow` and the auditor's
   read-only claim is still unenforced at the tool layer, so the ladder is a prompt convention. The
   `AUTONOMY_PHASE=bounded` state means no human confirmation step exists on the production path.
2. **Unexercised path.** Genuine definition-absence (R3 → relay / `SOURCE=STALE_CACHE` / `CONNECTOR DOWN`)
   has never been run live. The gate now classifies the class on first occurrence, so it will be observed
   rather than assumed.
3. **`toolset-gap-intermittent.md` filename** still asserts "intermittent"; renaming breaks 7 links.
4. Tomorrow's 09:00 ET BRIEF is the first real run under pass 2; check
   `Get-ScheduledTask QoderDesk-ToolsetDrift` output or `logs/toolset-drift.log` after 21:30Z.
5. Rollback of pass 2 alone: re-POST `patched/<role>.system.txt` (pass-1 bytes). Full rollback:
   `node .scratch/changes/2026-11-24-toolbox-rca/tools/rollback.mjs --apply` (23:19Z pre-fix bytes).
