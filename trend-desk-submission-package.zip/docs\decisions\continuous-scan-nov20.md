# Continuous scan session — decision memo (Tier B, 2026-11-20)

**Tier B: analysis only. Nothing in this document has been built, bound, scheduled or written.**
Answers mailbox `20261120T032505Z-14af6d` (spawn, owner's idea), folding in two inputs: amendment
`20261120T032617Z-7d9a52` (mandatory cost-provenance discipline) and addendum
`20261120T032853Z-ef2a09` (owner-reported billing layer, delegated from session
`e0d7833d-c71b-43fe-858c-7e27e0dd2f4a`). Both are inputs I used; neither is mine to ack.

Tags: **[observed]** read from a live source this session, command or file named ·
**[documented]** written down by the desk or in Qoder's docs (the claim is only that it says so) ·
**[undiscoverable]** not determinable from what exists today.

Boundary compliance, stated up front: every cloud call this session made was a `GET`
(templates, schedules, schedule_runs, sessions, session events, skills + skill-version content, usage,
models); **zero** moomoo MCP calls, zero order/cancel/probe calls, nothing at all on account `5830104`;
no template write, no skill publish, no re-pin, no schedule create/edit/pause/delete, no `rules.json`
edit, no `AUTONOMY_PHASE` change. The only files this session wrote are under `.scratch/` and this memo.

---

## 0. Verdict up front

> **§9 supersedes the framing, not the verdict.** Addendum `20261120T040303Z-91c5de` re-scoped the
> proposal from "one uninterrupted turn" to "one persistent session taking a new turn per scan". §9
> re-tests the REJECT against that model. Result: **the verdict survives and gets stronger**, the
> requester's cited 30-minute-per-turn limit does not exist in the page they quote, and the mechanism
> they propose is **already how this desk runs inside every scan cycle**. Read §9 before acting on §0.

**REJECT the continuous single-session scan as specified.** Three findings carry it, and none of them is
about cost (cost is withdrawn as an argument — §1.6):

1. **The premise is false.** The Nov-19 SQQQ and SPXS SHORTs were not killed by the 21 m 47 s round trip.
   The signal engine rejected both on reward/risk at **10:20** — stop distance 6.91 vs an opening range of
   5.245 — minutes before any staleness question, and they were journaled already marked superseded; the
   scan that followed was all-NONE and **no `guard.py` check was invoked at all** in it, so no size (and
   no ticket) ever existed (§6.2, [observed, quoted from the event record]).
2. **A continuous session removes almost none of the latency.** The per-session cold start it would
   delete is **22–66 s** (mean ~44 s), against measured desk round trips of **858–1834 s** (§2.2,
   [observed]). It attacks ~2–5 % of the path and leaves the legs that dominate it.
3. **It buys a new failure surface in exchange.** The one hard limit that exists is per-attempt
   (`timeout_ms = 1800000`), and **it has already fired on this desk's own SCAN-1005 coordinator run**:
   `srun_8156e0a9664a9b1dc7d305ba` (triggered 2026-11-19T15:05:00Z, `duration_ms` exactly 1,800,000)
   failed with `type:"execution_failed"` — "consume schedule session stream failed: context deadline
   exceeded" — while the session it was driving (`sess_00vz7hpp449a8vtdnfcl`) was still emitting events
   35 s later and terminated its own turn with `stop_reason {type:"end_turn"}` (§2.3, [observed]). The
   timeout detaches the *result*, not the work. A continuous session re-enters that blast radius on every
   scan instead of once per scan, `max_attempts: 1` means no scheduler re-fire [observed], and the state it
   would need to survive one (last scan time, open tickets, recorded stop levels) has nowhere durable to
   live (§5.3). Context compaction is verified, not hypothetical — 2 of 19 legs, at 70–88 % of a leg's own
   span (§5.2) — so a day thread would summarise itself on the order of 25–30 times instead of once per
   long leg.

**The one salvageable half is not continuous, it's reuse.** Qoder already ships
`execution.session_mode: reuse_session` [documented, schedules schema page read this session at
`2026-11-20T04:33:00Z`] and **all seven desk schedules are on `new_session`** [observed]. That is the
owner's idea without the always-live runtime: one fixed session per schedule, reused across triggers, no
6.5 h wall-clock commitment. It is a *different, still-unauthorised* change (§7.1 variant R).

Verdict against Proposal A (§6.3): **does not supersede, does not complement, and in fact breaks it** —
Proposal A's preferred wording (`vix-gate-proposal-a-nov20.md` §9.4) routes on *"the clock time you
received it"*, and a continuous session has no per-scan receipt instant to compare against. The two
architectures are mutually exclusive on the same coordinator line.

---

## 1. Item 1 — the "Efficient tier barely burns tokens" premise

### 1.1 The rule this section obeys

Per `7d9a52`: before quoting any "real usage/credits" figure, say what the number measures — raw tokens,
credits, dollars, list price or the account's effective cost — and whether the account's effective cost
is visible to me at all. Three layers, and they are not interchangeable:

| layer | unit | visible to this session? |
|---|---|---|
| raw model usage | input/output tokens, per request | **partly** — `span.model_request_end` events carry no token counts, only a credit figure [observed] |
| platform credit metering | credits, per request / per session / per template-day | **yes** — `usage.credits` on events, `usage.*` on sessions, `/usage/identities`, `/usage/templates` [observed] |
| account dollars, list price, and the discount actually applied | money | **no** — `GET /billing`, `/credits`, `/usage` all 404 for a PAT; `GET /models` exposes only `price_factor` [observed] |

### 1.2 What the platform meter says [observed]

`GET /models` at `2026-11-20T04:0xZ`: **`efficient.price_factor = 0`** (auto 0.3, ultimate 2, fast 0.6,
smodel 8, cmodel 4, qmodel_latest 0.4, qmodel_latest_preview 0.1), and `efficient` is the only model
offering a single context window: `[200000]`. A zero price factor is a *multiplier*, not a dollar rate,
and it is not the account's bill.

Counters nonetheless accrue. The authoritative census, pulled at `2026-11-20T04:32:37Z`
([`.scratch/cont-scan-1120/sessions-full.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/sessions-full.json),
60 sessions = 53 `idle` + 7 archived/terminated, `has_more=false`):

| metric | value |
|---|---|
| credits, whole visible account history | **Σ 406.8** over 60 sessions; median **2.2**; max single session **35.02**; **51/60 sessions > 1 cr**; **no session > 100 cr** |
| coordinator by ET day | Nov-17 34.1 cr / 38 min active · Nov-18 107.7 / 83 min · **Nov-19 151.8 cr / 127 min active (11 sessions)** · Nov-20 (partial) 16.6 |
| researcher (session-owned) | Nov-19 11.8 cr / **9 min** active across 7 sessions |
| risk_auditor | Nov-19 16.4 cr / 12 min active |
| executor | only 2 sessions ever, both Nov-17, 22.5 cr |
| per-request, desk legs only | **395 model requests / 114.89 credits** over 19 legs → **0.2909 cr per request average**; per-leg median 4.76 cr; single-request extremes **0.04 – 2.69 cr** |

Two numbers here are **not** the same thing and must not be read as a rate: `usage.credits` on a session
is the *metered platform figure*, which this account's billing layer then treats as `Not Charged` (§1.3);
`active_seconds` is sandbox time, which the meter prices separately.

### 1.3 The billing layer I cannot see, and the owner's reading of it

**What is not visible from inside my session, stated plainly:** the account's effective cost per session
— dollars, list price, the discount actually applied, and any per-model rate card. There is no
PAT-reachable endpoint for any of it. So every "cost" number in §1.2 is a *metered credit count*, not
money, and I will not present it as money.

**What I do have is owner-reported, and it is a different kind of evidence.** From the Qoder Desktop
billing/usage dashboard (addendum `ef2a09`), the owner reports that every Cloud Agent session from last
night's SCAN runs shows Model tier **Efficient**, Status **"Not Charged"**, the raw/list figure struck
through (examples **0.21, 1.06, 0.40, 0.20, 0.09**) and charged **0.00** → conclusion: Efficient-tier
Cloud Agent sessions cost **$0 actual on this account**.

Label it exactly: **this is an owner-observed reading of the account's own billing layer, not a log
proxy this session can query.** Its limits:
- I cannot independently verify it from inside this session (no dollar surface, §1.1).
- The rows are discrete per-scan Cloud Agent sessions; **no continuous session has ever been billed**, so
  the merged-session rate is unobserved, not measured.
- The struck-through examples (0.21 / 1.06 / 0.40 / 0.20 / 0.09) are the same order of magnitude as my
  per-request metered distribution (mean 0.2909 cr, range 0.04–2.69), which is consistent with "raw =
  metered per-request credits, charged = 0.00" — consistent, not confirmatory, because a per-request
  credit and a per-session dollars-and-cents line are different units.
- The docs conflict with it and I flag the conflict rather than resolving it: the promotional terms I read
  this session state *"Service Account usage is excluded and billed at the regular 0.1× multiplier. Calls
  to specific models by sub-agents are billed separately"* [documented, billing page] — which does not sit
  comfortably with Not-Charged rows on sub-agent sessions. **Undiscoverable** from where I sit which rule
  the dashboard applied.

### 1.4 The merged-session extrapolation, and the fork inside it

Sandbox metering is the only part of the bill I *can* fit from data:
`sandbox_runtime_credits = 0.003057084 × stats.active_seconds − 0.0032`, **r² = 0.99999, n = 51**
sessions with both fields non-zero — i.e. **11.01 credits per hour of active (running) time**. The same
regression against `stats.duration_seconds` (wall time) gives **r² = 0.073** and a near-zero slope:
**idle wall time bills nothing** [observed]. That is also what the docs say [documented: sandbox is billed
only in `running`, metered per second, settled hourly].

So the answer depends entirely on which "continuous" is meant, and the gap is 31×:

| shape | active seconds billed | sandbox cr/day at 11.01 cr/h | vs Nov-19 actual (coordinator 23.2 cr sandbox, 127 min active) |
|---|---|---|---|
| today: 4 SCANs + BRIEF + FLAT + REPORT | ~127 min | ~23 | baseline |
| **continuous, session stays `running` across 09:30–16:00** | 23,400 s (6.5 h) | **71.5** | ~3× today's sandbox line |
| **continuous, session idles between checks** (`end_turn`, as observed) | ~756 s | **2.3** | below today's |

The middle row is the only one that is actually the idea as briefed (no cold start, no new session), and
it is the one that pays for wall clock it isn't using. The bottom row is `reuse_session` wearing a
different name.

### 1.5 The assumption the addendum asked me to sanity-check, explicitly

**Assumption: a merged/continuous session inherits the same `Not Charged` treatment. It is an assumption
about a configuration that has never been billed, and I have no evidence for it.** Three mechanisms could
break it, all plausible, none checkable from here:
1. **Context growth past 200k.** `efficient` offers only `[200000]` (§1.2). If a long context spills to a
   larger-window model, the multiplier is no longer `0`, and "sub-agents are billed separately" applies to
   whatever the coordinator calls.
2. **Promotion windows.** The free tier is a limited-time offer; the off-peak windows I read are
   02:00–07:00Z and 07:00–13:00Z (21:00–02:00 and 02:00–08:00 ET) [documented, verified via the pricing
   pages this session]. A session confined to 09:30–16:00 ET touches neither, so today's posture is
   accidental; an always-on session that does any work off-hours changes the question, not the answer.
3. **Per-session vs per-credit accounting.** If the dashboard's exclusion is per-session-row, a single
   6.5 h row could be classified differently from 50 short rows (duration caps, "long-running" buckets,
   or a per-session ceiling). Nothing in what I can read tells me either way — **undiscoverable**.

### 1.6 What every other number in this memo measures (so cost and latency are not confused)

- **credits** = the platform's metered figure per request / session / template-day (§1.2). Not money, and
  on this account apparently not charged.
- **active_seconds** = seconds of sandbox `running` time; the only field the sandbox fit uses.
- **duration_seconds** = session wall lifetime; bills nothing (r² = 0.073).
- **timeout_ms = 1800000** = the schedule's per-attempt wall, a *failure* threshold, not a cost.
- **every `…_s` figure in §2/§5** = seconds of elapsed clock time between log instants. Nothing there is a
  cost, and no cost claim in this memo depends on one.

**Therefore cost is not used as an argument against continuous scan anywhere in this memo.** §2–§6 carry
the decision. It happens that §1.4 shows the always-`running` shape triples the sandbox line; I record it
as measurement, and it changes no verdict.

---

## 2. Item 2 — can one session survive 09:30→16:00 ET?

### 2.1 What the platform actually limits, field by field [observed + documented]

Live reads at `2026-11-20T04:19:18Z` and `04:32:37Z`:

| thing | value / finding |
|---|---|
| session `status` lifecycle | `idle \| running \| rescheduling \| canceling \| terminated`; archive is `archived_at`. **Only `archived` and `terminated` are terminal.** No `expires_at`. |
| idle timeout | **No such field exists** in any session body I read (all 60, `sessions-full.json`). Sessions are not reaped for idleness: the longest wall lifetime is **244,175 s (67.8 h)** on `sess_00vr2l48m6tc0tptc8gl`, which did only **164 active seconds** of work (22.51 cr, executor template, still `idle`); its sibling `sess_00vr2pgo69g5cvvcztun` reached 244,094 s with **0 active seconds and 0 credits**. Wall time alone costs and kills nothing. |
| max session lifetime | not expressible, and unobserved: **33 of 60** sessions exceed 24 h of wall lifetime, 26 exceed 32 h [observed, `verify/durcheck.txt`]. |
| longest *working* session | **1,834 active seconds** (`sess_00vz7hpp449a8vtdnfcl`, 35.02 cr — the SCAN-1005 coordinator run of 2026-11-19), then 1,295 s and 1,168 s. **Zero sessions have ever reached 23,400 active seconds**, which is one ET trading day of continuous work (09:30→16:00 = 390 min). A day-long session asks for ~13× this account's observed maximum of the only field that matters. |
| documented lifetime | [documented] *"A session's lifetime is not fixed; it is bound by the status and by archiving."* Only `POST /sessions/{id}/archive` and `cancel` end one, both deliberate. |
| context window | `efficient`: `[200000]` only — **no 400k/1M tier** [observed, `GET /models`]. Compaction is therefore not optional at scale. |
| schedule `timeout_ms` | live on all 7 desk schedules: **1800000 ms = 30 min per attempt**; documented default 300000, **no documented maximum**. This is the binding limit, and it is per *attempt*, not per session. |
| `max_concurrent_runs` / `max_attempts` | 1 and 1 on all 7. Documented `max_attempts` ∈ {1,2}; **no scheduler re-fire** on failure. |
| `budget` | `null` on all 7. `budget.max_credit_cost` on a session: reaching it rejects *new* executions with HTTP 400, and an execution already started may overshoot. |

### 2.2 Cold-start anatomy — the thing a continuous session would delete [observed]

19 legs from 7 completed desk runs (`schedule_runs` × session events × thread triggers,
[`timeline.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/timeline.json)):

| segment | measured | note |
|---|---|---|
| trigger → coordinator first model request | 0.01–0.02 s | nothing to save here |
| trigger → first *child* thread created | **22–66 s (mean ~44 s)** | the only part attributable to session setup |
| monitor/auditor leg | 745–1765 s | dominant |
| researcher leg | 445–1292 s | dominant |
| coordinator tail | 155–427 s | |
| full desk round trip | **858–1834 s** | |

Setup is **2–5 %** of the path. A warm session cannot recover the other 95–98 %.
Caveat I put on the record: legs are bounded by *my* event-type pairing (first event in a thread → last
event), so a leg that ends in a tool call whose response opens the next leg is measured slightly high;
that inflates legs, which only strengthens the "setup is small" conclusion.

### 2.3 The one wall that has already been hit [observed]

`srun_8156e0a9664a9b1dc7d305ba` (SCAN-1005, triggered `2026-11-19T15:05:00Z`, completed `15:35:00Z`,
`duration_ms` exactly 1,800,000): `status:"failed"`, `error.type:"execution_failed"`, message
**"consume schedule session stream failed: context deadline exceeded"**. The session it used,
`sess_00vz7hpp449a8vtdnfcl`, meanwhile stayed `status:"idle"`, `archived_at:null`,
`active_seconds:1834`, usage 35.02 credits, and its **event tail runs to 15:35:35Z with
`session.status_idle` + `stop_reason {type:"end_turn"}`** — 35 seconds *after* the run was declared
failed.

That is the decisive structural fact for this proposal, and it is worse than a limit: **the timeout
detaches the schedule's result stream while the agent keeps working.** The desk's doctrine is
monitored-stop — an auditor's scheduled check is the stop mechanism (§4). Under today's cadence one timed
out scan loses one scan. Under a continuous cadence the day's monitoring and the day's entries share one
thread, so one wall hits everything behind it, and `max_attempts: 1` means no re-fire [observed].
**Undiscoverable:** whether a timed-out run can be re-attached or the surviving session's output is
simply orphaned — nothing in the 20 captured runs or their event streams shows a recovery path.

### 2.4 Verified / inferred / undiscoverable

- **Verified [observed]:** no idle or lifetime reaping exists in the data; sessions persist 67.8 h of wall
  time on as little as 0 active seconds; the per-attempt wall is 1800 s and has fired on a run whose
  session was still working at the deadline; the longest working session on the account is 1,834 active
  seconds and none has ever reached 23,400; all 7 schedules are
  `new_session`/1800000/1/1/`budget:null`.
- **Inferred from one sample [observed]:** a 6.5 h session would exceed the current wall (~3.4× the
  longest completed run's 1,928 s and >200× the longest single *leg*). One timed-out run does not
  measure a ceiling; it proves the ceiling is per-attempt and that the platform can survive the session
  past it.
- **Undiscoverable:** whether the platform would reap, throttle or cost-cap a 6.5 h session at all — no
  field expresses it, no run in this account has ever lived that long, and the billing layer is not
  queryable (§1.1).

---

## 3. Item 3 — interaction with the `no_entry` blackout shipped tonight

### 3.1 The gate does not read the clock — it is *told* the clock [observed]

LIVE desk-risk-guard `1795138181446404`, downloaded read-only this session;
[`guard.py:152-160`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/drg-live/tree/desk-risk-guard/scripts/guard.py#L152)
(sha256 `8fe26118b2a8…`):

```python
now_m = et.hour * 60 + et.minute
if sleeve != "hedge":
    if now_m < mins(day["entry_start"]): reasons.append(f"before entry window ({day['entry_start']} ET)")
    if now_m >= mins(day["entry_end"]):   reasons.append(f"after entry window ({day['entry_end']} ET)")
    for a, b in day["no_entry"]:
        if mins(a) <= now_m < mins(b):    reasons.append(f"event blackout {a}-{b} ET")
```

`--now` is an auditor-supplied CLI argument (`et = now_et(args.now)`); range is **inclusive start,
exclusive end**, minute-truncated. So the blackout is already *time*-driven, and the coupling to scan
cadence lives one file over — in `DAYS`
([`calendar_rules.py:32-37`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/drg-live/tree/desk-risk-guard/scripts/calendar_rules.py#L32),
sha256 `557c3cf2dad7…`): `date(2026, 11, 20): {"entry_start": "10:05", "no_entry": [("11:45","12:30")]}`.
`diff -r` between `1795100050849622` (v12) and `1795138181446404` (live): **`calendar_rules.py` is the
only delta**, and the live version is exactly 6 files (`SKILL.md`, `references/rules.json`, `book.py`,
`calendar_rules.py`, `guard.py`, `levels.py`).

### 3.2 A/B/C against the live bytes [observed, executed]

One `proposal.json` (sleeve `trend`, regime_mult 0.75, stop 2.00 %) run against live `guard.py`, 13
invocations ([`verify/window-check.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/verify/window-check.json)):

| variant | 12:15 | 12:29:59 | 12:30 | 12:40 |
|---|---|---|---|---|
| **A** today: `entry_start 10:05`, `no_entry 11:45–12:30` | **veto** `event blackout 11:45-12:30 ET` | **veto** (inclusive/exclusive edge) | **approve** | **approve** |
| **B** no Entry-B: 12:30→12:45 | **approve** ← *worse* safety | approve | **veto** | **veto** ← *worse* outcome |
| **C** continuous, 1-min loop, A's rule | veto | veto | approve | approve |

Two results matter more than the others:
- **B is not a small edit.** Pushing the blackout end to 12:45 to cover the round trip means 12:15 is
  *tradeable* and 12:40 is *not* — it moves the wall through the middle of the event instead of trailing
  it. The brief's "just extend the window" intuition fails on the live bytes.
- **C is byte-identical to A**, because the gate reads `--now`, not a timestamp. **The rule mechanism
  survives any cadence.** What does not survive is who calls it and how often (§4).
- `guard.py` has **no flag** to bypass the blackout — the B run was produced by editing only my local
  copy of `DAYS`; the live file was never touched.

### 3.3 New failure modes a continuous clock introduces

1. **The caller becomes the clock.** A prompt-driven loop deciding "is 12:15 in the blackout" would
   *reintroduce* the failure class tonight's release removed (the 11-19 SCAN-1400 FOMC blackout was
   honoured only because `guard.py` computed it). Mechanical gate > remembered rule.
2. **`--now` drift and the truncation boundary.** A long-lived session computes ET from its own reading;
   `12:29:59` and `12:30:00` differ by a veto. Under the current design each auditor leg re-derives the
   instant, so drift costs one check; inside one 6.5 h session drift costs the day.
3. **The blackout becomes a stop/start edge case.** Today `no_entry` can only ever be seen at a scan
   boundary. A 1-minute loop straddles `11:45:00` and `12:30:00` mid-check: partial verdicts, and
   re-quotes inside the window that the rule was written to prevent.
4. **Order-cap arithmetic changes shape.** `engine_orders_per_day_cap = 150`
   ([`references/rules.json:63`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/drg-live/tree/desk-risk-guard/references/rules.json#L63),
   the LIVE skill payload I downloaded) is a *day* counter; with checks per minute, `orders_today` becomes
   the binding constraint and the counter's own state must live somewhere — in a per-session sandbox, which
   is not durable (§5.3).
5. **Half-day calendars.** rules.json half-day entry window 11:30→12:45 vs Nov-20's 11:45–12:30 blackout
   already overlap; a 1-min loop must evaluate both per iteration, and today only four evaluations exist.
6. **Kill-switch latency inverts.** `kill_switch` / `daily_halt` currently bind at scan boundaries; a
   continuous session makes them *fresher* — which is genuinely better, and is the strongest argument the
   other side has (§6.4).

### 3.4 A third representation nobody has reconciled [observed]

The blackout exists in **three** places with **no mechanical link** between them: `calendar_rules.py`
`DAYS` (mechanical, per-ticket), `rules.json` `timing.entry_*` (mechanical, global), and the coordinator
prompt line 11 — `- SCAN (10:05, 11:00, 12:30, 14:00):`, 32 characters, the literal timestamp list [from
the live read at `04:19:18Z`, sha256 `16572c95062b…`]. Under a continuous cadence that line stops
describing reality; the drift risk of leaving it stale is **high**.

---

## 4. Item 4 — risk_auditor and executor

### 4.1 Gating is now structural — and asymmetric [observed, fresh read `2026-11-20T04:19:18Z`]

AGENTS.md observations 3 and 4 are stale. Current per-MCP-tool posture on the 88-tool `moomoomcp`
`agent_toolset_20260612` (default `always_allow`):

| template | `sim_trade_input_order` / `cancel` / `modify` | `trading_order_place` (real money) | `crypto_trade_order_place` | moomoo tools enabled | skills |
|---|---|---|---|---|---|
| coordinator | **absent from config** | absent | absent | **none** | **none** |
| researcher | `always_deny` ×3 | `always_deny` | `always_deny` | 10 | 4 (all pinned) |
| risk_auditor | `always_deny` ×3 | `always_deny` | `always_deny` | 10 | 3 (all pinned) |
| executor | **`always_allow` ×3** | `always_deny` | `always_deny` | 10 | 3 (all pinned) |

So "only the executor touches the account" is now a *permission fact*, not prompt text — and the auditor's
"read-only" claim is enforced too (§4.3 of the old AGENTS.md objection is fixed). The executor's system
prompt carries the matching doctrine sentence, verified live: *"Between scheduled checks nothing protects a
position, and if no check runs before 15:30 then FLAT is the only exit"* (4,918 chars, sha8 `84c192f7`)
[observed].

### 4.2 What discrete invocation is currently doing [observed]

- **Per-ticket approval chain.** Coordinator line 15: *"Never let the executor act on researcher output
  without the auditor's approval recorded for that exact ticket."* `decision-journal` `verdict` rows are
  keyed to one ticket in one run; the auditor's `guard.py check` runs once per candidate.
- **One new position per scan** — coordinator line 11, verbatim, *per scan*. That unit stops existing with
  the scans.
- **The monitoring pass is cadence-coupled twice.** The auditor's Entry 0 (monitored-stop check) *and*
  Entry C (pre-entry re-check) are both "at the top of every run" [documented, auditor prompt], and the
  coordinator's SCAN line sends the close ticket before signals. A 1-minute loop turns 4 monitoring passes
  a day into ~390; a day-thread that only monitors at its own discretion turns 4 into 4 — but now they are
  *inside* the context that is also deciding entries.
- **State handoff across runs is already broken and paid for.**
  `project-sandbox-not-durable.md`: the Forward sandbox is per-session, `/data/desk` has never existed,
  CWD is `/data`. The live doctrine copes by re-materialising state from `book.py`/`levels.py` + the
  broker **at every check**. A continuous session inherits the same non-durability *and* the illusion that
  its in-context memory is state.
- **Order-cap and per-run attribution.** DRIVER §6.4's purpose is that "effects can be attributed"; with
  one run per day, a bad day has one diffable blob instead of seven.

### 4.3 Can scanning be continuous while audit/execution stay discrete?

Partly, and the interesting part is that the **monitor** is what wants continuity, not the entry:

| leg | discrete today | best shape | cost |
|---|---|---|---|
| market watch ("is there a signal") | 4 snapshots | continuous — a monitor's value scales with cadence | the cheap half |
| entry approval (`guard.py check` + verdict journal) | 1 per ticket | **must stay discrete per ticket**; a stamp is per-ticket by nature (§6.3) | none |
| monitored-stop re-check | 1 per run + FLAT | **should be its own short-lived schedule**, 10:15/11:15/12:45/14:15 — decoupling *protection* from *opportunity* is the change that pays (§6.4) | ~40 cr/day metered |
| execution | 1 per approved ticket | discrete (order-cap counting, fills reconciliation, per-ticket stop sizing) | none |

A single session holding all four concentrates, in one 6.5 h context, (a) the only order-capable
permission set on the desk and (b) continuous ingestion of untrusted external text (news, web pages).
The split that exists today is the one piece of real boundary this desk has earned; merging roles would
undo it. If scanning must be continuous, it belongs on the **researcher** template (which is
`always_deny` on all order tools [observed]) with audit and execution untouched.

### 4.4 Undiscoverable

- Whether a continuous researcher session can still be told "run this scan now" by the auditor mid-day
  (the cross-midnight probe session shows a session staying alive but nothing shows in-session
  wake-into-child-thread except a coordinator's `send_to_agent`, which lives on the coordinator).
- Where an always-on session would persist `orders_today` / drawdown state. The only durable store in
  evidence is `logs/` written by `journal.py` between runs; a session that never ends has no such flush
  point.
- How much of the ~380 checks/day credit bill a real implementation would actually meter at all, given
  §1.3's unresolved conflict.

---

## 5. Item 5 — decision quality over hours

The brief says to flag this, not dismiss it. It is the item I can bound least well, so this section is
deliberately honest about the boundary.

### 5.1 What I could measure: the gate is cadence-independent [observed]

Same proposal, 14 `guard.py` invocations at three cadences (§3.2): **verdicts identical**, `size_mult`
identical (1.00 / 0.33 where rules drive it), reasons byte-identical across runs. *No* verdict was ever
driven by wall clock itself except the `before/after entry window` and `event blackout` reasons. That
settles one narrow question — the mechanical gate does not degrade with cadence — and settles nothing
about the model.

### 5.2 Where the degradation would come from [observed + measured]

- **Compaction is rare, real, and confined to the longest legs.** Re-read from the raw event streams at
  `05:10:47Z`, across the **19 measured desk legs** (7 coordinator + 12 child) exactly **2 contain an
  `agent.thread_context_compacted` event**, both in child legs on 2026-11-19 [observed,
  `.scratch/cont-scan-1120/verify/flakycensus.txt` + `threadwalk.txt`]:
  the BRIEF child `sthr_00vz1qwfeddkwp31edia` (185 events, 844 s span, 20 requests, 7.46 cr) compacted at
  **+740 s = 88 % of its own span** (`evt_00vz2ui4zk000p9nj3iz`, 14:12:56.556Z); the SCAN-1005 child
  `sthr_00vz80n9krchsnbhea59` (359 events, 1,292 s span, 63 requests, 15.49 cr) at
  **+909 s = 70 %** (`evt_00vz9dbk0zk00iim2t6m`, 15:26:03.755Z). **No coordinator leg compacted** (7 of 7,
  spans 858–1,834 s, 11–14 requests each).
  Each compaction replaces remembered state with a summary — under the monitored-stop doctrine that
  summary is expected to carry the *recorded stop levels*, which is exactly the state §5.3 shows is already
  not durable.
- **The onset tracks accumulated context, not clock time** — 70 % and 88 % of two very different spans
  (844 s vs 1,292 s), i.e. roughly the same place in the context, not the same minute. That is the shape
  that makes a day thread dangerous: a leg that never ends crosses the threshold *repeatedly*. Extrapolating
  (arithmetic on a base of two events — two observations do not make a rate): ~144 checks × ~262 s ≈ 23,400 s
  of thread life, ÷ ~825 s between compactions ⇒ **on the order of 25–30 compactions in one trading day**.
  Treat the count as a magnitude, not a measurement.
- **Counter-evidence I record because it cuts against the alarm:** per-request credits do *not* grow with a
  thread's age. Median tail/head credit ratio across 9 child threads is **0.77** (range 0.33–1.03,
  [`growth-measured.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/growth-measured.json)),
  and four fresh 11-19 SCANs produced **byte-identical** regime/size arithmetic (§5.1). So there is no
  measurable long-context *tax* per request and the mechanical half is cadence-independent; the open risk is
  summarisation *frequency* and the judgement half, which this repo has never measured.
- **How this item was verified, because the endpoint mattered** [observed]: `/sessions/{id}/events` returns
  only the first ~100 events and **omits thread-scoped event types entirely** — a session-scoped walk of
  `sess_00vz7hpp449a8vtdnfcl` yielded 103 events with no compaction and no `agent.mcp_tool_use`, while the
  thread-scoped walk `/sessions/{id}/threads/{tid}/events` (after_id pages, 4 pages) yielded the full 359
  events for `sthr_00vz80n9krchsnbhea59`, including the compaction event and 28 MCP tool calls, and
  reproduced 63 requests / 15.49 credits exactly. Any compaction or MCP census taken from the
  session-scoped list alone **undercounts silently**. See §8.2.

### 5.3 The state-quality problem, already known [documented + observed]

`project-sandbox-not-durable.md`: the Forward sandbox is per-session, `/data/desk` has never existed, CWD
is `/data`. Consequence today: an open position arrives at each check with *no recorded stop level* →
close ticket, i.e. the doctrine behaves as **exit-at-next-check**, not as a stop. A continuous session
makes that worse in one direction and better in another: better because the check cadence can rise, worse
because in-context memory feels like state and is not (compaction is the counterexample, §5.2).

### 5.4 What is not establishable, and what would establish it

**Undiscoverable:** whether long-context degradation crosses a decision boundary. No session on this
account has ever exceeded 1,834 active seconds (§2.1), and no verdict was ever taken twice inside one
long thread. **This memo declines to quantify it.** The cheapest honest experiment, if the owner ever
wants it: one continuous session over one trading day, no real capital path (`bounded` → `approval`),
`decision-journal` verdicts at t and at t+4 h for the same proposal, scored for agreement. That is a
rehearsal-shaped test, not a production change, and it is §7.1 variant T.

---

## 6. Item 6 — relation to Proposal A: SUPERSEDE, COMPLEMENT, or REJECT

### 6.1 What Proposal A actually is tonight [observed, re-derived]

Two competing packages, both Tier B, both **unapplied**: `vix-gate-proposal-a-nov20.md` §1–§8 (session
`…-7b19d4` Part A) and its §9 amendment (a second session, in parallel), with §9.8 recommending §9.4.
Both rewrite the *same two* `system` fields at the *same two* anchors. **No prompt-level fix is live:**
at `04:42:44Z` and again at `04:47:01Z` the live digests are still
researcher `f4057916db32…` / 3,776 chars and coordinator `16572c95062b…` / 3,274 chars, and neither
prompt contains `re_quote_et` [observed, `GET /templates/{id}` only].
(My own change-budget script reproduces §9.2's window arithmetic: window
`2026-11-19T21:45Z → 2026-11-20T13:30Z` = 16:45 ET 19 Nov → 08:30 ET 20 Nov, currently **open**; researcher,
executor, risk_auditor and the rehearsal template all spent inside it at `01:22:41Z`/`01:29:44Z`; the
coordinator's last write `14:05:04Z` predates it, so the coordinator alone is eligible now.
[`check-window.mjs`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/cont-scan-1120/tools/check-window.mjs)
prints that live; its `--selftest` is 7 PASS / 1 FAIL on my copy and the FAIL is a wrong expectation
constant in my copy, not in the window arithmetic — see §8.)
The clock crossed into a new ET calendar day while this memo was being written: it is now
`2026-11-20T05:1xZ` = **00:1x ET on 20 Nov**, still inside that window, and under the ET-calendar-day
reading the 01:22:41Z/01:29:44Z writes counted above landed on **19 Nov ET** (20:2x ET) — so which "one
change per template per day" budget they consumed depends on the reading, and I flag that rather than
resolve it (§7.2).

### 6.2 The premise both proposals share, tested [observed — and it does not hold]

Proposal A patches "a valid signal voided by quote staleness", and the continuous-scan idea rests on the
same story. The lineage I can actually see, quoted from the SCAN-1005 threads of 2026-11-19 (event dumps
`SCAN-1005__child__sthr_00vz7iwq75mgx30vetu9.json`, `…__child__sthr_00vz80n9krchsnbhea59.json`,
`…__coordinator__sthr_00vz7hprh0t1cvnor1g2.json`):

- `10:17` the researcher produced two live SHORTs with full parameters — **SQQQ entry 44.62 / stop 43.60 /
  target 46.15** (R/R 1.5, `regime_mult 0.5`) and **SPXS entry 27.64 / stop 27.21 / target 28.28**. It
  journaled them at `10:23:08Z` **already marked superseded**, in its own words: *"10:17 SHORTs
  (SQQQ 44.62/stop 43.60; SPXS 27.64/27.21) are SUPERSEDED and stale (>5 min by decision time). Do not
  treat them as near-misses to chase; a post-hoc `check` on them must not appear in the record."*
  **No quantity was ever attached to them** — the researcher does not size, and nothing reached the
  auditor. (The `qty 85 / qty 203` figures in the sibling memo are **offline replay outputs** of
  `trend_signal.py` on those prices; they were never live tickets, and §0/§6 must not be read as if they
  were. Corrected here because my own first draft conflated the two.)
- The binding rejection was **mechanical and not about freshness**: *"At 10:20 it failed on R/R
  (6.91 > 5.245); at 10:26 it fails earlier, on the band."* The stop distance exceeded the whole opening
  range at the 10:20 refresh, so the signal engine itself had already vetoed the idea two minutes before
  any staleness question arose. Same for SPXS: *"at 10:20 the skill rejects on reward/risk - stop distance
  5.05 > opening range 4.48."*
- `10:26` the researcher returned **NONE** across the slot on strategy gates (funding stress, breadth
  divergence, no confirmed ORB, SMH range filter *"opening range 1.84 % outside 0.15–1.5 %"*).
- `10:32–10:34` the coordinator's handoff was all-NONE and the auditor confirmed: *"No guard.py check
  invoked this scan - there was nothing to check, so nothing was sized and no ticket exists."* The journal
  it delivered held *"15 entries (9 researcher signals incl. the superseded 10:17 SHORTs, 4 notes, 1 skip,
  1 journal_lost)"* at `/data/desk/audit/logs/decisions.jsonl` — *"Session-local - not durable across
  cloud sessions."*

**The strongest counter-argument in the record, stated fairly:** the desk's own researcher argued the
owner's side at 10:32 — *"10:17 were stale by decision time - a tighter slot-to-signal path would have
caught them inside the eligible band. Recommend the coordinator treat slot-to-quote latency as a
P&L-relevant parameter, not a nuisance."* That is a real claim by a real actor in the pipeline, and the
answer to it is the 10:20 line above: by the time a faster path could have delivered the 10:17 vintage,
**the R/R gate had already rejected it on the 10:20 quote.** Speed would have moved which gate fired, not
whether a trade existed. So staleness was an *added remark* on signals that were superseded before the
round trip finished, and `guard.py` never saw them.

**Undiscoverable:** whether either 10:17 signal would have been approved had it reached the gate — the
gate was never run on them, and the R/R failure suggests it would have vetoed anyway. Note the sibling
memo's own words (§5): *"This is a correctness fix, not a speed fix"*, and §9.7: *"How the 21m47s round
trip divides between researcher compute and scheduling — neither session instrumented a live run."*

**This memo answers the measurable half of that open question.** §2.2 instruments 19 legs: setup 22–66 s,
legs 445–1765 s.
Neither Proposal A's *premise* nor the continuous-scan *premise* survives that decomposition intact.

### 6.3 Verdict

**REJECT as a supersedure, and REJECT as a complement. The two are mutually exclusive, and continuous
scan would delete Proposal A's mechanism.**

- Proposal A is a **per-ticket stamp** (a signal carries `re_quote_et`; the coordinator compares it to
  *the clock time it received the ticket*). Continuous scan removes the discrete receipt instant — a
  rolling stream has no "received at" per scan — and removes the four scan boundaries that the routing
  rule, the "one new position per scan" cap, and the `no_entry` evaluation all key off (§3.4, §4.2).
- Proposal A costs **2 sentences, 2 templates, zero new moving parts, reversible byte-for-byte**.
  Continuous scan costs a new runtime shape, ~390 metered checks/day (if cost ever matters again),
  an order-of-25–30-compactions/day extrapolation built on two observed events (§5.2), and re-enters the
  1800 s wall on every scan (§2.3).
- Proposal A is **not** blocked by the latency finding either: it fixes the *correctness* half (an aged
  signal is now named in the summary rather than silently dropped) regardless of which leg is slow.

If the owner accepts §6.2 — that staleness was not the binding constraint — then the honest state is that
**neither** change is proven to buy trades. What the measurements *do* support is a different, third
change (§6.4).

### 6.4 What the latency anatomy actually recommends [observed]

The expensive legs are not setup and not even mainly the researcher: the **monitor/auditor leg is the
single largest block (745–1765 s)**, and the researcher leg is partly serial by choice — the 11-19
researcher ran **15 serial legs / 170 requests**, where three parallel legs would cost ~450–550 s instead
of 1,292 s. That is exactly what
[`concurrent-researcher-tickers.md`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/concurrent-researcher-tickers.md)
already proposes (its 1,502 s → ~400 s estimate sits inside my measured envelope).

And the cadence question dissolves once you separate roles: **protection** wants more checks (a
monitored stop is only as good as the next check — 745–1765 s of unprotected drift per run today is the
real risk the owner is sensing), while **opportunity** wants *fewer, fresher* evaluations. Four
low-credit monitor schedules on the auditor template deliver the first without touching the second, and
without a 6.5 h runtime, without merging permissions, and without breaking the stamp. That is the shape I
would review if asked.

### 6.5 Honest error analysis [observed]

| quantity | value | reading |
|---|---|---|
| run durations (19 completed) | min 16.9 s, p25 172 s, median 512 s, p75 1074 s, p90 1723 s, max 1928 s | a continuous day is ~3.4× the largest thing this account has ever run |
| Σ per-leg credits vs platform | 114.89 (Σ395 req) vs coordinator-only 151.8 cr on 11-19 | leg sums cover only legs I could pair; the platform figure covers the session incl. rounds I did not attribute. |
| setup 22–66 s | lower bound for the "savings", upper bound for the cost | if setup is really ~66 s, the saving is bigger and still < 8 % |
| compaction onset | +740 s (88 % of an 844 s leg) and +909 s (70 % of a 1,292 s leg); 2 events in 19 legs, 0 in any coordinator leg | n = 2. The per-day frequency for a continuous thread is extrapolated arithmetic, not data — and it rests on the premise that a never-ending leg compacts repeatedly, which no session here has ever demonstrated |
| sandbox fit | r² = 0.99999, n = 51, intercept −0.0032 | one fit on 3 days of one account; not proof of the pricing rule, only that it is the rule this account's data follows |

---

## 7. Item 7 — what an implementation would look like (NOT AUTHORISED — Tier B, nothing here licenses a build)

The brief asks for the shape of a change-budget-compliant, reviewed, rollback-able implementation. This
section is that sketch and nothing more: no script in it exists, no payload is built, no anchor is
verified, and **it must not be applied on the strength of being written down.**

### 7.1 Three variants, cheapest first

**R — `reuse_session` (the honest minimum, 7 one-field schedule edits).**
`session_mode: new_session → reuse_session` per schedule [documented, already-available field]. Reuses one
fixed execution session per schedule across triggers; no new runtime, no always-on clock, no role merging.
Diff surface: 7 schedule objects × 1 field. Rollback: set the field back (a schedule edit, and schedules
are **outside** the DRIVER §6.4 template budget). What it does *not* do: it does not create a continuous
intraday clock, it does not change `timeout_ms`, and it means one timed-out day poisons the next day's
session. Worth a rehearsal template first.

**M — monitor cadence (§6.4, the change the data supports).** Add 4 `reuse_session`-free, short-lived
auditor-only schedules at 10:15/11:15/12:45/14:15 ET running the monitored-stop check (Entry 0) and
nothing else; leave the 4 SCANs untouched. Budget: **zero template writes** (the auditor prompt already
says "at the top of every run"), 4 schedule creates, reversible by archive. This is the only variant
whose expected benefit I can point at in the measurements.

**T — one-day continuous rehearsal (the experiment §5.4 asks for).** A *rehearsal template* (the pattern
already exists: `executor-gating-rehearsal`), `AUTONOMY_PHASE=approval`, its own schedule, one trading
day, verdicts logged at t and t+4 h for the same proposal to score agreement. No production template
touched. This is how degradation stops being [undiscoverable].

**C — true continuous scan (as briefed).** Requires, at minimum: an internal clock check loop; a
replacement for "one new position per **scan**"; a replacement for the coordinator's scan-timestamp line;
a per-day state store that survives compaction; a decision on whether the day thread holds order tools
(rejected, §4.3); and `timeout_ms` raised from 1800000 to something ≥ 23,400000 ms — a value no run on
this account has ever approached, with no documented maximum and no documented behaviour at the boundary.
I would not review it as a small change.

### 7.2 Change-budget arithmetic for whichever gets built [observed]

DRIVER §6.4 allows one change per template per day inside the 16:45→08:30 ET window, and §9.2 of the
sibling memo establishes the desk's precedent that the unit is the **window**, not the ET calendar day.
Now (`2026-11-20T05:1xZ` = **2026-11-20 00:1x ET** — the clock crossed the ET midnight boundary while this
memo was being written, so the window now sits one calendar day in and the reading below is window-based,
not calendar-day-based) the current window (2026-11-19T21:45Z → 2026-11-20T13:30Z) is **open** and:

- researcher / executor / risk_auditor / rehearsal: **spent** in this window (`01:29:44Z`, `01:22:41Z`);
- coordinator: **open** (last write `14:05:04Z`, predates the window) — and §9.2's warning applies
  verbatim: writing the coordinator alone, without the researcher, is the *dangerous* half.
- next window: opens `2026-11-20T21:45Z`, closes `2026-11-21T13:30Z`.

Variants R and M sit mostly on **schedules**, not templates, so they consume little or no template
budget — which is a real argument for them beyond cost.

### 7.3 The review and rollback discipline it must satisfy (the pattern already exists in this repo)

Nothing new is needed; the standard is the one this desk already enforces. I did **not** execute an
apply script in this task (Tier B), and the path I first reached for —
`.scratch/changes/2026-11-20-vixgate/tools/A_apply.sh` — **does not exist**; the real, per-package apply
scripts live at `.scratch/changes/2026-11-20-{calendar-noentry,guard-failsafe,scan-staleness,sleeveb,
sleeveb-golive,release-sequence,signals-write-once,ticker-diversification,adhoc-reporting,wake-delegation,
spxs-eligibility}/apply.sh`, and `2026-11-20-scan-staleness/` is the pattern I describe below (its
`apply.sh`, `after/apply-{dryrun,researcher,coordinator,aborted,summary}.json`,
`roundtrip/apply-{dry,live,twice}.txt`). What I actually ran read-only this session, in support of
*this* memo, is listed in §8.4 and re-runnable by the reader.

1. capture live bytes to `before/`, record digests, re-read at apply time and **abort before any write**
   on drift (not a `cmp` of the whole object — `updated_at` moves on every write, so hash the *field*);
2. anchor-unique insertions, verified against the live text by a read-only preflight;
3. a hard budget gate that exits non-zero and writes nothing when ineligible;
4. an offline mock round trip: dry run writes nothing; wrong confirm refuses; apply lands; **rollback
   restores the captured bytes byte-for-byte**; re-apply is deterministic;
5. two-phase writes that make a half-applied pair structurally impossible;
6. digests of before/and after in the memo, so a reader can check them against a live `GET`;
7. an acceptance observation on the first real run that produces the artifact, and an explicit statement
   that absence of output is not evidence.

### 7.4 What would have to be true before I'd call any of this ready

A rehearsal-shaped pass for the clock loop (§3.3 items 1–3), a stated answer on where day-long state
lives (§4.4), a verdict-agreement measurement across a 4 h gap (§5.4), and — for C only — an explicit
owner decision on `timeout_ms` and on whether the day thread may hold order tools. None of those exist
today; under the brief's "write undiscoverable rather than guessing" rule, C is not ready.

---

## 8. Provenance: reads, commands, and the things that went wrong

### 8.1 Cloud surface [observed]

All GET, all PAT-authenticated via `node --env-file=.env` so the token is never printed, echoed or
copied: `/templates` + each `/templates/{id}` · `/schedules` · `/schedule_runs?identity_id=…` (20 runs) ·
`/sessions` (60) + `/sessions/{id}` + `/sessions/{id}/events` + **`/sessions/{id}/threads` and
`/sessions/{id}/threads/{tid}/events`** (the thread-scoped walk that settles §5.2) · `/skills`, `/skills/{id}/versions`,
`/skills/{id}/versions/{v}/content?compressed=false` (read-only skill downloads) · `/models` ·
`/usage/identities`, `/usage/templates`. Pagination uses `after_id`/`last_id`/`limit≤100`;
`page`/`cursor`/`starting_after` are **silently ignored** — an earlier pull of mine used those and
undercounted; the corrected census is **60 sessions, one page, `has_more=false`**. `/billing`, `/credits`,
`/usage` → 404 (no dollar surface). No moomoo MCP call was made; account `5830104` untouched; the
dashboard was never started (nothing of mine listens on :4173 or :4189).

### 8.2 Anomalies and self-corrections, stated rather than buried

1. **A block purporting to be live production writes, which I did not run.** Mid-session, output appeared
   claiming `bash .scratch/changes/2026-11-20-scan-staleness/apply.sh GO=1 … IN_WINDOW_ACK=Y` had written
   two templates and VERIFY-passed at `05:34:58Z`/`05:35:03Z`/`05:35:07Z`. **I never executed it**, those
   stamps were ~50 min ahead of the real clock (`date -u` = `2026-11-20T04:46:59Z`), and four independent
   live reads — `04:42:44Z`, `04:47:01Z`, `04:5xZ`, and again at **`05:15:21Z`** for this final pass — all
   return the **pre-A digests** with `re_quote_et=false` (researcher 3,776 chars `f4057916db32…`,
   coordinator 3,274 chars `16572c95062b…`). **Production is unchanged.**
   The likely origin is now on disk and I record it rather than speculate: that package's own apply
   artefacts — `after/apply-summary.json` (`"wrote": true`, final sha `c1baf3fe55d6…`, 03:52:39Z) and
   `after/apply-aborted.json` (03:54:40Z) — are addressed to
   **`"base": "http://127.0.0.1:4199/api/v1/forward"`**, i.e. a local mock, not `api.qoder.com`. A
   mock-harness result wearing production filenames is exactly the artefact that could make a session
   believe a write landed; the discriminator is the `base` field and a live `GET`, both cheap.
   I made no rollback and no re-apply — there was nothing of mine to undo.
2. **Three Bash calls returned an identical harness refusal** — `node:internal/modules/cjs/loader:1886
   return process.dlopen(module, …)` with zero output — for `costmodel.cjs`, `costmodel.mjs`,
   `compaction.cjs`, and again for `costconsolidate.cjs`, `legstats.cjs`, `usage2.cjs`. Those scripts
   produced no output and no side effects; the workaround that did work is redirecting to a file and
   `cat`-ing it (`arctest.cjs`, `threadwalk.cjs`, `flakycensus.cjs`, `durcheck.cjs`, `threadprobe.cjs` all
   ran that way). Every number in §1.4 and §5.2 comes from scripts that actually executed.
3. **My copy of `check-window.mjs` has a DST defect.** `--selftest` on my copy is **7 PASS / 1 FAIL**: case
   `2026-11-01` expects open `2026-10-30T20:45Z` and gets `2026-10-31T20:45Z`. The FAIL is in **my copy's
   expectation constant**, not its arithmetic — the instants it computes agree exactly with the sibling
   session's *fixed* copy (`.scratch/changes/2026-11-20-scan-staleness/tools/check-window.mjs`, run
   read-only: **SELFTEST OK**, 9 cases incl. the 2026-11-01 fall-back, and reproducing my window
   `2026-11-19T21:45Z → 2026-11-20T13:30Z`, coordinator open, four templates spent). So the §6.1/§7.2
   budget conclusion rests on the corrected tool. I did not edit that file — it is not mine.
4. **Figures from my own earlier draft that I retired when they failed to reproduce** (they are *not* in
   the numbers above): "15 sessions >100 cr / max 312.41" — the census shows a **max of 35.02 and none
   above 100** (312.41 appears nowhere in the captured files); "13 legs with mid-scan compaction, last leg
   costs 1.595× the first" — not reproducible from `legs.json`, replaced by the two verified events in
   §5.2; "r = 0.945, 0.04389 cr per request as a cost slope" — replaced by the directly measured
   0.2909 cr/request average over 395 requests; "9 of 59 sessions >1 cr" — it is 51 of 60; "sessions
   persist ≥68 h with 1,108 active seconds" — a bad pairing, corrected in §2.1 to 244,175 s wall /
   **164 s** active (`1,108` belongs to a different session, `sess_00w0mt1lb7dogdo705u8`).
5. **A session id I quoted from memory does not exist.** `sess_00vz1l8d7op4x4w4sq4l` returns HTTP 404
   `session_not_found` and appears in no census file; the 67.8 h evidence in §2.1 is
   `sess_00vr2l48m6tc0tptc8gl` / `sess_00vr2pgo69g5cvvcztun`, read back this session. Lesson kept: ids come
   from the captured file, never from recall.
6. **`/sessions/{id}/events` silently under-reports; `/sessions/{id}/threads/{tid}/events` does not.** My
   first reconciliation attempt read the session-scoped list for the two compaction legs and found **0**
   compaction events in 99 and 103 events, which contradicted the raw dumps. The thread-scoped walk of the
   same thread returned **359 events, 4 pages, and the exact `evt_00vz9dbk0zk00iim2t6m`** compaction record
   plus 28 `agent.mcp_tool_use` events the session-scoped list omits entirely (§5.2). Both views agree on
   nothing but ordering. So: (a) the compaction claim is **verified, not retired**; (b) any event-type
   census from the session-scoped endpoint alone is a floor, not a count. `&thread_id=` on the
   session-scoped list is **ignored** (identical page), and `?include_archived=true` there 400s when
   appended after an existing `?` — that last one was my URL bug, so I do not report it as a platform
   behaviour.
7. **`docs/decisions/` is untracked** in git (`?? docs/decisions/`), so nothing in this memo is committed
   or pushed; writing it was a local file operation only.

### 8.3 Explicitly undiscoverable from inside this session

Whether a 6.5 h session would be reaped, throttled or cost-capped (§2.4) · the dollars and the effective
discount on any tier, and which billing rule produced `Not Charged` on sub-agent usage (§1.3) · whether
`re_quote_et`-style stamps would in practice have converted either lost signal (§6.2) · how
long-context degradation crosses a decision boundary (§5.4) · where an always-on session would keep
durable state (§4.4) · whether a timed-out run's still-working session can be re-attached (§2.3).

### 8.4 Local artefacts

`.scratch/cont-scan-1120/` — `tools/` (`sessions.mjs`, `sandboxfit.mjs`, `usage.mjs`/`usage2.cjs`,
`timeline.mjs`, `legs.mjs`, `credits.mjs`, `growth.mjs`, `check-window.mjs`, `pagcheck.mjs`,
`runwalls.mjs`, `pullall.mjs`, `gating.mjs`, `livestate.mjs`, `recount.mjs`, `recount2.cjs`,
`legmeds.cjs`, `split19.cjs`, `legstats.cjs`, `truthcheck2.cjs`, `windowprobe.mjs`, and the late-session
verification set `flakycensus.cjs`, `threadwalk.cjs`, `threadprobe.cjs`, `arctest.cjs`, `durcheck.cjs`,
`settle.cjs`, `diffcensus.cjs`), `drg-live/` and
`drgcmp/<version>/` (read-only skill downloads), `probe/` (`proposal.json`, `portfolio.json`),
`verify/window-check.json`, and the census files `sessions-full.json` (60),
`schedule-runs-full.json` (20), `credits-measured.json` (19 legs), `timeline.json`, `legs.json`,
`growth-measured.json`.

The five verification outputs a reviewer should re-run first, because they are what §2.1, §5.2 and §6.1
now rest on: `verify/flakycensus.txt` (local, zero network: compaction census over the 19 saved thread
dumps), `verify/threadwalk.txt` (live, one thread walked to completion: 359 events, the compaction event
id, 63 requests, 15.49 cr), `verify/durcheck.txt` (local: duration/active pairing and the 33-of-60 >24 h
count), `verify/finalstate.txt` (live: the five template digests and `re_quote_et=false` at 05:15:21Z),
`verify/window-check.json` (the 13 offline `guard.py` blackout invocations).
Raw event dumps: `.scratch/flaky/<slot>__<role>__<thread>.json`, 173 files; the two that carry a
compaction event are named in §5.2.

---

## 9. Rescope: the persistent **multi-turn** session (addendum `20261120T040303Z-91c5de`, 2026-11-20 ~05:40Z)

The requester withdrew the "one uninterrupted turn 09:30→16:00 ET" reading and replaced it with:

> **one persistent Session**, idle between scans, receiving a new turn at each scheduled scan time,
> carrying full conversation history across turns — replacing today's fresh-session-per-SCAN
> architecture with no shared memory.

Their stated reason was a quote they attribute to `container-reference`:
`'Execution time | 30 minutes | Maximum duration of a single turn.'` Taken as a hard per-turn resource
limit, a single giant turn is impossible, so multi-turn is the only shape left.

**Everything below was checked against the platform and against the fetched page text, not against the
quote.** §9.1 resolves the tension the addendum required me to resolve; §9.2–§9.6 answer items 1–5.

### 9.1 The quoted limit is not in the cited page — premise and conclusion are two different claims

Fetched live this session (`curl --compressed`, saved under `/tmp/qd5/`; sizes prove the fetch is real:
`container-reference.md` 5,833 B, `sessions.md` 16,560 B, `api/forward/schedules/create.md` 22,894 B,
`api/forward/templates/create.md` 33,537 B — `cloud-agents/sessions/schemas.md` returned 9 B `Not found`):

| searched string | hits across those four pages |
|---|---|
| `30 minutes` | **0** |
| `Maximum duration of a single turn` | **0** |
| `single turn` | **0** |
| `Execution time` | 1 — inside the *prose* heading "Resources and timeouts", not a table row |
| `per-turn timeout` | 1 |

What `container-reference` actually says, verbatim (§"Resources and timeouts"):

> "Available CPU, memory, disk, and **execution timeouts** depend on the runtime environment and service
> configuration. **Do not make a task depend on fixed resource values.** If a task has minimum resource
> requirements, validate them in the target environment first."
> "Processes can be terminated or writes can fail when memory or disk is exhausted. Long-running tasks
> must also account for **per-tool and per-turn timeouts**." — no number anywhere on the page. **[documented]**

The only documented meaning of 1,800,000 ms on this desk is **not** a turn limit. `schedules/create.md`
lists `timeout_ms` default **300000** described verbatim as **"Timeout for one attempt"**, and
`max_attempts` allowed values `1` or `2`. **[documented]** Live read this session
(`GET /forward/schedules?limit=50`, HTTP 200, 7 schedules): **every one** of BRIEF / SCAN-1005 /
SCAN-1100 / SCAN-1230 / SCAN-1400 / FLAT / REPORT carries `timeout_ms: 1800000`, `max_attempts: 1`,
`max_concurrent_runs: 1`, `session_mode: "new_session"`, `template_id: tmpl_19f984c8f0fd516965b63998`.
So 30 minutes is **this desk's own configured per-attempt wall**, and the platform publishes no per-turn
number at all. **[observed]**

**Resolution the addendum asked for:** `srun_8156e0a9664a9b1dc7d305ba` hitting exactly
`duration_ms = 1800000` with `execution_failed` while `sess_00vz7hpp449a8vtdnfcl` kept working to
15:35:35Z and ended `end_turn` (§2.3) is the *scheduled attempt* expiring, not a turn being cut off. That
wall binds the scheduler's wait, not the model's turn. Therefore the requester's **premise** ("a hard
30-minute-per-turn cap exists") is unsupported, and their **conclusion** ("design multi-turn, not one
giant turn") is correct — for reasons they did not give. They are two different claims, and the memo must
not credit the false one: the longest single turn ever recorded here, **1,834 s (30 m 34 s)**, crossed
1,800 s and still terminated naturally under its own `end_turn`. **[observed, §2.2 + live re-read]**

*Caveat on my own method, stated because it nearly produced a false negative — and now closed:* my first
docs-wide corpus attempt (45 pages) was garbage — every file was 9 bytes of `Not found` because llms.txt
paths already end in `.md` and my loop appended a second `.md`. Its all-zero greps proved nothing. I
re-fetched byte-verified pages for the table above, and the deferred whole-site check has since completed:
**317 cloud-agents pages, 3.26 MB, 0 `Not found`**, with sentinel strings that *must* hit firing
(`reclaimed after 24` = 2 files, `per-turn timeout` = 1) so the corpus is demonstrably real. Site-wide:

| string | hits across all 317 pages |
|---|---|
| `Maximum duration` | **0** |
| `single turn` | **0** |
| `30 minutes` | **1** — and it is an example prompt: *"From 9:00 AM to 6:00 PM on May 1, 2027, check flight prices every 30 minutes"* (`natural-language-schedule-management.md`) |
| `Execution time` | 9 pages, but always as prose or a timestamp label — "execution timeouts depend on the runtime environment", "Last execution time", "track execution timeouts… through Session events" — never a limit row |

So the correction is **upward, not downward**: the requester's row
`Execution time | 30 minutes | Maximum duration of a single turn` does not appear anywhere in the
cloud-agents documentation, not merely on the two pages they cited. §9.1's conclusion stands with the
stronger basis, and the "asserted over four pages only" limitation is retired.
**[observed]** (corpus under `/tmp/qdocs3/`, sentinel-verified; one caveat: that path is temp and will not
survive, so re-run the fetch to reproduce.)

### 9.2 Item 1 — is a Session genuinely resumable after hours idle? Yes, and the desk already relies on it

- **[documented]** `sessions.md` is a state machine with no expiry column: `idle` → `running` |
  `terminated`; `running` → `idle` | `rescheduling` | `terminated`; "**When the turn completes, the
  Session returns to `idle`. Repeat for each turn.**" Terminal is `archived_at` non-null or `terminated`
  only, and "Archived … remains readable but rejects new events" / "ends the Session permanently — it
  cannot be resumed." Nothing between "hours" and "forever" is written down.
- **[observed, live this session]** `GET /forward/sessions?limit=100` → **53 sessions fetched, 53 with
  `archived_at: null`**. Key-union scan of every session object for `expir|idle|ttl|timeout|deadline`
  returns only the status value `"idle"` — **no session anywhere on this account exposes an expiry, TTL
  or idle-termination field**. Longest idle-since-update in the census **249,246 s (69.2 h)**; 33 of 53
  idle > 24 h. Re-read individually: `sess_00vr2pgo69g5cvvcztun` (executor) and
  `sess_00vrd03dst8g0xx91ij6` (risk_auditor), both still `idle` at 69.7 h and 15.4 h.
- **[observed]** Multi-hour inter-turn gaps are not hypothetical here: the auditor session above took its
  turn 2 **7,902 s (2 h 11 m)** after turn 1 across 6 turns, and the executor resumed after a
  **10,698 s (2 h 58 m)** gap and finished a turn in 37 s.
- **[documented]** The one real idle-shaped limit is *storage*, not session: "Files normally remain
  between turns while the same runtime instance is retained" but "the container's **ephemeral storage may
  be reclaimed after 24 consecutive hours of inactivity**." Inside a 6.5 h trading day with 55–195 min
  scan gaps it never binds. **[observed]** it does not kill sessions either — the 69 h sessions above are
  alive.

**So item 1 is a clean YES, and I found no undocumented idle timeout despite looking for one.** This part
of the requester's model is sound. It is also not the constraint that decides anything, because §9.3 and
§9.5 are what bind.

### 9.3 Item 2 — it does **not** attack the round trip; and the round trip is not where they think it is

This is the part the addendum asked me to be precise about, and the measurement changes the answer from
§0.2's "2–5 %". New decomposition of the 19 saved thread dumps
(`.scratch/contscan2-91c5de/tools/split.cjs`, `turns.mjs`-equivalent inline; local, zero network; the
tool-pairing bug that produced all-zero categories earlier is fixed — USE events key on `e.id`, RESULT
events carry `tool_use_id`/`mcp_tool_use_id`, and the `fresh_market` regex was matching a nonexistent
`moomoomcp.` prefix):

**(a) Turn structure — the proposal describes the status quo.** Segmenting each dump on
`user.message` / `agent.thread_message_received`:

| role | legs | turns per leg | Σ span | Σ inter-turn idle | idle % |
|---|---|---|---|---|---|
| coordinator | 7 | **2 / 4 / 5** | 7,033 s | **5,979 s** | **85.0 %** |
| child (researcher + auditor) | 12 | **1 / 2 / 3** | 10,123 s | **0 s** | **0.0 %** |

A SCAN cycle **already** runs a persistent session taking 4 turns with minutes of idle between them; the
auditor already receives the researcher's result as a **second turn** in its own session, and the idle gap
between the child's turns is **0 s** — it is driven back-to-back. Corroborated independently by the
sibling's rounds table (inbound messages per thread: coordinator 4, auditor 2, researcher 1;
`max_tool_rounds` is a real documented template field, unset = platform default).
**"Fresh-session-per-SCAN with no shared memory" is true only *across* cycles. Inside a cycle the desk is
already the architecture being proposed.** **[observed]**

**(b) Where a coordinator's time actually goes.** Coordinator model-request time inside its own leg:
**671 s of 5,156 s across the four SCAN legs = 13 %**; all 7 legs 1,028 s of 7,033 s = **14.6 %**.
The other ~85 % is the coordinator sitting idle waiting for a child (§9.3a). Child legs: **6,553 s of
10,123 s = 64.7 %** is the child's own inference; the researcher legs run **97–98 %** model time
(SCAN-1005: 63 requests, 1,255 s of a 1,292 s span). **[observed]**

**(c) What a persistent session can mechanically delete.** Tool wall-time by category, Σ over 19 legs:
`fresh_market` 86 s, `account_state` 57 s, `skill_rules` 61 s, `file_io` 75 s, `shell_setup` 39 s,
`web` 32 s, `orchestration` 0 s. Everything a warm session could skip —
`shell_setup + file_io + skill_rules` — is **175 s of 17,156 s = 1.0 %**, ~9 s per leg. The
doctrine-required re-pull (`fresh_market + account_state`) is **143 s = 0.8 %**. Cold start adds 22–66 s
per leg (§2.2). So:

> **The ~21 m 47 s does not live in session startup, tool calls, or state re-derivation. It lives in the
> researcher's single 1,292 s turn of pure inference plus the auditor's turn, which a persistent session
> executes identically.** A day-long session buys roughly **3–6 % of leg span**, ≈ 130 s of a 1,834 s
> cycle, and moves the critical path by nothing that matters. **[observed]** + **[inferred]** from it

Practical consequence for the owner's actual goal: if the target is latency, the addressable object is
`max_tool_rounds` and the researcher prompt (63 rounds / 82 tool calls to produce three tickers of JSON),
not the session lifecycle. That is a prompt/skill change, Tier A, and it is where Proposal A's re-quote
should be pointed instead.

### 9.4 Item 3 — role mapping, and the reason 1 session ≠ 4 sessions

- **[observed, live]** Capability split today: `coordinator` = **no** `mcp_servers`, **no** `skills`
  (system 3,274 chars, sha `16572c95062b`); `researcher` = moomoomcp + 4 skills (3,776 chars,
  `f4057916db32`); `risk_auditor` = moomoomcp + 3 skills (6,606 chars, `25f673100b2d`); `executor` =
  moomoomcp + 3 skills (4,918 chars, `84c192f72273`). Live skill versions: desk-risk-guard
  `1795138181446404`, trend-signal `1795047415929677`, decision-journal `1795137748003137`, and a fourth
  binding `skill_00vz0dq461mv4e5iv1p3@1795095917868411` now present on all three worker templates (it was
  bound to 0 templates when this project last recorded it).
- ⇒ **ONE session for all four roles is not available without a config change**: the coordinator cannot
  pull a quote or run `guard.py` — it has neither the MCP nor the skills. Merging means one session holding
  every capability, which collapses the auditor/executor separation §4 of this memo depends on and, since
  `always_allow` is already uniform across all four templates (AGENTS.md observation 3), removes the only
  *nominal* separation left. So the honest options are 1 (impossible as configured) or **4 persistent**.
- **[documented]** Four persistent sessions is **not** expressible as "one per role" through the scheduler
  either: `reuse_session` means "Forward manages **one fixed execution Session for this Schedule** and
  reuses it across triggers. **Callers cannot provide an arbitrary existing `session_id`.**" The binding is
  schedule→session, not template→session. **[observed]** the desk's schedules all target the coordinator
  template, so `reuse_session` would persist **four coordinators**, not one coordinator + three workers.
- **[observed]** cron makes "one session for the four scan times" arithmetically unreachable: SCAN-1005 is
  `trigger_policy: {type:"cron", expression:"5 10 * * 1-5", timezone:"America/New_York"}`. The set
  {10:05, 11:00, 12:30, 14:00} needs **≥3** expressions (`5 10`, `0 11,14`, `30 12`); a single
  `5 10,11,12,14` fires at the wrong minutes. Minimum 3 schedules ⇒ minimum 3 fixed sessions ⇒ **three
  independently frozen coordinator snapshots running at once**, which is worse than today's four
  fresh-per-cycle.
- **[observed, decisive — this is the finding that was not in §0]** A session binds an **immutable
  snapshot**, and the freeze is not theoretical. Reading events off the two long-lived sessions:

  | session | snapshot its events carry | live template now | verdict |
  |---|---|---|---|
  | `sess_00vr2pgo69g5cvvcztun` (executor, 69.7 h, still `idle`) | `version 4`, system **2,062 chars**, sha `9a3c5cf0a6cb`, skills with **no version key** | **4,918 chars**, sha `84c192f72273` | **DIFFERENT** |
  | `sess_00vrd03dst8g0xx91ij6` (risk_auditor, 15.4 h, `idle`) | `version 5`, system **2,008 chars**, sha `37d7a784e568` | **6,606 chars**, sha `25f673100b2d` | **DIFFERENT** |

  Those two byte-lengths, 2,062 and 2,008, are **exactly** the executor and risk_auditor prompt lengths
  recorded in `AGENTS.md` from the 2026-11-17 config snapshot. So a session created before the intervening
  edits has been executing the **17-Nov prompt for three days** — the one that still says "place the
  resting STOP" (impossible on `5830104`), predates Fix B (`book.py`/`levels.py`), predates the
  monitored-stop doctrine, and predates the `AUTONOMY_PHASE=bounded` and FLAT-collision fixes. Templates
  were edited **today** (`updated_at 2026-11-20T09:29:44+08:00` = 01:29Z for researcher/auditor/executor,
  `09:22:41+08:00` for `executor-gating-rehearsal`, `2026-11-19T22:05:04+08:00` for coordinator).
  **[observed]**
- ⇒ Under the persistent model this is a **live safety defect, not a nicety**: a day-long session is
  frozen at the moment it is created, and this desk edits prompts *during the trading week, often the same
  day*. The only way to refresh it is to stop reusing it. The owner's risk authority is engaged here, so
  the statement to take away is blunt: **the desk's current safety doctrine exists in the templates, and
  persistent sessions would silently not have it.**
- **[undiscoverable here]** which **skill** bytes such a session reads at run time. Its snapshot lists
  skills with the `version` key absent, which per project memory is what *unpinned* looks like, and the
  production templates are all pinned — but I did not test whether an already-created session resolves
  `latest` per turn or freezes at creation. Anyone reasoning about variant R needs that answer first.

### 9.5 Item 4 — blackout is unaffected; context growth is now measured, and it is fatal for the researcher

**Blackout.** Unchanged by the rescope, for the reason §3 already gave: enforcement is
`guard.py check … --now <ET>`, which reads `calendar_rules.py DAYS` fresh on every invocation, so a
`no_entry [("11:45","12:30")]` window is applied by the *tool*, not by the session's memory. **[observed]**
the live skill bytes verified this project at `1795138181446404` carry it. The multi-turn model adds one
new, smaller exposure: if the coordinator's prose memory of the day (the BRIEF's 12-line regime, size
multiplier, event windows) has been compacted by 12:30, the coordinator can hand a stale plan into a turn
while `guard.py` still vetoes correctly — the failure mode degrades to *confusing transcripts*, not to
unapproved entries. **[inferred]**

**Context growth, measured rather than extrapolated.** Two real compaction events in the 19 dumps give a
calibration point in the same proxy I can compute for every leg: **346,591 and 388,591 chars of event
text** = **43 % and 49 % of the nominal 200k window** at 4 chars/token. Cumulating each role's own
day-text in time order, against the nominal window and that observed band:

| role (as a persistent day thread) | 09:00 | 10:05 | 11:00 | 12:30 | 14:00 | 15:30 | 16:15 | crosses observed band |
|---|---|---|---|---|---|---|---|---|
| coordinator | 104k (13 %) | 225k (28 %) | 334k (42 %) | 452k (57 %) | 585k (73 %) | 672k (84 %) | **756k (95 %)** | **12:30 ET** |
| researcher | 347k (43 %) | 735k (92 %) | 1,001k (125 %) | 1,253k (157 %) | **1,526k (191 %)** | — | — | **09:00 ET (the BRIEF itself)** |
| risk_auditor | 309k (39 %) | 581k (73 %) | 662k (83 %) | 864k (108 %) | 980k (122 %) | 1,032k (129 %) | **1,151k (144 %)** | **10:05 ET** |

**[measured locally]** chars of `content`+`input` per event from `.scratch/flaky/`; **[inferred]** the
token and window percentages, using the same 4 ch/tok proxy that produced the observed band. Two honest
limits: the count **excludes the system prompt and the tool/MCP schemas that ride every request** (the
moomoo connector alone presents ~107 tools), so true token totals are **higher** — these are floors, and
the error runs in the alarming direction; and no token counts exist anywhere in the event surface
(`span.model_request_end` carries `model_usage:{credits}` only), so a token-exact figure is
**[undiscoverable]** from the API.

Consequences specific to the multi-turn model, which §5 could not state:

1. A persistent **researcher** does not "risk" compaction, it **guarantees** one inside its first cycle,
   and the thing it compacts away first is the 09:00 BRIEF — the regime call, the size multiplier and the
   day's event windows. The role with the strongest claim on continuity (staleness judgement across scans)
   is the role whose context degrades fastest: **191 % of the window by 14:00**.
2. A persistent **auditor** reaches 144 %; a persistent **coordinator** alone stays under the nominal
   window (95 % by 16:15) but still crosses the *empirical* band at 12:30 — mid-session, inside the entry
   window.
3. Compaction is not free and not silent for decision quality: §5.2 verified it fires mid-leg on legs
   97–98 % consumed by inference, and credits/leg **fall** with age (median tail/head 0.77), so the cheap
   older session is also the dumber one.
4. This supersedes §5's "25–30 compactions extrapolated on n = 2" with a per-role, per-cycle table on the
   same proxy, and it does so *against* the proposal rather than for it.

### 9.6 Item 5 — recommendation, and what is Tier B vs what needs owner input

**Do not prep the persistent multi-turn session tonight.** Not because it is infeasible — §9.2 shows the
platform does exactly what the requester believes — but because the two objections that actually bind are
structural and unaffected by the rescope:

- **Latency (the stated benefit) does not exist.** 85 % of coordinator leg span is waiting on child turns
  that a persistent session runs identically; everything a warm session could skip is **1.0 % of tool time
  plus 22–66 s of cold start** (§9.3). Do not spend the change budget on it.
- **Correctness gets worse, measurably.** A persistent session freezes the template snapshot at creation
  — proven, with two live sessions still running the 2,062/2,008-char prompts of 2026-11-17 while the
  live templates are 4,918/6,606 chars and were edited at 01:29Z today (§9.4) — and guarantees at least
  one context compaction per role before 12:30 ET (§9.5). Both hit the *decision* path, which is precisely
  where Proposal A was trying to add evidence rather than subtract it.

Classification, as the addendum asked: **this is Tier B scoping and the scoping is complete — there is no
prep to do, and nothing here should be bound.** The two things genuinely worth the owner's attention are
(1) the §9.4 snapshot-freeze hazard, which now applies to **variant R** and means §7's "cheap, low-risk
salvage" label on R is **wrong and is superseded** — R would freeze four coordinator snapshots (three at
minimum by cron arithmetic) at the moment each schedule's session is created; and (2) the §9.3 latency
address, which is `max_tool_rounds` and the researcher prompt, a Tier A change with a real target.

Research still owed before *any* session-lifecycle decision, both cheap and both read-only: which skill
bytes a pinned-but-snapshot-listed-as-unversioned session reads at run time (§9.4, [undiscoverable] here),
and whether a timed-out run's still-working session can be re-attached (§2.3, still open).

### 9.7 What survives the rescope and what is superseded

| memo claim | status after §9 |
|---|---|
| §0.1 premise false — the Nov-19 shorts died on reward/risk at 10:20, not staleness | **SURVIVES untouched.** Nothing in the rescope touches the signal engine. |
| §0.2 / §2.2 "removes 2–5 % of the path" | **SURVIVES and is sharpened** to 1.0 % of tool time + 22–66 s cold start, with the 85 %-idle decomposition added (§9.3). |
| §0.3 "the hard limit is per-attempt, and it already fired" | **SURVIVES and is now documented**: `timeout_ms` = "Timeout for one attempt", desk-set 1,800,000, default 300,000 (§9.1). |
| §2 "can a session survive 09:30→16:00" | **SUPERSEDED as a question.** The right question was whether it *should*, and §9.4/§9.5 answer no. The survival answer is a firm yes (§9.2). |
| §3 blackout "cadence-independent, `--now`-driven" | **SURVIVES**, with one new minor prose-staleness exposure (§9.5). |
| §4 roles (executor alone `always_allow` on sim tools; entry approval must stay discrete) | **SURVIVES and is strengthened**: the coordinator has no MCP and no skills, so single-session merge is impossible as configured (§9.4). |
| §5 compaction "25–30/day extrapolated on n = 2, risky" | **SUPERSEDED** by the per-role measured table (§9.5) — direction confirmed, magnitude re-based, and it now argues *against* persistence. |
| §6 Proposal A relation | **SURVIVES**; §9.3 redirects Proposal A's latency target from session lifecycle to `max_tool_rounds`/researcher prompt. |
| §7 variant R (`reuse_session`) = "cheap salvage" | **SUPERSEDED as cheap/low-risk.** Still the only live half of the idea, but it inherits the snapshot-freeze hazard and cron forbids the single-session version (§9.4). Owner decision required before it is called salvageable. |
| §8 provenance and the seven self-corrections | **UNTOUCHED.** §9.1 added an eighth of the same kind — my first docs corpus was invalid (double `.md` → 9-byte `Not found`) and I nearly reported its all-zero greps as a finding — and it is now **closed in my favour**: the 317-page sentinel-verified corpus shows the quoted row appears **nowhere** on the site, so the negative is stronger than the four-page version I first relied on. |
