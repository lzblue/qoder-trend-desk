# AGENTS.md — Qoder Cloud "Forward" template configuration snapshot

This file is a **read-only snapshot** of the Qoder Cloud Forward configuration this
dashboard tracks. It documents what is currently configured **in the cloud**; it does
**not** configure anything, and editing this file changes nothing remotely.

- Retrieved: `2026-11-25T06:40Z` (UTC) via `GET https://api.qoder.com/api/v1/forward/{templates,skills,schedules}`
  plus one `GET /templates/{id}` per template
- Auth: `QODER_PAT` from `.env` (server-side only; the token value is not recorded here)
- Raw responses for every number below are kept at `.scratch/tmp-guard-1125/`
  (`t-tmpl_<id>.json` production, `c-tmpl_<id>.json` non-production, `skills.json`,
  `schedules.json`, `guard-new.zip` = the mounted desk-risk-guard build,
  `guard-head.zip` = its head). That directory is **not** part of the submission package;
  if this file needs re-verifying, re-fetch rather than trusting the capture.
- Re-fetch a single template with:
  `curl -H "Authorization: Bearer $QODER_PAT" https://api.qoder.com/api/v1/forward/templates/<id>`
- **The four system prompts are no longer reproduced verbatim here.** They total ~60.6k
  characters (2026-11-17 snapshot: ~8.3k), which is too large for a file that is loaded into
  every session. Each prompt's length and SHA-256 prefix is recorded below, the operative
  statements are quoted, and the bytes themselves are in the capture files.

## Note on "cloud version"

Forward template objects expose **no version or revision field**. Re-confirmed on 2026-11-25:
`GET /templates/{id}/versions` and `/revisions` are not served, and the template body carries
no `*version*` key. The only per-template marker is `updated_at`.

**Do not read `created_at == updated_at` as "never edited."** `created_at` is *reset on edit*,
so that equality is meaningless — it holds for all nine templates today even though three of
the four production roles were edited ~2.5 hours before this capture. The 2026-11-17 snapshot
drew exactly that wrong inference and it is corrected here.

Skill **bindings** do carry a real, immutable build id (`skills[].version` on the template),
and each skill exposes `latest_version`. **A pin and the head can differ** — see observation 10.

## Production templates (4 of the 9 that exist)

| Template | Agent ID | Model | Context | Effort | MCP | Skill pins | Vault | `updated_at` (UTC) |
|---|---|---|---|---|---|---|---|---|
| coordinator | `tmpl_19f984c8f0fd516965b63998` | `dfmodel` | 400k | high | none | **0** | moomoo-mcp | 2026-11-25T01:57:30Z |
| researcher | `tmpl_d7df3829ed5d73548bb5e9ed` | `dfmodel` | **1M** | high | moomoomcp | 5 | moomoo-mcp | 2026-11-25T04:32:29Z |
| executor | `tmpl_6c3c42cc4500efcbd6d60309` | `dfmodel` | 200k | high | moomoomcp | 4 | moomoo-mcp | 2026-11-25T04:32:30Z |
| risk_auditor | `tmpl_bf2c477c0fba1a3363833f91` | `dfmodel` | 400k | high | moomoomcp | 4 | moomoo-mcp | 2026-11-25T04:32:29Z |

All four share: `status: active`, `type: template`, `environment_id: env_00vqul91jtzi9aekyu8m`,
`environment_byoc: ""`, `user_id: 01a1e42a-0bc2-7ef4-a584-9f8a39485309`,
`multiagent` per observation 1, `files: {}`, `github_repositories: {}`,
`environment_variables: {}`, and `vaults: {"vault_00vqumr1quqkgmdtt1fw": {"enabled": true}}` —
the vault is now enabled on the **coordinator too**, which the 17 Nov snapshot recorded as "none".
Timestamps in this table are converted from the API's `+08:00` form; `/schedules` returns `Z`.

## Non-production templates (5) — same API, not the desk

| Name | Agent ID | Model | Skill pins | `system` chars | `updated_at` (UTC) |
|---|---|---|---|---|---|
| `smoke-coordinator-1122` | `tmpl_abdff737e6dc428a75f766d8` | `efficient` / 200k | 1 (mock-moomoo) | 10,791 | 2026-11-23T06:29:47Z |
| `smoke-researcher-1122` | `tmpl_e0b62229b1e58b6086e80fd8` | `efficient` / 200k | 6 | 8,654 | 2026-11-23T09:05:48Z |
| `smoke-risk_auditor-1122` | `tmpl_b5e34d87fdd260b15b4929bd` | `efficient` / 200k | 6 | 15,238 | 2026-11-23T09:05:48Z |
| `smoke-executor-1122` | `tmpl_f61822c674a31826e6ab42b7` | `efficient` / 200k | 6 | 18,819 | 2026-11-23T10:14:15Z |
| `executor-gating-rehearsal` | `tmpl_f3214189de633d9d34ce77b6` | `efficient` / 200k | 1 (decision-journal) | 2,420 | 2026-11-20T01:22:41Z |

These are the rehearsal clones. **They are not on the production configuration**: they stay on
`efficient`/200k and bind desk-risk-guard `1795422986200317` rather than the mounted pin. A
result measured on a clone is not a result measured on the desk, and the four `smoke-*` clones
are the only binders of `mock-moomoo`.

## Skills (6) — inventory, head, and what is actually mounted

| `display_title` | Skill ID | `latest_version` | head published (UTC) | pinned build | templates binding it |
|---|---|---|---|---|---|
| desk-risk-guard | `skill_00vqwa9tq5szk3y13lg4` | `1795584029544437` | 2026-11-25T05:20:29Z | **`1795580552453332`** (≠ head) on researcher/executor/risk_auditor; `1795422986200317` on the 3 `smoke-*` clones | 6 |
| trend-signal | `skill_00vqvkdtlzojk2xg1rku` | `1795160305077544` | 2026-11-20T07:38:25Z | `1795160305077544` = head, on researcher + smoke-researcher | 2 |
| decision-journal | `skill_00vqvbzcimznkggtyd1t` | `1795137748003137` | 2026-11-20T01:22:28Z | `1795137748003137` = head, on all 3 desk roles + 4 clones | 7 |
| vwap-chop | `skill_00vz0dq461mv4e5iv1p3` | `1795160305163946` | 2026-11-20T07:38:25Z | `1795160305163946` = head, on all 3 desk roles + 3 clones | 6 |
| option-adapter | `skill_00w0ip0yri8sgag736ks` | `1795402814211564` | 2026-11-23T03:00:14Z | `1795402814211564` = head, on all 3 desk roles + 3 clones | 6 |
| mock-moomoo | `skill_00w95252gq48wrscwcjp` | `1795341202256698` | 2026-11-22T09:53:22Z | `1795341202256698` = head, on the 4 `smoke-*` clones only | 4 |

Every `binding_info.agent_template_count` reconciles with the per-template `skills[]` arrays
counted independently (6 / 2 / 7 / 6 / 6 / 4), which is the evidence that the bindings were
read completely and none are hidden.

**File hashes of the two desk-risk-guard builds** (per-file SHA-256 prefixes; a version's
`content_sha256` is *not* the sha of the zip):

| File | mounted pin `1795580552453332` | head `1795584029544437` |
|---|---|---|
| `SKILL.md` | 18,420 B `7d5f3edb80c7` | 18,420 B `7d5f3edb80c7` |
| `references/rules.json` | 6,954 B `060fc5b572d6` — `version: "2026-11-25.2"` | identical |
| `scripts/guard.py` | 87,747 B `a4ea554b1d1a` | 92,283 B `6f51bf8cf968` |
| `scripts/book.py` | 12,875 B `b12c1077498e` | identical |
| `scripts/calendar_rules.py` | 4,818 B `f3e2b4ee326f` | identical |
| `scripts/levels.py` | 6,515 B `746a01510d00` | identical |

The backtest shipped in the submission (`docs/submission/trading-journal.md` §4) replays
exactly these mounted bytes: `guard.py a4ea554b1d1a…`, `rules.json 060fc5b572d6…`,
trend-signal `1795160305077544`, vwap-chop `1795160305163946`, option-adapter
`1795402814211564` (`sleeve_b_fly.py`).

### Pin chain of the three desk roles, 2026-11-25 (from `.scratch/changes/budget-ledger.json`)

| Ledger seq | `recorded_at_utc` | desk-risk-guard build | What actually moved | Gate status |
|---|---|---|---|---|
| 43–45 | 01:57:30Z | v8 `1795422986200317` → **v9 `1795571706823549`** | `rules.json` `f35744b28dc4a891` → `a5efd7210edc5f7d` (`structure.max_loss_pct_of_nav` 0.75 → 1.5); `guard.py` unchanged | owner instruction "proceed Option A … if verify ok proceed to publish" |
| 46 | 01:57:30Z | — (coordinator, no skill pins) | `system` prose only ("cap prose") | same package |
| 47–49 | 02:55:14Z | v9 → **v10 `1795575276828792`** | `rules.json` → `060fc5b572d6b9ba` (`structure.fee_max_pct_of_credit` 10.0 → 12.5); `guard.py` unchanged | **owner override of the budget gate**, no CONFIRM token typed |
| 50–52 | 04:32:30Z | v10 → **v11 `1795580552453332`** = what is mounted now | `SKILL.md` one documentation line; `guard.py` and `rules.json` byte-identical | **owner override again** ("Override now, GO=1") |
| *(none)* | 05:20:29Z | **head `1795584029544437`** | `guard.py` 87,747 → 92,283 bytes (`a4ea554b1d1a` → `6f51bf8cf968`) | published but **bound by no template**, so no ledger entry and no effect on the desk |

Rollback for the mounted pin is one write per template: the same `skills` array with
desk-risk-guard `1795575276828792` (v10). Note that `et_day` on all ten entries in the window
(43–52) is **2026-11-24** even though they were filed on the 25th UTC — midnight ET is 05:00Z in
November, so seq 50–52 at 04:32:30Z is still 23:32 ET on the 24th, and `recorded_at_utc` is filing
time rather than the trading day a change lands on. Also note a recording gap:
`drift_check.new_version` is empty on seq 43–46 even though those writes happened, so the ledger
alone cannot reconstruct the chain — the live pins in this file are the primary record for those.

## Tool and permission posture

Two toolset entries per connected template, not one:

1. `agent_toolset_20260401` — `default_config.permission_policy: always_allow`, 12
   `enabled_tools`: Bash, Read, Write, Edit, Glob, Grep, WebFetch, WebSearch, ImageSearch,
   ImageGen, VideoGen, DeliverArtifacts. Identical on all four.
2. `mcp_toolset` (absent on coordinator) — `default_config: null`, `enabled_tools: []`, and a
   **per-tool override list**. On all three MCP-connected roles these are `always_deny`:
   `trading_order_place`, `trading_order_cancel`, `trading_order_replace`,
   `trading_order_confirm`, `crypto_account_create_order`, `crypto_account_modify_order`,
   `crypto_account_cancel_order`, `quote_modify_user_security`.
   - **executor additionally** has, as `enabled: true` + `always_allow`: `sim_trade_input_order`,
     `sim_trade_cancel_order`, `sim_trade_modify_order`, `sim_trade_account_list`,
     `sim_trade_max_buy_sell`, `sim_trade_history_order_list`.
   - **researcher and risk_auditor** instead carry `sim_trade_input_order`,
     `sim_trade_cancel_order`, `sim_trade_modify_order` as `enabled: false` + `always_deny`.

So the auditor's "read-only" claim is now enforced for order *mutation* at the tool layer, and
the live-money order family is unreachable by configuration on every template — denied on the
three MCP-connected roles, absent on the coordinator — rather than by prompt alone.
What is **not** expressed at the tool layer: which `acc_id` a call targets, and any limit on
`sim_trade_*` reads — the mutating/blind-tool split is the boundary, the account choice is
still prompt-level.

## Schedules (11, all `status: active`)

All are `trigger_policy.type: cron`, `timezone: America/New_York`, `session_mode:
new_session`, `max_concurrent_runs: 1`, `max_attempts: 1`, and send exactly one
`initial_events` message. There is **no per-run budget field beyond `timeout_ms`**.

| Name | Schedule ID | Fires on template | Cron | `timeout_ms` | `last_run_at` (UTC) | Message |
|---|---|---|---|---|---|---|
| BRIEF | `sched_c4ca1e6d49b8a007a8e3cd4f` | coordinator | `0 9 * * 1-5` | 1,800,000 | 2026-11-24T14:00:00Z | `BRIEF` |
| SCAN-1005 | `sched_9e39ba55d65df537f059e7e5` | coordinator | `5 10 * * 1-5` | 5,100,000 | 2026-11-24T15:05:00Z | `SCAN` |
| SCAN-1100 | `sched_a6aa60a0a6bfdb103bf438b2` | coordinator | `0 11 * * 1-5` | 5,100,000 | 2026-11-24T16:00:00Z | `SCAN` |
| SCAN-1230 | `sched_78045832a02a9baf6c8c98cc` | coordinator | `30 12 * * 1-5` | 5,100,000 | 2026-11-24T17:30:00Z | `SCAN` |
| SCAN-1400 | `sched_d5072d8839172c774409deb3` | coordinator | `0 14 * * 1-5` | 5,100,000 | 2026-11-24T19:00:00Z | `SCAN` |
| FLAT | `sched_984eb3d3fe7f6c415b740bce` | coordinator | `30 15 * * 1-5` | 1,800,000 | 2026-11-24T20:30:00Z | `FLAT` |
| REPORT | `sched_7804ae21274fea2d24bd7ff6` | coordinator | `15 16 * * 1-5` | 1,800,000 | 2026-11-24T21:15:00Z | `REPORT` |
| OPT-CHECK-AM | `sched_c4a35c82f5c842f1ccd9cbb2` | **executor** | `7,22,37,52 10 * * 1-5` | 1,320,000 | 2026-11-24T15:52:00Z | `OPT-CHECK` |
| OPT-CHECK-MID | `sched_aed0fd02141b993a49eb908b` | **executor** | `7,22,37,52 11-14 * * 1-5` | 1,320,000 | 2026-11-24T19:52:00Z | `OPT-CHECK` |
| OPT-CHECK-PM | `sched_05c7916b40775b78dad3f020` | **executor** | `7,22 15 * * 1-5` | 1,320,000 | 2026-11-24T20:22:00Z | `OPT-CHECK` |
| OPT-CLOSE-1530 | `sched_e2347ec7dfe436c2755413dc` | **executor** | `25 15 * * 1-5` | 1,320,000 | 2026-11-24T20:25:00Z | `OPT-CLOSE` |

- The four `OPT-*` schedules fire **directly on the executor template**, not through the
  coordinator. The 17 Nov framing ("the coordinator orchestrates every run") is now only true
  for the 7 coordinator-owned schedules.
- The next fire is `trigger_policy.upcoming_runs_at` (an array). There is no `next_run_at` key;
  reading one returns `None` and looks like "nothing is scheduled".
- `1-5` is Mon–Fri with **no exchange-holiday knowledge**. 26 Nov (Thanksgiving) and the 27 Nov
  half day are caught by desk-risk-guard's `day` command inside the run, not by the schedule.
- Last full session in the ledger is 24 Nov; every `last_run_at` above is 24 Nov, so as of this
  capture nothing has yet fired on 25 Nov (BRIEF is due at 14:00Z).

## System prompts: size, hash, and what they now assert

| Template | chars | bytes | SHA-256 (first 12) |
|---|---|---|---|
| coordinator | 12,788 | 12,788 | `61125a4526d5` |
| researcher | 10,534 | 10,538 (non-ASCII) | `d70ac3902331` |
| executor | 20,302 | 20,302 | `265761b24d97` |
| risk_auditor | 16,992 | 16,992 | `cdddef103a27` |

Operative statements verified in those strings (quoted fragments, not paraphrase):

- **Autonomy.** `AUTONOMY_PHASE=bounded` in the coordinator prompt. Its rule 2 still defines
  both phases; under `bounded`, "orders the auditor approved go straight through" — there is no
  human confirmation step on the production path.
- **No stop orders, by design.** Coordinator: "there is no stop order on this account (LIMIT and
  MARKET …)". Executor: "Stops are levels, not orders. Exit a breached level only on a close
  ticket the risk_auditor approved in this run (`is_close` verdict)". Auditor: "Do not report a
  missing resting order as an emergency — this account cannot rest a stop at all". The
  17 Nov snapshot's "resting STOP" doctrine is gone.
- **Account identity is a two-part test.** Executor: "Call `sim_trade_account_list` (not
  `account_authorized_trd_accs`) and confirm you are targeting the one account where
  `account_type == 2` AND `account_title` contains "Qoder" (currently `account_id 5830104`).
  Do not match on `market_id`" — because the paper and margin accounts share `market_id`.
- **Sleeve B is live in the prompts.** Coordinator budgets "one structure a day" with
  "max loss per lot = (width - credit) x 100, lots = floor(1.5% of NAV / that)" and says it
  "is a risk, not a hedge"; FLAT closes "sleeve B included" and the auditor confirms "flat by
  15:45 with no option position of any kind left". Researcher sources the fly only from
  "option-adapter's fly builder and nowhere else", and if that build is not in the toolset
  answers `SKILL BUILD ABSENT (option-adapter)` instead of hand-building legs.
- **Sleeve C routing is explicit.** Researcher step 3: "Sleeve C (vwap-chop), only for a ticker
  whose trend-signal result was NONE for the opening-range width (reason
  "outside 0.15-1.5%")" … "A C entry counts against the same one-equity-entry-per-family-per-day
  budget as A." This is the routing the backtest reproduces.
- **Latency is acknowledged, not hidden.** Coordinator: "because a scheduled session cannot
  loop, a breach is acted on 12-22 minutes after it happens — the structure's max loss is the
  backstop, not a stop you can outrun."
- **Order cap source.** Executor: "at most 150 orders a day — 150 is the desk cap the guard
  enforces (`competition.engine_orders_per_day_cap`), not the contest's own 200
  (`max_orders_per_day`)".
- **Auditor's guard call.** `python3 /data/.qoder/skills/desk-risk-guard/scripts/guard.py check
  --proposal proposal.json --portfolio portfolio.json --now $(date -u …) --phase bounded`.

## Cross-template observations (2026-11-25)

1. **The coordinator is wired for delegation but carries no skills and no MCP.**
   `multiagent: {"type": "coordinator", "agents": [researcher, risk_auditor, executor]}` names
   all three by `template_id`; `mcp_servers: []` and no `skills` entry. So the invocation path
   the 17 Nov snapshot called absent now exists in the template — the coordinator reaches the
   desk through its children's mounts, not through its own.
2. **`server.js`'s assumption needs re-checking.** `server.js:188-192` states the other three
   "are invoked as tool calls inside that same session"; the `multiagent` block is consistent
   with that, but the claim was written against the older config and the per-role broker
   evidence still has to come from `GET /sessions/{id}/threads/{tid}/events`.
3. **Permission posture is no longer uniform.** See the tool section: real-money and crypto
   mutating tools are `always_deny` on every MCP-connected template, and the auditor/researcher
   are denied the paper-account mutating tools the executor is explicitly allowed. The 17 Nov
   observation "`always_allow` everywhere, so the approval gate is prompt-only" is superseded —
   though `AUTONOMY_PHASE=bounded` means there is now no approval gate at all on that path.
4. **The auditor's "read-only" is partially configured.** Mutation is denied; nothing in the
   template restricts which account a read targets.
5. **Account conflict with a human session still stands.** The cloud desk is pointed at
   `5830104` ("Moomoo x Qoder AI Paper Trading Agent Challenge") by design. An interactive
   session operating `3732983` ("US Margin Account [Paper Trading]") is a different account, and
   nothing in this snapshot reconciles the two — the prompts even warn that both share
   `market_id`.
6. **`researcher`'s name is fixed; its description is not.** `name: "researcher"` (was
   `"researcherTrend desk researcher: market"`), and `description: ""` remains the only empty
   one of the four.
7. **No repo, no mounted files, no injected env on any template.** `files`,
   `github_repositories`, `environment_variables` are `{}` for all four (and `environment_byoc`
   is `""`). Every `guard.py` / `journal.py` / `chop.py` / fly-builder path resolves inside the
   skill mounts under `/data/.qoder/skills/…`, i.e. the pins above *are* the code version.
8. **A sandbox is per-session and `/data/desk` has never existed** — CWD is `/data`. Anything
   the auditor "saves" lives only in that session, which is why the prompts insist the report
   "must still say so" and why a monitored stop cannot survive a run boundary.
9. **The three desk roles were re-pinned twice today** (02:55:14Z and 04:32:30Z, ledger seq
   47–52), and the coordinator's `system` was edited at 01:57:30Z (seq 46). Combined with
   observation 10 — a desk-risk-guard head published at 05:20:29Z, *after* the last template
   write — the desk is mid-change: re-census before quoting any pin, model, or prompt hash
   forward.
10. **Mounted ≠ head for desk-risk-guard.** The three roles pin `1795580552453332` ("v11":
    `guard.py` 87,747 B, `a4ea554b1d1a`). Head is `1795584029544437`, published
    2026-11-25T05:20:29Z, with `guard.py` 92,283 B (`6f51bf8cf968`) and an otherwise identical
    build — same `rules.json` `2026-11-25.2`. **No template binds head**, so those +4,536 bytes
    of `guard.py` are published but unreleased to the desk, and a verdict reproduced from the
    mounted bytes is the correct baseline for anything the submission claims. The template API
    does not show this; it takes a `GET /skills` head read next to the per-template pin.
11. **`GET /skills` name field is not the display name.** `name` returns `null` in this list;
    the human name is `display_title`. A snapshot keyed on `name` silently loses every skill.

## Delta from the 2026-11-17 snapshot

| Item | 2026-11-17 | 2026-11-25 (live) |
|---|---|---|
| Model / context | `efficient` / 200k on all four | `dfmodel` / effort high; 200k–1M by role |
| Coordinator wiring | `multiagent: null`, no vault | `multiagent` coordinator over 3 roles; vault enabled |
| Skill pins | none / 3 / 1 / 2 | 0 / 5 / 4 / 4 (vwap-chop and option-adapter added) |
| Order permissions | one `always_allow` toolset | `mcp_toolset` per-tool `always_deny` on live + crypto; sim mutations allowed only on executor |
| Stop doctrine | resting STOP order per entry | no stop orders possible; levels + auditor `is_close` tickets |
| Sleeves | A only (+ 1 option hedge) | A, C (vwap-chop), B (0DTE iron fly) |
| Schedules | 7 implied | 11 active; 4 fire on the executor directly |
| Prompt size | ~8.3k chars total | ~60.6k chars total |
| Researcher `name` | malformed | fixed (`description` still empty) |
| `created_at == updated_at` | read as "never edited" | meaningless — `created_at` resets on edit |
