# D4 regime gate loosened for Mon 23 / Tue 24 (owner decision, Tier B)

Decided: Mon 2026-11-23 08:20 SGT (Sun 2026-11-22 20:20 ET). Recorded here as the decision of record for
this change; the cloud state it describes was measured at 03:20Z, not asserted.

## The decision

Sleeve B's D4 open-gate ceilings are loosened for two sessions only, Mon 23 and Tue 24 November:

| D4 ceiling, over 09:30-10:00 ET | before | now |
|---|---|---|
| `structure.move_max_frac_of_em` | 0.25 | **0.35** |
| `structure.range_max_frac_of_em` | 0.9 | **1.0** |

Both stay CEILINGS and both stay strictly less than: `abs(move) < 0.35 x EM` AND `range < 1.00 x EM` over the
six close-stamped 5-minute bars 09:35, 09:40, 09:45, 09:50, 09:55, 10:00. A value equal to the ceiling does
not pass. Nothing else changed: the 0.75% max-loss cap, the sizing, the fee model, the 10:00-11:00 entry
window, one fly per day, the fresh-credit check and the 15:25 shorts-flat time are untouched, and I measured
`max_loss_pct_of_nav` at 0.75 and `entry_window_et` at `["10:00","11:00"]` in the published bytes rather than
relying on that sentence.

## Why

We want a logged fly this week. Mildly trending opens lose a little on average in the model, so a wider
ceiling costs expected value on the margin; the worst case per trade is unchanged at 0.75% of NAV because the
sizing cap did not move. This is a sample-size decision, not an edge decision.

Model-measured cost, from the sleeve B work already on disk: D4 is what rejected the mildly-trending days, so
loosening it admits trades the model scores slightly negative on average. That is the price being paid for
getting any live fly record at all this week.

## Where the thresholds live (census, measured before editing)

Every site that carried 0.25 or 0.9 for D4, and what it says now. Line numbers are from the published bytes
under `.scratch/changes/2026-11-23-d4-loosen/after/`, re-grepped after publish, not from a staged copy.

| # | site | what it is | before | after |
|---|---|---|---|---|
| 1 | desk-risk-guard `references/rules.json:131-132` | the authority the guard reads | 0.25 / 0.9 | 0.35 / 1.0 |
| 2 | desk-risk-guard `references/rules.json:2` | `rules.version` stamp | `2026-11-22.1` | `2026-11-23.1` |
| 3 | desk-risk-guard `SKILL.md:96-98` | prose stating both ceilings | 0.25 / 0.9 | 0.35 / 1.0, plus the Nov 23-24 window and the due date |
| 4 | option-adapter `scripts/sleeve_b_fly.py:56-57` | `STRUCTURE_DEFAULT`, the no-rules fallback | 0.25 / 0.90 | 0.35 / 1.00 |
| 5 | option-adapter `SKILL.md:268-270` | prose stating both ceilings | `0.25 x EM` / `0.90 x EM` | `0.35 x EM` / `1.00 x EM` + ruling sentence |

Sites that READ the numbers but do not carry them (so nothing to change there):
`guard.py:667-668` (`_num(st.get(...))`), `guard.py:615` (comment), `sleeve_b_fly.py:640-641`
(`num(cfg.get(...))`), `sleeve_b_fly.py:608` (docstring).

Prompts: none. I grepped all four production `system` fields for `0.25`, `0.9`, `0.90`, `move_max`, `range_max`
and `D4`. The only hits are in the **executor** prompt at two places that read `0.90 x the ticket's credit` -
that is the fresh-credit decay floor, a different quantity that happens to share the number. No prompt states a
D4 ceiling, so no prompt write was needed and the change costs one template POST per role, not two.

The offline test suite is also a place the old numbers lived, in expectations rather than logic:
`freshcredit/test_fly_candidate.py:327` and `:343-344` asserted `== 0.25` / `== 0.9` outright, and
`:133-141` asserted a decline for a 2.95-point move. Those live in my scratch tooling, not in shipped bytes,
so they are re-cut in this package's copies (`tools/suite/cand_test_fly_candidate.py`) rather than edited in
place - see the test section.

## Single setting, and the one change I did not ship

The instruction was: if the adapter hard-codes the numbers, make it read rules.json so a future change is one
setting. Measured, the production path already does that - the researcher runs
`sleeve_b.py fly --input envelope.json --rules <desk-risk-guard>/references/rules.json`, and rules.json is
what governs; `STRUCTURE_DEFAULT` is only used when no rules.json is in force.

I first implemented the literal reading, `--rules` made `required=True`, and then measured its blast radius:
argparse exits 2 with a usage message before any handler runs, so
`freshcredit/test_fly_candidate.py:539-541` (and its twin at `test_fly_mounted_control.py:539`) fails. Those
checks exist to guarantee the CLI is fail-closed - a bad call prints JSON with `action: STATE_UNAVAILABLE` and
exits 0 rather than handing the agent a shell error. Making the flag mandatory trades a real fail-closed
contract for a tidier config story, which is a non-D4 behaviour change. Under "the only verdict changes
allowed are D4 decline-to-pass; list any other and stop", **I dropped it.** `sleeve_b.py` is byte-identical to
the live file (sha256 `a8ce9955f9b6…`), and the publish rail no longer claims ownership of it, so a change to
that file now aborts the publish.

What holds "single setting" instead:
1. the guard re-derives D4 from rules.json only, so a stale adapter fallback can be vetoed but never honoured -
   the drift direction that matters is structurally safe;
2. `tools/d4_parity.py` (new) compares every leaf rules.json and `STRUCTURE_DEFAULT` both carry, resolving the
   adapter's own named constants (`FLYSHORTS_FLAT_ET`, `SESSION_MINUTES_DEFAULT`, `TRADING_DAYS_DEFAULT`) from
   the file rather than importing it, and fails on any value drift beyond a measured baseline;
3. the suite's own parity check, `STRUCTURE_DEFAULT does not quietly disagree with rules.json on any shared
   number` - which PASSES on the published pair.

## Adjacent finding, pre-existing, NOT changed (owner's call)

`d4_parity.py` found one real value disagreement that existed before this change and is identical on both
pairs: `structure.exit.shorts_flat_by_et` is `15:25` in rules.json but `15:30` in the adapter's fallback,
because the Nov-22 flat-time fold was never applied to `FLYSHORTS_FLAT_ET` (`sleeve_b_fly.py:40`). Production
takes 15:25 (rules.json governs whenever `--rules` is passed, and `mark_structure` reads the stamp baked at
entry anyway), so this only bites a rules-less call. It is out of scope for "nothing else changes" and is
recorded as a baseline in the parity tool rather than fixed here.

## What was published

| skill | new version | supersedes (rollback pin) | what moved |
|---|---|---|---|
| desk-risk-guard | `1795402802487026` (`skillver_00wbon6opineo02atunn`) | v6 `1795387675729428` | `SKILL.md`, `references/rules.json`; 4 scripts byte-identical |
| option-adapter | `1795402814211564` (`skillver_00wbont9ygdts4kamf7s`) | `1795318866825667` | `SKILL.md`, `scripts/sleeve_b_fly.py`; `scripts/sleeve_b.py` byte-identical |

Byte-verified file by file after publish: for all 9 files, the sha256 of the bytes served from
`GET /skills/{id}/versions/{v}/content` equals the manifest sha256 equals the on-disk sha256 equals the sha in
the reviewed pre-publish digest. Guard: `SKILL.md aa5915bb1eef`, `rules.json e721054cb75f`, `book.py
b12c1077498e`, `calendar_rules.py f3e2b4ee326f`, `guard.py 8fce6d62ca87`, `levels.py 746a01510d00`. Adapter:
`SKILL.md 33f5d018c99b`, `sleeve_b.py a8ce9955f9b6`, `sleeve_b_fly.py 00340ea37274`.

A publish alone changes no agent's behaviour: every desk binding carries an explicit pin, so nothing moves
until the templates are re-pinned.

## Tests

All offline, zero credits, zero network, run against the DOWNLOADED published trees - not against the staged
copies that were used to build them.

**1. The D4 matrix** (`tools/d4_matrix.py --label PUBLISHED-v7`, 18 rows at EM = 8.72, both evaluator levels:
the adapter's own `regime_gate()` on constructed bars, and `guard.check()` on a real fly proposal whose gate
object is the adapter's output).

| move | passes? | | range | passes? |
|---|---|---|---|---|
| 0.24 x EM | yes (qty 2) | | 0.89 x EM | yes (qty 2) |
| 0.30 x EM | yes | | 0.95 x EM | yes |
| 0.34 x EM | yes | | 0.99 x EM | yes |
| **0.35 x EM** | **no - veto** | | **1.00 x EM** | **no - veto** |
| 0.36 x EM | no | | 1.01 x EM | no |

Boundaries behave as stated: exactly at the ceiling vetoes, and one ulp below the ceiling
(`math.nextafter(cap, 0)`) passes. Counted out of the run JSON rather than from its summary line: at-ceiling
**0 pass / 18 veto**, over-ceiling **0 pass / 18 veto**, one-ulp-under **18 pass / 0 veto** - so a gate that
LIES (`pass: true` fed at or above the ceiling) is vetoed by the guard's re-derivation in all 36 of those
sites. The adapter's own verdict and the guard's re-derivation agree on **18/18** rows on both arms.
Approvals 3 on the mounted v6 bytes -> 11 on the published v7 bytes, and the 8 new passes are all D4 rows.
Runs: `out/d4-matrix-base-recheck.json` (mounted v6, 3 approvals), `out/d4-matrix-published.json` (v7, 11).

**2. v6 suite** (`oracle_run_v6.py`, 18 cases x 3 trees).
- Control, C = mounted v6: `ORACLE: PASS`, 18/18 expectation matches, 0 unexplained diffs.
- C = published v7: `ORACLE: FAIL (2 invariants)` - I0 and I14. Both are the harness's attribution machinery,
  not behaviour: I0 demands the v5->v7 rules.json delta be exactly one path (the flat key) so that C-vs-B is
  provably cap logic, and a D4 change deliberately makes that delta four paths; I14 then finds 10 D-vs-C
  differences because the D arm still carries the old ceilings. Every one of those 10 rows is still in
  agreement on `approved` - I12 (all 18 verdicts vs the written expectation table) PASSES on v7, and I1-I13 all
  PASS. Proof: `proof/oracle-v6-control.txt`, `proof/oracle-v7-published.txt`.

**3. v6 differential, in the form this axis needs** (`tools/d4_diff.py`, BASE = mounted v6 served bytes,
CANDIDATE = published v7, same 18 cases / same clock / same phase, classified by kind):

```
SAME 8   TEXT 10   GAIN 0   GAIN_NOT_D4 0   LOSS 0   SIZE 0
```

No row's approval moved and no qty or risk number moved on this corpus, because no corpus case ever reaches a
D4 veto - measured: 0 of 18 base rows carry a D4 reason at all. The 10 TEXT rows are two new WARNINGS each,
`the gate's threshold 47.33 is not 66.25 (= 0.35 x em 189.30)` and the matching `range_threshold` line: the
fixtures' gate objects still state thresholds computed under 0.25/0.9, and the guard notices. The allowed class
(decline -> pass) is therefore empty on the v6 corpus, and nothing outside it moved. The loosen is demonstrated
by the matrix in test 1, which is built to reach the branch. `proof/d4-diff.json`.

**4. Adapter suite** (`test_fly_candidate.py`, 274 checks, re-pointed copies for both arms):
- BASE (mounted adapter + mounted v6 rules): 2 failed - the frozen `structure` snapshot digest
  `497c9b16a74a3a3b` and the no-exit-block `STRUCTURE_DEFAULT` comparison. Both pre-existing; both are the
  "2 known old failures".
- CANDIDATE (published adapter-v2 + published v7 rules): before any test maintenance, 8 failed. All 6 new ones
  are D4-attributable, and I list them rather than smooth them over: `:133` expects `fly-inputs-gatefail.json`
  (move 2.95 = 0.34 x EM) to decline - it now passes, which IS the owner's change; `:135` and `:139` then have
  no refusal to quote; `:143` expects the veto text to say `a 7.84 cap` and it says `a 8.72 cap` (the veto
  itself still fires, range 9.05 > 8.72); `:327` and `:343-344` assert the retired 0.25/0.9 outright.
  Re-cut in this package's copy: the two value assertions now read 0.35/1.0; the 2.95 row is asserted as the
  newly-opened band passing, and a new row at move 3.10 (0.36 x EM) carries the over-ceiling mechanism, so the
  test still tests the gate rather than the old number. Result: **275 checks, 2 failed - the same two that
  fail on BASE, i.e. zero new failures.**
- `test_cli_surface.py` pointed at the published adapter: flag set unchanged (7 flags, none dropped), `fly
  --help` exits 0, bad-flag path still exits 2 with usage, and `decide_fly`'s signature is IDENTICAL to the
  served adapter's. It reports 2 FAILs and a KeyError - both are that child harness's own expectation that a
  candidate adds `--ticket`/`ticket_path`, which the fresh-credit work does and this change deliberately does
  not ship. Not a defect in the published bytes; recorded so the next reader does not re-litigate it.

## Cloud state - LANDED 2026-11-23T06:00:51Z (01:00 ET, within the 05:00Z-13:30Z window)

One `POST /templates/{id}` per template, six templates, all six verified. Per template the rail ran 7 checks
(array equality, both pins present exactly once, every non-target binding deep-compared, rest-of-body digest,
effective-config resolution, and all 19 top-level fields hashed and compared individually) and reported
`readback.ok=true`, `downstream outcome=as_expected`. Evidence: `after/pin-live-6/`, summary file
`mount-two-1795402802487026-1795402814211564-wrote.json`. The confirm token is recorded as length + sha256
(`49d4186b18b2…`, 17 chars), never as the string; no `system` field was touched on any template, so each of
these was a one-change write.

| template | id | guard pin now | adapter pin now | was |
|---|---|---|---|---|
| researcher | `tmpl_d7df3829ed5d73548bb5e9ed` | **1795402802487026** | **1795402814211564** | v6 + 1795318866825667 |
| executor | `tmpl_6c3c42cc4500efcbd6d60309` | **1795402802487026** | **1795402814211564** | v6 + 1795318866825667 |
| risk_auditor | `tmpl_bf2c477c0fba1a3363833f91` | **1795402802487026** | **1795402814211564** | v6 + 1795318866825667 |
| smoke-researcher-1122 | `tmpl_e0b62229b1e58b6086e80fd8` | **1795402802487026** | **1795402814211564** | v4 + 1795318866825667 |
| smoke-executor-1122 | `tmpl_f61822c674a31826e6ab42b7` | **1795402802487026** | **1795402814211564** | v4 + 1795318866825667 |
| smoke-risk_auditor-1122 | `tmpl_b5e34d87fdd260b15b4929bd` | **1795402802487026** | **1795402814211564** | v4 + 1795318866825667 |

coordinator `tmpl_19f984c8f0fd516965b63998` binds no skills and was not written.

Both targets were byte-verified as mounted, not merely named: rail (e) downloaded the archive of each pinned
version and re-hashed every file against `after/pin-expect-bytes-v7.json` - 6 guard files + 3 adapter files,
**9 hashes OK on each of the 6 templates** (54 file-hash assertions, re-counted from `after/pin-live-6/wrote-*.json`
rather than from the rail's summary line: 6 guard files + 3 adapter files per template, each entry
`{expected, actual12, ok:true}`). The other bindings (decision-journal,
trend-signal, vwap-chop, mock-moomoo) came back unchanged in place, in the original array order.

Ledger: six entries filed, one per template, `et_day 2026-11-23`, each with the rollback pair in `confirm`
and `readback.ok=true` + `downstream=as_expected` (condition A), seq **#25** researcher, **#26** executor,
**#27** risk_auditor, **#28** smoke-researcher-1122, **#29** smoke-executor-1122, **#30**
smoke-risk_auditor-1122 - change_id form `<template>-2026-11-23-skill_00vqwa9tq5szk3y13lg4+skill_00w0ip0yri8sgag736ks-b48fac8f`,
package `changes/2026-11-23-d4-loosen`, proofs in `verify/replay-*.md`. The budget gate was re-run read-only
afterwards and validated the ledger (no corruption exit) and reads every template as having exactly one change
today.

Rollback pair, and the fact that it cannot be exercised today: **guard v6 `1795387675729428` + adapter
`1795318866825667`** (production), **guard v4 `1795327622081120` + adapter `1795318866825667`** (clones). A
second guard-pin write on any of these templates is refused by condition B, because change #1 already carries
that artifact - so today's state is fixed and the earliest revert is the next ET day, Tuesday from 05:00Z.

One thing to read before trusting a clone result: the smoke clones were on guard **v4**
`1795327622081120` before this write, so syncing them to v7 moved four things at once - the SPXW universe, the
position-only one-fly-per-day cap, the X2 change and the 15:25 flat fold, on top of D4. A T2 outcome on a clone
therefore cannot be attributed to the gate alone; the offline matrix and the differential in the tests above are
what isolate D4. The production roles, by contrast, move v6 -> v7, where D4 is the only difference.

`executor-gating-rehearsal` (`tmpl_f3214189de633d9d34ce77b6`) was left untouched, but not for the reason my own
brief assumed: a read-only census of the live templates shows it binds **only decision-journal**
`1795137748003137` - no desk-risk-guard and no option-adapter at all. It was never "on v4"; the D4 gate is
unreachable in that template whatever version is published, so re-pinning it would have been a no-op dressed as
a sync. `smoke-coordinator-1122` (`tmpl_abdff737e6dc428a75f766d8`) likewise binds only the mock
(`1795341202256698`) and was not written - the D4 numbers live on the three role clones it fans out to.

### The T2 fixture for today's clone run

The owner asked T2 to use an open that passes only under the new gate. `tools/build_t2_band_fixture.py`
(builds `fixtures/t2-fly-day-d4band.json`, sha256 `a9990a2c3d30…`, log in `proof/t2-band-fixture-build.txt`)
takes the existing T2 fixture and lowers only the 09:35 open, so the 09:30-10:00 window moves
**2.61 pts = 0.2995 x em** (em 8.7152, computed by the shipped `expected_move()` from the fixture's own
spot 690.85, iv 0.212 and minutes_to_close 348) while the range stays **3.32 = 0.38 x em**, far under both
ceilings. That puts exactly one leg - the move - inside the band the 0.35 ceiling opened.

Lowering the open rather than raising the close is deliberate: the 10:00 close, every later bar, the option
chain, the combo and the ticket block stay identical, so the strike context does not move and a verdict
difference can only be D4. The builder proves that by structural diff (25 changed leaves, all inside the six
window bars plus the two annotation fields), checks the bars are a coherent feed (open == previous close,
high/low wrap o/c, 10:05 continues from the 10:00 close - an earlier cut of this builder zipped 6 bars against
5 points and left a 0.85 chained-OHLC hole, which the check now refuses), and then runs the shipped
`regime_gate()` from BOTH published trees over the same bars:

- v6 adapter `1795318866825667` + v6 rules `1795387675729428`: **pass=False** (declines, as it must)
- v7 adapter `1795402814211564` + v7 rules `1795402802487026`: **pass=True** (opens)

### The clone run: what it proved, and the one thing it did not

One live hop (`smoke/runner.mjs --scenario=T2B`, session `sess_00wc64k0aaayoztlfms0`, 187 events, 3 threads,
sim clock 2026-11-23T10:05:00-05:00 ET on the clone fleet). Capture: `smoke/run/raw/`, verdict
`smoke/run/T2B.result.json` (`pass: null` - the harness had no expectations declared, and a run without
expectations is not a pass).

**Proved live:** the loosened ceilings really are what the mounted adapter reads. The structure the researcher
emitted carries, verbatim from the cloud: `"rule":"abs(move)<0.35xEM AND range<1.00xEM"`,
`"threshold":3.083`, `"range_threshold":8.8086`, `"status":"owner_confirmed"` - and 3.083 is exactly
0.35 x em(8.8086), i.e. the fraction came from rules.json v7, not from a stale fallback.

**NOT proved: the discrimination.** That ticket's window was `move 0.12, range 0.87` - a flat open, which passes
under the OLD 0.25 ceiling too (cap would have been 2.20). The band fixture never reached the desk, and the
reason is a harness fact worth keeping: the mock skill resolves `--fixture` **by name from its own mounted
`fixtures/` directory**, and `fixtures/t2-fly-day-d4band.json` was never published there. The book seed set
`scenario/fixture_scenario = t2-fly-day-d4band`, but the book shipped without a `fixture` node (the known config
fault), so the desk repaired it with the only matching file on disk - `fixtures/t2-fly-day.json` - and got the
base flat-open bars. So today's run demonstrates the values are live, not that a 0.30 x EM open now trades; the
both-trees decline/pass split above is still the only evidence for the discrimination.

**The blocker that actually bit, and it is not D4:** the auditor vetoed the structure on the **fee gate** -
6 leg-orders x $2.308 = $13.85 against $2.72 x 100 = $272 credit = **5.09%** vs rules
`fees.option_fee_max_pct_of_premium` 3.0%. Read this together with the D4 loosening: widening the regime gate
cannot log a fly on a small-credit structure, because the fee gate rejects it downstream. That is task #54,
untouched by this change. The coordinator's own guard run agreed (`approved=false`, same fee reason) and the
desk correctly did nothing: broker stayed 0 positions / 0 orders, sleeves A and C returned NONE, and the
one-per-day warning reproduced its known no-producer state (`fly_structures_today` absent), which the auditor
told it not to hand-fill.

**The auditor's reason for that veto is wrong in one respect, and it matters.** It wrote that the ratio "is
SIZE-INVARIANT (fees and credit both linear in lots) so no re-sizing clears it". The live fee rule is not
linear in lots - `rules.json fees.fee_note` is `max(1.99, 0.65n) + 0.318n` per order per side, and the 1.99 is
a floor. Measured on the published bytes (`tools/fee_lots_probe.py`, proof `proof/fee-lots-probe.txt`, same
ticket, NAV swept so the guard sizes the lots itself):

| NAV | lots the 0.75% cap buys | fee | % of credit | guard |
|---|---|---|---|---|
| 100,000 | 1 | $13.85 / $272 | 5.09% | **veto** |
| 167,466 | 1 | $13.85 / $272 | 5.09% | **veto** |
| **167,467** | **2** | $15.76 / $544 | **2.90%** | **APPROVED** |
| 251,200 | 3 | $17.66 / $816 | 2.16% | approved |

So re-sizing DOES clear it - just not at this account's size: `sim_trade_cash_info` for 5830104 returns
`total_asset 99,998.11` (flat book), and 2 lots at `max_loss_per_lot` 628 needs NAV >= 167,467. The equivalent
statement at 1 lot is that the structure needs **credit >= 4.616/share against 2.72 quoted** - the auditor's
number, correct - but the conclusion it drew from it ("nothing can clear this") is the part that fails. At the
current geometry (width 9 = 1.02 x em, credit/width 0.302) clearing at 1 lot would need a ~15.3-point width,
i.e. roughly IV 36% rather than 21.2%. That is why this is a ruling for #54 and not a bug: at $100k NAV, a
SPY 0DTE iron fly priced at IV ~21% cannot pass the fee gate whatever D4 says, and the honest options are a
wider-credit venue (SPXW, whose legs the mock returns `4004 invalid_symbol` for, so the clone fleet can never
show it), a fee-rule change, or accepting that this week has no logged fly.



**One correction to a shipped conclusion of mine.** I had recorded `KeyError 'ticker'` as scoped to
`kind == "share"` (sleeves A/C), Sleeve B immune. Wrong as stated: `guard.py:1015` is
`ticker = proposal["ticker"]`, **before** the `kind` branch driver at :1013, with the comment "stays a hard
requirement: every branch reads it" - so an iron_fly envelope missing `ticker` aborts with a traceback and no
verdict. Measured live here: the auditor's guard run on the object it was forwarded died at :1015 with
`KeyError 'ticker'` before the iron_fly branch could run. Mitigating fact, verified in the published adapter:
the builder DOES emit the key (`sleeve_b_fly.py:934` and `:1337` both write
`"ticker": venue, "underlying": venue, "venue": venue`), so this is a transcription/degraded-envelope failure,
not a normal-path failure - but the failure mode is a crash rather than a decline, which is the same class as
the `is_close` short-circuit finding.

Cost, measured, not the number the runner printed: the runner recorded 21.2 cr at its last poll and then timed
out (hop deadline 900 s; a 504 "First Token Timeout or Upstream Timeout" with `retry_status: retrying` landed at
06:25:14Z), while the cloud session kept spending - final `GET /sessions/{id}` usage is **27.64 cr**
(24.70 model + 2.94 sandbox), against the 20 cr ceiling I passed. A deadline that expires without
`POST /sessions/{id}/cancel` does not stop the spend; the session is `idle` now, so nothing is still burning.


Rollback if the review point says revert: re-pin `1795387675729428` and `1795318866825667`. A published
version can only be superseded, never withdrawn, so v7 stays on the shelf either way.

## Review point

Before Wed 25 Nov 08:30 ET (Wed 21:30 SGT), the owner decides: keep 0.35 / 1.00, or revert to 0.25 / 0.90.
Reminded Tuesday after the close. Evidence to decide on: whether Mon/Tue produced a logged fly, what its D4
numbers were, and whether the admitted days behaved as the model predicted.

Read with one caveat from today's clone run: on that fixture class a 1-lot fly cannot be logged at all whatever
D4 says, because the fee gate vetoes it downstream (5.09% vs the 3.0% cap at 1 lot, and at this account's
$99,998 NAV the 0.75% risk cap only buys 1 lot - measured to need NAV >= 167,467 to clear). So "no logged fly
by Wednesday" is not evidence that the loosening failed - to judge the loosening you need either a
bigger-credit structure or the fee-gate ruling (#54) resolved first.

## Files

- Change package: `.scratch/changes/2026-11-23-d4-loosen/` (`try/v7`, `try/adapter-v2`, `tools/d4_matrix.py`,
  `tools/d4_parity.py`, `tools/d4_diff.py`, `tools/publish_d4.mjs`, `tools/census-pins.mjs`,
  `tools/suite/*`, `proof/`, `out/`, `after/`)
- Published byte captures: `after/guard/published-1795402802487026/`, `after/adapter/published-1795402814211564/`
- Pin plan evidence: `after/pin-dry/`, `after/pin-dry-bytes/`
- Clone run: `smoke/runner.mjs` (own copy of the `run-t11t12` harness, `PLANS` = T1/T2/T2B, own `RUN` dir),
  `smoke/clones-live.json` (generated from live `GET /templates/{id}`, records the mock pin and
  `c_mock_moomoo_bound` as measurements), result `smoke/run/T2B.result.json`, capture
  `smoke/run/raw/T2B-*.events.json`, extractors `smoke/tools/dump-msgs.mjs`, `dump-results.mjs`,
  `dump-pairs.mjs`
- Live ticket, extracted verbatim from the event stream by brace-matching its message:
  `out/live-t2b-ticket.json`; the fee/lots re-derivation on the published bytes:
  `tools/fee_lots_probe.py` -> `proof/fee-lots-probe.txt`
