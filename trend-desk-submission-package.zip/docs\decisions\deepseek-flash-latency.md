# DeepSeek-Flash as a latency fix — measured evaluation

**Status: evaluation and memo only. Nothing was applied.** No template, prompt, model, skill, schedule or
`rules.json` write; no publish or re-pin; no session created against any production template; no order or
trading tool; nothing on account 5830104. All cloud access was `GET`. **If a live switch is ever proposed it
is Tier B — owner sign-off required — and this memo does not implement it.**

- Task: `20261120T010022Z-91ba5c` (mailbox wake, `kind:ask`, payload `.scratch/mailbox/payloads/20261120T010022Z-91ba5c.md`)
- Builds on `20261119T235028Z-1f6d9b` (cost + existence + "quality unverified without a run"), which is **not**
  restated here. This memo adds the speed axis and the order-rate axis.
- Evidence: the 2026-11-19 Forward event dumps in `.scratch/flaky/` (19 thread files, 7 desk runs), read with
  scripts in `.scratch/dsflash/` (`3-round-decomp.mjs`, `5-roles-gaps.mjs`, `6-tail.mjs`, `7-cloud-readprobe.mjs`,
  `8-critical-path.mjs`, `9-per-run.mjs`, `10-lever-grid.mjs`, `11-scan-subset.mjs`, `12-actionability.mjs`,
  `13-interval.mjs`, `14-baseline.mjs`, `15-emitted.mjs`, `16-disjoint.mjs`, `17-handoff.mjs`, `18-verify.mjs` —
  the last recomputes every scenario figure quoted here so no hand-derived number ships).
- Authority: `docs/decisions/concurrent-researcher-tickers.md` is the current latency analysis; I re-derived its
  primitives rather than inheriting its conclusions, and **disagree with one of its lever rankings for the
  order-rate question** (§3).
- **Method constraint honoured.** Per the owner-verified correction `20261120T004725Z-b81f9a`, `tool_use`↔`tool_result`
  ID pairing is **invalid** on these dumps (139 of 487 result events carry no `tool_use_id`), so nothing here counts
  paired calls. What I used instead: `span.model_request_start`↔`end` pairing via `model_request_start_id` (**valid** —
  every end event carries the link), the terminating-sequence check, and `stop_reason`. Where I needed call
  attribution I assigned calls to the window they occurred **inside** (`tool_use` sits between its own window's
  start and end, not after it — my first pass got this wrong and attributed nothing).
- Claim tags: **[documented]** / **[observed]** / **[inferred]** / **[undiscoverable]**.

---

## 0. Bottom line

1. **The order-rate premise does not survive measurement.** Across the 7 desk runs of 2026-11-19 (19 threads) the
   desk journaled **22 `--kind signal` records and exactly 2 distinct actionable signals** — both `SHORT`, both in
   SCAN-1005, both at the 10:17 ET quote vintage (SQQQ 44.62/43.60/46.15 and SPXS 27.64/27.21/28.28) — and
   **both were superseded to `NONE` by the researcher's own re-checks at 10:20 and 10:26** on the strategy's
   filters, not on staleness. SCAN-1100/1230/1400 emitted `NONE` only. Orders: **zero, confirmed two ways** — the
   journal carries **no `order`, `fill` or `close` record in any thread** (kinds present: `signal` 22, `note` 32,
   `skip` 7, `verdict` 1, `journal_lost` 1) and **no `sim_trade_input_order` / `trading_order_place` call appears
   in any of the 19 dumps**. **[observed: `12-actionability.mjs`, `15-emitted.mjs`, `17-handoff.mjs`]** So the
   counterfactual "a faster model → more orders" has an observed sample of **one** candidate idea in a full
   trading day, and that idea was invalid on the numbers before any handoff completed.
2. **The SCAN-1005 SHORT did not die of latency; it died of the market moving.** The researcher's own report says
   the 10:17 leg "failed on R/R (6.91 > 5.245)" at 10:20 and "fails earlier, on the band" at 10:26, and adds the
   judgement *"Reporting it now would be chasing a 3x product already −1.07% from VWAP."* **[observed]** A
   speedup buys minutes of exposure to a level that the desk's own gates rejected within 3 minutes of it being
   struck. It is not nothing — but it is not the clean "expired unfilled" story the payload carries.
3. **All 4 SCANs breach the 300 s staleness rule, and the auditor is as big a term as the researcher.** Measuring
   the interval that actually gates an order — last quote the researcher used → the auditor's verdict — gives
   **434.5 / 368.6 / 474.7 / 434.4 s; mean 428.1 s, breach 4/4.** The payload treats this as a researcher problem.
   Mean split: **researcher tail model time 197.7 s (46.2%) vs auditor verdict-pass model time 200.4 s (46.8%)**,
   inter-agent relay 26.3 s (6.1%). **[observed: `13-interval.mjs`]** Switching only the researcher leaves the
   larger single term untouched.
4. **Answer to Q1 — the throughput-addressable fraction is 48%, not 97%, and it needs a 2.54× decode rate to
   clear the rule.** The "97% is model windows" figure is real for whole-run wall **[observed: 1,255.0/1,291.6 s
   on SCAN-1005]** but it is not what a faster *token rate* attacks. Splitting each window at the first emitted
   token: on the order-gating interval, **pre-first-token (queue + prefill + reasoning) 192.8 s = 45.4%;
   visible output decode 205.3 s = 48.4%; relay 26.3 s = 6.2%** (sums exactly to 424.4 s of the 428.1 s interval).
   Reaching 300 s needs **−124.4 s**. A pure throughput gain only shrinks the 205.3 s decode term ⇒ **2.54×**,
   and 48.4% of the interval is a ceiling, not a promise. The 45.4% pre term is *not* model token speed —
   queueing and prefill scale with context size and load, not with decode rate.
5. **Answer to Q2 — the model lever is arithmetically bigger, the edit-churn lever is certain, and neither
   passes alone.** On the order-gating interval churn is **62.0 s = 14.6%**, not the ~38% the authoritative memo
   quotes (that is churn's share of *whole-run wall*, a quantity that does not gate an order). Deleting churn
   alone: 362.4 s — **still breaches.** A model speedup alone at 1.5×: 291.7 s — passes, *if* the factor is real.
   **The lever nobody has priced is the third one: 46.8% of the interval is the auditor's verdict pass**, which
   neither the memo nor the payload measured.
6. **There is no evidence that DeepSeek-Flash is faster, and none is obtainable from any system I can read.**
   **[observed: `7-cloud-readprobe.mjs`]** The Forward model catalog advertises exactly
   `available_context_windows, default_context_window, default_effort, display_name, efforts, id, is_enabled,
   is_new, is_vl, max_input_tokens, price_factor, support_disable_reasoning, template_default_effort`. **No
   throughput, latency or speed field exists on any model entry.** `price_factor 0.1` is a price. Per payload
   instruction 4, stated plainly: **I cannot show Flash is faster in this test, and I am stopping the
   speed argument there rather than tuning for it.**
7. **Recommendation: NO-GO on a DeepSeek-Flash proposal as a latency fix, and no Tier B memo is warranted yet.**
   The cheap, certain, already-recommended fix (kill the edit thrash, and shorten the auditor's verdict pass)
   addresses 62.0 s + up to 200.4 s with a prompt change and zero model risk, against a model swap whose entire
   benefit case is unevidenced **and** whose failure mode on this desk is silent (§4). Run the phase-1 A/B in §5
   only as a *quality* gate, and treat latency as not measurable offline.

---

## 1. What the order rate actually was (the premise, tested)

The payload's chain is: latency → missed windows → fewer orders → a faster model raises order rate. The first
link is measured and true; the second is where the data breaks the chain.

| run | researcher `kind:signal` records | `LONG`/`SHORT` | final state at report | interval quote→verdict |
|---|---|---|---|---|
| SCAN-1005 | 9 | **2 SHORT** (SQQQ 44.62/43.60/46.15; SPXS 27.64/27.21/28.28) | **superseded to NONE** at 10:20 and 10:26 | 434.5 s |
| SCAN-1100 | 4 | 0 | NONE ×4 (extension, range 1.857%, extension, vwap_crosses) | 368.6 s |
| SCAN-1230 | 2 | 0 | NONE | 474.7 s |
| SCAN-1400 | 4 | 0 | NONE ×4 (`extension_cap`, `range filter 0.15-1.5%`, `>=2 running-VWAP crosses`, `extension_cap`) | 434.4 s |

**[observed]** Orders placed by the desk on 2026-11-19: **0** — no `order`/`fill`/`close` journal record in any of
the 19 threads and no order-placing MCP call in any dump (the FLAT thread independently found the account
`VACUOUS_CLEAN`). Reconciling the two signal counts quoted above: the four researcher SCAN threads hold **19**
`--kind signal` records (9 + 4 + 2 + 4); the full **22** across all 19 threads includes 3 from BRIEF/FLAT/REPORT.

Consequences for the memo's honesty:

- The upper bound on "order-rate improvement from any latency fix", measured on the only day with full dumps, is
  **one idea**, and that idea failed the desk's reward/risk and eligibility-band gates on the researcher's own
  re-measurement 3–9 min later. **[observed]**
- n = 1 is not a pattern. I cannot claim a model swap would have converted it, and I cannot claim it would not
  have. What I can claim is that the payload's "which is the concrete reason a real SQQQ/SPXS signal expired
  unfilled rather than reaching `guard.py`" is **half right**: it never reached `guard.py`, but the recorded
  reason it was not routed is that its numbers went stale *and* its gates re-failed, in the researcher's own words.
- Because the emitted `action` vocabulary here is `NONE` for 3 of 4 runs, **latency is not the binding constraint
  on order rate for most of the observed sample.** The binding constraint is the strategy's own filters, which no
  model in the catalog changes.

One genuine defect this surfaced, independent of any model choice: the researcher wrote
`"signal_at_1017_vintage": {"action":"SHORT", …}` into `research/signals_20261119_1005.json` and then superseded
it, while its report header self-declared *"DELIVERED AT 10:31 ET: the decision vintage below (quotes stamped
10:26:30) crosses the desk's 5-minute staleness limit at ~10:31:30 ET, so nothing here may be routed as an active
signal after that."* **[observed]** The correct behaviour is fail-closed at emission, and it happened — but only
because the model volunteered it in prose. Nothing in the artifact schema makes a superseded `SHORT` unrouteable,
and the auditor parses the file, not the paragraph. That is a structural fix available at Tier A and has nothing
to do with the model.

## 2. The interval that gates an order, decomposed (Q1)

Whole-run wall is the wrong denominator: the run starts ~5 min after the trigger and spends minutes on regime and
range work whose numbers the signal does not rest on. The order-gating interval is
**last quote the researcher consumed → the auditor's verdict windows** (the verdict is what the executor may act on).

Per run, mean over the 4 SCANs **[observed: `13-interval.mjs`, `16-disjoint.mjs`]**:

| component | mean | share | what can shrink it |
|---|---|---|---|
| researcher tail model time, pre-first-token | 79.1 s | 18.6% | queue + prefill + reasoning — **not** decode rate |
| researcher tail model time, output decode | 118.6 s | 27.9% | decode rate, fewer output tokens, churn deletion |
| relay (researcher end → auditor first window) | 26.3 s | 6.2% | fixed; no model lever |
| auditor verdict pre-first-token | 113.7 s | 26.8% | queue + prefill + reasoning |
| auditor verdict output decode | 86.7 s | 20.4% | decode rate, fewer output tokens |
| **interval** | **424.4 s** (wall-measured 428.1 s) | 100% | — |
| of which: output-file churn windows | 62.0 s | 14.6% | Tier A prompt fix, no model change |

Two things to read off this table:

1. **A token-throughput story can attack at most 205.3 s (48.4%) of a 424.4 s interval**, and to satisfy the 300 s
   rule it must remove 124.4 s of that ⇒ **2.54× decode throughput**, which is not advertised, measured, or
   estimable for `dfmodel` (§0.6). If instead you (wrongly, but generously) assume a "faster model" scales the
   *whole* window by one factor, the requirement drops to **1.45× across both agents** — or **2.70× if only the
   researcher switches**, which is the payload's narrower framing. **[observed components: `18-verify.mjs`]**
2. **The pre-first-token half is where the only catalog-attested lever lives.** `dfmodel` carries
   `support_disable_reasoning: true`; `efficient` carries `support_disable_reasoning: false` **[observed]**. So
   DeepSeek-Flash is *selectable for a different, evidenced reason* — you can ask it to think less, which attacks
   the 45.4% pre share — and the naive "turn reasoning off" scenario is the only one in my grid that clears the
   rule with a plausible mechanism: churn deleted **and** 60% of pre removed → **246.7 s (PASS)**.
   Note what that is: not a faster model, **a less-ratiocinating one**, on two risk-critical templates. §4 prices
   that. **[observed components, inferred scenario]**

Correlation evidence against a pure output-size story, measured on SCAN-1005's 63 windows:
`corr(window_duration, argument_bytes) = 0.35` and `corr(window_duration, credits) = 0.17` **[observed:
`3-round-decomp.mjs`]** — output volume explains a third of window-duration variance at best, which is exactly what
you would expect if a large share of each window is queue + prefill rather than decode. Pooled over all **43**
researcher tail windows in the 4 SCANs: regressing model-authored call-argument bytes on window duration gives
**30.5 chars/s with R² = 0.12** (mean ratio 56.2 chars/s) — a weak relationship, so window length is *not*
meaningfully a function of how much the model has to type. **[observed: `18-verify.mjs`]** Note also that the
pre/decode split never needed a fallback: **0 of 43 researcher tail windows and 0 of 45 auditor verdict windows
lacked an `agent.thinking` event**, so every window's first-emitted-token is directly timestamped. Cost side:
**0.246–0.432 credits/round** on researcher threads, **15.49 cr** for SCAN-1005's researcher. **[observed:
`14-baseline.mjs`]**

## 3. Which lever is bigger (Q2), and where I part company with the authoritative memo

The memo's §2 establishes ~38% whole-run wall is `Edit`/`Read` churn on `research/signals_20261119_1005.json` and
recommends deleting it first. On whole-run wall that is right. **On the order-rate question it inverts.**

| lever | interval after | passes 300 s? | evidence for the factor |
|---|---|---|---|
| churn deleted, models unchanged | 362.4 s | **no** | measured cost (62.0 s), mechanism certain |
| researcher switches, auditor does not, whole window ×k | needs **2.70×** | only at that factor | **none** — no speed field exists |
| both agents, whole window ×k | needs **1.45×**; 344.8 s at 1.25×, 291.7 s at 1.5× | yes at ≥1.45× | none |
| both agents, decode term only ×k | needs **2.54×** | no basis to assume | none |
| churn deleted + reasoning-suppressed on both | **246.7 s** | **yes** | mechanism **is** catalog-attested; magnitude is not |
| researcher infinitely fast, auditor untouched | **226.7 s** | yes | arithmetic bound, not a proposal |

**Plain answer: the model lever is bigger in arithmetic, and smaller in certainty.** The single largest removable
term with a *demonstrated* mechanism is not either one — it is the **auditor's verdict pass (200.4 s, 46.8%)**,
and shortening it is a prompt/output-shape change, not a model purchase. If the goal is orders, the ordering is:
(1) delete researcher churn, (2) attack the auditor's verdict pass, (3) re-measure, (4) only then ask whether a
different model is needed, because steps 1–2 may put the interval under 300 s with zero quality risk.

Floor, for calibration: the relay is the only term no model lever touches — **26.3 s**. Everything above the
table's last row is arithmetic on measured components; none of it is a proposal.

## 4. Quality risk specific to this desk (Q3) — where a degraded model fails *silently*

Fail-silent is the right fear, and it is locatable in live code rather than rhetorical. `guard.py` (desk-risk-guard
`1795138181446404`, the published tree read at
`.scratch/changes/2026-11-20-calendar-noentry/after/1795138181446404-tree/desk-risk-guard/scripts/guard.py`) has a
**contract asymmetry**: presence-critical fields are hard subscripts and fail loud; magnitude-critical fields are
`.get(key, default)` and fail into a number.

Loud (a model omission is caught) **[observed]**:
- `proposal["entry"], proposal["stop"]` — `KeyError`, no verdict, visible.
- `drawdown_state` refuses on non-numeric `nav`/`peak_nav`/`day_start_nav` → `state_unavailable` → decline.
- the cash gate declines on missing/non-numeric `cash` rather than guessing 0.

**Silent (a model omission changes size and the verdict still says `approved: true`)** **[observed]**:
| line | default | what a degraded model costs |
|---|---|---|
| `mult = day["size_mult"] * … * proposal.get("regime_mult", 1.0)` | 1.0 | the SCAN-1005 trigger carried `size_mult 0.5` under `bear_high_vol`; **dropping `regime_mult` doubles the size** with no reason and no warning |
| `open_risk = sum(p.get("open_risk", 0) …)` | 0 | the open-risk cap becomes slack; a mis-read position list reads as risk-free |
| `if proposal.get("entry", 0) < comp["min_price"]` | 0 → fails the $1 test, so this one is safe-by-accident | — |
| `kind = proposal.get("kind", "share")` | `"share"` | an option ticket evaluated on the share branch, i.e. share sizing on an option |
| `o.get("dte", 0)` (hedge) vs `o.get("dte", 1)` (0DTE warning) | inconsistent defaults | the same absent field reads as an error in one branch and a warning in the other |
| `protection.stop_level = proposal.get("stop")` on the option branch | — | under `mechanism: "monitored"`, a mis-copied level is *the* protective action; nothing checks it against a resting order because none can exist |

Worst compounding case, arithmetic-only: `dist = entry − stop` is bounded **only** by `if dist <= 0` and
`qty = floor(nav * risk% / 100 * mult / dist)`, so a model that emits a stop 0.1% under entry produces a huge
`qty` — which then gets capped by `q_cap` (35% single-asset) and `q_cash` (10% cash floor), i.e. **a too-tight
stop converts into a near-max single-asset position, not a small one.** No plausibility bound on `dist` exists in
the live gate. **[observed; the consequence is inferred from the code as read]** A model swap that perturbs level
selection is precisely the event that produces such a ticket, and `guard.py` will approve it.

Symbol fidelity, where the picture is better than feared: `trend-signal` `regime()` now fails **closed** to
`bear_high_vol` with `source: "fail_closed"` on missing/invalid/stale index input, and the trigger re-states the
double-dot requirement (`US..VIX` etc., "single-dot = `invalid_symbol`"). So a model that loses the symbol format
degrades toward *less* risk rather than more — **provided the `source` tag survives**. The documented failure mode
is a model that *substitutes a number instead of omitting the field* (the researcher prompt forbids exactly this).
That yields `source: "computed"` with wrong inputs and no trace at all. **[documented in the trigger + prompt;
observed in `regime`'s shipped behaviour]** On this path a different model family's compliance is genuinely unknown.

Aria note: the desk's arithmetic surface is not trivial — SCAN-1005's report shows VWAP as
`sum(turnover)/sum(volume)` over 11 completed bars cross-checked against a typical-price basis (671.2823 vs
671.2209), right-edge bar stamps, and 200-bar SMA windows computed on persisted payloads with `closes[-1]`
asserted. **[observed]** That all passed on `efficient` on 2026-11-19 — one sample. `support_disable_reasoning:
true` is a lever on the *same* arithmetic, and suppressing reasoning is the plausible way to buy the 45.4% pre
share. It is also the plausible way to break bar-stamp reasoning that is currently correct. This is why the
verdict below is gated on measured contract compliance, not on a benchmark.

## 5. The A/B that settles it, with thresholds (Q4)

**Hard constraint that shapes the design: latency is not measurable offline.** A replay of recorded tool
sequences measures *decisions*, not wall-clock under the Forward harness — queue depth, prefill cost and serving
rate are properties of the platform, and the catalog publishes none of them (§0.6). So the honest instrument is
two-phase, and phase 1 must pass before anyone spends cloud writes on phase 2.

### Phase 1 — offline replay, zero cloud writes, zero desk credits

Harness: for each of the 5 logged runs, take the recorded inbound trigger plus every tool result the live run
actually received, in the live order (`.scratch/flaky/*.json`; the sequences are already complete). Feed the
identical transcript to (a) `efficient` as control and (b) `dfmodel`, each at **its default effort and also at
reasoning-disabled where selectable** — 3 arms, because the interesting variable is reasoning, not brand.
Score the emitted artefacts. No network, no moomoo, no account.

| # | metric | how measured | **pass** | **fail** |
|---|---|---|---|---|
| M1 | JSON contract validity | parse each per-ticker signal object against the shape the live run emitted | **≥ 95% parse clean, 0 missing `stop`** | any single object that parses but omits `regime_mult`/`stop` while the control carried it |
| M2 | Fail-closed fidelity | count inputs the model *substituted* instead of omitting (breadth, `sox_5d` anchor, any `US..` index) | **identical omission set to the control, or strictly more omissions** | any substituted number the control left absent — **single-veto** |
| M3 | Symbol fidelity | index arguments passed to `regime()` | **100% double-dot `US..VIX/VXN/NDX/SPX/SOX`** | any single-dot or non-moomoo source (CBOE/web) — **single-veto** |
| M4 | Signal agreement | per ticker `action` + `instrument` vs the Efficient baseline | **≥ 3 of 4 runs identical on the *emitted final* action**; any disagreement must carry the same gate name in `reason` | an actionable `LONG`/`SHORT` where the baseline was `NONE` — **single-veto** (that is the fail-silent direction: extra risk) |
| M5 | Level arithmetic | `stop`, `target`, `vwap`, OR high/low vs baseline | **within 0.05% or exactly equal**; `dist` within the desk's own band | any `dist < 0.25%` of entry, or any `dist > opening range` that the baseline rejected — **single-veto**, this is the §4 compounding case |
| M6 | `guard.py` verdict equivalence | run both proposals through published `1795138181446404` `check` with identical `--portfolio --now --phase bounded` | **byte-identical `approved` and `qty`** | any `qty` difference >1 share, or any `true` where baseline was `false` — **single-veto** |
| M7 | Output-token proxy | `chars(model-authored tool args + messages)` and call count, per run | **report only** — a >30% cut is what makes a 2.54×-decode claim worth testing | n/a; **M7 can never justify a switch by itself** |
| M8 | Cost | credits/run from the session's `model_usage` | record against the 14.97–20.54 cr SCAN baseline | n/a |

Pre-registered decision rule: **any single-veto row in M2/M3/M4/M5/M6 ends it — no Tier B memo, no live trial.**
If all quality rows pass *and* M7 shows ≥30% less model-authored output, that is the only honest basis on which
to ask the next question, and the next question is §0.4's 2.54×.

### Phase 2 — the measurement only a cloud run can give, on a rehearsal template

Requires owner sign-off (it is a template write, so it is **not** in this task's scope and nothing was created):
one rehearsal template copying the researcher config with `model: {id: dfmodel}`, **no schedule**, driven by one
manual trigger per arm on the same recorded slot, 3 repeats. Measure with the same scripts
(`13-interval.mjs`/`16-disjoint.mjs`) the components, not the wall: **pre-first-token per round** and **chars/s in
the decode term**. A switch is evidenced only if the *interval* components drop by the ≥124.4 s the rule needs,
with M1–M6 re-passing on live output.

### Acceptance gate for ever proposing the live switch (all must hold)

1. Phase 1 M1–M6 all pass, no single-veto fires.
2. Phase 2 measures an interval reduction **≥ 124.4 s** on the researcher+auditor pair with the components
   attributed, not inferred from total wall.
3. Steps 1–2 of §3's ordering (churn deletion, auditor verdict-pass shortening) are **already done or
   demonstrated insufficient** by re-measurement — otherwise the model is being asked to outrun a bug that a
   prompt fixes.
4. The order-rate counterfactual is shown on more than one day: a `kind:signal` row that was actionable at
   emission and expired for latency reasons alone. On 2026-11-19's data that row does not exist (§1).

Until then a DeepSeek-Flash switch is **not** a latency fix; it is an unmeasured bet that trades a 45% silent-
failure surface (§4) for a speed claim no field in the system supports.

## 6. What I did not do

No template, prompt, model, skill, schedule or `rules.json` write; no publish, re-pin or session against any
production template; no order, quote-submission or trading tool of any kind; nothing on account 5830104; no
CBOE/web market source called; no file deleted. `docs/decisions/concurrent-researcher-tickers.md` and
`AGENTS.md` were read, not edited (both carry stale observations — the memo's §1 already notes the fixed
researcher name and the coordinator's now-present `multiagent` wiring; that is out of scope here). New files:
this memo and `.scratch/dsflash/` scripts 12–17. Cloud access was two `GET`s through
`.scratch/dsflash/7-cloud-readprobe.mjs`, which prints the PAT's **length (64) and never its value**; no PAT,
`.env` content, vault value or credential appears in any file, ack or result.

Two limits I am not papering over. First, **n = 1 day, 4 SCANs, 7 desk runs** — every interval figure here is a
sample of one trading day in `bear_high_vol` with `size_mult 0.5`, and §1's zero-orders finding is a statement
about 2026-11-19, not about the strategy. Second, the biggest single number in this memo — that a faster model is
faster — **is the one number I could not measure at all**, and the recommendation is built on that absence rather
than around it.
