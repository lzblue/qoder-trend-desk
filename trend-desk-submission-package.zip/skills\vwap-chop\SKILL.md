---
name: vwap-chop
description: Sleeve C VWAP-fade signal for QQQ, SMH and SPY on sessions Sleeve A rejects because the opening range is wider than 1.5%. Requires a rotating session (2+ running-VWAP crosses after the opening range), a stalled bar and |z| between 1.5 and 3.0 on volume-weighted VWAP bands. Returns a LONG, SHORT (via the 3x inverse ETF) or NONE with a reason.
---

# vwap-chop

Sleeve C. It fires **only** where Sleeve A says NONE because the opening range is too wide
(`or_width_pct > 1.5`). On such days the breakout edge is gone but the session often rotates
around VWAP, so the desk fades a stretch back toward VWAP instead.

Plain Python (stdlib only). It proposes; it never trades. Every proposal goes through
desk-risk-guard exactly like a Sleeve A signal, and the desk's existing executor ladder
and close-at-next-check protection apply unchanged - this skill chooses no entry mechanism.

## Input
```
python scripts/chop.py signal --input chop_input.json
```
```json
{"ticker":"QQQ","time_et":"12:30","or_width_pct":1.87,"inverse_price":38.11,
 "flat_by_et":"15:45",
 "bars":[{"high":..,"low":..,"close":..,"volume":..}, ...]}
```

| field | source |
|---|---|
| `bars` | today's 5-minute regular-session bars, oldest first, 09:35-stamped and later (moomoo `quote_history_kline`, ktype 6). Only close-stamped OHLCV is used; no indicator is trusted. |
| `or_width_pct` | **Sleeve A's own number**: `(or_high - or_low) / price * 100` from the same first-six-bar opening range the trend-signal run already built. Never recompute it separately. |
| `inverse_price` | last price of the mapped inverse ETF (SQQQ / SOXS). Required only when the fade is bearish. SPY has no bearish instrument right now (SPXS was removed as ineligible), so a bearish SPY fade returns `NONE` — report that as the result and do not substitute a fund of your own choosing. |
| `time_et` | scan time, `HH:MM`. |
| `flat_by_et` | `15:45`, or `12:45` on a half day (the auditor's `day` output is authoritative). |

## Rules (all must hold, else NONE with the reason)
1. `or_width_pct > 1.5` - otherwise it is Sleeve A's day, not C's.
2. `time_et` between 10:30 and `flat_by_et` minus 90 minutes.
3. At least 2 running-VWAP crosses after the first six bars - one-sided sessions are trend days.
4. `|z| = |price - vwap| / sigma` in `[1.5, 3.0]`, where `sigma` is the **volume-weighted** std dev
   of typical price around session VWAP.
5. A stalled last bar (`high <= max(high of the two prior bars)` for a bearish fade,
   `low >= min(low)` for a bullish one).
6. A 1.5R stop that clears the session extreme by `0.1 * sigma`.
7. Instrument levels must not round onto the entry price.

## Output
`action` is `LONG` (buy the 1x ETF), `SHORT` (buy the 3x inverse ETF) or `NONE`.
`entry`, `stop` and `target` are already in the **instrument's** prices, exactly as
trend-signal emits them: for a bearish fade the underlying's percentage stop and VWAP target
are scaled by 3x from the inverse ETF's own quote. `reward_risk` is 1.5: `target = VWAP`,
`stop = entry -/+ |price - VWAP| / 1.5`.

Anything missing, stale or inconsistent means NONE. Never substitute a bar, a quote or a
width - the desk treats a guessed input as an error, not as a fallback.

## Notes for the auditor
Expect very few trades: C needs a wide-range day, a rotating session, a stretch and a stall,
all inside the window. Size and caps are unchanged (same rules.json risk, same one-equity-
position-per-family-per-day gate, same portfolio check). Invalidated if after 20 closed
Sleeve C trades the net expectancy after fees is negative - the expectancy gate then
disables it on its own.
