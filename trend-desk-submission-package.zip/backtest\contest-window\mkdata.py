"""Derive scan-time inputs (opening range, session VWAP, price) from real 5-min bars.

Step 1 of the live-faithful backtest: prove this reproduces the hand-built
.scratch/bt/inputs.json rows before any execution model is layered on top.
Bars come only from persisted moomoo quote_history_kline payloads (UTF-8: the
bar dicts carry CJK sc_name/tc_name, so an encoding must be stated explicitly).
"""
import glob
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
SCANS = ("10:05", "11:00", "12:30", "14:00")


def load_bars(ticker, pages_dir=None):
    """Return {session_date: [bar, ...]} for one ticker, bars ordered by time_key."""
    files = sorted(glob.glob(os.path.join(HERE, "moomoo_quote_history_kline_*.txt")))
    files += sorted(glob.glob(os.path.join(HERE, "pages", "intraday_*.json")))
    if pages_dir:
        files += sorted(glob.glob(os.path.join(pages_dir, "*.json")))
    by_session = {}
    seen_names = set()
    for f in files:
        try:
            payload = json.loads(open(f, encoding="utf-8").read())
        except (ValueError, OSError):
            continue
        klines = (payload.get("data") or {}).get("kline_list") or []
        if not klines:
            continue
        if ticker not in NAMES.get(f, set()):
            continue
        for b in klines:
            by_session.setdefault(b["date"], {})[b["time_key"]] = b
        seen_names.add(f)
    return {d: [bars[tk] for tk in sorted(bars)] for d, bars in sorted(by_session.items())}


def tickers_in_file(path):
    try:
        payload = json.loads(open(path, encoding="utf-8").read())
    except (ValueError, OSError):
        return set()
    klines = (payload.get("data") or {}).get("kline_list") or []
    return {b.get("name", "") for b in klines}


# moomoo returns the long fund name, not the symbol; map once, from the payloads themselves.
NAME2SYM = {
    "Invesco QQQ Trust": "QQQ",
    "SPDR S&P 500 ETF": "SPY",
    "VanEck Semiconductor ETF": "SMH",
    "ProShares UltraPro Short QQQ ETF": "SQQQ",
    "Direxion Daily S&P 500 Bear 3X Shares ETF": "SPXS",
    "Direxion Daily Semiconductor Bear 3x Shares ETF": "SOXS",
    "iShares Russell 2000 ETF": "IWM",
    "Direxion Daily Small Cap Bear 3X Shares": "TZA",
    "SPDR Dow Jones Industrial Average ETF": "DIA",
    "Direxion Daily Dow Jones Internet Bear 3X Shares": "SDOW",
    "Financial Select Sector SPDR Fund": "XLF",
    "Direxion Daily Financial Bear 3X Shares": "FAZ",
    "iShares 20+ Year Treasury Bond ETF": "TLT",
    "Direxion Daily 20+ Year Treasury Bull 3X Shares": "TMV",
    "SPDR Gold Shares": "GLD",
    "ProShares UltraShort Gold": "GLL",
    "Energy Select Sector SPDR Fund": "XLE",
    "Direxion Daily Energy Bear 3X Shares ETF": "ERY",
}

NAMES = {}


def all_intraday_files():
    return (sorted(glob.glob(os.path.join(HERE, "moomoo_quote_history_kline_*.txt"))) +
            sorted(glob.glob(os.path.join(HERE, "pages", "intraday_*.json"))))


def index_files():
    """Fill NAMES[filepath] = {symbols} by reading each payload's bar `name`."""
    for f in all_intraday_files():
        NAMES[f] = {NAME2SYM.get(n, n) for n in tickers_in_file(f)}


def load_all():
    """Parse every intraday source once -> {ticker: {session_date: [bars by time]}}.

    bars/ is the deduplicated merged store and wins where it has a session; the raw
    payloads still fill any ticker or day the store does not cover, so a partially
    fetched extension degrades to the older window rather than to nothing.
    """
    out = load_merged()
    index_files()
    for f, syms in NAMES.items():
        if len(syms) != 1:
            continue
        try:
            klines = json.loads(open(f, encoding="utf-8").read())["data"]["kline_list"]
        except (ValueError, OSError, KeyError):
            continue
        sym = next(iter(syms))
        have = out.setdefault(sym, {})
        for b in klines:
            if b["date"] in have:
                continue
            have.setdefault(b["date"], {})[b["time_key"]] = b
    return {t: {d: [m[k] for k in sorted(m)] for d, m in s.items()} for t, s in out.items()}


def _tz(bar):
    """UTC offset of a bar. Bars from the merged store carry no time_zone field, and
    assuming one offset for the whole window is wrong: this range spans the DST end
    (2026-11-01), so October is -4 and November is -5. Resolve it from the exchange
    calendar instead of a constant."""
    if "time_zone" in bar:
        return bar["time_zone"]
    import datetime as dt
    try:
        from zoneinfo import ZoneInfo
        utc = dt.datetime.fromtimestamp(bar["time_key"] / 1000.0, dt.timezone.utc)
        off = utc.astimezone(ZoneInfo("America/New_York")).utcoffset()
        return int(off.total_seconds() // 3600)
    except Exception:
        raise SystemExit("zoneinfo/tzdata unavailable: cannot resolve the October/November "
                         "UTC offset, and a hardcoded one silently shifts every scan bar")


def hhmm(bar):
    """Wall-clock ET stamp of a bar's time_key (ms epoch, exchange tz as reported)."""
    import datetime as dt
    return dt.datetime.utcfromtimestamp(bar["time_key"] / 1000.0) + dt.timedelta(
        hours=_tz(bar))


def load_merged():
    """{ticker: {date: {time_key: bar}}} from the deduplicated bars/<TICKER>.json store.

    Keys stay as the raw time_key ints and the shape stays a dict: load_all overlays the
    legacy payloads onto dates this store does not cover, and a silently skipped unreadable
    file would turn into trading a subset of tickers while reporting a full sample.
    """
    out = {}
    for f in sorted(glob.glob(os.path.join(HERE, "bars", "*.json"))):
        sym = os.path.basename(f)[:-5]
        try:
            store = json.loads(open(f, encoding="utf-8").read())
        except (OSError, ValueError) as exc:
            raise SystemExit("bars/%s.json will not parse (%s): refusing to run the backtest "
                             "on the tickers that did load" % (sym, exc))
        if not isinstance(store, dict):
            continue
        bucket = out.setdefault(sym, {})
        for k, b in store.items():
            tk = int(k) if str(k).isdigit() else k
            # the store keys bars BY time_key, so the bar itself has no time_key field;
            # everything downstream stamps bars from that field, so put it back
            b.setdefault("time_key", tk)
            bucket.setdefault(b["date"], {})[tk] = b
    return out


def derive_session(bars, scan):
    """Opening range = first six 5-min bars; price/vwap as of the bar stamped `scan`."""
    if len(bars) < 7:
        return None
    if hhmm(bars[0]).strftime("%H:%M") != "09:35":
        # truncated day (a pagination boundary cut the session): the first six bars are
        # not the opening range, so refuse rather than invent one
        return None
    or_bars = bars[:6]
    or_high = max(b["high"] for b in or_bars)
    or_low = min(b["low"] for b in or_bars)
    pv = vv = 0.0
    for b in bars:
        tp = (b["high"] + b["low"] + b["close"]) / 3.0
        v = b.get("volume") or 0
        pv += tp * v
        vv += v
        stamp = hhmm(b).strftime("%H:%M")
        if stamp == scan:
            break
    vwap = pv / vv if vv else None
    price_bar = next((b for b in bars if hhmm(b).strftime("%H:%M") == scan), None)
    if price_bar is None or vwap is None:
        return None
    return {"price": price_bar["close"], "vwap": round(vwap, 4),
            "or_high": or_high, "or_low": or_low, "rng": round(or_high - or_low, 2)}


def main():
    index_files()
    wanted = {f: sorted(NAMES[f]) for f in NAMES if len(NAMES[f]) == 1}
    print("payload files ->", json.dumps({os.path.basename(f)[-16:]: v[0] for f, v in wanted.items()}))
    for f, s in wanted.items():
        pass
    # sanity: show the bar stamp convention on one known session
    qqq = load_bars("QQQ")
    d = 20261112 if 20261112 in qqq else sorted(qqq)[0]
    print("\nsession", d, "bars", len(qqq[d]), "first stamps:",
          [hhmm(b).strftime("%H:%M") for b in qqq[d][:8]])
    print("OR(first 6) high/low:", max(b["high"] for b in qqq[d][:6]), min(b["low"] for b in qqq[d][:6]))

    inputs = json.load(open(os.path.join(HERE, "inputs.json"), encoding="utf-8"))
    cache = {}
    ok = bad = miss = 0
    diffs = []
    for row in inputs:
        t = row["ticker"]
        cache.setdefault(t, load_bars(t))
        sessions = cache[t]
        bars = sessions.get(row["date"])
        if not bars:
            miss += 1
            diffs.append(("NO_BARS", t, row["date"], row["scan"]))
            continue
        got = derive_session(bars, row["scan"])
        if got is None:
            miss += 1
            diffs.append(("NO_DERIVE", t, row["date"], row["scan"]))
            continue
        want = {k: row[k] for k in ("price", "or_high", "or_low")}
        # vwap compared loosely: the prior rows may have used a different typical-price rule
        tol = {"price": 0.005, "or_high": 0.005, "or_low": 0.005}
        bads = [k for k, tv in tol.items() if abs(got[k] - want[k]) > tv]
        vwap_gap = abs(got["vwap"] - row["vwap"])
        if bads:
            bad += 1
            if len(diffs) < 12:
                diffs.append(("FIELD", t, row["date"], row["scan"], bads,
                              {k: (want[k], got[k]) for k in bads}, "vwap_gap=%.4f" % vwap_gap))
        else:
            ok += 1
            if vwap_gap > 0.02 and len(diffs) < 12:
                diffs.append(("VWAP_ONLY", t, row["date"], row["scan"], round(vwap_gap, 4)))
    print("\n=== derive vs inputs.json: exact=%d mismatch=%d unavailable=%d of %d ==="
          % (ok, bad, miss, len(inputs)))
    for x in diffs:
        print("  ", x)


if __name__ == "__main__":
    main()
