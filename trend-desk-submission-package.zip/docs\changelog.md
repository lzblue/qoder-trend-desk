# Changelog

Running summary of meaningful changes to this repo and to the live cloud desk
(skill versions shipped, `rules.json` diffs, prompt edits, decision memos), as
required by the change-control procedure. Newest entry first.

## 2026-11-26 09:2x SGT (2026-11-26T01:2xZ) — dashboard, submission-facing fixes

Local dashboard code only; **no cloud template, skill pin, schedule or order was
touched**, so there is nothing to roll back remotely.

- **Header chip** (`server.js`, `status.state`) now names the desk's risk ladder state
  (`normal` / `caution` / `daily_halt` / `hedges_and_closes_only` / `kill_switch`), taken
  from the newest mined verdict that prints `state`. It used to render a single vetoed
  proposal as `BLOCKED`, which a reader took to mean the whole desk was blocked.
- **Documentation reads are no longer mined as desk output** (`server.js`,
  `docReadCallIds` + `collectFromEvents`). A tool result is attributed to the call that
  produced it; if that call read a markdown document the result is dropped. This removed
  86 events in the current 40-session window, including 5 copies of the same
  `{"ticker":"QQQ","approved":false,"reasons":["event blackout 13:45-14:30 ET"]}` example
  from `decision-journal/SKILL.md` — 8 of the 14 Decision Log rows had been documentation,
  not decisions. A Bash call that runs desk code (`python3`, `guard.py`, `journal.py`, …)
  is exempted, so a real verdict cannot be lost to the filter; measured on this window the
  exemption costs no documentation-only read. Count exposed as
  `mining.doc_read_events_skipped` and printed in the panel footer.
- **Broker order rows decode honestly** (`public/sleeveb.js` `orderStatusCode`):
  `sim_trade_history_order_list` answers `"5 cancelled"` where `sim_trade_order_list`
  answers `5`. Both now map, the dedupe key uses the code, and a code outside
  {2,4,5} is labelled with its raw value instead of being called a fill or a cancel.
  History rows carry no `create_time`, so the timeline falls back to the event stamp.
  Effect on the current window: 13 rows → 11, `state_unavailable` → 0.
- **Everything trading-related renders in America/New_York** (`public/app.js` `fmtTime`,
  `fmtClockEt`, `sleeveb.js` `fmtEt`). The serving machine is UTC+8, which had been
  printing a 16:15 ET REPORT as "5:15 AM".
- **No bare `unknown` / `—` left in the panels**: the all-zero `unknown` sleeve chip is
  omitted, `Max loss used` / `Premium headroom` state why they have no number
  (`no credit structure open`), `NAV` says `no equity row mined yet`, and the regime
  fallback says `not stated in this record` instead of echoing the `source` field.
- **Chart axes are labelled** (`drawLineChart` `scale.fmtY`): four ledger points spanning
  0.17% of NAV had drawn as a cliff.
- **Capability captions come from the server** (`capNote`, `premium_cap_source`,
  `max_loss_cap_source`) instead of the stale hardcoded `(D3; staged, not live)`.
- **`deliverables/dashboard-capture.gif`** (379,361 B, 6 frames, 1680x1000, 0.7 s per
  frame — a 4.2 s loop): real Chrome-CDP screenshots of the running page on 2026-11-26,
  scrolling and pressing **Refresh now**. No frame is a mockup and no number was authored
  for the capture. The builder had passed centiseconds to `gifenc`, which already converts
  milliseconds, so the first build played ten times too fast (0.42 s); the stored delays
  are 70 cs and were re-read from the file's graphic-control blocks.
- **README** documents child-thread mining, the documentation-read exclusion, the capture,
  and corrects a stale `server.js:185-188` citation (the key lists are `:262-265`).

## 2026-11-20 07:3x SGT (2026-11-19T23:3xZ)

- **Repo hygiene**: local git baseline created. `.gitignore` was rewritten to exclude
  `.scratch/` (first rule), `.env`, `*.key`, `*.pem`, `node_modules/`, `*.log` **before**
  `git init`, so no mailbox or token-adjacent material is tracked. One scoped commit covers
  the dashboard app (`server.js`, `public/`, `package.json`, `package-lock.json`,
  `.env.example`) and `docs/`. No remote configured and nothing pushed — local-only.
  Verification: `git check-ignore -v` shows `.scratch/` and `.env` ignored; `git ls-files`
  contains no `.scratch` or `.env` entry; scrub grep for `claude|anthropic` across the
  committed set returned zero hits, so no file content was rewritten for this commit.
