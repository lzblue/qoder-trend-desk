# Portability notes (post-contest: local model / OpenClaw migration)

Purpose: a running inventory of what's already portable off Qoder vs. what's
coupled to it, built lazily as a side-effect of normal work -- not a dedicated
audit. Add a one-line note here only when you notice something while doing
something else for a different reason. Don't go looking for this on purpose.

Context: the desk may move to a local agent framework (OpenClaw or similar,
local GPU inference via Ollama/llama.cpp) after the 17-28 Nov 2026 contest
ends. Until then this file is purely additive documentation -- it changes no
template, skill, schedule or trading behaviour, so it needs no change-control
window and no sign-off to edit.

## Already portable, no rework expected

- **moomoomcp**: a standard MCP server. OpenClaw (and most agent frameworks)
  speak MCP natively -- this should attach unchanged regardless of what
  orchestrates the agents or which model runs them.
- **Skill code** (trend-signal.py, guard.py/desk-risk-guard, journal.py,
  vwap-chop, option-adapter): plain Python with a SKILL.md contract, not
  Qoder-template syntax. Should run under any orchestrator that can execute a
  script and pass it the same inputs.
- **rules.json / desk-risk-guard's gates**: deterministic code+config, not
  LLM judgment. Risk enforcement doesn't depend on which model is reasoning
  upstream -- this is a big reason the system's safety properties shouldn't
  degrade much even on a weaker local model.
- **The mailbox protocol** (`.scratch/mailbox/`, CONTRACT.md, JSON
  ack/message schema): pure filesystem + JSON. No Qoder dependency at all.

## Coupled to Qoder or to the current cloud model -- fill in as noticed

(empty by design -- this fills in opportunistically over the remaining
contest days)

- Schedule/cron timing currently lives only in Qoder's template JSON, not in
  a portable schedule file. [example placeholder -- confirm/replace when
  someone actually touches a template's schedule]
- Any prompt wording in coordinator/researcher/risk_auditor/executor that
  implicitly relies on a specific model's reasoning strength or quirks
  (rather than being fully explicit) is a hidden coupling -- the DeepSeek-
  Flash A/B (91ba5c) is already probing exactly this for two of the four
  templates.

## Standing instruction for future tasks

Any task that touches a skill or template for its own (unrelated) reason:
if you notice a Qoder-specific or model-specific coupling in passing, add
one line to the second section above. Zero extra scope otherwise -- this is
not a reason to expand what the task does.
