# Tier B decision memo — SPXS is ineligible; remove it (A) or swap to SH (B)

**Status: proposal only. Nothing was applied.** No skill publish, no re-pin, no template write, no schedule
change, no `rules.json`/`guard.py`/`trend_signal.py`/`chop.py` edit outside
`.scratch/changes/2026-11-20-spxs-eligibility/`, and no order or account call on 5830104. Cloud calls this
session were reads: the 01:50Z snapshot under `before/` plus two accidental-by-omission dry runs that each did
`GET /templates` ×1 and `GET /skills/{id}` ×3 against production before the test harness was pointed at a local
mock (see §9). Every moomoo call was a quote-side read. Both packages were executed end-to-end against
`tools/mock-forward.mjs`, never against production.

- Task: `20261120T013558Z-b4d721` (mailbox wake) · prepared 2026-11-20 02:00–02:40Z
- Change dir: `.scratch/changes/2026-11-20-spxs-eligibility/`
- Claim tags: **[documented]** = written in a repo file or an official page I read; **[observed]** = read from a
  live system this session; **[undiscoverable]** = not knowable from here.

---

## 0. Bottom line

1. **The violation is real and live.** `SPXS` — the engine's bearish instrument for SPY in both Sleeve A
   (`trend_signal.PAIRS`) and Sleeve C (`chop.INVERSE`) — has net assets of **$322.7M** [observed 2026-11-20
   02:19Z, `quote_market_snapshot`], below the [documented] "$1 price / market cap under $500M is not eligible"
   bar (`docs/contest-rules-notes.md:42-43`). `desk-risk-guard`'s `rules.json` lists it in `universe.shares`
   and `universe.leverage`, so the guard approves it.
2. **Package A (remove) is the recommendation.** It is the only option whose behaviour is fully specified
   today: SPY keeps its long leg, loses its short leg, and every SPY-bearish path returns NONE with a reason.
   Cost: the desk cannot express a bearish SPY view until you name a replacement.
3. **Package B (swap to SH) is eligible but not like-for-like.** SH is the only inverse S&P 500 ETF of the five
   I could check that clears $500M ($971.2M) [observed]. It is **1x**, so the same signal produces a ticket with
   roughly 2/3 of SPXS's planned risk and 2x its notional, with the 35% single-asset cap binding before the
   0.35% risk budget (§4.3). Picking a new tradable ticker is your Tier B call; B is prepared, verified, and
   deliberately **not** the default.
4. **One surface is outside both packages:** the coordinator prompt, line 7, still says bearish ideas buy
   "(SQQQ, SOXS, SPXS)". That is a template text edit. It is listed as a follow-up in §7 rather than wired into
   either apply script, because a prompt edit is a different write with its own verification.
5. **No evidence the desk ever traded SPXS.** Local records contain `"instrument": "SPXS"` only in backtest
   fixtures, never in a ticket or a decision-journal entry [observed]. The exposure is potential, not realized.

---

## 1. What is live (read from the API, not from AGENTS.md)

Snapshot `before/live-read-2026-11-20T015003152Z.json` (01:50Z), cross-checked by `tools/show-pins.mjs`:

| skill | live version | bound on |
|---|---|---|
| desk-risk-guard | `1795138181446404` (v13) | researcher, risk_auditor, executor (3) |
| trend-signal | `1795047415929677` | researcher (1) |
| vwap-chop | `1795095917868411` | researcher, risk_auditor, executor (3) |
| decision-journal | `1795137748003137` (v3) | researcher, risk_auditor, executor, executor-gating-rehearsal |

All bindings are explicitly pinned; none resolves to latest. Every production skill tree is unpacked under
`live/<skill>-<version>/` and the diffs in each package are taken against those bytes.

**Correction to the brief:** Sleeve C is live *and* `vwap-chop` is bound on **three** templates, not just the
researcher. That does not add a template write (the re-pin is one POST per template anyway) but it does mean the
Sleeve C change reaches the auditor and the executor too.

## 2. The four files that carry the ticker (five files per package)

`grep -rn SPXS live/` returns exactly:
[documented-code, observed-bytes]

| file | what it does |
|---|---|
| `trend-signal/scripts/trend_signal.py:21` | `"SPY": {"long": "SPY", "short": "SPXS", "lev": 3}` |
| `trend-signal/SKILL.md:52` | "buy the 3x inverse ETF: SQQQ for QQQ, SOXS for SMH, SPXS for SPY" |
| `vwap-chop/scripts/chop.py:28` | `INVERSE = {"QQQ": ("SQQQ",3), "SPY": ("SPXS",3), "SMH": ("SOXS",3)}` |
| `vwap-chop/SKILL.md:30` | "last price of the mapped inverse ETF (SQQQ / SPXS / SOXS)" |
| `desk-risk-guard/references/rules.json:34,36` | `shares` includes SPXS; `leverage.SPXS = 3` |

`book.py`, `levels.py`, `calendar_rules.py` and `guard.py` contain no ticker table — both packages prove this
byte-for-byte (§3.3), so the release is five changed files across three skills.

## 3. Package A — remove SPXS (recommended)

### 3.1 Behaviour
- `PAIRS["SPY"]["short"] = None`; the SHORT branch returns
  `{"action":"NONE","reason":"SPY has no eligible bearish ETF configured - long entries only"}` **before** it
  looks at `inverse_price`, so no quote can resurrect the trade.
- `chop.INVERSE["SPY"] = (None, 0)` and the SHORT branch returns NONE with the same class of reason. `FAMILY`
  no longer maps SPXS at all.
- `rules.json`: SPXS out of `universe.shares` **and** `universe.leverage` in the same release (the paired-edit
  rule — §6). A new SPXS buy is vetoed with "not in the approved share universe"; an existing SPXS position can
  still be **closed**, because `guard.check()` returns "closing order: always allowed" before the universe gate.
- SPY long, QQQ short (SQQQ), SMH short (SOXS) and every long path are byte-identical to live output
  (`roundtrip/behaviour-A.txt`, section 4).

### 3.2 Artifacts it needs
- 3 new skill versions: desk-risk-guard, trend-signal, vwap-chop (version numbers exist only at publish time).
- 3 template POSTs: researcher (3 skills), risk_auditor (2), executor (2).

### 3.3 Verification actually run
- `tools/assert-behaviour.py A` — **32/32 PASS** (`roundtrip/behaviour-A.txt`): compile, byte-identical
  report-only modules, live-violation reproduction, untouched-path equality, A's NONE paths, guard veto +
  close exemption, rules pairing, determinism.
- Round-trip against the mock (`roundtrip/roundtrip-result.txt`): refusals intact, dry run writes nothing,
  apply = 6 POSTs (3 versions + 3 templates), per-file published bytes match the package, effective config
  resolves, rollback restores every template's `skills` array **byte-identically** to `before/`.
- `A-remove-spxs/diff/*.diff` show exactly the five files.

## 4. Package B — swap SPXS → SH (prepared, informational)

### 4.1 The scan [observed 2026-11-20 02:19Z, `B-substitute/market-data-2026-11-20.json`]

| ticker | fund | lev | net assets | last | day volume | day turnover |
|---|---|---|---|---|---|---|
| **SH** | Short S&P 500 Proshares | 1x | **$971.2M** | 34.68 | 21.8M sh | $749.0M |
| SPXS | Direxion Daily S&P 500 Bear 3X | 3x | $322.7M | 29.71 | 21.6M sh | $621.1M |
| SPXU | ProShares UltraPro Short S&P500 | 3x | $424.5M | 41.74 | 25.0M sh | $1.01B |
| SDS | Proshares Ultrashort S&P500 | 2x | $435.1M | 61.92 | 7.2M sh | $434.0M |
| SPDN | Direxion Daily S&P 500 Bear 1X | 1x | $285.8M | 9.08 | 255.1M sh | $2.29B |

Only SH clears the $500M floor, and it is liquid by the same bar (bid/ask 34.71/34.73 = 5.8 bp). **Coverage
limit [undiscoverable]:** `quote_stock_screen` has no name/text filter, so an exhaustive enumeration of every
inverse S&P 500 product is not possible with the tools available; a product not in this list cannot be ruled in
or out from here.

### 4.2 Behaviour
- `PAIRS["SPY"] = {"long":"SPY","short":"SH","lev":1}`, `chop.INVERSE["SPY"] = ("SH", 1)`;
  `rules.json` drops SPXS and adds `"SH": 1`.
- Levels are scaled by the instrument's own leverage: at 1x the stop/target distance equals the underlying's
  percentage move (asserted in `behaviour-B.txt`), where SPXS was scaled 3x.

### 4.3 What changes in the sizing (measured, same fixture ticket)
Same SPY breakdown (price 699, OR 700–706, VWAP 703), same portfolio (NAV 100k, cash 60k, size_mult 1.0):

| | instrument | qty | notional | effective gross | trade risk | binding cap |
|---|---|---|---|---|---|---|
| live | SPXS 3x | 514 | $17,826 | $53,477 (53%) | $351.67 (0.35%) | risk per trade |
| B | SH 1x | 1009 | $34,992 (35%) | $34,992 (35%) | $234.38 (0.23%) | **35% single-asset target** |

So B is not a drop-in: it buys ~2x the notional, carries ~1/3 less planned risk per ticket, and the capital cap
— not the risk budget — becomes the limiter. That is a strategy change, not a config swap, which is why it is
yours to choose.

### 4.4 Artifacts it needs
Same shape as A: 3 new versions (desk-risk-guard, trend-signal, vwap-chop) + the same 3 template POSTs.

### 4.5 Verification actually run
- `tools/assert-behaviour.py B` — **38/38 PASS** (`roundtrip/behaviour-B.txt`), including stop<entry<target at
  1x, R/R ≈1.5, the exact 1009-share cap-bound sizing, and the veto on an old SPXS ticket.
- Same mock round-trip: 6 POSTs, per-file byte match, rollback byte-identical.

## 5. How to run or undo (both packages)

```
# choose (dry run first; the flag is the choice, GO=1 is the write)
CONFIRM=REMOVE-SPXS-A     PORTFOLIO_JSON=<dump.json> bash .../A-remove-spxs/apply.sh
CONFIRM=REMOVE-SPXS-A     PORTFOLIO_JSON=<dump.json> GO=1 bash .../A-remove-spxs/apply.sh
CONFIRM=ROLLBACK-SPXS-A   GO=1 bash .../A-remove-spxs/rollback.sh

CONFIRM=SWAP-SPXS-SH-B    PORTFOLIO_JSON=<dump.json> bash .../B-substitute/apply.sh
CONFIRM=SWAP-SPXS-SH-B    PORTFOLIO_JSON=<dump.json> GO=1 bash .../B-substitute/apply.sh
CONFIRM=ROLLBACK-SPXS-B   GO=1 bash .../B-substitute/rollback.sh
```

Each `apply.sh` refuses with exit 2 without its flag, and refuses (exit 1) when:
- `PORTFOLIO_JSON` is missing, is not a live dump, or lists an open SPXS position (§6);
- the candidate tree differs from the live bytes in anything other than the five allowed files;
- a skill's `latest_version` has moved off the version the package was cut from;
- an unpinned binding exists on any template it would write (a wholesale array write would freeze it).

Rollback re-pins the three skills to `before/map-rollback.json` and verifies with `--bindings-only`. A published
version cannot be withdrawn, only superseded, so rollback restores the binding, not the version list. Nothing
restores `created_at`/`updated_at`, which the platform moves on any write.

## 6. The paired-edit hazard cuts both ways

`docs/decisions/ticker-universe-nov20.md` §7.3 records the *addition* hazard: `guard.py` uses
`leverage.get(ticker, 1)`, so adding a leveraged ticker to `universe.shares` without its leverage entry sizes it
at 1x and silently permits far too much exposure. The *removal* direction has the twin problem: dropping
`leverage.SPXS` while an SPXS position is still open makes `eff_now` value that position at 1x, which
**understates** gross exposure. Both packages therefore require a `PORTFOLIO_JSON` dump proving no open SPXS
position before they will run; that precondition is exercised in the round-trip test.

## 7. Follow-ups deliberately not in either package

1. **Coordinator prompt line 7** — "(SQQQ, SOXS, SPXS)". A text edit on `tmpl_19f984c8f0fd516965b63998`; no
   skill version involved. It does not change trading behaviour (the coordinator places no orders), but it is
   wrong text that would keep a stale ticker in front of the orchestrator. Apply it after A or B lands, with its
   own read-back.
2. **A replacement 3x bearish SPY instrument**, if you want SPY's short leg back. Nothing in the five checked
   clears $500M at 3x, so this needs a name from outside that list, or a rule interpretation you are willing to
   accept.
3. **A decision on whether "market cap" applies to ETFs at all.** The desk has been using fund net assets as the
   proxy since the 5e8c3a memo. If the organisers meant parent-company market cap, SPXS's issuer is large and the
   whole finding changes; that is a question for them, not something this memo can settle [undiscoverable].

## 8. Evidence index

| what | where |
|---|---|
| live snapshot (skills, templates, effective config, downloaded trees) | `before/`, `live/` |
| diffs, exactly five files per package | `A-remove-spxs/diff/`, `B-substitute/diff/` |
| offline behaviour proof | `tools/assert-behaviour.py` → `roundtrip/behaviour-A.txt` (32/32), `behaviour-B.txt` (38/38) |
| apply/rollback round-trip vs mock | `tools/roundtrip-test.sh` → `roundtrip/roundtrip-result.txt` (31/31) |
| market data | `B-substitute/market-data-2026-11-20.json` |
| rollback target versions | `before/map-rollback.json` |

## 9. Limits and honesty about what was touched

- **The mock is not the API.** It models the endpoints and the whole-array `skills` replace, stores uploads,
  serves them back as a zip for per-file comparison, and moves `updated_at`. It does not model auth, idempotency
  semantics, rate limits, or the real `content_sha256`. The production behaviours those hide are exactly the ones
  every previous publish in this repo already exercised; the round-trip proves this change's *logic*, not the
  platform's.
- **Two dry runs reached production by omission.** Before the harness set `FORWARD_BASE`, two invocations of
  `A-remove-spxs/apply.sh` in dry-run mode used the real base for their read-only gates: `GET /templates` twice
  (the pin table, once per run) and `GET /skills/{id}` three times (the version gate, second run only — the first
  stopped at the file-integrity gate before any skill read). All of them returned the versions recorded at 01:50Z,
  i.e. nothing had drifted. No write is reachable without `GO=1`, and `GO` was never set in those invocations.
- **Published versions are irreversible.** The moment either package is applied, its versions exist for good.
  That is why both gates abort instead of warn, and why the packages are not "one flag away" in this session.
- **Prices in the fixtures are synthetic.** The Sleeve C bars are a deterministic seed-1 series plus its exact
  mirror; the trend-signal fixture is a hand-set summary. The real-data sweep of 38 sessions × 3 tickers × 3
  scans found no SPY Sleeve C fire at all (`tools/real-fires-spy.json` is empty), which is why synthetic
  fixtures were used.

---

## 9. Correction appended 2026-11-20T03:50Z by `20261120T032028Z-b6e923` — §0.1's "violation is real" is interpretation, not documentation

Nothing above this line was edited. Appended because this memo's owning task
(`20261120T013558Z-b4d721`) has ack `done`, so no session is inside this file. Full audit with every other
memo: `docs/decisions/rules-source-of-truth-nov20.md`.

The official rules page was re-read in full at 03:28Z. Its eligibility floors are written **per instrument
class**, and neither of them names ETFs:

> - Only **U.S.-listed stocks, ETFs, and options** may be traded. All other instruments are excluded. *(§1)*
> - Stocks priced below **USD 1** are not eligible for trading. *(§3)*
> - Stocks and options of companies with a market capitalisation below **USD 500 million** are not eligible
>   for trading. *(§3)*

`docs/contest-rules-notes.md:42-43` collapses those two floors into one sentence attached to the
stocks/ETFs/options product list, and §0.1 of this memo cites that line correctly — which is how
"the violation is real and live" came to read as though the page said it. It does not. Consequences, in
order of how much they change this memo:

1. **§0.1 should read "real under the desk's interpretation of the floor", not "real".** The $500M bar is
   written against *companies'* market capitalisation; SPXS is a trust with net assets, and §7 item 3 of
   this memo already identified that substitution as the open question. The correct label for §0.1's claim
   is therefore the one §7 item 3 already used — **[undiscoverable]** from the page — and the two sections
   should no longer disagree with each other.
2. **Package A (remove SPXS) is unaffected and remains the safer recommendation.** Its case does not rest
   on the floor: it is the option whose behaviour is fully specified, and removing a vehicle is
   risk-reducing under *either* reading of the rule. §0.2 stands as written.
3. **Package B's wording does not survive.** "SH … **is eligible**" (§0.3) carries the same inference.
   What the page supports is "SH clears the desk's net-assets proxy at $971.2M"; eligibility under the
   written rule is undetermined for any ETF, including SH.
4. **The desk's code is more precise than its documentation, and this memo should point at it.** In live
   `desk-risk-guard 1795138181446404`, the price floor is enforced at `guard.py:190` **inside
   `if kind == "share"`**, i.e. scoped to stocks exactly as the page words it; and `min_market_cap_usd`
   appears in `rules.json:12` but in **no** code file — so the market-cap floor is neither interpreted nor
   enforced, it is only asserted. Any fix that decides the ETF question should land as an enforced check
   with its interpretation written down, not as a prompt sentence.
5. **One floor the page *does* extend, and this memo does not test: options.** "Stocks **and options** of
   companies" below $500M are ineligible, which reaches Sleeve B's contract selection, not just the share
   universe. Irrelevant while SPY/QQQ/IWM/SMH/XSP are the only underlyings (`rules.json:35`), and worth
   remembering the day a cheaper name is added.

Two adjacent page details this memo's §4 cost comparison should inherit, since neither the notes nor this
file records them: option fees per the page are commission $0.65/contract (premium > $0.10) or
$0.15/contract, minimum $1.99/order, **plus** $0.30 platform, $0.00279 transaction-activity and $0.015
regulatory per contract — live `guard.py:66-68` models only $2 × (1.99 + 0.30 × contracts), which is short
from 4 contracts upward; and a sub-$1 *option premium* is plainly contemplated by that fee tier, so the $1
floor must not be read across to options.
