// toolset-drift.mjs — regression gate for the 2026-11-23 "toolbox missing" incident.
// Read-only. Usage: node tools/toolset-drift.mjs [--date=YYYY-MM-DD] [--server=moomoomcp]
// Exit 1 on a HARD signal: a server-prefixed tool name (the shape the model invents),
// an MCP call whose array/int param arrived string-serialised, or an emitted TOOLSET ABSENT.
// Soft signals (false-claim prose) are reported but do not fail the gate on their own.
import fs from "node:fs";

const REPO = "C:/Users/tteh/Documents/qoder-trend-desk-dashboard";
const PAT = (process.env.QODER_PAT || fs.readFileSync(`${REPO}/.env`, "utf8").match(/^QODER_PAT=(.*)$/m)[1]).trim();
const BASE = "https://api.qoder.com/api/v1/forward";
const arg = (k, d) => (process.argv.find((a) => a.startsWith(`--${k}=`)) || "").split("=")[1] || d;
const DATE = arg("date", new Date().toISOString().slice(0, 10));
const SERVER = arg("server", "moomoomcp");
// Only params that must NOT be strings. acc_id is legitimately a string on this connector.
const ARRAY_PARAMS = ["code_list", "symbols", "code_list_arr"];
const INT_PARAMS = ["ktype", "num", "market", "page_size", "index_option_type", "start_date_offset"];
// Declaration form only; retrospective prose ("the TOOLSET ABSENT gap cost...") is history, not a new halt.
// Scoped to the connector: `SKILL BUILD ABSENT (option-adapter)` is a legal local-skill label since the 11-24 rename.
const HARD = [/TOOLSET ABSENT\s*\(\s*moomoomcp\s*\)/i];
const OTHER_LABEL = /TOOLSET ABSENT\s*\(/i;
const SOFT = [/namespace (dropped|died|unregistered)/i, /died mid-run/i, /unregistered at runtime/i, /toolset gap/i];

const get = async (p) => {
  const r = await fetch(`${BASE}${p}`, { headers: { Authorization: `Bearer ${PAT}` } });
  const j = await r.json().catch(() => null);
  if (r.status !== 200) throw new Error(`HTTP ${r.status} on ${p}: ${JSON.stringify(j).slice(0, 160)}`);
  return j;
};
const paged = async (p) => {
  const out = new Map();
  let after = "";
  for (let i = 0; i < 40; i++) {
    const j = await get(`${p}?limit=100${after}`);
    const rows = j?.data ?? j?.items ?? [];
    for (const r of rows) out.set(r.id, r);
    if (rows.length < 100) break;
    after = `&after_id=${rows[rows.length - 1].id}`;
  }
  return [...out.values()];
};

const onDate = (await paged("/sessions")).filter((s) => (s.created_at || "").slice(0, 10) === DATE);
// a labelled self-test deliberately fires a wrong-name call; counting it would fail the gate forever
const SELFTEST = /toolbox-rca-acceptance/;
const skipped = onDate.filter((s) => SELFTEST.test(s.metadata?.purpose || ""));
const sessions = onDate.filter((s) => !SELFTEST.test(s.metadata?.purpose || ""));
console.log(`# toolset-drift ${DATE} server=${SERVER} - ${sessions.length} sessions${skipped.length ? ` (${skipped.length} self-test session excluded: ${skipped.map((s) => s.title).join(", ")})` : ""}`);
const hard = [], soft = [], verdicts = [];
let threads = 0, mcpOk = 0, native = 0, stringly = 0, wrongName = 0, rej = 0, compactions = 0;
for (const s of sessions) {
  for (const t of await paged(`/sessions/${s.id}/threads`).catch(() => [])) {
    threads++;
    // per-thread shape: a wrong name that is later followed by a good call means the ladder recovered
    let tw = 0, tcBefore = 0, tcAfter = 0, tr = 0;
    for (const e of await paged(`/sessions/${s.id}/threads/${t.id}/events`).catch(() => [])) {
      if (e.type === "agent.mcp_tool_use") {
        mcpOk++;
        if (e.mcp_server_name === SERVER) (tw || tr ? tcAfter++ : tcBefore++);
        const inp = e.input || {};
        const bad = [...ARRAY_PARAMS.filter((k) => typeof inp[k] === "string"),
                     ...INT_PARAMS.filter((k) => typeof inp[k] === "string" && /^\d+$/.test(inp[k]))];
        if (bad.length) { stringly++; hard.push(`STRING-TYPED ${s.title} ${e.processed_at.slice(11, 19)} ${e.name} [${bad}] ${JSON.stringify(inp).slice(0, 80)}`); }
        else native++;
        if (e.mcp_server_name !== SERVER) hard.push(`OTHER-SERVER ${s.title} ${e.processed_at.slice(11, 19)} ${e.mcp_server_name}`);
      }
      if (e.type === "agent.tool_use" && (e.name || "").startsWith(`${SERVER}__`)) {
        wrongName++; tw++;
        const inp = JSON.stringify(e.input || {});
        hard.push(`WRONG-NAME ${s.title} ${e.processed_at.slice(11, 19)} ${e.name} stringTyped=${new RegExp(`"(${[...ARRAY_PARAMS, ...INT_PARAMS].join("|")})":\\s*"`).test(inp)}`);
      }
      // the registry form is valid, so only a denial of it is drift
      if (e.type === "agent.tool_use" && (e.name || "").startsWith(`mcp__${SERVER}__`) && e.evaluated_permission === "deny") {
        hard.push(`REGISTRY-DENIED ${s.title} ${e.processed_at.slice(11, 19)} ${e.name}`);
      }
      // an invented name is only reliably visible in the rejection it produced: the composed prefix
      // varies (`moomoomcp__x` on 11-23, `moomoo__x` on 11-19), so count the string, not one shape.
      if (e.type === "agent.tool_result") {
        for (const m of JSON.stringify(e.content || "").matchAll(/Tool '([^']+)' does not exist in this session's tool set/g)) {
          if (/^moomoo/i.test(m[1])) { tr++; hard.push(`REJECTED-NAME ${s.title} ${e.processed_at.slice(11, 19)} ${m[1]}`); }
          else soft.push(`OTHER-REJECTED ${s.title} ${e.processed_at.slice(11, 19)} ${m[1]}`);
        }
      }
      if (/^agent\.(message|thread_message_sent)$|^user\.message$/.test(e.type)) {
        const txt = (e.content || []).map((c) => c.text || "").join(" ").replace(/\s+/g, " ");
        if (!txt) continue;
        if (HARD.some((re) => re.test(txt))) hard.push(`EMITTED-LABEL ${s.title} ${e.processed_at.slice(11, 19)} ${txt.slice(0, 100)}`);
        else if (OTHER_LABEL.test(txt)) soft.push(`OTHER-LABEL ${s.title} ${e.processed_at.slice(11, 19)} ${txt.slice(0, 100)}`);
        else if (SOFT.some((re) => re.test(txt))) soft.push(`${s.title} ${e.processed_at.slice(11, 19)} ${txt.slice(0, 100)}`);
      }
      if (e.type === "agent.thread_context_compacted") compactions++;
    }
    if (tw || tr) {
      const bad = Math.max(tw, tr);
      const cls = tcBefore ? "after-a-good-call" : "first-moomoo-call";
      verdicts.push(`${s.title}/${t.id} wrong=${bad} (prefix=${tw} rejected=${tr}) class=${cls} correctBefore=${tcBefore} recovered=${tcAfter ? "YES(" + tcAfter + ")" : "NO"}`);
    }
    rej += tr;
  }
  if (s.metadata?.created_by && s.metadata.created_by !== "forward") soft.push(`MODE ${s.title}: created_by=${s.metadata.created_by}`);
}
console.log(`  threads=${threads} correct-path mcp_tool_use=${mcpOk} (native ${native} / string-typed ${stringly}) wrong-name tool_use=${wrongName} rejected-name=${rej} compactions=${compactions}`);
const lost = verdicts.filter((v) => v.includes("recovered=NO")).length;
if (verdicts.length) console.log(`  wrong-name threads=${verdicts.length} recovered=${verdicts.length - lost} lost=${lost}`);
for (const v of verdicts) console.log("  THREAD - " + v);
for (const h of [...new Set(hard)].slice(0, 30)) console.log("  HARD - " + h);
for (const x of [...new Set(soft)].slice(0, 10)) console.log("  soft - " + x);
const uniq = [...new Set(hard)];
if (!hard.length && !mcpOk && !wrongName) {
  console.log(`INCONCLUSIVE: ${DATE} produced no moomoo dispatch at all (${threads} threads observed) — an unmeasured day is not a clean day.`);
  process.exit(2);
}
console.log(uniq.length ? `FAIL: ${uniq.length} hard signal(s) on ${DATE}` : `PASS: no wrong-name dispatch, no string-typed params, no retired label on ${DATE} (${mcpOk} correct-path calls seen)`);
process.exit(uniq.length ? 1 : 0);
