# Pre-market / after-hours pure-stock trading — is it worth adding?

**Owner idea (2026-11-20, via mailbox `20261120T033944Z-c8019f`):** options are confined to the
9:30–16:00 ET regular session (confirmed tonight), but the contest's own trading-hours rule for
stock covers 4:00 AM–8:00 PM ET. So: would trading *pure stock* — no inverse-ETF pairing, no
options — in the pre-market and after-hours sessions be a good addition to the desk?

**Verdict: NO-GO. Do not build a sleeve for it.** The idea passes the availability gate and fails
the worth-it gate, and it fails on the owner's own acceptance criterion: of everything the
unmodified live engine called in the pre-market, **zero tickets would have been approved by the
live guard**, and the signals the engine *would* have called if its clock gate were removed lose
money **before** any spread or fee is charged.

| Gate the owner set | Result |
|---|---|
| 1. Actually available on this contest account? | **YES** — six independent evidence levels, §1 |
| 2. Real signals fire AND clear every gate on real pre-market tape? | **NO** — 0/157 clear the guard at their own clock, §2 |
| 3. Spread / slippage / fill-rule kill the edge? | **Not even the mechanism** — total cost is 1.6–2.8% of the gross target, and the 20× fill rule trips on 1/157 tickets; the raw expectancy is already negative **before** any cost, §3–§4 |
| 4. Backtest on real tape | −0.333R per independent trade (n=30), 26.7% win rate against the 40% breakeven a 1.5R target needs, §5 |

Per the pre-authorization add-on: both gates must be true to start prep work. Gate 2 is false with
numbers behind it, so **this memo is the whole deliverable** — no `before/` snapshot, no apply
script, no GO/NO-GO flag package. Cloud changes: none. No order was placed, modified or cancelled
anywhere; every capability question below is answered from documentation, from a read-only
market-data call, or by running the published scripts locally against downloaded tape.

- Author: session `20261120T033816Z-3bd872` (Tier B, memo-only)
- Evidence dir: `.scratch/premarket-3bd872/` (`bars.jsonl` 3,648 bars, four scripts, four `*-out.txt`)
- Labels: **[documented]** = written in the rules page, a schema or a file in this repo;
  **[observed]** = produced by a call or a run in this session, with n; **[undiscoverable]** = cannot
  be settled from what this session can reach.

---

## 1. Gate 1 — availability: YES, on four independent levels **[documented]** + **[observed]**

The load-bearing question first, because the whole analysis hangs off it. It is not an assumption.

1. **The contest rule text.** Official rules page, *Moomoo Paper Trading Account Terms &
   Conditions → 1. Eligible Products and Trading Hours*: "Only U.S.-listed stocks, ETFs, and options
   may be traded… Trading is available during U.S. **pre-market, regular, and after-hours sessions**,
   from **4:00 AM to 8:00 PM ET**." Same page FAQ: "Can I trade outside regular US market hours?
   Yes…". Fetched 2026-11-20, saved at
   `.scratch/premarket-3bd872/official-rules.md` (1,110 lines of readable text; the trading-hours
   sentence is L810, the fill rule L878, the FAQ L989). **[documented]**
2. **The local rules note agrees.** `docs/contest-rules-notes.md:44` —
   `- Trading hours: 4:00 AM–8:00 PM ET (pre-market + regular + after-hours).` Re-read fresh tonight
   against the fetched page; the line is accurate. **[documented]**
3. **The broker's own order schema has a field for it.** `sim_trade_input_order.order_trade_time_type`
   — schema text read this session, verbatim: *"Trading session type: 0=Not set, 1=Intraday only,
   2=Includes pre-market and after-hours (supported for U.S. stock margin accounts)"*.
   A parameter that did not apply to this account family would not be in its order schema.
   **Caveat, stated rather than glossed:** the schema scopes value 2 to *U.S. stock margin accounts*.
   This session did not verify the margin/segment type of the contest account 5830104 (touching it is
   out of bounds here), so the schema confirms the capability exists in the product family and the
   rules text confirms it is permitted — it does not by itself prove the flag is accepted on that one
   account. The prior-session equity fill in the pre-market (item 5) is the direct evidence for that
   account. No order was submitted to test it. **[documented]**
4. **The same schema has no stop order type at all**: `order_type` — *"Order Type: 1=Limit 3=Market"*,
   enum `[1,3]`. See §7.1; this is the fact that makes extended hours dangerous rather than merely
   inconvenient. **[documented]**
5. **Live market data quotes the extended sessions for every tracked symbol.** Read-only
   `quote_market_state` for QQQ, SMH, SPY, SQQQ, SOXS, SPXS, IWM returned explicit pre
   (04:00–09:30 ET) and after (16:00–20:00 ET) sections alongside the regular one (n=1 snapshot,
   2026-11-20 ~03:4xZ). **[observed]** Extended-hours 5-minute bars are also physically present in
   the history feed — 3,648 of them in `bars.jsonl`, which is what §3–§5 are computed from. **[observed]**
6. **Another session has already seen a pre-market equity fill on the contest account.**
   `docs/sleeve-b-findings-nov19.md:4-5` [observed on 5830104, 08:55 ET Nov 19]: the sim matched an
   equity order in the pre-market in ~8 seconds at 353.59. I did not repeat it and will not —
   an order probe is not mine to spend. **[observed by another session]**

**Gate 1: PASS.** The capability exists, is permitted by the rules, is addressed by the API, and is
already being quoted and matched. The analysis therefore had to go the full distance.

---

## 2. Gate 2 — does the desk actually act on it? No, at two independent layers

### 2a. The live engine refuses pre-market before it looks at a single price

`trend_signal.py:156-161` (published trend-signal `1795047415929677`, local read of
`.scratch/audit-persist/live/trend-signal/scripts/trend_signal.py`):

```python
h, m = s["time_et"].split(":")
now_m = int(h) * 60 + int(m)
if now_m < 10 * 60:
    return {"action": "NONE", "reason": "opening range not complete before 10:00 ET"}
if now_m > 14 * 60 + 30:
    return {"action": "NONE", "reason": "too late for a new trend entry"}
```

These are the first statements in `signal()` after the ticker check. They run *before* the range
test, the VWAP test and the breakout geometry, so no extended-hours bar can reach the logic at all.

**Replay, mode A (unmodified engine, real bar clock)** — `.scratch/premarket-3bd872/analysis.py`
loads the published file via importlib and feeds it real 5-minute bars:

| Session | Bars evaluated | LONG | SHORT | Blocking reason |
|---|---|---|---|---|
| pre-market | 900 | 0 | 0 | `opening range not complete before 10:00 ET` — **900/900** |
| regular | 1,080 | 0 | 2 | mixed: no breakout 388, after 14:30 270, missing inverse quote 195 |
| after-hours | 630 | 0 | 0 | `too late for new trend entry` — **630/630** |

n = 3,648 bars, 19 symbol-days, 5 days × {QQQ, SPY, SMH} + 1 day × {SQQQ, SOXS, SPXS, IWM}.
**Zero pre-market and zero after-hours signals from the engine as it ships.** **[observed]**

### 2b. And the live guard vetoes every ticket anyway

Even the geometry, run with only the *input clock* neutralised, produces tickets that the
published risk gate declines. `desk-risk-guard` `1795138181446404`, `guard.py:152-157`:

```python
now_m = et.hour * 60 + et.minute
if sleeve != "hedge":
    if now_m < mins(day["entry_start"]):
        reasons.append(f"before entry window ({day['entry_start']} ET)")
    if now_m >= mins(day["entry_end"]):
        reasons.append(f"after entry window ({day['entry_end']} ET)")
```

with `references/rules.json` `"timing": {"entry_start_et": "10:00", "entry_end_et": "15:00",
"flat_by_et": "15:45"}`. `calendar_rules.py` can move those hours per day (today, Nov 20, it moves
the open to 10:05) but has no notion of a session boundary — 04:00 and 19:00 are just numbers that
fail the same comparison.

**Live guard, real published bytes, run locally** (`sizes.py`, `guard.check()` called in-process):

- the 157 pre-market tickets, each judged at **its own clock**: `approved = 0/157`.
  Reason, 157/157: `before entry window (10:00 ET)`. **[observed]**
- one after-hours ticket (buy SQQQ at 16:35 ET on Nov 19): `approved = False`,
  `after entry window (15:00 ET)`. Same ticket at an 11:00 clock → `approved = True`, qty 318.
  The *only* thing that changed is the clock. **[observed, n=1 each]**
- a hedge sleeve at 06:00 → `hedges are placed during the regular session only`
  (`guard.py:161-162` hardcodes 09:35–15:55). **[observed, n=1]**

So a pre-market sleeve is not a config gap — it is a **design conflict**. Three components
independently decline, and every one of them was written to protect a specific regular-session
behaviour. Making it work means editing the clock gate, the entry window, *and* the hedge window.

### 2c. There is also nobody awake

The coordinator's own run list (`AGENTS.md`, coordinator system prompt, verbatim) is
`BRIEF 09:00 · SCAN 10:05, 11:00, 12:30, 14:00 · FLAT 15:30 · REPORT 16:15`. Nothing runs before
09:00 ET. A position opened at 06:00 has **no scheduled check until 09:00** — and tonight's
doctrine makes a monitored check the *only* stop mechanism that exists on this account
(`protection.mechanism = "monitored"`, `guard.py:261-263`, because no STOP order type exists on a
paper account). A pre-market entry is therefore unprotected for three to five hours by design.
**[documented]** + **[observed in the live guard output]**

---

## 3. Liquidity reality: the fill rule almost never trips; the *tape* is the issue

The owner's specific worry was the contest's own matching rule. Text, fetched page L876–878:
"Where actual market trade volume multiplied by 20 is less than the order quantity, the order may
be partially filled. Any unfilled balance will remain pending until matched or cancelled."

### 3a. Pre-market is a small share of the day — measured

Pooled over 5 days (n=330 pre-market bars per symbol), share of daily traded shares:

| Symbol | pre | regular | post |
|---|---|---|---|
| QQQ | **4.07%** | 85.61% | 10.32% |
| SPY | **2.30%** | 82.42% | 15.28% |
| SMH | **2.41%** | 92.65% | 4.94% |
| SQQQ | 5.08% (n=1 day) | 90.86% | 4.07% |
| SOXS | 15.10% (n=1 day) | 79.00% | 5.91% |
| SPXS | 2.71% (n=1 day) | 95.55% | 1.74% |
| IWM | 1.25% (n=1 day) | 94.05% | 4.71% |

**[observed]** Single-day rows are one day, not a pattern — SOXS's 15% is Nov 19's post-NVDA
panic flow and should not be read as a typical share. The three 5-day numbers are the reliable ones,
and they say the pre-market carries roughly **1/25th to 1/40th** of the day's volume. **[observed]**

### 3b. The 20× rule trips on exactly one ticket out of 157 — in a bar with 2 shares in it

`fillcheck.py` / `fillworst.py`: for each of the 157 pre-market tickets I asked the **live guard**
what size it would approve (clock moved to 10:30 so the time veto doesn't hide the number), then
compared that qty to 20× the actual volume of the very bar the order lands in.

- approved qty: **min 37 / median 50 / max 73 shares**, notional $24.6k–$34.9k
  (139/157 tickets carry the warning `size limited by 35% single-asset target`). **[observed]**
- the three worst ratios in the sample (qty ÷ 20× bar volume; **>1 means the rule trips**): **[observed]**

| ratio | qty | bar volume | 20× volume | ticket |
|---|---|---|---|---|
| **1.725** | 69 | **2 shares** | 40 | SMH 2026-11-13, 06:20 ET |
| 0.157 | 69 | 22 | 440 | SMH 2026-11-13, 06:05 ET |
| 0.038 | 69 | 92 | 1,840 | SMH 2026-11-13, 05:25 ET |

- orders tripping the rule: **1/157** at the single-bar level; **0/190** when the working window is
  widened to 3 bars (05:20+05:25+05:30-style aggregation), i.e. the one breach is a momentary hole,
  not a persistent one. All three worst cases are SMH on the same early morning.

**[observed]** The reason it is *nearly* a non-issue is structural, and it is worth keeping straight:
`competition.single_asset_target_pct = 35` caps a new position at ~$35k of notional, which at
$688/share QQQ is 50 shares. A 69-share order only trips when the bar traded under 3.5 shares —
which is not a thin market, it is an absent one. So the fill rule does not bind because of the size
caps, and the single exception is not a size story.

For the after-hours SHORT idea the inverse-ETF tickets are sized 318–700 shares, so the trip
threshold moves to a bar trading under ~16–35 shares. On the one day of SPXS tape I hold, **4 of 66
pre-market bars (6.1%)** are below 15.9 shares and **3 of 66** below 3.45. So a 3×-inverse
pre-market entry has roughly a **1-in-16** chance of landing in a bar too dead for it. **[observed,
n=1 day]** In this sample none of the 31 after-hours tickets actually drew such a bar (0/31).

**So the owner's stated liquidity worry is close to unfalsified — it costs one ticket in 157 — but it
is the wrong worry.** The dead bar that trips the rule is the same bar that makes the price
meaningless, which is §3c.

### 3c. The liquidity problem is somewhere else: stale prints and dead bars

`liquidity.py` — pre-market 5-minute **bar volume**, the full distribution rather than a median:

| Symbol | days | n bars | min | p10 | median | max | bars too thin for 69 sh | for 318 sh |
|---|---|---|---|---|---|---|---|---|
| QQQ | 5 | 330 | 664 | 5,635 | 19,454 | 382,193 | 0 (0.0%) | 0 |
| SPY | 5 | 330 | 286 | 1,723 | 9,113 | 1,325,156 | 0 (0.0%) | 0 |
| SMH | 5 | 330 | **2** | 272 | 1,917 | 41,749 | **1 (0.3%)** | 3 (0.9%) |
| IWM | 1 | 66 | 146 | 318 | 1,825 | 36,877 | 0 | 0 |
| SQQQ | 1 | 66 | 6,834 | 18,359 | 40,597 | 1,098,278 | 0 | 0 |
| SOXS | 1 | 66 | 47,633 | 63,240 | 130,555 | 5,979,520 | 0 | 0 |
| SPXS | 1 | 66 | **0** | 175 | 3,936 | 89,048 | **3 (4.5%)** | **4 (6.1%)** |

**[observed]** Second measurement, the one that matters more — how often the bar is a **quote that
did not move** (its close equals the previous bar's close) and how often it is **under 100 shares**:

| Symbol | session | n | zero-change | bars <100 sh |
|---|---|---|---|---|
| QQQ | pre | 329 | 4 (**1.22%**) | 0 |
| QQQ | regular | 390 | 1 (0.26%) | 0 |
| SPY | pre | 329 | 4 (**1.22%**) | 0 |
| SMH | pre | 329 | 18 (**5.47%**) | 11 (**3.34%**) |
| SMH | regular | 390 | 0 (0.00%) | 0 |
| SPXS | pre | 65 | 7 (**10.77%**) | 5 (**7.69%**) |
| SPXS | regular | 78 | 0 (0.00%) | 0 |
| IWM | pre | 65 | 1 (1.54%) | 0 |

**[observed]** A 5-minute bar with 2 shares in it (SMH) or 0 shares (SPXS) is not a market: the
"last price" the researcher would read off it is a stale print. The regular-session rate for the
same symbol is 0.00%, so this is a session property, not a symbol property — which is also the
evidence that the metric discriminates rather than just counting flat prices.

This is where the desk actually breaks. Its evidence rule is the researcher prompt, SCAN step 3: any
number "missing, stale (older than 5 minutes) or inconsistent" → return NONE with the reason. In a
session where the least liquid signal name (SMH) prints no change on 5.5% of bars, SPXS on 10.8%, and
some bars print two shares, **"stale" and "live" are not separable at 5-minute resolution** — a real
move and an absent tape look identical in the payload.
The rule that is supposed to protect the desk is the one the pre-market degrades, and it degrades it
in the direction of trading a phantom price. That is a worse problem than the fill rule. **[observed
volume distribution; inference for the failure mode]**

**Diversification candidates.** The idea's only real promise is breadth — the desk currently signals
on QQQ/SMH/SPY only (`trend_signal.py:18-22 PAIRS`) and the guard emits the 3-ticker ASSUMPTION
warning on 146/157 tickets. I measured IWM as the candidate with the least room: **1.25%** of its
daily volume trades pre-market, p10 bar 318 shares, min 146. It is the *thinnest* pre-market tape in
the set. Adding names to cure the 3-ticker warning does not become easier by doing it at 05:00 ET.
**[observed, n=1 day for IWM]**

---

## 4. Spread and slippage against the hard-wired 1.5R geometry

The engine hardcodes the reward:risk relationship — `trend_signal.py:182` `target = price + 1.5 * dist`,
reported as `"reward_risk": 1.5`, and the guard has no ratio at all (pure pass-through). So costs
have to be judged against a fixed 1.5R, not a flexible one.

**What is measurable.** Historical bid/ask is **not** in the kline payload and no endpoint this
session can reach returns historical NBBO — **[undiscoverable]**. I used two published-data proxies
instead of guessing a spread:

- **Per-bar range as an activity proxy** (high−low)/close, bps, medians, 5 days:

  | Symbol | pre | regular | post | pre/regular |
  |---|---|---|---|---|
  | QQQ | 9.8 | 24.5 | 11.8 | 0.40× |
  | SPY | 5.9 | 16.0 | 6.8 | 0.37× |
  | SMH | 18.1 | 41.6 | 22.9 | 0.44× |

  **[observed]** n=330/390/240 bars per symbol. Pre-market is *less* active than the regular session
  on this measure — which matters because the engine's stop is derived from the range (§4b).

- **How much of each ticket's stop distance the next bar actually moves.** `spreadtab.py`, using the
  half-range of the bar immediately after entry as a *lower bound* on what crossing costs, measured
  against that ticket's own stop distance:

  | Group | n | median | p75 | p90 | max | >25% of stop distance |
  |---|---|---|---|---|---|---|
  | signal (pre-market LONG) | 157 | **13.6%** | 25.8% | 47.8% | 152.4% | 41 (26.1%) |
  | unfiltered (regular 10:00–14:30) | 63 | **44.5%** | 105.8% | 167.6% | 6,065% | 53 (84.1%) |

  **[observed]** This is the opposite of the intuition. The pre-market stop sits *further* from the
  tape relative to what the tape does: a typical next bar covers under 1/7th of the distance to the
  stop, versus nearly half in the regular session. So the stop is not perched one spread away — and
  that is also the mechanism behind §5: with 224 ticks of slack and a bar that moves 30 of them,
  neither level gets touched and the trade simply ages until the forced exit (144/157 end `flat_by`).
  A quiet market does not need a tight stop; it needs a reason to move, and this one is not given one
  by the signal.

- **Cost as a bounded range**, not a point: 1, 2 and 5 ticks of adverse fill round trip, plus the
  documented share fee (`fees.stock_platform_fee_per_order 0.99` +
  `stock_transaction_fee_per_share 0.000166`, round trip = $1.98 per order at these sizes).

### 4a. The result: cost is small, and it is not what kills the idea

`sizes.py`, live-guard qty and live `stock_round_trip_fee()`, 157 tickets:

| Adverse fill | cost/share | mean gross R | mean net R | cost as % of the 1.5R target (median / p90 / max) |
|---|---|---|---|---|
| 1 tick | $0.048 | −0.140 | **−0.170** | 1.6% / 3.8% / 8.3% |
| 2 ticks | $0.058 | −0.140 | −0.177 | 1.9% / 4.6% / 9.8% |
| 5 ticks | $0.088 | −0.140 | −0.196 | 2.8% / 6.9% / 14.5% |

Trades where cost exceeds 25% of the target distance: **0/157 at every level.** **[observed]**

The 1.5R geometry **does still clear its own cost bar** — the brief asked me not to assume that, and
the honest answer is that this particular objection is not the one that matters. Costs add
0.03–0.06R of drag to a number that is already −0.14R before they are applied.

### 4b. The real cost of the thin tape is *where* the geometry puts the levels

Because `dist` comes from the opening range and the range comes from the first six bars, a quieter
tape produces a proportionally tighter stop for the same *percentage* move — and the tight stop is
then measured against a quote that only updates a few times a minute. The mean pre-market signal
distance was **$2.24 on a ~$690 ETF (0.33%)**, i.e. about **224 one-tick steps** wide, which sounds
safe until §3c's 2-share and 0-share bars are remembered: the level is precise, the *observation*
of it is coarse. The desk cannot enforce that stop at all outside a monitored check (§2c), so the
tighter pre-market stop does not mean tighter risk — it means *earlier* forced exits at whatever the
next scheduled check sees.

---

## 5. The backtest: real tape, unmodified engine, with a control group

Method, all in `.scratch/premarket-3bd872/`, all reproducible:

1. Pull 5-minute bars with `extended_time=1` for QQQ/SPY/SMH on Nov 13, 16, 17, 18, 19 and for
   SQQQ/SOXS/SPXS/IWM on Nov 19 via read-only `quote_history_kline` (3,648 bars). **[observed]**
2. Bars are **close-stamped**, verified before anything was computed (`stampcheck.py`): the 16:00
   bar carries the closing auction (2,165,416 QQQ shares) and the 09:30 bar is thin. Pre-market
   therefore spans stamps 04:05–09:30. **[observed]** — getting this backwards shifts every signal.
3. Opening range = first six bars of the session, session VWAP = Σturnover/Σvolume, `price` = bar
   close — the same construction the researcher feeds the engine. Two modes: **literal** (real clock)
   and **neutered** (input `time_et` forced to `10:00`, which is a change to the *input*, never to the
   engine's bytes).
4. Regime forced to the `normal` bucket (fixture `source: "replay_fixture"`) because the desk's real
   09:00 BRIEF does not run pre-market. This **helps** the idea; it does not hurt it.
5. Outcomes: walk forward bar by bar, **stop checked before target** (conservative), force-close at
   15:45 ET (the flat-by rule). A second horizon force-closes at 10:00 ET to model "no check exists
   before the entry window opens".

### 5a. Results

| Group | n | Win rate | Mean R (gross) | Exits |
|---|---|---|---|---|
| **Pre-market signals** (engine said LONG) | 157 bars | 34.4% | **−0.140** | 103 stop / 54 target |
| **Pre-market control** (every bar, same geometry, **no breakout filter**) | 610 | 31.0% | −0.225 | 421 stop / 189 target |
| Signals, force-closed at 10:00 instead of 15:45 | 157 | 34.4% | −0.136 | — |
| After-hours signals (neutered) | 31 | not evaluated | not evaluated | 4 LONG / 27 SHORT |

**[observed]** Breakeven win rate for a hard-wired 1.5 reward:risk is **40%**. The pre-market
signals sit at 34.4% gross, before costs, and 26.7% net at episode level (§5c).

Two things this table establishes:

- **The filter is not nothing, but it is far from enough.** LONG signals beat the unfiltered control
  by +3.4 points of win rate and +0.085R. The gap to breakeven is +5.6 points. A filter that closes
  a third of the distance does not make a losing tape tradeable.
- **The direction of the failure is not "costs ate it"** (§4a) and not "the horizon was too long"
  (−0.136R at 10:00 vs −0.140R at 15:45 — flat).

### 5b. n-inflation: 157 rows are 30 trades, not 157

`episodes.py` groups consecutive firing bars — the engine re-evaluates every 5 minutes, so one
drift morning emits one signal per bar for the whole drift:

```
QQQ 20261113: 34 rows -> 6 episodes (longest run 13 bars, 06:00-09:25)
QQQ 20261117: 34 rows -> 2 episodes (longest run 32 bars)
SMH 20261113: 25 rows -> 5 episodes
SPY 20261113: 32 rows -> 3 episodes (longest run 22 bars)
... 8 symbol-days total -> 30 independent episodes
```

**[observed]** The QQQ Nov-17 row is the clearest illustration: 32 consecutive bars "signalling" is
one drift episode, and the desk would have bought it once, late, after the move already happened.
This is what a trend filter on a thin, drifting tape does — it confirms the drift instead of
predicting anything.

And the concentration is worse than the episode count alone suggests. The 157 pre-market rows come
from **four of the five days**, and **132 of them (84%) from two mornings** — Nov 13 (91 rows, 17
episodes) and Nov 17 (41 rows, 4 episodes); Nov 18 contributed exactly 1 row and Nov 16 none.
**[observed]** So the effective sample for "does pre-market trend work" is closer to *two drift
days* than to *157 trades*, and any positive-looking symbol cut below has to be read against that.

### 5c. Episode-level, the honest sample

| Metric | Bar-level | **Episode-level (n=30)** |
|---|---|---|
| Win rate | 34.4% | **26.7%** |
| Mean net R (1 tick + fees) | −0.170 | **−0.364** |
| Mean net $ | −$68 | **−$79** |
| Sum over the 5 days | — | **−$2,381 on a $100k start = −2.4% of NAV** |

By symbol at episode level: QQQ n=8 +0.562R, SPY n=9 −0.167R, **SMH n=13 −1.000R (every single
episode hit its stop before its target)**. **[observed]** QQQ's +0.562R on n=8 across two mornings is
not a pattern, and this session's own evidence standard forbids calling it one; SMH's 13-for-13 is
the opposite kind of fluke — it is a coherent story about a wide-range name on a thin tape, but it is
still one week.

### 5d. What the control group says about blame

The same unfiltered geometry with the same exit simulator, restricted to the engine's own
10:00–14:30 window on the same symbol-days, yields n=63, win 12.7%, mean **−0.683R**.
**[observed]** That number is a *control-group construct*, not the live strategy's regular-session
P&L — the live engine produced only 2 regular-session signals on these 5 days, which is the
zero-trade finding already documented in `docs/decisions/vix-gate-and-zero-trades-nov20.md`. Its only
legitimate reading is: **this bar-level 1.5R geometry has negative expectancy on 5-minute closes in
both sessions**, so the pre-market result should not be attributed to the pre-market alone. It does
not rescue pre-market — pre-market is not *worse* than regular on this measure, but "equally
negative" is not a reason to add a sleeve whose only upside is more trades.

### 5e. Robustness of the simulator itself

The stop-before-target tie-break inside one bar could in principle decide outcomes. It does not:
**0 of the 157 filtered signals** had both levels touched in the bar immediately after entry, and
the effect on the unfiltered control is 10/416 (2.4%) pre-market and 4/63 (6.3%) regular.
**[observed]** The negative expectancy survives a simulator that was deliberately built to be
unfriendly to nothing in particular.

---

## 6. After-hours deserves its own paragraph, because it is a different and worse idea

The 31 after-hours calls the neutered replay produced are **27 SHORT + 4 LONG**. The 27 SHORTs are
all Nov 19 — the one day in the sample with a real post-close move to chase — and the 4 LONGs are
Nov 16 (×2), 17 and 18. **[observed]** A SHORT here means *buy SQQQ/SOXS/SPXS* — which is precisely
the "pure stock, no inverse pairing" the owner was trying to avoid: at 17:00 ET there is no
mechanism to be flat and bearish except the levered inverse ETFs. None of the 31 tickets lands in a
bar thin enough to trip the 20× rule (0/31, §3b), which is the least interesting thing about them.

Four things make after-hours strictly worse than pre-market:

1. **It is an unhedged overnight position by construction.** Flat-by is 15:45 ET
   (`rules.json timing.flat_by_et`); an entry at 16:35 is already past it. The coordinator's
   doctrine permits exactly one thing to survive the night — the option hedge — and the coordinator
   prompt states "flat by 15:45 ET; one small option hedge may stay overnight". **[documented]**
2. **The 3× inverse ETFs decay overnight, and they are not what the signal is about.** Entering
   SQQQ at 16:35 and exiting at 10:05 the next morning converts an intraday breakout idea into an
   overnight volatility bet on a 3× instrument.
3. **No check exists between 16:15 and 09:00.** Same argument as §2c, with a whole overnight on it.
4. **The scoreboard may not even count it.** `docs/contest-rules-notes.md:61-63` — final settlement
   uses regular-market closes and after-hours trades on the final day are excluded, though weekly
   returns mark at Friday 10:00 PM ET. So after-hours activity is mostly self-inflicted risk whose
   contribution to the measured result is murky. **[documented]** (Whether the weekly 22:00 mark
   *rewards* after-hours positioning is **[undiscoverable]** from the rules text alone.)

I did not attempt a next-day follow-through test for the 27 Nov-19 after-hours shorts: as of this
writing (~04:00Z, 23:00 ET Nov 19) the next regular session has not traded, so the data does not
exist yet. **[undiscoverable]** — and given 1–4, that gap is not worth scheduling a wake for.

---

## 7. Two structural facts found while doing this, which matter regardless of the verdict

Reported because they are properties of the live configuration, not opinions about the idea.

1. **`order_type` on this account family is Limit(1) or Market(3) only — no STOP, confirmed in the
   same schema read that confirmed extended hours.** This is already the established position
   (memory: moomoo docs say paper = limit or market, DAY-only) and tonight's `protection.mechanism =
   "monitored"` fix encodes it. Extended-hours trading makes it *more* painful, not less: the
   monitored check is the only stop, and there is no check to monitor with. **[documented]** + **[observed]**
2. **`order_trade_time_type` normalises 0→1 on rows both accounts return** (memory,
   `.scratch/sleeveb/fills/2026-11-20-filled-option-rows.md:63` records 1 on every option row and 2
   on every equity row). If the desk ever *did* add extended-hours entries, this is the field to
   read back and verify — the submitted value is not necessarily the stored value. **[documented, prior session]**

---

## 8. Interaction with the other in-flight streams

- **`continuous-scan-nov20.md` (another session, in flight).** That work aims to make scanning more
  responsive; this memo says a pre-market sleeve would *add* rounds to a desk whose binding
  constraint is round-trip latency, not lack of hours. If the scan cadence is being reconsidered, the
  pre-market is the wrong place to spend it. Not a contradiction, but the two must be decided
  together. **[documented, read-only]**
- **`vix-gate-and-zero-trades-nov20.md`.** That memo's central finding — SCAN round-trip 21m47s vs
  the researcher's 5-minute staleness rule (`docs/decisions/vix-gate-and-zero-trades-nov20.md:486`) —
  gets **worse**, not better, pre-market: measured zero-change bars (a close identical to the previous
  bar's close) run 5.5% of SMH's and 10.8% of SPXS's pre-market bars versus **0.00% in the same
  symbols' regular session** (§3c, `liquidity.py`), so a 21-minute-old reading is proportionally
  further from the tape. The zero-trades problem cannot be solved by adding hours. **[observed]** +
  **[documented]**
- **`calendar_rules.py` no_entry work (published tonight as `1795138181446404`).** A pre-market
  sleeve would need per-day event blackouts expressed in the pre-market too (CPI at 08:30 ET is
  *inside* a 04:00–09:30 entry window and currently invisible to it, because `entry_start` is 10:00).
  That is a second calendar to maintain and verify. **[observed in the live calendar]**
- **Credit budget.** Nov-18 actuals: 100.54 cr/day, a single SCAN 14.97–20.54
  (`docs/decisions/regime-robustness-nov20.md:281`). Five added pre-market rounds ≈ +75–100 cr/day,
  roughly **doubling** the daily burn, bought for an edge measured at −0.364R per trade.
  **[documented]** + arithmetic.

---

## 9. Conflicts with other memos

1. **`docs/sleeve-b-golive-nov20.md:29`** — "The sim engine does **not fill outside the regular
   session** (09:30–16:00 ET, trading days)". Read literally that contradicts
   `docs/sleeve-b-findings-nov19.md:4-5` ("sim matched an equity order in the pre-market in ~8
   seconds") and §1's rules text. **In context it is about the option path, and both statements are
   right:** options are confined to the regular session, equities are not. The sentence is however
   unqualified, and it was the assumption this whole task was framed against, so it deserves a
   clarifying word. **I did not edit that file** — another session owns it. Flagged here for its
   owner. **[documented, both sides]**
2. **The brief's own premise, gently corrected.** The idea was motivated by
   "options are restricted to 9:30–16:00 while stock may trade 4:00–20:00, so use the extra hours for
   stock." The extra hours are real for stock, but §6 shows the desk cannot *use* them for a
   direction-neutral stock idea: bearish exposure in this design means a 3× inverse ETF
   (`trend_signal.py:18-22 PAIRS`, `guard.py` universe), and `guard.py:161-162` already confines
   hedges to the regular session. The asymmetry the idea rests on is narrower than it looks.
3. **My own earlier framing of the liquidity risk, corrected twice.** Before sizing with the live
   guard I expected the 20× fill rule to bind on QQQ at ~383 shares; with the real 35%-cap sizing it
   approves 37–73, so the rule is near-non-binding (1/157, §3b). Then the *first* fill-rule run
   reported 0/157 with "2,538× headroom" and was wrong for a second reason — a timestamp bug, item 4.
   Both corrections are in §3b; the direction of the conclusion survived, the numbers did not.
4. **A bug in this session's own scripts, found by cross-checking.** `fillcheck.py` and
   `fillworst.py` converted the ET offset from hours to minutes **twice**, which indexed each bar
   7 hours away from its real clock and pooled the wrong slice of the day. I caught it because the
   QQQ pre-market median they printed (355,872 shares) contradicted `analysis.py`'s independent
   figure (19,454), and confirmed it against a single known bar (QQQ 2026-11-13 06:00 ET is
   7,456 shares, not the 182,513 they reported). Fixed, re-run, and the honest finding is 1/157
   tripping the rule rather than 0/157. Every other number in this memo comes from `analysis.py`,
   `outcome.py`, `episodes.py`, `sizes.py` or `liquidity.py`, whose clock math was always correct;
   the one after-hours table I had quoted informally ("15/226 SPXS below the $1.00 floor") came from
   the buggy run, is **not** in this memo, and the corrected equivalent is **0/31** (§6).
   `liquidity.py` now recomputes the whole distribution as a single source so no figure in §3
   depends on either buggy script. **[observed, self-reported]**

---

## 10. Recommendation

**Do not build a pre-market/after-hours sleeve. Keep the desk as configured.**

The gate-1 answer is a clean yes, so this is a decision about worth, not possibility, and the worth
test is unambiguous:

1. Nothing in the current system is designed to act in those hours — the engine, the guard, the
   hedge rule and the schedule each independently decline it (§2). Enabling it is not a flag flip; it
   is a fork of the strategy into a second regime with its own calendar and its own risk controls.
2. The tape is 1/25th–1/40th of the day's volume, with 5.5% of SMH's and 10.8% of SPXS's pre-market
   bars printing no price change at all and bars that trade 0–2 shares, which attacks the freshness
   discipline the desk depends on (§3). The fill-rule worry, though, barely binds — 1 ticket in 157 —
   so the honest case against is thinner than reflex would suggest, and sits on the tape's quality
   and the strategy's own expectancy instead.
3. Costs are genuinely small (1.6–2.8% of the target, §4a). The 1.5R geometry is not rescued by
   cheaper execution; it fails at 34.4% win rate against a 40% breakeven, **before** costs, and at
   26.7% / −0.364R once the 157 rows are collapsed into their 30 independent trades (§5c).
4. Its only structural advantage — more time in the market — is worthless here, because the binding
   constraint is round-trip latency and evidence freshness, not the number of hours (§8).

**What would change my mind** — stated so the next reader does not have to redo this work:

- A signal family that is *about* the pre-market rather than borrowed from it: overnight gap
  behaviour, first-auction imbalance, or news-window repricing around 08:30 ET CPI. That is a
  different engine with its own thresholds and its own backtest, not a clock change to
  `trend_signal.py`. And it must be evaluated on outcomes measured at the regular open, since that
  is the only print that settles.
- Evidence of a *persistent* drift the 1.5R/VWAP geometry can actually monetise, on ≥10 trading days
  and ≥30 independent episodes, showing >40% win rate gross. This week's pre-market data shows the
  opposite: the filter beats a no-filter control by 3.4 points, which is a hint, not an edge.
- A real stop. If a resting STOP order ever exists on this account family, the risk objection in
  §2c weakens materially — the *reason* the desk's doctrine is "fewer, cleaner trades" is that an
  unmonitored position has no exit.

---

## 11. The overnight session (20:00–04:00 ET) — SIMULATE does not have it

Appended 2026-11-20 by mailbox item `20261120T035805Z-6a3e18`, which §9.2 pre-authorized to extend this
memo's "pure stock outside RTH" question into the *third* extended session. §1–§10 cover 04:00–09:30 and
16:00–20:00 ET and conclude "possible but not worth it". This section covers the remaining window, and its
answer is different in kind: **there is no worth debate, because the gate never opens.** Read on this machine
between 04:54Z and 05:31Z 2026-11-20 (= 00:54–00:31 ET, inside a live overnight session). No order was placed,
modified or cancelled; the only account-side reads were lists and history (rule 8 of the mailbox contract, and
this item's own hard limit).

### 11.1 The load-bearing question, answered first

**The overnight session exists in moomoo's market data on this connection. It is not orderable in SIMULATE.**

Three independent lines say so, at different layers:

1. **The sim order schema has no overnight code.** `sim_trade_input_order.order_trade_time_type`, verbatim
   from the connector's own input schema: *"Us stock order trading session type. 0-99 reserved values. 0: Not
   set, 1: Intraday only, 2: Includes pre-market and after-hours"*. Enum `[0,1,2]`. **There is no value for
   20:00–04:00 ET.** **[observed]**
2. **The contest's own paper-account terms list three sessions, not four.** §1 *Eligible Products and Trading
   Hours*: *"Trading is available during U.S. **pre-market, regular, and after-hours sessions**, from **4:00 AM
   to 8:00 PM ET**."* ([`.scratch/premarket-3bd872/official-rules.md:810`](../../.scratch/premarket-3bd872/official-rules.md)),
   and the FAQ answer to *"Can I trade outside regular US market hours?"* names the same three (line 991). A
   grep for `overnight` in that fetched rules file returns **zero matches** — the word is absent from the
   paper-account rules entirely. **[documented]**
3. **The observed order rows agree.** In the 10 most recent history rows for `5830104`,
   `order_trade_time_type` takes only `2` (the pre/post-flagged AAPL legs) and `1` (the 14:0xZ ET QQQ/SQQQ
   entries). No row carries anything else. **[observed, n=10]**

The data side, for contrast — it is unambiguously there:

| call (all 2026-11-20) | what came back |
|---|---|
| `quote_history_kline(…, ktype=6, extended_time=2)` | 5-min bars continuing through the night from **20:00 ET Nov 19** to the newest completed bar **00:00 ET**; `ext` values 0/1/2 all present, the 2's stamped `date: 20261120` |
| `quote_stock_quote` × 7 symbols | a populated `overnight` sub-object for **every** one of QQQ/SPY/SMH/SQQQ/SOXS/SPXS/IWM (prices, volume, turnover, amplitude, change) |
| `quote_snapshot US.5830104` | `VIRTURAL_OVERNIGHT` section, **`is_trading: false`** (05:18Z read) |
| `quote_market_state US.QQQ` | `AFTER_HOURS_END`, and the only `trade_section` enumerated is type **12** (RTH 09:30–16:00 ET, `traded_seconds` 23400) — moomoo's market-state enum has **no overnight label** |

Two caveats on that table, stated rather than smoothed over. The `VIRTURAL_OVERNIGHT` begin/end
(1795118400 → 1795176000) decode to 2026-11-19T20:00Z → 2026-11-20T12:00Z, a 16-hour span that does **not**
reconcile to a 20:00–04:00 ET window, so I do not use that call as evidence of the window — the bar stamps do.
And `VIRTURAL` plus `is_trading: false` plus the `AFTER_HOURS_END` label all point the same way as §11.1: as
far as moomoo's own status fields are concerned, *nobody is trading right now*. **[observed] / [inferred]**

**One sub-question is not answerable without an order.** `order_trade_time_type` says *"0-99 reserved values"*,
so a code 3 is conceivable, and only a submission attempt could prove or disprove it. The brief forbids placing
an order to find out, so it stays open: *not answerable without an order* — which does not matter, because
codes 0–2 are documented, code 2's documented meaning excludes 20:00–04:00, and the paper terms cap trading at
20:00 ET. **[undiscoverable]**

### 11.2 The five doc constraints, checked instead of inherited

The brief carried five constraints from Moomoo's public docs and required each to be verified against the real
API. Verdicts, and whether each would even bite this desk:

| # | doc constraint | verdict against the tool surface | bites this desk? |
|---|---|---|---|
| 1 | overnight is **limit only**, no market orders | **moot, and the premise does not map.** There is no overnight order at all in sim, and sim is not limit-only: `sim_trade_input_order.order_type` exposes a market-order code, unlike the T&Cs' extended-hours wording. **[observed]** | no |
| 2 | **no short selling** during the session | **confirmed vacuous — twice.** `sim_trade_input_order.order_side` enum is `[1,2]` (Buy, Sell); there is **no short code** in the sim family at all (the real family's `trading_order_place.side` does carry `SELL_SHORT`/`BUY_BACK`). Separately, the desk's bearish expression is *"buy the 3× inverse ETF"*, which is a plain BUY on a long-only instrument. The paper T&Cs add *"Margin trading and short selling are available"* (§2 line 816) with no session qualifier. **[observed + documented]** | **no** — this was the constraint worth checking and it does not apply |
| 3 | only tickers with an **overnight-eligibility flag** are tradable | **cannot be checked — the field does not exist in the read surface.** Checked `quote_stock_quote`, `quote_snapshot`, `quote_owner_plate`, `quote_plate_list`/`quote_plate_stock` (their overnight exposure is *sort* fields — `OVERNIGHT_PRICE/TURNOVER/VOLUME/AMPLITUDE/PRICE_CHANGE_VAL/CHANGE_RATE` — and `price_type=OVERNIGHT`), `quote_stock_screen` factor lists, and every `sim_trade_*` schema. No boolean, no status enum, no count field. Best available proxy is a populated `overnight` block: **7/7 universe symbols pass it** (§11.3 table). **[observed → undiscoverable]** | moot on paper; would be the binding constraint on a **real** account |
| 4 | orders are **DAY / limit** and expire at session end | **partly confirmed.** `sim_trade_input_order` has **no `time_in_force` parameter** and the stored rows carry `time_in_force: 0`, so DAY is implicit and non-selectable (the real tool exposes `DAY/GTC/GTD/IOC`). Session-end auto-expiry itself is only observable on an order that reaches a session end, so it is not confirmed here. **[observed + inferred]** | not on the overnight path; already handled §2b/§7 |
| 5 | overnight **trade date attributes to T+1** | **CONFIRMED.** Bars time-stamped 20:05→00:00 ET on Nov 19 print with `date: 20261120`, and `ext=2` carries that stamp. The consequence is structural, not cosmetic: `guard.py:257` (`_et_date(now)`) and `calendar_rules.py:60-77` key `no_entry`/`entry_start`/`entry_end`/holidays off the **calendar** ET date, while the broker would key the fill off the **next** trade date. A ticket booked at 22:00 ET Nov 20 is Nov 20 to the guard and Nov 23 to the account. **[observed]** | **yes**, if it were ever reachable |

### 11.3 Eligibility proxy + tape, all seven symbols, read live at 00:31 ET

`quote_stock_quote` 2026-11-20T05:31Z — the `overnight` block, session-to-date. The volume figures are the
point: the inverse ETFs are *more* active overnight than their long-side counterparts (SQQQ 1.58 M and SOXS
3.34 M shares vs QQQ 348 k and SMH 30 k).

| symbol | overnight price | session high / low | volume (sh) | turnover (USD) | amp % |
|---|---|---|---|---|---|
| QQQ | 638.40 | 644.15 / 637.63 | 347,764 | 222,875,607.04 | 1.01 |
| SPY | 712.27 | 715.87 / 711.71 | 103,991 | 74,220,978.56 | 0.58 |
| SMH | 438.30 | 444.44 / 437.18 | 30,467 | 13,414,866.66 | 1.62 |
| SQQQ | 51.02 | 51.20 / 49.70 | 1,577,325 | 79,539,621.01 | 3.04 |
| SOXS | 67.84 | 68.22 / 64.28 | 3,343,632 | 222,218,319.27 | 6.24 |
| SPXS | 30.20 | 30.26 / 29.80 | 69,548 | 2,086,572.64 | 1.55 |
| IWM | 263.28 | 264.65 / 263.14 | 8,669 | 2,285,635.39 | 0.57 |

**[observed]**. 7/7 carry a non-zero overnight block, so the eligibility proxy passes for the whole universe.
Per-bar the majors are still thin, and thinner than the pre-market §3 measured: in the 5-min bars I read, **SPY
ran 202–3,496 shares**, **QQQ 1,300–20,000**, **SMH had bars of 2–3 shares and several at zero volume**, and
**SPXS's last three bars were 0 / 80 / 100 shares** (its whole session is 69,548 shares against SQQQ's 1.58 M).
So the pattern is the same as §3's finding but the magnitude is worse: the liquid names are the *hedged*
instruments, and the desk's actual entry list (QQQ/SMH/SPY) is the illiquid half of the overnight tape.
**[observed]**

### 11.4 What the as-shipped engine says about a live overnight breakout

Replayed through the **imported, unmodified, live** `trend_signal.py` (sha8 `60d5573d` = the pinned LIVE
version `1795047415929677`, confirmed by a read-only `GET /forward/skills`; `signal()`/`PAIRS` byte-identical to
§2a's copy), driven with **real** tape: the 20:00–00:00 ET overnight 5-min bars for the three signal tickers,
with the opening range = the first six 5-min bars of the *overnight* window and VWAP from the snapshot's
`overnight_turnover / overnight_volume`. `.scratch/overnight-6a3e18/replay_overnight.py`.

| run | input | QQQ | SMH | SPY |
|---|---|---|---|---|
| **A** — as shipped, real clock `00:00` | real tape | `NONE` · *"opening range not complete before 10:00 ET"* | same | same |
| **B** — counterfactual, `time_et` → `"10:00"`, **nothing else touched** | same tape, regime `caution`/0.75 | **SHORT** · entry 50.74 stop 47.62 target 55.43 | **SHORT** · 66.98 / 61.13 / 75.73 | **SHORT** · 30.10 / 28.94 / 33.57 |
| **C** — control: A's tape, regimes `normal` and `bear_high_vol` | — | SHORT in both (identical levels) | SHORT | SHORT |

Underlying numbers feeding B: ranges 0.547% (QQQ), 0.972% (SMH), 0.278% (SPY) — all inside the 0.15–1.5% gate,
so B fires on geometry rather than on a degenerate range. C is the check the brief asked for in a different
form: **the SHORT verdict is regime-independent**, because `allow_bearish_etf` is `True` in every branch
including fail-closed (`trend_signal.py:44,137-145`). Run A is also the general result, not a clock accident:
any time in the window is either before 10:00 (20:00–23:59 side) or after 14:30 (00:00–03:59 side), so
**`trend_signal.py:158,160` structurally rejects the entire overnight session whatever the tape shows.**
**[observed]**

The guard refuses independently — and in the opposite direction at each end, which is what makes §2b's
*single* refusal less interesting than this pair. Live `guard.py check` (byte-identical copy, sha256 prefix
`8fe26118b2a8a3fd`, pinned LIVE desk-risk-guard `1795138181446404` per a read-only `GET /forward/skills`),
verdict 2026-11-20T05:27:39Z:

| clock | guard verdict |
|---|---|
| 21:00 ET Nov 19 (first half of the window) | `after entry window (15:00 ET)` |
| 00:00 ET Nov 20 (second half) | `before entry window (10:05 ET)` |

Liquidity, had it mattered: at NAV $98,472.21 **[observed, `sim_trade_account_funds` 5830104]**, a 1%-of-NAV
sleeve cap sizes to 1,537 SQQQ / 1,163 SOXS / 3,267 SPXS, and against the observed session-to-date volume the
participation is 0.098% / 0.035% / 4.70% — so the 2% test passes for the two Nasdaq legs and is borderline on
SPXS (which is exactly the §3 shape, but see the zero-share SPXS bars above; a session-average denominator
flatters a tape that stops printing). **[inferred, from observed inputs]**

### 11.5 Timeline, recomputed in `America/New_York` (the box clock is UTC+8 and naive offsets are wrong)

From `quote_trading_days US` + the Nov-1 DST change (ET = UTC−5 now, so the overnight window *starts* at
01:00Z and *ends* at 09:00Z):

| window (ET) | opens (UTC) | closes (UTC) | notes |
|---|---|---|---|
| Nov 19 → Nov 20 (**tonight, live now**) | 2026-11-20T01:00Z | **2026-11-20T09:00Z** | 3.5 h left at the time of writing; RTH Nov 20 begins 14:30Z |
| Nov 22 → Nov 23 | 2026-11-23T01:00Z | 2026-11-23T09:00Z | next candidate |
| Nov 23 → 24, Nov 24 → 25 | 01:00Z each | 09:00Z each | Nov 25 is a **half day** (`HALF_DAYS`, Black Friday) |
| Nov 25 → 26 | — | — | **does not exist**: Nov 26 is `CLOSED` Thanksgiving |

The "can anything be built/tested/run before 09:00Z tonight" question is answered by §11.1: there is nothing to
run, because there is no order path to test. The replay above is what is achievable inside three hours with
zero cloud writes and zero orders, and it is the whole of it.

### 11.6 Recommendation for this section

**Do not build an overnight sleeve, and do not treat it as a deferred idea.** Unlike pre-market — where the
gate opened and §10 left the door ajar for a signal family *about* the pre-market — overnight on this account
family has no entry at all: the sim order schema has no code for it, the contest's own terms cap trading at
20:00 ET, and moomoo's status fields report `is_trading: false` while it runs. Any "overnight edge" work would
have to be a **real-account** project (`trading_order_place.session = OVERNIGHT` / `ALL_DAY`), which this
desk's rules put out of scope, and constraint 3 (per-ticker eligibility) becomes the first blocker there.

What this section does add is a fact worth carrying into other designs: **the overnight tape is real, readable,
and cheap to study as data.** §10's "what would change my mind" already asks for an engine about overnight gap
behaviour; §11.3's table and §11.4's bars show the data needed for that exists today via
`quote_history_kline(extended_time=2)` and the `overnight` snapshot fields, with no order capability required.
That is a research path, not a trading path, and it is the only overnight item worth scheduling.

Files this section added (all under `.scratch/overnight-6a3e18/`; no cloud writes, no git commit, no order):
`replay_overnight.py` (the A/B/C replay, imports the live engine), `guard-live-copy/` (byte-identical copy of
live `scripts/` + `references/`, run outside the live tree so no `__pycache__` lands in it), `skills.json`
(read-only `GET /forward/skills`, the version proof), and this memo. The reads behind the tables:
`quote_history_kline` (extended_time 0/1/2, ktype 6, 7 symbols), `quote_stock_quote` (7), `quote_snapshot`,
`quote_market_state`, `sim_trade_account_funds`, `sim_trade_history_order_order_list`,
`sim_trade_input_order` + `sim_trade_max_buy_sell` + `sim_trade_modify_order` + `trading_order_place` +
`quote_plate_*` + `quote_stock_screen` (**schemas only — never called to place anything**),
`quote_trading_days`.

---

## Appendix A — files written by this session

All under `.scratch/premarket-3bd872/` (my only permitted scratch dir) plus this memo. No other
file in the repository was modified.

| File | What it is |
|---|---|
| `docs/decisions/premarket-stock-nov20.md` | this memo |
| `collect.py` / `profile.py` / `stampcheck.py` / `tzcheck.py` | dataset assembly, per-date session coverage, the close-stamp proof, the tz probe |
| `analysis.py`, `analysis-out.txt` | §1/§2a/§3/§4 tables + the two-mode replay through the unmodified live engine |
| `fired-literal.json`, `fired-neutered.json` | every non-NONE signal with the input that produced it (2 and 190 rows) |
| `outcome.py`, `outcome-out.txt`, `outcome.json` | exit simulator, control groups, cost drag, the after-hours instrument dump |
| `episodes.py` | bar-rows → independent episodes (157 → 30) |
| `sizes.py`, `sizes-out.txt` | live `guard.check()` in-process: pass 1 real clock, pass 2 sizes + costs |
| `fillcheck.py`, `fillworst.py`, `fillcheck-out.txt` | per-order 20× fill-rule exposure; after-hours ticket through the live guard. **Both had a timestamp bug, found and fixed — see Appendix B.7** |
| `liquidity.py`, `liquidity-out.txt` | §3's single source: per-session volume share, the pre-market bar-volume distribution with counts of bars too thin for the approved sizes, and the zero-change / sub-100-share bar rates |
| `spreadtab.py`, `spreadtab-out.txt` | §4's next-bar half-range as a share of each ticket's own stop distance, pre vs regular |
| `bars.jsonl` | 3,648 close-stamped 5-min bars, 19 symbol-days |
| `official-rules.md` | fetched contest rules page (source of every **[documented]** quote in §1/§3a) |
| `prop-*.json`, `pf.json` | guard fixtures (synthetic $100k portfolio; **not** a live account read) |

Reproduce: `python collect.py .marker bars.jsonl` → `python analysis.py bars.jsonl <live
trend_signal.py>` → `python outcome.py bars.jsonl fired-neutered.json` → `python episodes.py` →
`python sizes.py <live guard scripts dir> outcome.json <portfolio.json>` →
`python liquidity.py` → `python spreadtab.py` →
`python fillworst.py <live guard scripts dir> bars.jsonl fired-neutered.json <portfolio.json>`.
No network calls after `bars.jsonl` exists; every number in §3–§5 is offline-reproducible.

## Appendix B — limits of this evidence, stated plainly

1. **5 trading days** (Nov 13, 16, 17, 18, 19) for the majors; **1 day** (Nov 19) for
   SQQQ/SOXS/SPXS/IWM, because `quote_history_kline` caps `num` at 370 and I did not page.
   Every single-day figure is labelled n=1 above. **[observed]**
2. **No historical bid/ask.** Spread enters only as a bounded assumption (1/2/5 ticks) and as the
   next-bar half-range, which is a *lower bound* on crossing cost, never a measured quote.
   **[undiscoverable]**
3. **The `time_et` neutralisation is a change to the input, not the engine.** It is reported as a
   *counterfactual* ("what would the geometry have said") and every such row is marked; the
   as-shipped number is §2a's 0/900.
4. **Regime forced to `normal`.** The real desk in this regime was `caution`/`bear_high_vol` on some
   of those mornings, which would have vetoed longs outright and made the results *more* empty, not
   less. The fixture is generous to the idea.
5. **`bars.jsonl` is 1× ETF tape**, so the 27 after-hours shorts could not be scored on their actual
   instruments (I have inverse bars only for Nov 19), and no next-session data exists yet.
6. **One market regime, one week, one calendar.** This is enough to reject the cheap version of the
   idea (flip the clock). It is not enough to prove that no pre-market edge exists, and §10 says what
   would be needed to look for one.
7. **A bug of mine sat in the middle of this analysis.** `fillcheck.py` and `fillworst.py` applied the
   ET offset twice (`-5 * 60` and then `* 60`), indexing each bar 7 hours from its real clock. Their
   first output — "0/157 trips the 20× rule, 2,538× headroom" — was therefore measured against the
   wrong bars, and I published those two sentences into §3 of an earlier draft of this memo before
   noticing that their QQQ pre-market median (355,872 shares) contradicted `analysis.py`'s (19,454).
   Corrected and re-run: **1/157**, worst ratio 1.725 on a 2-share SMH bar. The verification that
   caught it was checking one bar against a number I had already independently established (QQQ
   2026-11-13 06:00 ET = 7,456 shares), and the structural fix was to stop reusing those scripts'
   tables and recompute §3 from one file, `liquidity.py`. Nothing else in this memo depended on the
   buggy clock math. Recorded here because a corrected number without the correction note is not
   auditable. **[observed, self-reported]**
