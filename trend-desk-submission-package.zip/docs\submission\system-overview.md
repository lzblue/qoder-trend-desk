# System overview — Moomoo x Qoder trend desk

Prepared 2026-11-20 for the contest submission. Mailbox task `20261120T115503Z-ab0c1d`.

## 0. How to read this document

**Sources.** Every figure here comes from a file in this repository that was opened while writing it:
`AGENTS.md`, `README.md`, `docs/`, `docs/decisions/`, `.scratch/mailbox/` (contract, scripts, packages)
and `.scratch/changes/`. No live API call was made to produce this document — it is a synthesis of
recorded reads. Where a file records the instant of its own read, that instant is repeated below.

**As-of discipline.** The cloud configuration changed repeatedly during 2026-11-20 while these docs were
being written. A number quoted below is true *as of the read that produced it*, not necessarily now. Two
sources of the same fact at different times are shown side by side rather than reconciled silently.

**Evidence labels** (the convention used across `docs/decisions/`, e.g.
`docs/decisions/wake-delegation-nov20.md:11-14`):

- `[documented]` — written in a file in this repo.
- `[observed]` — read from an on-disk artifact during this task (directory listings, file contents, script output kept on disk).
- `[inferred]` — derived from the above, not stated anywhere.
- `[unsourceable]` — could not be established from what is in the repo.

**Deliberate omissions.** Trading performance, backtest results and NAV history are out of scope here and
belong to the daily reports and the strategy memos. Nothing in this file asserts a P&L figure.

---

## 1. What the system is

Three layers, on two machines-roles that are in fact one PC:

1. **The trading desk** — four Qoder Cloud Agent templates running on a cron schedule against a Moomoo
   paper-trading account, with the strategy logic held in versioned Skills rather than in prompt prose.
2. **The observation layer** — a local Express dashboard that reads the cloud sessions' event history and
   mines the structured JSON the Skills print, so a human (or a judge) can watch the desk run unattended
   (`README.md:1-8`).
3. **The engineering loop** — a filesystem mailbox between Claude Desktop (which writes task requests) and
   Qoder Desktop (which consumes them on a cron wake and does the build work), plus the change-package
   discipline that governs any write to the live cloud desk.

Contest frame: account `5830104`, $100,000 virtual funds, window 17–28 Nov 2026
(`docs/contest-rules-notes.md:4`).

**Judging weights.** Risk-adjusted return 25%, "Qoder & Qoder Cloud Agent usage" 30%, strategy & risk design
30%, reusability & documentation 15%. `[observed]` — quoted from the official page on 2026-11-25T07:21Z and
now held verbatim in `docs/contest-rules-notes.md`; the same four bullets appear twice on that page, in the
event section and in Terms & Conditions clause 2 — compared on 2026-11-25, all four are identical once the
event copy's bold markup is stripped. They were first recorded here as a
`[documented]` quotation from `docs/decisions/rules-source-of-truth-nov20.md:187` (handbook lines 674-679 /
706-711), and two caveats in that memo are now closed rather than carried: the memo's finding that
`docs/contest-rules-notes.md` "ha[d] no judging, submission or deadline content at all"
(`rules-source-of-truth-nov20.md:46`) was true when written and is fixed as of 2026-11-25, and
`docs/judging-criteria.md`, which `DRIVER.md` §3.3 asked for, still does not exist — by choice, because the
rules file is now the single place the rubric is kept.

---

## 2. Cloud agent templates

Four **production** templates, all `status: active`, all in environment
`env_00vqul91jtzi9aekyu8m` ("Default") (`AGENTS.md`, "Production templates"). The model is **not**
stable across reads: `efficient` / `context_window: 200000` for all four in the 2026-11-17 snapshot and
in the 2026-11-20 read, but `dfmodel` with `effort: high` and per-role contexts (1M researcher, 400k
coordinator and risk_auditor, 200k executor) as of the 2026-11-25T06:40Z read.

| Role | Template id | Job, in one line | Skills bound (Nov-17 snapshot) |
|---|---|---|---|
| coordinator | `tmpl_19f984c8f0fd516965b63998` | orchestrates the other three on schedule | none |
| researcher | `tmpl_d7df3829ed5d73548bb5e9ed` | market data, regime, signals; never sizes or orders | trend-signal, desk-risk-guard, decision-journal |
| risk_auditor | `tmpl_bf2c477c0fba1a3363833f91` | the only voice that can approve a ticket; writes the record | desk-risk-guard, decision-journal |
| executor | `tmpl_6c3c42cc4500efcbd6d60309` | the only agent that touches the paper account | decision-journal |

Skill bindings are pinned to explicit version ids; the 2026-11-17 snapshot records
`trend-signal@1794898969002255` at that instant. Later reads show different pins and a wider binding set:
as of the 03:08Z read on 2026-11-20, "researcher carries desk-risk-guard `1795138181446404`, trend-signal
`1795047415929677`, decision-journal `1795137748003137`, vwap-chop `1795095917868411`; coordinator carries
**none**; executor and risk_auditor carry guard + journal + vwap-chop. All pins are explicit (no binding
resolves to `latest`)" (`docs/decisions/vix-gate-proposal-a-nov20.md:80-83`). The 2026-11-25 read is
0 / 5 / 4 / 4 pins with every value listed in `AGENTS.md`, "Skills".

**"4 templates" is true only of the production set.** Two further template objects are documented in the
repo: `executor-gating-rehearsal` (`tmpl_f3214189de633d9d34ce77b6`), used for rehearsal and excluded from
the budget audit as "not production" (`docs/decisions/ticker-diversification-nov20.md:359`;
`docs/decisions/change-budget-policy-update-nov20.md:88`), and `contsched-e71c9a-probe`
(`tmpl_fd8f0fe4fc322ddb3f8cf929`), which was archived at 10:41:27Z on 2026-11-20
(`.scratch/changes/2026-11-20-stray-schedule-cleanup/README.md:28`). A five-template capture also exists:
"before/ snapshots (5 templates incl. the rehearsal template, schedules, skills…)"
(`docs/decisions/sleeve-b-readiness.md:186`). `[observed]` six distinct `tmpl_…` ids appear across `docs/`
and `.scratch/changes/`.

**The live count is nine.** `GET /templates?limit=100` on 2026-11-25T06:40Z returns 9 records with
`has_more: false`: the four production roles plus `smoke-coordinator-1122`, `smoke-researcher-1122`,
`smoke-risk_auditor-1122`, `smoke-executor-1122` (the 22–23 Nov round-trip clones) and
`executor-gating-rehearsal`; the archived `contsched-e71c9a-probe` is not among them. The clones are **not**
on the production configuration — they remain `efficient`/200k and bind desk-risk-guard `1795422986200317`
instead of the mounted pin, which is why a clone result cannot be quoted as a desk result. Full table:
`AGENTS.md`, "Non-production templates".

**Properties that changed between the Nov-17 snapshot and now**, both material to how the desk runs:

| Property | `AGENTS.md` snapshot, retrieved 2026-11-17T12:26:32Z | Live read 2026-11-20 03:0xZ | Live read 2026-11-25T06:40Z |
|---|---|---|---|
| coordinator `multiagent` | `null` — "carries no declared link to researcher/risk_auditor/executor" (Nov-17 `AGENTS.md`, observation 1) | "`multiagent` wired to the other three" (`docs/decisions/sleeve-b-golive-nov20.md:201`) | wired, `type: coordinator` over the three by `template_id` (`AGENTS.md`, observation 1) |
| `AUTONOMY_PHASE` | `approval` — verbatim in the coordinator system prompt (`AGENTS.md`, coordinator block) | `bounded` (`docs/decisions/sleeve-b-golive-nov20.md:201`) | `bounded`, and the auditor passes `--phase bounded` into `guard.py` (`AGENTS.md`, "System prompts") |
| stop orders | "place the resting STOP at the ticket's stop price" | not re-read | doctrine reversed: no stop order exists on this venue, exits ride auditor `is_close` tickets |
| sleeves | A + one option hedge | A + C bound, B blocked | A + C + B all routed in the researcher prompt |

`bounded` means auditor-approved tickets go straight to the executor with no human step
(`docs/decisions/first-scan-volatility-gate-nov20.md:378`). See §10 for why that matters.

---

## 3. Schedules

**Eleven cron schedules, all `active`, as of the 2026-11-25T06:40Z read** — seven on the coordinator and
four that fire **directly on the executor template** (`AGENTS.md`, "Schedules"). The earlier documents in
`docs/decisions/` count seven (`docs/decisions/sleeve-b-golive-nov20.md:198-200`;
`docs/decisions/vix-gate-and-zero-trades-nov20.md:415`); that was true on 2026-11-20, before the sleeve-B
`OPT-*` cadence was added on 2026-11-22.

| Schedule | Expression / slot | Fires on | Purpose, from the coordinator prompt |
|---|---|---|---|
| BRIEF | `0 9 * * 1-5` | coordinator | researcher produces the regime and day plan; auditor logs it |
| SCAN-1005 | `5 10 * * 1-5` | coordinator | signal JSON per ticker; gate approvals; ≤1 new position |
| SCAN-1100 | `0 11 * * 1-5` | coordinator | as above |
| SCAN-1230 | `30 12 * * 1-5` | coordinator | as above |
| SCAN-1400 | `0 14 * * 1-5` | coordinator | as above |
| OPT-CHECK-AM | `7,22,37,52 10 * * 1-5` | **executor** | sleeve-B option mark / monitoring, no new risk |
| OPT-CHECK-MID | `7,22,37,52 11-14 * * 1-5` | **executor** | as above, 16 slots |
| OPT-CHECK-PM | `7,22 15 * * 1-5` | **executor** | as above, afternoon |
| OPT-CLOSE-1530 | `25 15 * * 1-5` | **executor** | closes the fly's short legs before expiry |
| FLAT | `30 15 * * 1-5` | coordinator | executor closes every open position including sleeve B, cancels open orders; auditor confirms flat by 15:45 with no option position left |
| REPORT | `15 16 * * 1-5` | coordinator | auditor records NAV, updates the equity curve, writes the daily report |

All times are `America/New_York`, `cron` day-of-week `1-5`, US trading days only; the coordinator is told
that if `desk-risk-guard day` says the market is closed it must log a note and stop (`AGENTS.md`,
coordinator system prompt). The cron has **no exchange-holiday knowledge**, so 26 Nov (Thanksgiving) and
the 27 Nov half day are caught inside the run by `day`, not by the schedule.

The count on 2026-11-20 was `GET /schedules?limit=50` → **7** records, and `?limit=100&include_archived=true`
→ **8**, the eighth being a one-shot `contsched-e71c9a-q1-once` that fired once at 08:42:00Z on 2026-11-20 and
is archived and inert (`.scratch/changes/2026-11-20-stray-schedule-cleanup/README.md:22-23`). A
`status=active` filter does **not** exclude the archived record (same file, line 26) — relevant to anyone
counting schedules by filter rather than by default list. On 2026-11-25 the default list is 11 and the
one-shot is gone from it.

Two schedule fields to read carefully: the next fire is `trigger_policy.upcoming_runs_at` (an array) — there
is **no** `next_run_at` key, so a read of one returns `None` and looks like "nothing is scheduled". And
`execution.timeout_ms`, which was `1800000` on all seven on 2026-11-20
(`docs/decisions/vix-gate-proposal-a-nov20.md:82-84`;
`.scratch/changes/2026-11-20-scan-timeout-max/README.md:7`), is now `5100000` on all four SCANs, `1320000`
on the four `OPT-*`, and `1800000` on BRIEF/FLAT/REPORT. The `2026-11-20-scan-timeout-max` package raised it
on the four SCAN schedules, "APPLIED 2026-11-20T12:14:19Z" with a read-back of
`CHECK verify PASS: 4/4 records as expected` and `unexpected 0, volatile 1` (`README.md:3-10`; applied values
`3000000 / 5100000 / 5100000 / 5100000` per `README.md:236`) — SCAN-1005 has since been raised from that
intermediate `3000000` to `5100000`, so the package README is no longer the live value. There is still no
per-run credit or event budget field on a schedule, and a `sched_` write cannot be ledgered or gated.

---

## 4. The three sleeves

The desk splits its ideas into three lanes. Each lane is implemented by a Skill, and the sleeve letters are
used consistently in the Skill headers and in `docs/decisions/`. `[unsourceable]`: no single file in `docs/`
states the sleeve roster as a set — the mapping below is assembled from the per-skill contracts and the
memos, and is labelled `[inferred]` only for that assembly step.

### Sleeve A — trend / opening-range breakout (`trend-signal`)

"Opening-range breakout plus VWAP trend signal and market-regime filter for liquid ETFs (QQQ, SMH, SPY).
Takes a few numbers per ticker, returns LONG, SHORT (via inverse ETF) or NONE with entry, stop and target"
(`.scratch/changes/2026-11-20-spxs-eligibility/live/trend-signal-1795047415929677/trend-signal/SKILL.md:3`).

- Opening range: "the first six 5-minute bars (09:30-10:00 ET)" (`SKILL.md:50`), restated as
  "close-stamped 09:35 through 10:00. It excludes pre-market entirely"
  (`docs/decisions/first-scan-volatility-gate-nov20.md:46`).
- Width gate: `if not 0.15 <= rng_pct <= 1.5:` (`…/scripts/trend_signal.py:165`).
- Trigger: `price > hi + 0.1 * rng and price > vwap` → LONG; `price < lo - 0.1 * rng and price < vwap` →
  SHORT (`trend_signal.py:169-172`); otherwise NONE, "no confirmed breakout beyond the opening range on the
  right side of VWAP".
- Bearish exposure is bought as a 3× inverse ETF, not shorted: `PAIRS` maps QQQ→SQQQ, SMH→SOXS, SPY→SPXS,
  each at `"lev": 3` (`…/trend-signal/scripts/trend_signal.py:18-21`). `vwap-chop` carries the same table as
  `INVERSE = {"QQQ": ("SQQQ",3), "SPY": ("SPXS",3), "SMH": ("SOXS",3)}` (`chop.py:28`, quoted at
  `docs/decisions/spxs-eligibility-fix.md:68`). The choice is recorded as an open question — direct shorting
  is available on the account, and the trade-off is "not yet resolved" (`docs/contest-rules-notes.md:25-35`).
- Exit doctrine: "the stop at VWAP/range midpoint and 1.5R target, flat by 15:45 ET. Invalidated if after
  20 closed trades the net expectancy (after fees) is negative" (`SKILL.md:56`).
- Binding: `trend-signal@1795047415929677` on **researcher only** (`docs/decisions/spxs-eligibility-fix.md:48`).
- Recorded weakness: "**Sleeve A is not robust across regimes.** Over 84 sessions (2026-03-26…11-18)…"
  (`docs/decisions/regime-robustness-nov20.md:22`); the same memo finds the positive result concentrated in
  `caution` sessions (`:128`). On entry and exit style the 38-session replay is explicit in the other
  direction: "Marketable-limit entry and monitored-stop protection both underperform in every tested variant —
  **do not adopt either for Sleeve A** based on this evidence" (`docs/sleeve-b-findings-nov19.md:27`).

### Sleeve B — option overlay (`option-adapter`)

"Turns one already-approved Sleeve A entry plus a live option chain into a contract decision and an executor
ticket (delta band 0.25-0.50, DTE band from rules.json, premium from last_price or the book ask only), or
NONE, or STATE_UNAVAILABLE… Proposes only; it has no order path"
(`.scratch/changes/2026-11-20-spxs-eligibility/live/option-adapter-1795137189020914/option-adapter/SKILL.md:3`).
It is additive by design — it sits on top of an entry "Sleeve A has already opened and that desk-risk-guard
has already approved", and "**Sleeve B never originates a direction**" (`SKILL.md:59`).

Status **as documented on 2026-11-20**, stated plainly because the requester's framing of that week
implied more than the files did — every bullet below was true then and four of them are superseded
today:

- Bound to **zero** production templates: "`option-adapter` is bound to **zero** templates" and
  "`GET /skills` binding counts: option-adapter **0**; decision-journal 4, vwap-chop 3, desk-risk-guard 3,
  trend-signal 1" (`docs/decisions/sleeve-b-readiness.md:4-5, 96`).
- Even if bound, it would not trade: "**Binding does not make Sleeve B trade.** No prompt on researcher,
  executor or risk_auditor calls `option-adapter` yet; the wiring … is a separate change"
  (`docs/decisions/sleeve-b-golive-nov20.md:188-190`).
- The bind package is prep-only: "**Nothing in this document was applied.** No template binding, no skill
  publish, no re-pin" (`docs/decisions/sleeve-b-golive-nov20.md:5`).
- The prompt-wiring packages prepared later the same day (`2026-11-20-sleeveb-tonight/`) carry
  `OPTION_ADAPTER_V5=PLACEHOLDER` with the note that its version id "does NOT exist until that publish
  lands" (`.scratch/changes/2026-11-20-sleeveb-tonight/wiring-researcher/VERSIONS.env`).
- Two structural gaps are recorded from the 2026-11-19 read-only dry run, and both are why B is still Tier B:
  "`dte_min`/`dte_max` do not exist in `rules.json`, despite `sleeve_b_overlay`'s docstring claiming they're
  sourced from there" (`docs/sleeve-b-findings-nov19.md:17`), and "the contract picker defaults to 0DTE every
  time — sort is max-|delta| first with DTE only as tiebreak", which carries auto-exercise risk after 16:00
  ET (`:18`). The same dry run found the day's confluence gate blocked the overlay outright on both
  underlyings (`:16`).

Status **as read from the cloud on 2026-11-25T06:40Z** — B is bound, wired and rule-banded, and the
strategy it implements is no longer the overlay described above:

- **Bound and pinned on all three working roles** at `option-adapter@1795402814211564` (= head, so a
  publish is not outstanding), 6 templates binding it in total (`AGENTS.md`, "Skills").
- **The prompts call it.** Researcher SCAN step 4: "Sleeve B (the 0DTE iron fly), only when the day plan
  allows a fly: gather the venue's own underlying price (the index for SPXW, SPY for SPY), the ATM implied
  vol, today's expiry chain for that venue, the top of book on every leg…" and if the builder is missing it
  must answer `SKILL BUILD ABSENT (option-adapter)` and "never hand-build a fly to replace it". So the
  Nov-20 "no prompt calls option-adapter" gap is closed.
- **It originates a structure, not an add-on.** The coordinator's one-line strategy now carries sleeve B as
  "max loss per lot = (width - credit) x 100, lots = floor(1.5% of NAV / that), one structure a day", and
  says explicitly "**it is a risk, not a hedge**". The old "never originates a direction" contract belongs
  to the superseded overlay.
- **Sizing is now reachable.** Mounted `rules.json` `2026-11-25.2` carries the `structure` block:
  `dte: 0`, `max_loss_pct_of_nav: 1.5` (raised from 0.75 on 2026-11-25 precisely because $750 could not
  size one SPY lot), `fee_max_pct_of_credit: 12.5`, `iv_floor: 0.05`, wings from the expected move to the
  16:00 ET close, `strike_grid` 1.0 (SPY) / 5.0 (SPXW), entry cut-off `10:00–11:00` ET as its own
  authority, and the D4 quiet-and-tight gate (`|move| < 0.35 × EM` and `range < 1.0 × EM` over the six
  09:35–10:00 bars). `risk.dte_min/dte_max` stay 1–5 for the debit paths, deliberately separate.
- **Monitoring exists as a schedule family.** Four `OPT-*` schedules fire on the executor itself at
  :07/:22/:37/:52 through 10:00–15:22 ET plus `OPT-CLOSE-1530`; exit policy is in `structure.exit`
  (`first_check_et` 10:15, every 15 min to 15:30, take profit at 25% of credit, stop at 50%,
  `shorts_flat_by_et` 15:25, assignment guard after 15:00, `enforcement_lag_min` `[12, 22]`).
- **What has *not* happened: a live fly trade on the desk.** The only close in `logs/closes.csv` is the
  24 Nov SQQQ share trade, and `structure.exit` was reached on clones, not in production. The submission
  therefore scores Sleeve B as build-side coverage only — payoff bracket and mirrored downside, no dollar
  P&L — for the documented reason that 0DTE credit is unrecoverable historically (expired chains are
  purged from the venue's cache 3–4 weeks post-expiry): `docs/submission/trading-journal.md` §4.4c.

### Sleeve C — VWAP chop (`vwap-chop`)

"Sleeve C VWAP-fade signal for QQQ, SMH and SPY on sessions Sleeve A rejects because the opening range is
wider than 1.5%. Requires a rotating session (2+ running-VWAP crosses after the opening range), a stalled bar
and |z| between 1.5 and 3.0 on volume-weighted VWAP bands"
(`.scratch/changes/2026-11-20-scan-staleness/before/vwap-chop-1795095917868411/tree/vwap-chop/SKILL.md:3`).

- Handoff condition: "It fires **only** where Sleeve A says NONE because the opening range is too wide
  (`or_width_pct > 1.5`)" and "otherwise it is Sleeve A's day, not C's" (`SKILL.md:8-9, 35`; the constant is
  `A_BAND_MAX_PCT = 1.5` in `chop.py:26`). It reuses A's number and is told "Never recompute it separately"
  (`SKILL.md:29`).
- Window 10:30 ET → `flat_by_et` − 90 min (`SKILL.md:36`); 1.5R stop clearing the session extreme by
  `0.1 * sigma` (`SKILL.md:42`).
- Bound on three templates: "vwap-chop `1795095917868411` | researcher, risk_auditor, executor (3)", with the
  memo's own correction "**Sleeve C is live *and* `vwap-chop` is bound on three templates, not just the
  researcher**" (`docs/decisions/spxs-eligibility-fix.md:49, 55`).
- Its proposals go through the same risk gate as A's: "Every proposal goes through desk-risk-guard exactly
  like a Sleeve A signal" (`vwap-chop/SKILL.md:12-13`).

### Inter-sleeve findings recorded in the repo

- **Design trap, recorded and then confirmed in production**: a scan-level gate placed *before*
  `trend-signal` "would suppress the width-NONE reason and blind Sleeve C on exactly the disorderly days it
  was built for" (`docs/decisions/first-scan-volatility-gate-nov20.md:376`).
- **A and C are not separable inside the guard**: "A Sleeve C ticket is submitted as `sleeve: "trend"` — A
  and C are the same value inside the guard. An A-only scope therefore cannot be expressed at the auditor at
  all" (`docs/decisions/sleeve-c-freshness-nov20.md:78-79`).
- **C has no freshness rule** while A does: "**Sleeve C has no mechanical freshness protection at all, and
  has never had any**" (`docs/decisions/sleeve-c-freshness-nov20.md:9`, versus A's "stale (older than 5
  minutes)" at `:49-50`).
- **The dashboard does separate them** by journal field: `const sleeves = { A: {}, B: {}, C: {}, unknown: {} }`
  keyed on `normalizeSleeve(r.sleeve)` (`server.js:331, 339`).

---

## 5. Skills as the strategy carrier

`trend-signal`, `desk-risk-guard`, `decision-journal`, `vwap-chop`, `option-adapter`. They are "plain Python
with a SKILL.md contract, not Qoder-template syntax" and the risk gates are "deterministic code+config, not
LLM judgment" (`docs/decisions/PORTABILITY.md:19-26`). The prompts call them by name and pass numbers only;
the researcher is told to "Send only these numbers into the signal tool" (`AGENTS.md`, researcher prompt).
`docs/changelog.md:1-5` describes this file set as the record of "skill versions shipped, `rules.json` diffs,
prompt edits, decision memos".

### 5.1 The controls the rubric names, and where each one actually lives

The contest rubric scores "robust risk controls, including position limits, drawdown responses, and kill
switches" (`docs/contest-rules-notes.md`, quoted from the official page). All three are `rules.json` +
`guard.py` behaviour in the pinned desk-risk-guard version, read from those bytes on 2026-11-25 — not prompt
intent. Every number below is from the mounted `references/rules.json` (version `2026-11-25.2`), and the
enforcement column is what `guard.py` in the same bytes does with the key, not what the rule implies.

| Control | Rule as shipped | Enforcement, as read from the mounted `guard.py` |
|---|---|---|
| Per-asset weight | `competition.single_asset_target_pct: 35` | a **sizing** limit: `cap = nav * 35 / 100`, `q_cap = (cap - current market_value) / entry`. It shrinks the order rather than refusing it. |
| The contest's 40% cap | `competition.single_asset_cap_pct: 40` | recorded in `rules.json` and read by **nothing** in `guard.py`. The operative number is the desk's own 35%. |
| Cash floor | `risk.min_cash_pct: 10` | `q_cash = (cash - nav * 10%) / entry` — another limiter feeding the same min(). |
| Gross exposure | `risk.max_effective_gross_pct: 120`, leverage-weighted | `q_gross` on the same pattern, using `universe.leverage` for the 3x names. |
| Per-trade risk | `risk.trade_risk_pct: 0.35` (options `option_trade_risk_pct: 0.5`) | sets the starting `qty` from the entry-to-stop distance; `risk.max_open_risk_pct: 1.5` caps aggregate open risk. |
| Unpriceable book | — | hard veto: if any leg cannot be priced the guard returns `open risk not evaluable … no new risk is sized`, because the 1.5% cap cannot be measured. |
| Size that collapses | — | hard veto with `size rounds to zero (binding: <which limit>)`, and a `size limited by …` warning when a limiter other than risk-per-trade bound the order. |
| Drawdown ladder | `risk.drawdown_ladder`: >=3% `half_size`, >=5% `hedges_and_closes_only`, >=8% `kill_switch`, off `peak_nav` | `drawdown_state()` recomputes it from `nav`/`peak_nav`/`day_start_nav` every run; desk-global and self-resetting. |
| Day-loss halt | `risk.daily_loss_limit_pct: 2.0` -> `daily_halt` | same function, and only while the ladder is still `normal` or `half_size`. |
| Kill switch | `kill_switch` is the >=8% rung, not a button | prompt-level consequence: coordinator rule 3 is "Auditor state kill_switch, hedges_and_closes_only or daily_halt means no new risk in the trend, option and B sleeves. Closes are always approved, and guard exempts the `hedge` sleeve from that veto"; the auditor is told to "close everything when the state is kill_switch". |
| Missing data | — | if any of `nav`, `peak_nav`, `day_start_nav` is absent or non-numeric, `drawdown_state()` returns `state_unavailable` and the caller declines. An unread account figure is treated as a data gap, never as zero. |

Two things this table makes visible that are worth stating plainly rather than smoothing over:

1. **The position limits size orders; the ladder and the halt stop them.** Nothing in the mounted guard
   refuses a ticket for being 36% of NAV in one name — it would be sized down to 35%. That is the correct
   behaviour for a cap, but it means "position limit" in the rubric is met by arithmetic, not by a veto.
2. **`min_distinct_tickers: 3` is a desk assumption the organisers have now answered.** The guard emits, as a
   *warning* and never a veto: `ASSUMPTION to confirm with organisers: competition asks for 3+ distinct
   tickers; add another ticker`. The official terms do not ask for that — the 3-ticker figure is a consequence
   of the 40% cap, and sitting flat carries no penalty (`docs/contest-rules-notes.md`, "Resolved: no
   minimum-trades or minimum-ticker rule"). The warning text is stale against the rules page and is a
   candidate for the next rules-only publish; until then it is cosmetic, because it changes no verdict.

---

## 6. Change control, the budget gate, and the override

### 6.1 The procedure

`DRIVER.md` §6, labelled "non-negotiable", is six steps per change
(`.scratch/mailbox/DRIVER.md:69-80`): (1) save the current effective config to
`.scratch/changes/<date>-<slug>/before/` plus an idempotent `apply` and a `rollback` — "A change with no
tested rollback is not allowed"; (2) verify offline or by replay; (3) verify on a rehearsal/sandbox session,
read-only or dry-run; (4) apply in the change window only, with pinned skill versions and "no binding may
resolve to `latest`"; (5) fetch the effective config, diff against intended, record before/after refs and
rollback in the ack (`cloud_changes`) and in `docs/changelog.md`; (6) confirm on the next live run, and roll
back immediately on regression.

The window is 16:45–08:30 ET, and editing during 09:00–16:30 runs is forbidden
(`.scratch/mailbox/DRIVER.md:51`).

Authority is tiered: **Tier A — decide and ship** covers prompt wording, skill code fixes, run reliability,
alerting, data-source fallbacks, logging and dashboard work; **Tier B — stop and ask the user** covers
anything that changes risk-taking or contest exposure, including `rules.json` keys, adding tradable tickers,
"enabling Sleeve B or any option adapter live", switching inverse ETFs to direct shorts, changing
`AUTONOMY_PHASE`, or "probes or any manual action on account 5830104" (`.scratch/mailbox/DRIVER.md:85-92`).
The memos in `docs/decisions/` carry their tier in the title line, e.g. "Tier B decision memo — per-ticker
concurrent Researcher children" (`docs/decisions/concurrent-researcher-tickers.md:1`).

### 6.2 The budget gate

The v1 rule is one line of §6.4: "One change per template per day so effects can be attributed"
(`.scratch/mailbox/DRIVER.md:76`).

It was replaced by a **v2 rule** in `docs/decisions/change-budget-policy-update-nov20.md`: up to **two**
changes per template per **America/New_York calendar day**, the second allowed only when **both** hold —
**(A)** the first change is applied, re-verified live, and shown to behave downstream (a real run, or before
any run exists a live-read verification plus a synthetic/replay check against the new bytes); and **(B)** the
two changes touch **non-overlapping artifacts** (`system` vs `skill/<skill_id>`)
(`change-budget-policy-update-nov20.md:1, §1`). "A rolled-back change never satisfies (A), though it still
counts toward the cap", and "The first change of an ET day on a template that carries an unledgered same-day
write is refused" (`:§1`).

The gate is one implementation, `runGate({scope, ledgerPath, base, log})` in
`.scratch/proposal-a-1120/tools/budget.mjs`, with a second adapter deriving scope from live bindings
(`change-budget-policy-update-nov20.md:§3`). It resolves eleven states per in-scope template — outside the
16:45–08:30 window, no ledger entry today, unledgered same-day write, ≥2 entries (cap), ledger/state
mismatch, rolled-back, failed read-back, missing downstream proof, downstream outcome not `as_expected`,
intersecting artifacts, and the single allowed change-#2 path. Exit codes: 0 eligible, 2 bad invocation
(including a deliberate ET self-check that "asserts 05:00:00Z→Nov-20 00:00 ET … so an unusable
`America/New_York` fails loud instead of misdating the budget"), 3 refused (`:§3`).

The ledger is `.scratch/changes/budget-ledger.json`, `schema: 2`, one entry per applied change with
`artifacts`, `applied {go, at_utc, confirm}`, `readback {ok, detail}` and
`downstream {kind: "live_run"|"replay", outcome, ref}` (`:§3`). `[observed]` it currently holds 4 entries:
researcher `system`, coordinator `system`, risk_auditor `system`, coordinator `system` — the last three all
on ET-day 2026-11-20.

### 6.3 The owner override, and what a refusal actually stops

The gate is advisory against a determined writer, and the design says so. Passing a refusal requires the
owner's explicit `OWNER_OVERRIDE=1`; the script never decides that itself — "apply.sh/rollback.sh treat only
0 as 'may proceed'; a refusal is quoted verbatim and the owner's `OWNER_OVERRIDE=1` is what gets past it --
this script never decides that itself" (`.scratch/changes/2026-11-20-entries-per-scan/tools/gate.mjs:8`).
The refusal path prints the exact override line and then demands the attribution record:

```
if [ "${OWNER_OVERRIDE:-0}" != "1" ]; then
  echo "   Nothing was written. Continue only with the owner's explicit OWNER_OVERRIDE=1…"
  exit 3
fi
echo "   OWNER_OVERRIDE=1 is set, so this run proceeds past the gate BY THE OWNER'S AUTHORITY, not the script's."
```
(`…/entries-per-scan/tools/apply.sh:57-62`), and "This package's entry records the OWNER_OVERRIDE, because
the gate refused and the apply happened anyway -- that is the attribution the ledger exists for" (`:99-100`).
Rollback is under the same discipline: "rollback also runs the gate; a second same-day write needs
`OWNER_OVERRIDE=1` the same way" (`:109`).

The honest limit is stated in the policy memo: "the ledger is a local file and the cloud has no budget
concept, so enforcement is at the gate… A session that bypasses the gate entirely is caught at the *next*
gate run by row 3, not prevented… nothing stops an unscripted raw POST"
(`docs/decisions/change-budget-policy-update-nov20.md:140-146`).

Two gaps worth a reader's attention:

1. **The v2 rule is implemented in code but not yet in the governing document.** The §6.4 replacement is
   "**STAGED, not applied**" (`change-budget-policy-update-nov20.md:17`), and `.scratch/mailbox/DRIVER.md:76`
   still carries the v1 text. The gate enforces v2; the file a human reads says v1.
2. **`OWNER_OVERRIDE` has no decision memo.** `[observed]` `grep -rn OWNER_OVERRIDE docs/` returns nothing;
   the mechanism exists only in the package scripts and their transcripts. The owner grant is recorded in the
   package README rather than in `docs/decisions/`.

Separately, the **trading**-level owner checkpoint is `AUTONOMY_PHASE`. In `approval` mode the coordinator
must "show the ticket … and wait for an explicit yes in the conversation. No answer means no order"; in
`bounded` mode approved orders "go straight through" (`AGENTS.md`, coordinator rules 2). The live read at
03:0xZ on 2026-11-20 reports `bounded` (`docs/decisions/sleeve-b-golive-nov20.md:201`), which combined with
`always_allow` means "there is no human checkpoint in the" live path
(`.scratch/changes/2026-11-20-scan-timeout-max/README.md:122`).

---

## 7. What a change package looks like

The pattern, as the repo itself states it: "before/ live GET → CONFIRM token over before/ → budget gate →
preflight byte-diff → `GO=1` write → read-back that only the intended fields moved → rollback → mock
round-trip. Every one of those steps presumes a field that changes"
(`.scratch/changes/2026-11-20-stray-schedule-cleanup/after/NONE.md:3-8`).

`[observed]` 19 package directories exist under `.scratch/changes/`, all dated 2026-11-20. The pattern is
real but not uniform, and the variations are the interesting part.

**CONFIRM tokens — three different designs, not one.**

- *Content digests of before and after* (the majority of the full-strength packages): "It writes only with
  BOTH: `GO=1 CONFIRM=<sha12-before>,<sha12-after>` … the first 12 hex of the sha256 of the CURRENT live
  prompt and of the NEW prompt" (`entries-per-scan/tools/apply.sh:6-9`). Live evidence:
  `CONFIRM=25f673100b2d,ef9214565277` (`.scratch/changes/2026-11-20-journal-persistence/README.md:4-5`).
- *A composite that is not a pure before-hash*: `sha(rows.map(r => `${r.id}:${r.before_sha256}:${r.after_timeout_ms}`).join("\n")).slice(0,16)`
  (`scan-timeout-max/tools/payload.mjs:62-63`), and `release-sequence/apply.sh:60-62` derives its token from
  **after** digests only.
- *Human-chosen literals*, where the change is a bind/unbind rather than a byte swap:
  `CONFIRM=BIND-OPTION-ADAPTER` to apply, `CONFIRM=UNBIND-OPTION-ADAPTER` to roll back — "an undo is never
  reachable with the enable token" (`docs/decisions/sleeve-b-golive-nov20.md:153`;
  `sleeveb-golive/template-skills.mjs:24`). `spxs-eligibility/A-remove-spxs/apply.sh:36-44` uses
  `REMOVE-SPXS-A` / `ROLLBACK-SPXS-A`.
- `[observed]` Five packages have **no CONFIRM gate at all**: `calendar-noentry` (`CAND=1 GO=1`),
  `guard-failsafe` (`GO=1 MEMO=read`), `scan-staleness` (`GO=1 IN_WINDOW_ACK=Y`), `signals-write-once`
  (`APPLY_WO=1`), `sleeveb` (`APPLY_SLEEVEB=1`).

**GO gate.** Present in the ten packages that can write, and deliberately never defaulted: "GO is
${GO:-<not set>} -- go.sh never sets and never defaults it" (`scan-timeout-max/tools/go.sh:104-106`).
Refusals are explicit: "`REFUSED: GO=1 without MEMO=read`" (`guard-failsafe/apply.sh:31-34`).

**Snapshots and read-back.** `before/` holds live GET bodies with sha256 indexes
(e.g. `entries-per-scan/before/capture-report.json`: `record_bytes`, `record_sha256`,
`system {chars 3684, sha256 4246c3bf…, lines 22}`). Read-back proves field-level containment:
`only_field_changed: "execution.timeout_ms"` plus per-row `untouched_fields[19]`
(`scan-timeout-max/after/manifest.json`), and post-apply transcripts such as "`CHECK verify PASS: 4/4
records as expected`" with "`unexpected 0, volatile 1`" (`scan-timeout-max/verify/readback-applied-2026-11-20T12-14Z.txt`;
also `journal-persistence/probe/verify-after-apply.txt`: "`PASS non-system fields vs before/: []`").
A preflight byte-diff runs first and aborts on drift: "`byte-diff vs …: IDENTICAL|DRIFT`", exit 4
"`ABORT: the cloud does not hold the bytes…`" (`entries-per-scan/tools/write-system.mjs:75-102`).

**Rollback restores the before bytes.** "put the exact bytes in before/ back into each template's `system`
field" (`scan-staleness/rollback.sh:2`); local-file rollback by copy (`ack-guard/rollback.sh:7-8`); and
"Restores the five touched live files from before/ and retires plan.mjs by MOVING it, never deleting"
(`wake-delegation/rollback.sh:3-4`). `calendar-noentry/rollback.sh:16` is the exception: a re-pin to
`BASELINE=1795100050849622` rather than a byte restore.

**Mock round-trips are loopback-forced, and the code says so.** "against the local mock Forward API …
Nothing here touches api.qoder.com" (`entries-per-scan/tools/roundtrip.sh:2-5`); `FORWARD_BASE` may only be
loopback (`spxs-eligibility/tools/lib.mjs:32-34`); and a test run against the production base throws
"`A test run must not write for real.`" (`release-sequence/tools/release.mjs:114-119`). Where a package's
`after/` was produced against `http://127.0.0.1:4199/api/v1/forward` (`scan-staleness/after/apply-summary.json:4`)
those artifacts are mock output, not live state — which is exactly why that package is labelled unapplied.

**Which packages actually reached the cloud.** Three, each applied by the owner typing the line:

| Package | Status on disk | Evidence |
|---|---|---|
| `journal-persistence` | APPLIED 10:54:56Z, "8/8 read-back PASS" | `README.md:4-7` ("The owner typed `OWNER_OVERRIDE=1 GO=1 CONFIRM=25f673100b2d,ef9214565277 bash tools/apply.sh`") |
| `entries-per-scan` | APPLIED, ledger seq 4 | `probe/apply-live.txt`, `budget-ledger.json` seq 4 `confirm 4246c3bfeca2,54b3185fc110` |
| `scan-timeout-max` | APPLIED 12:14:19Z, "4/4 records as expected" | `README.md:3`, applied by `GO=1 CONFIRM=86c91d5bf87d6bb5 bash …/tools/apply.sh` (`README.md:12-16`) |

The rest are prep-only and say so: "**neither applied**" (`spxs-eligibility/README.md:5`), "Prep only"
(`sleeveb-golive/README.md:3`), "`GO=1` was never set against `api.qoder.com` in this session"
(`scan-timeout-max/proof/LIVE-AT-HANDOFF.md:13-21`, an earlier handoff state),
`ticker-diversification` and `guard-failsafe` likewise.

**Failure evidence is kept, not deleted.** `[observed]` round-trip transcripts with failures remain on disk:
"`== ROUND-TRIP VERDICT == 38 PASS / 1 FAIL`"
(`sleeveb-tonight/wiring-researcher/probe/roundtrip.log:143`), "`29 PASS / 1 FAIL`"
(`sleeveb-tonight/wiring-auditor/probe/roundtrip-4344.log:84`), and "`VERDICT: 4 FAILURE(S) (9 cases)`"
(`sleeveb-tonight/wiring-optcheck/probe/mock-roundtrip-optcheck.log:90`). Passing tallies also sit on disk:
`entries-per-scan/probe/roundtrip.log:74` "25 PASS / 0 FAIL", `release-sequence/proof/roundtrip.txt:6`
"11 passed, 0 failed", `spxs-eligibility` "31 passed, 0 failed",
`proposal-a` suite "exit 0, 27 PASS, 0 FAIL, `ROUND TRIP: PASS`"
(`docs/decisions/change-budget-policy-update-nov20.md:§4.1`). `[observed]`
`guard-failsafe/roundtrip/` exists but is empty, and `ack-guard/after/` is empty — the directory shape
overstates completeness in those two cases.

**Negative space is documented too.** A package with nothing to apply writes a note instead of a script:
"An `after/` directory would therefore have to contain a byte-identical copy of `before/`, and a rollback
script would have to restore a state that was never left. Writing those would make the package look
applicable when it is not" (`stray-schedule-cleanup/after/NONE.md:15-17`).

**Coverage matrix** `[observed]`:

| Package | apply | rollback | before/ | after/ | round-trip | verify/proof |
|---|---|---|---|---|---|---|
| entries-per-scan | ✔ | ✔ | ✔ | ✔ | mock | live + mock |
| journal-persistence | ✔ | ✔ | ✔ | ✔ | mock | live |
| scan-timeout-max | ✔ | ✔ | ✔ | ✔ manifest | mock | live |
| release-sequence | ✔ | ✔ | ✔ | ✔ | mock | 11 checks |
| spxs-eligibility | ✔ (A, B) | ✔ | ✔ | ✔ | mock | ✔ |
| sleeveb-golive | ✔ | ✔ | ✔ | ✔ | mock | compare.txt |
| calendar-noentry | ✔ (no CONFIRM) | ✔ (re-pin) | ✔ | ✔ real version id | ✖ | ✔ |
| scan-staleness | ✔ (no CONFIRM) | ✔ | ✔ | mock only | mock | ✔ |
| guard-failsafe | ✔ (no CONFIRM) | ✔ | ✔ | dry-run log | **empty dir** | tests/live |
| sleeveb-tonight (4 wirings) | ✔ | ✔ | ✔ | ✔ | probe logs | ✔ (with FAILs) |
| sleeveb | ✔ (flag-only) | ✔ | ✔ | ✔ | ✖ | ✖ |
| signals-write-once | ✔ (flag-only) | ✔ | ✔ | ✔ | ✖ | semantics.txt |
| ack-guard | ✖ | ✔ (cp) | ✔ | **empty** | test only | ✔ |
| wake-delegation | ✖ | ✔ | ✔ | ✖ | harness | publish-log |
| adhoc-reporting | ✖ | ✖ | ✖ | ✖ | ✖ | proposed.md only |
| ticker-diversification | ✖ (apply.py) | ✖ | ✔ | out/ | ✖ | verify.txt |
| record-change-fix | present | — | — | — | — | not opened in this task |
| stray-schedule-cleanup | ✖ (deliberate) | ✖ (deliberate) | ✔ | `NONE.md` | ✖ | re-runnable verify |
| ack-ownership | ✖ | ✖ | ✖ | ✖ | ✖ | two .md files |

---

## 8. The engineering delegation loop (mailbox protocol)

Root `.scratch/mailbox/`, contract **v2.1** (`CONTRACT.md:1`). Direction of travel: "Claude drives through
`mbx.mjs` (atomic writes, polling, status). Qoder consumes via a cron wake. Qoder cannot be woken directly;
it can only be asked." (`CONTRACT.md:5-6`).

**Layout** (`CONTRACT.md:10-18`): `inbox/` requests, `outbox/` Qoder-initiated questions and escalations,
`acks/` Qoder→Claude status, `done/` archive, `results/` long results, `payloads/` long prompts, `tmp/`
scratch, `heartbeat.json`.

**Message and ack schemas** (`CONTRACT.md:21-35`). Message kinds: `ask`, `spawn`, `notify`, `cancel`. Ack
status moves `accepted` → `done` | `failed` | `rejected`, and a code ack must list `files_changed` and the
verification actually run, because "Claude does not take it on trust; it re-runs the checks itself"
(`CONTRACT.md:35`).

**Concurrency rules**, which are where the design lessons are recorded:

- *Claim before work*: an `accepted` ack is written as the first action of a non-idle wake, before any
  reading or editing (`CONTRACT.md:43`). The stated reason is a specific incident: "on 2026-11-19 two wakes
  2 minutes apart both consumed and re-spawned the same batch, and a session that had not read `acks/`
  replaced a `done` ack with `accepted` 28 seconds after it was written."
- *Claims are bounded and releasable*: a `RELEASED` marker voids a claim, and an `accepted` claim older than
  20 minutes with no terminal ack may be taken over (`CONTRACT.md:44`). Releasing by writing `failed` is
  forbidden, because a terminal ack auto-archives the message and "a fake failure would bury unfinished work".
- *Ack ownership was reversed* (`CONTRACT.md:47`, rule 4): the spawned child now owns its own terminal ack.
  The rationale is recorded, including the measured cost of the old rule — "four ids left `accepted` an hour
  after their children finished". The underlying investigation is
  `docs/decisions/ack-ownership-nov20.md`, whose verdict disconfirms the "automation cannot observe the
  child" hypothesis and identifies an ownership vacuum instead (`:3-9`).
- *The wake dispatches; it does not do* (rule 4a, `CONTRACT.md:48`): a tick may check, claim, run recon,
  spawn, and answer `ask`/`notify`/`cancel`, but "MUST NOT perform a dispatched item's substantive work in
  its own turn". Overflow is queued, never absorbed. The concurrency cap is explicit policy, not platform:
  "measured 2026-11-20, six children were `running` at once at 03:18Z and ten at 00:36Z, so only this rule
  makes 4 real." `[observed]` `plan.mjs` defaults its ceiling to 10, not 4: "`--cap 10` override the policy
  ceiling (default 10; CONTRACT rule 4 states 4)" (`.scratch/mailbox/plan.mjs:8, 42`), and the header calls
  the cap "advisory … the ceiling is a policy per batch, not a platform" limit (`:26`). The policy and the
  default disagree on the record.
- *Refusals are pre-declared* (rule 8, `CONTRACT.md:52`): a session must reject and ack
  `rejected` / `error:"needs-human"` rather than delete non-scratch project files, force-push, place live
  orders, change live trading behaviour, move money, or publish anything off this machine. Rule 9 forbids
  secrets in messages, acks or results; `.env` is referenced by path only.

**Timing.** The tick is `*/2 * * * *` (`.scratch/mailbox/cron.json`, task `05d67f16-…`), and that file is
self-described as "a hand-kept statement of what the tick is set to, not a live read", because "The Desktop
scheduled-task tool is not reachable from a mailbox-wake session". The acknowledged side effect: "individual
wake runs take longer than 2 minutes, so ticks fire while an earlier wake is still working the same batch".

**Component split**, which is deliberate and explained: `plan.mjs` is read-only on purpose — "the thing that
has gone wrong is a wake deciding to do the work itself, so the component that tells it what to dispatch must
not be able to do any work either" (`.scratch/mailbox/plan.mjs:2-5`); `recon.mjs` classifies session state
and can self-correct clean cases (`recon.mjs:2-9`); `sweep.mjs` detects scratch work with no mailbox record
and publishes `outbox/` notifies before it prints, "so detection never depends on the wake reading or acting
on its output" (`sweep.mjs:2-6`). The four sweep findings, their guards and their stated limits — including
"session activity is invisible to the sweep" and "the suppression test is a substring match" — are written
out in `CONTRACT.md:62-114`.

Why the sweep exists is itself documented: a completed answer directory sat unnoticed because the producing
session had been told not to touch the mailbox and its one handoff attempt failed silently
(`CONTRACT.md:64-68`).

`[observed]` This document is an artifact of that loop: dispatched as inbox
`20261120T115503Z-ab0c1d.json`, briefed via `payloads/ab0c1d-child-brief-1208z.md`, claimed by the 12:08Z
wake, and terminal-acked by the child session that wrote it.

---

## 9. The local dashboard

An Express server on port 4173 that is a *reader*, not a controller (`README.md:22-33`). Its line numbers
move every time the file changes, so this section cites symbols:

- `const TEMPLATES` — the four template ids come from the environment (`TMPL_COORDINATOR`,
  `TMPL_RESEARCHER`, `TMPL_EXECUTOR`, `TMPL_RISK_AUDITOR`), with `QODER_PAT` from `.env`; the browser never
  sees the token (`README.md:31-33`).
- `GET /api/sessions` lists Forward sessions for all four templates, newest first; `GET /api/overview` pulls
  event history for the most recent sessions and "mines it for JSON blobs matching our skills' known output
  shapes (guard verdicts, signal regimes, equity rows, stats)" to assemble the equity curve, drawdown, latest
  NAV, win rate, decision log and recent signals (`README.md:35-44`).
- Endpoints `[observed]`, by route string in `server.js`: `/api/health` (reports `hasPat` and the template
  map), `/api/mailbox`, `/api/sessions`, `/api/overview`, `/api/sleeveb`, `/api/activity`. The mailbox panel
  reports wake age, nominal/observed/effective interval, inbox count, total acks, acked-not-closed and recent
  acks (`function mailboxState`) — i.e. the delegation loop is observable from the same page as the desk.
- The activity strip buckets journal records by sleeve and refuses to print an unsupported zero: "when no
  journal record exists yet the strip says so instead of printing a confident zero" (`function activityView`).
- **One 2026-11-25 fix, because the equity curve was structurally empty.** A live REPORT session was read
  back from `GET /sessions/{id}/events` (53 events, `sess_00whyryhczqbkeidn0m4`, 24 Nov 21:15Z) and the
  miner's `collectFromEvents` returned **zero records in every bucket**. The reason is not the key list:
  `journal.py equity` really does emit `{date, nav, bench, drawdown_pct}` (verified across every captured
  decision-journal build, none of which writes `spy_close`), but in production the equity never reaches the
  event stream as a JSON blob — it reaches the coordinator's stream as *prose inside a `tool_result`*, in
  this case a Read of the awareness journal whose header is
  `et_date,nav,spy_close,peak_nav,signals,vetoes,approvals,fills,closes,net_realized_pnl,expectancy,n`.
  A key-set test cannot match prose, so `buildDesk` now also reads the desk's own ledger
  (`function readEquityLedger`, `logs/equity.csv`) and the ledger wins per date, with mined rows used only
  for dates the ledger lacks. `/api/overview` then returns 3 curve points and `latest_nav` 99825.82 — the
  same NAV as §1 of the trading journal, which is the point of the check.
- Frontend: `public/index.html`, `public/app.js`, `public/sleeveb.js`, `public/style.css` `[observed]`. Only
  `nav` and `drawdown_pct` are plotted; `bench` is carried but not charted, so mapping the ledger's
  `spy_close` into it cannot distort a scale.
- No Moomoo credential is needed here: the agents already hold MCP access and "their tool calls/results are
  what gets mined out of the session event log" (`README.md:45-47`).
- Maintenance coupling worth naming: if a skill's output format changes, `GUARD_KEYS` / `SIGNAL_KEYS` /
  `JOURNAL_EQUITY_KEYS` / `JOURNAL_STATS_KEYS` at the top of `server.js` must be updated "so the miner still
  recognizes it" (`README.md:57-59`) — and the 24 Nov read above is the case where that instruction is not
  enough, because the output was never machine-shaped JSON in the first place.

Git posture: a local baseline only, `.scratch/` and `.env` excluded before `git init`, "No remote configured
and nothing pushed — local-only" (`docs/changelog.md:9-16`).

---

## 10. Defects and unenforced claims recorded by the project itself

`AGENTS.md` is a read-only snapshot, re-retrieved 2026-11-25T06:40Z (the previous version was
retrieved 2026-11-17T12:26:32Z) and it keeps a numbered list of cross-template observations. They are
reproduced here because a system overview that omitted them would describe a design rather than the
system. The left-hand quotation is the 2026-11-17 wording; the right-hand note is the 2026-11-25 read.

1. **`always_allow` everywhere.** "All four templates grant the same 13 tools with `permission_policy:
   always_allow`, including the executor that submits orders. The `AUTONOMY_PHASE=approval` gate and the
   auditor's veto are therefore prompt-level conventions with no corresponding permission boundary."
   **Superseded.** There are now two toolset entries per MCP-connected template: `agent_toolset_20260401`
   (still `always_allow`, 12 named `enabled_tools`) and `mcp_toolset`, which carries per-tool
   `always_deny` on the whole live-money and crypto order family on all three roles, and additionally
   `always_deny` on `sim_trade_input_order` / `_cancel_order` / `_modify_order` for researcher and
   risk_auditor while granting those six `sim_trade_*` tools to the executor (`AGENTS.md`, "Tool and
   permission posture"). The permission boundary the snapshot said did not exist now does — but it
   delimits *which tools*, not *which account*, and with `AUTONOMY_PHASE=bounded` there is no human
   approval step left to gate.
2. **The auditor's "read-only" is not configured.** risk_auditor and executor have identical `tools` and
   identical `mcp_servers`, "so the read-only claim in the auditor prompt is unenforced at the MCP/tool
   layer". **Partly superseded:** the auditor is now denied every order-mutating tool, including the
   paper-account ones; what remains unenforced is the choice of `acc_id` on a read.
3. **Malformed researcher template name.** `name: "researcherTrend desk researcher: market"` on
   `tmpl_d7df3829ed5d73548bb5e9ed`, with that template's `description` the only empty one of the four —
   "consistent with the description text having been concatenated into `name` during creation".
   **Fixed as to `name`**: it is `researcher` today. `[observed]` every occurrence of the malformed
   string in this repo sits in a read capture (`…/raw/`, `…/probe/`, `…/mirror-root/tmp/`), not in an
   applied-write package — so the write that fixed it is not documented here, and `description` is
   still `""`, leaving the cosmetic half open. The Tier A classification is
   `.scratch/mailbox/DRIVER.md:86` ("cosmetic fixes such as the researcher template name"); that file
   is mailbox scratch and is **not** part of the shipped package.
4. **Account conflict.** The coordinator prompt restricts the desk to "competition account only" and the
   executor prompt requires an account whose "name contains 'Qoder'", i.e. paper account `5830104`; the
   snapshot records that the operator session it was taken in works `3732983` and never `5830104` —
   "The cloud desk and this session are pointed at different accounts; nothing was changed to reconcile
   them." **Still true**, and the executor prompt now hardens the discriminator: `account_type == 2`
   **and** a title containing "Qoder", explicitly *not* `market_id`, because the two accounts share it.
5. **No delegation wiring in the Nov-17 snapshot** — later superseded, see the table in §2 and
   `AGENTS.md`, observation 1.
6. **No mounted files or injected environment.** `files`, `github_repositories` and
   `environment_variables` are empty on all four, so "`guard.py` / `journal.py` invocations named in the
   prompts must come from the bound skills". Still true on 2026-11-25, and it is what makes the skill
   pins the code version of record.
7. **The "cloud version" a reader might look for does not exist.** "Forward template objects expose **no
   version or revision field**"; `updated_at` is the only monotonic marker, and `…/versions` and
   `…/revisions` both return 404. Still true. One addition, because it burned the 17 Nov snapshot:
   `created_at` is *reset on edit*, so `created_at == updated_at` does **not** mean "never edited".
   Skill bindings do carry a real build id, and that is what the pins record.
8. **A live eligibility violation with an unapplied fix.** "**The violation is real and live.** `SPXS` — the
   engine's bearish instrument for SPY…" (`docs/decisions/spxs-eligibility-fix.md:20`), with two candidate
   packages and the ordering rationale in `docs/decisions/tonight-release-sequence-nov20.md:12-16`; the
   packages are "neither applied" (`spxs-eligibility/README.md:5`).
9. **A ledger gap the harness caught.** The gate's own fail-closed rule (row 3) exists because "If a template
   was written today but no ledger record exists, condition A is *unshowable*"
   (`docs/decisions/change-budget-policy-update-nov20.md:68-70`); `[observed]` `budget-ledger.json` has 4
   entries while more than four cloud writes are recorded across package READMEs and the release memos.
   The ledger has since grown to **52 entries** (`seq` 1–52,
   `.scratch/changes/budget-ledger.json`, `schema: 2`); the three 2026-11-25 desk-risk-guard
   re-pins (seq 47–52) were each filed with the owner's override recorded in
   `applied.confirm` and an explicit `rollback.single_write`. `[observed]` `drift_check.new_version`
   is empty on seq 43–46, so those four writes cannot be reconstructed from the ledger alone —
   the live pins in `AGENTS.md` are the primary record for them.
10. **New on 2026-11-25: the mounted build is not the head build.** desk-risk-guard head is
    `1795584029544437` (published 05:20:29Z, `guard.py` 92,283 bytes, sha `6f51bf8cf968…`); the three desk
    roles pin `1795580552453332` (`guard.py` 87,747 bytes, sha `a4ea554b1d1a…`) with an otherwise identical
    file set and the same `rules.json` `2026-11-25.2`. Nothing in the template API reveals this — it takes a
    `GET /skills` head read next to the per-template pin. Any verdict reproduced for the submission must
    come from the **pinned** bytes, which is what §4 of the journal does.

---

## 11. What is reusable, and what is not

`docs/decisions/PORTABILITY.md` keeps an explicit inventory, built "lazily as a side-effect of normal work"
(`:3-6`).

**Already portable, no rework expected** (`:14-28`): the moomoo MCP server (standard MCP); the skill code —
`trend-signal.py`, `guard.py`/desk-risk-guard, `journal.py`, `vwap-chop`, `option-adapter` — as "plain Python
with a SKILL.md contract, not Qoder-template syntax"; `rules.json` and the guard gates as "deterministic
code+config, not LLM judgment", which the memo argues is why "the system's safety properties shouldn't
degrade much even on a weaker local model"; and the mailbox protocol as "pure filesystem + JSON. No Qoder
dependency at all."

**Coupled** (`:30-42`): schedule and cron timing "currently lives only in Qoder's template JSON, not in a
portable schedule file"; and any prompt wording that relies on a specific model's reasoning strength is a
hidden coupling, which the DeepSeek-Flash A/B is probing.

**Reuse visible inside this repo** `[observed]`: the shared gate implementation is one function consumed by
two adapters (§6.2); later packages copy the `tools/` + `before/` + `after/` + `roundtrip` shape from
`entries-per-scan`; `wake-delegation` ships a fixture mailbox root
(`harness/mirror-root/`) so the dispatcher can be tested without touching the live batch; and the decision
memo has a consistent header form (task id, tier, claim tags, "Nothing was applied") that ~20 memos repeat.

---

## 12. Claims in the tasking that this document could not source

Recorded rather than smoothed over, because the tasking brief asked for verification rather than copying:

| Claim in the request | Finding |
|---|---|
| "4 Qoder Cloud Agent templates" | True for the **production** set at every read. The live set is bigger: six template ids in the 20 Nov sources, **nine** in `GET /templates?limit=100` on 2026-11-25 (four production + four `smoke-*` clones + `executor-gating-rehearsal`); §2. |
| "7 cron schedules" | Confirmed against a read at 12:46–12:56Z on 2026-11-20 on the default list; the archived-inclusive list returned 8. The 2026-11-25 default list returns **11**, four of them attached to the executor rather than the coordinator; §3. |
| "the 3 sleeves" | A/B/C are individually defined and their skill mapping is documented, but no single file states the roster as a set. §4. |
| "15% of judging is reusability & documentation; 30% is Qoder/Cloud Agent usage" | Unsourceable when this file was first written, and **now sourced**: all four weights, the submission list and the deadline are quoted from the official page at 2026-11-25T07:21Z into `docs/contest-rules-notes.md`, which is the rules-of-record. `docs/judging-criteria.md` still does not exist, deliberately. §1. |
| "CONFIRM tokens computed from `before/`" | True for the digest-pair packages; three other forms exist (composite, after-only, human-chosen literal) and five packages have no CONFIRM gate. §7. |
| "owner-override model" | Two distinct mechanisms are conflated by that phrase: `OWNER_OVERRIDE=1` past the budget gate (code-only, no memo in `docs/`) and `AUTONOMY_PHASE=approval`/`bounded` at the ticket level. §6.3. |
| "before/after snapshots, mock roundtrips, rollback scripts" demonstrate the pattern for "tonight's go-live packages" | The pattern is real, but of 19 packages only 3 have evidence of an actual applied cloud write; the go-live packages named in the request (`sleeveb-golive`, `spxs-eligibility`) are explicitly prep-only, and one package's `after/` is mock output. §7. |
| "Ready by 15:00Z" | Met for this deliverable: `docs/submission/` did not previously exist `[observed]` and this file is the first content in it. |

---

## 13. Source index

Files opened while producing this document, by section:

- Repo root: `AGENTS.md` (snapshot 2026-11-17T12:26:32Z), `README.md`, `server.js`,
  `docs/changelog.md`, `docs/contest-rules-notes.md`.
- Architecture / rules: `docs/decisions/rules-source-of-truth-nov20.md`,
  `.scratch/mailbox/DRIVER.md` §6–§7, `.scratch/mailbox/cron.json`.
- Sleeves: `docs/decisions/{regime-robustness,sleeve-b-readiness,sleeve-b-golive,first-scan-volatility-gate,sleeve-c-freshness,spxs-eligibility-fix,vix-gate-proposal-a,vix-gate-and-zero-trades,ticker-universe,ticker-diversification}-nov20*.md`,
  `docs/sleeve-b-findings-nov19.md`, and the `SKILL.md` / script files captured under
  `.scratch/changes/2026-11-20-{spxs-eligibility,scan-staleness}/`.
- Change control: `docs/decisions/change-budget-policy-update-nov20.md`,
  `docs/decisions/tonight-release-sequence-nov20.md`, `.scratch/changes/budget-ledger.json`, and the
  `apply.sh` / `rollback.sh` / `gate.mjs` / `roundtrip*` / `verify*` / `probe` / `proof` artifacts of the 19
  packages listed in §7.
- Mailbox: `.scratch/mailbox/CONTRACT.md` (v2.1), `plan.mjs`, `recon.mjs`, `sweep.mjs`,
  `docs/decisions/{wake-delegation,ack-ownership}-nov20.md`, plus this task's inbox message, child brief and
  ack under `.scratch/mailbox/{inbox,payloads,acks}/`.
- Portability: `docs/decisions/PORTABILITY.md`.
