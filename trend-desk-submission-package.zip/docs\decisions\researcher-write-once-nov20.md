# Tier A change record — researcher output discipline ("compose once, write once")

- Task: `20261120T010150Z-8a5fc3` (mailbox spawn, priority high), worked in session
  `00a3faab-f8ea-5a5a-a0d7-406fa76d2703`.
- Target: live Forward researcher template `tmpl_d7df3829ed5d73548bb5e9ed`, `system` field only.
- Time of work: 2026-11-20 01:14–01:41Z (= 20:14–20:41 ET 19 Nov, inside the 16:45–08:30 ET change
  window). Next live run: BRIEF 2026-11-20 14:00Z (09:00 ET).
- **Status: PREPARED, NOT APPLIED.** No template write was made by this task. See §6.
- Claim tag: **[documented]** = written in a file I read · **[observed]** = read from a live or cached
  system artefact this session · **[inferred]** = derived from those · **[undiscoverable]** = not knowable
  from anything I can reach.

---

## 1. Bottom line — three premises in the brief did not survive the evidence

The direction is right and the fix is worth shipping, but the stated reason is not the reason.

1. **The thrash is not systemic.** Across the seven logged 2026-11-19 desk runs, the repeated-patching
   behaviour appears in **exactly one** thread: the SCAN-1005 researcher (`sthr_00vz80n9krchsnbhea59`,
   14 Edits). SCAN-1400 wrote its signals file **once, zero edits**. SCAN-1100 and SCAN-1230 wrote **no
   signals file at all** — they emitted helper scripts (`build_findings_1100.py`,
   `compute_regime_inputs.py`, `parse_or.py`) instead. **[observed]**
   So the scan-latency breaches on 1100/1230/1400 are *not* caused by output patching, and deleting the
   patch loop does not fix the desk's steady-state staleness problem.
2. **The 38% is a span, not a cost.** The "~38% (711 s → 1,206 s)" figure measures elapsed wall time
   *between* the first and last edit, which also contains a **170.6 s stretch with no tool call at all**
   (pure reasoning, 739 s → 909 s) and a mid-run re-price to a fresher quote vintage. Measured properly,
   the 14 Edits sit in 14 model rounds costing **144.3 s total = 11.2% of that run's 1,291.6 s wall**
   (11.5% of its 1,255.0 s model time). **[observed]** See §3.
3. **The instruction that causes it is not in the researcher template.** The brief asked whether the
   researcher "is told to append per ticker". It is told **nothing**: the live researcher `system`
   contains no file path, no filename convention, no JSON shape and no write-timing rule. The output
   instruction lives in the **coordinator's per-scan `create_agent` trigger text**, which is composed
   fresh every run and worded differently each time. **[observed]** See §2.

Also: the 14 Edits are **not** the agent correcting its own errors. All 14 returned `is_error: false`,
zero failed-Edit retries, and each carries substantive new content — so they are genuine serialisation
plus in-place revision, and the assumed story holds on *that* point even though it fails on scope and
cost. **[observed]**

## 2. Mechanism, established

**(a) Live researcher prompt — no file contract.** Read-only `GET
https://api.qoder.com/api/v1/forward/templates/tmpl_d7df3829ed5d73548bb5e9ed`, `system` = 3,776 chars,
`updated_at 2026-11-20T09:22:41+08:00`. The entire SCAN section is four numbered steps; the only
output sentence is step 2: *"Return one compact JSON per ticker (action, instrument, entry, stop,
target, reason)."* **Nothing says "write a file", so nothing says write it once.** **[observed]**

**(b) The instruction comes from the coordinator trigger, ad hoc per scan.** The four SCAN trigger
messages in the dumps each specify the file differently — **[observed]**:

| scan | trigger wording about the output file | what the researcher actually did |
|---|---|---|
| 10:05 | "Write your findings under `/data/desk/research/` only (e.g. `.../signals_20261119_1005.json`) … RETURN compact JSON: {…files_written…}" | `Write` @696.7 s, then **14 `Edit`** |
| 11:00 | "**If you write** any findings file, use a name like `.../signals_20261119_1100.json`" | no signals file; wrote a `.py` |
| 12:30 | "state which path you actually wrote" | no signals file; wrote two `.py` helpers |
| 14:00 | "signals to `/data/desk/research/`" | `Write` **once, 0 edits** |

One mandatory example path, one conditional, one unenforced, one bare directory. The behaviour tracks the
wording, which is why it is inconsistent run to run.

**(c) Why 10:05 in particular degenerated.** The 10:05 trigger demanded a *single nested object* spanning
`vintage_proof`, per-ticker fields, `volume_read`, `not_supportable`, `risks`, `files_written`. The
researcher then re-priced mid-run to a fresher vintage (a `DECISION_VINTAGE_1026` block is inserted at
edit #7, and `vix_read` is rewritten 23.51 → 24.47 at #3). Having already saved the file early, every
superseded number invalidated one field of the saved artefact, so each correction became another
round-trip whose only tool action was an Edit. **The trigger's own shape requirement plus an early save
is the mechanism; the missing write-timing rule in the template is why nothing stopped it.** **[inferred,
from observed edit payloads]**

**(d) The skill does not instruct it either.** Pinned live trend-signal
`skill_00vqvkdtlzojk2xg1rku@1795047415929677` documents only *inputs* (`snapshot.json`,
`signal_input.json`) and says the script *returns* JSON. It names no findings file and no output path.
**[observed]**

**(e) Nobody downstream reads the file.** Across all logged 19-Nov threads, no auditor or coordinator
event contains a `Read`/`Bash` of any `signals_*` path; the only `signals_` file operations belong to the
researcher child threads. The real handoff is `send_to_parent` plus the decision journal — the 11:00
coordinator durably delivered `decisions.jsonl`, not a signals file. **[observed]** So the brief's stated
reason for preserving the JSON shape ("because the auditor and coordinator read that file") is not
supported. I preserved the shape and path convention anyway, because it is the stated boundary and costs
nothing to honour. **[inferred]**

## 3. Measured cost (replaces the 35–40% claim)

SCAN-1005 researcher `sthr_00vz80n9krchsnbhea59`, 359 events, 63 model rounds. **[observed]**

| measure | value |
|---|---|
| wall (first→last event) | 1,291.6 s |
| sum of `model_request_start→end` | 1,255.0 s (97% of wall) |
| signals-file `Write` / `Edit` / `Read` | 1 / 14 / 1 (**not** 3 reads) |
| Edits returning `is_error` | 0 of 14 |
| rounds whose only tool action is a signals Edit | **14 rounds, 144.3 s = 11.2% of wall** |
| mixed rounds (analysis + an edit together) | 0 — the patch loop was fully serialised |
| bytes emitted as `old_string`+`new_string` | 14,010 (≈1,001 per edit) |
| longest no-tool-call reasoning stretch | **170.6 s @739→909** (inside the span the memo charged to edits) |

Per-edit round costs (s): 13.8, 24.7, 7.8, 4.8, 9.7, 12.3, 10.3, 12.0, 11.9, 10.3, 11.3, 7.9, 4.1, 3.4.

**Honest expected effect of the fix: −11% wall on the 10:05-class run, not −35–40%**, and ~0% on runs
that already write once. The saving is real and it is free, but it does not by itself bring the
444–636 s steady-state scans under the 300 s staleness rule — so it does not remove the case for fan-out,
and it does not fix the staleness breach. **[inferred from observed]**

## 4. The change (prepared)

One added line to the SCAN run, appended as step 5. Zero lines removed or reworded.

```diff
 4. Never argue for a trade. Evidence first. Say what would invalidate the idea.
+5. Findings file: hold every ticker result in memory until the run is complete, then save it once with `Write` at the path and in the JSON shape the trigger names. Never `Edit` a findings file, and never save it early and patch it field by field.
```

3,776 → 4,023 chars (+247). It defers to "the path and the JSON shape the trigger names" rather than
hard-coding either, so it cannot drift from the coordinator's wording or break the convention, and it
takes a position only on *when* and *how many times* the file is written — inside the stated boundary.
It also removes the shared-file write race that blocks per-ticker fan-out.

Artifacts (all under `.scratch/`, none committed):

| file | purpose |
|---|---|
| `.scratch/changes/2026-11-20-signals-write-once/before/tmpl_d7df3829ed5d73548bb5e9ed.json` | full live template object, read 01:20Z |
| `…/before/system.current.txt` | the exact live `system` string (3,776 chars, sha256 prefix `f4057916db327944`) |
| `…/after/system.proposed.txt` | the patched string (4,023 chars) |
| `…/diff/system-diff.txt` | unified diff, 1 added / 0 removed |
| `…/build-system.mjs` | anchored generator; aborts if the anchor is not content-unique |
| `…/verify-semantics.mjs` + `…/verify/semantics.txt` | offline guard, **18/18 PASS** |
| `…/template-system.mjs` | the write worker (apply and rollback, `system` only, read-back verified) |
| `…/apply.sh` / `…/rollback.sh` | env-gated one-command wrappers |

## 5. Apply and rollback commands

```bash
# apply (posts {system: <4023-char proposed>} only)
APPLY_WO=1 bash .scratch/changes/2026-11-20-signals-write-once/apply.sh
# undo — restores the recorded live string
ROLLBACK_WO=1 bash .scratch/changes/2026-11-20-signals-write-once/rollback.sh
```

Both are idempotent (an already-at-target template prints `NO CHANGE` and posts nothing), both refuse to
write without their env flag, and both re-read the live template immediately before deciding and again
after, printing which fields moved.

**Rollback verification actually performed — and its honest limit.** I verified the restore path in dry
run against the live API: it fetched the template, compared, and reported `NO CHANGE - live system already
equals the target`, which proves the recorded snapshot is byte-identical to what is live right now. I did
**not** execute a live write-and-restore drill, deliberately: while the template is unmodified there is
nothing to roll back, and performing the drill would itself be a write to this template in a window that
already contains one (see §6). The write path is nonetheless **empirically proven** rather than assumed:
at 01:22:41Z another task POSTed a partial body containing only `skills` to this same template, and its
recorded pre/post pair (`.scratch/fixdj2/pre-researcher-tmpl.json` → `post-researcher-tmpl.json`) shows
`system`, `model`, `tools`, `mcp_servers` byte-identical afterwards — so a partial `system`-only POST
merges and cannot clobber the sibling fields, and a same-shaped restore is safe. **[observed]**
`created_at`/`updated_at` move on every write and no API lets a caller set them.

## 6. Why nothing was written — the change budget was already spent

The brief authorised spending today's one-change-per-template allowance on the basis that
`20261119T235022Z-9d4b1e` made no change. **That part checks out**: its terminal ack says
`cloud_changes: "None by this wake"`, "no truncation found, no change made, no template write".
**[documented]**

But the live read contradicts the wider premise. The researcher template was written today at
**01:22:41Z by a different task** — a decision-journal re-pin, `skill_00vqvbzcimznkggtyd1t`
`1795094895883552` → `1795137748003137`, applied to researcher, risk_auditor and executor from
`.scratch/fixdj2/` (file mtimes 09:22:40–42+08:00). **[observed]** Consequences:

- DRIVER §6.4 allows **one change per template per day** so effects can be attributed. That allowance is
  consumed, by a change this task was not told about.
- The re-pin appears in **no ack and no `docs/changelog.md` entry** — `grep` for `1795137748003137`
  returns only `.scratch/` artefacts, and the changelog contains no decision-journal re-pin line. So a
  live skill-version move on three production templates is currently unattributed. **[observed]**
- Adding my line on top means Nov 20's runs would carry two unattributable researcher changes at once.
  Mitigating fact: they touch **disjoint fields** (`skills` vs `system`), each with its own before/after
  artefact, so attribution is still recoverable by inspection — but recovering it by argument is exactly
  what §6.4 exists to avoid. **[inferred]**

The boundary I was given says to stop and report rather than improvise when the fix turns out to need
something outside its scope. Here the blocker is not the fix but the precondition, and the decision —
"accept two writes in one window, or hold this to the next change window (16:45 ET 20 Nov, before the
21 Nov BRIEF)" — belongs to the driver who wrote the rule. So this task stopped, escalated via
`outbox/`, and left the change one command away from shipping. No other boundary was touched: no order,
no trading tool, no account 5830104 action, no `rules.json`, no `AUTONOMY_PHASE`, no model/tier change, no
skill or MCP binding change, no schedule change, nothing published off this machine.

## 7. Confirmation plan for the next live run

Only after the change is applied, and only this way:

1. Read back `system` and confirm 4,023 chars, `updated_at` after the apply, and `skills` unchanged.
2. On the next SCAN run, from that run's own event dump — not from the ack — count `Edit` events whose
   `file_path` matches `signals_`: **target 0**. Count signals-file `Write`: target ≤1.
   Reuse `.scratch/changes/2026-11-20-signals-write-once/measure.mjs` if kept, or the one-liner in §3.
3. Confirm nothing regressed: the returned `send_to_parent` payload still carries the same fields; the
   decision journal still records kind `signal`; regime/`source` labelling and the vintage line still
   appear; ticker set still QQQ/SMH/SPY.
4. Also record the run's wall seconds. Expected −11% **only if** that run re-prices mid-stream the way
   10:05 did; a clean single-write run should show no change at all, which is a valid outcome and must
   not be read as the fix failing.
5. Any regression or an unexpected side effect → run `rollback.sh` immediately, then investigate.

## 8. What remains unverified, stated plainly

- **Whether one added sentence actually stops the behaviour.** Not tested on a live or rehearsal run. The
  root cause is partly the *coordinator's* improvised wording, which this change does not touch; a
  researcher-level rule may be overridden next run by a differently-worded trigger. **[undiscoverable]**
- **The 11% is measured from n=1 run.** One run exhibited the thrash; I cannot put a confidence interval
  on how often it recurs, nor price the fan-out precondition benefit.
- **The 1,206 s figure and the memo's "3 Reads of the same file"** do not match the dump (1 Read; last
  edit at 1,206.1 s but the run ran to 1,291.6 s). The memo's other conclusions are unaffected.
- **Who authorised the 01:22:41Z re-pin, and whether it is still in flight.** I found its artefacts and
  its effect, not its authorising instruction. Several sessions were running concurrently against this
  repo and against these templates when I read them, so a fresh live read is required before any apply.
- **No stop-order, no order, no account state was inspected for this task** — the analysis is entirely
  event-log and template-config based.
