#!/usr/bin/env python3
"""Rebuild the desk's NAV history from the broker, once per run.

Nothing is persisted: peak_nav, day_start_nav and realized P&L are recomputed from the
order history every run. When the history cannot support an exact answer the command
returns state=unavailable with the reason, and the caller must veto rather than trade on
a seeded NAV -- an invented peak reports a drawdown that was never measured.
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import date, datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import guard  # noqa: E402  (to_et, load_rules)

EPS = 1e-9
SIDE_BUY = "1"   # Futu Trd_Common.TrdSide: 1=Buy, 2=Sell, 3=SellShort, 4=BuyBack (futu-api-doc 3.13, base_define)
SIDE_SELL = "2"
RECONCILE_TOLERANCE = 0.02


def num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f == f else None


def bare(symbol):
    """The join key between the order history and the position list, with any venue prefix removed.

    The prefix is not observed on either endpoint for options -- both 2026-11-20 rows read
    `SPY261123P686000` -- but `market` IS asymmetric across those same two endpoints (100 on the
    position row, 2 on the order row for one contract), so nothing here should be trusted to spell a
    code the same way twice. `guard.parse_osi` already tolerates a leading `US.` for the same reason."""
    s = str(symbol or "")
    return s.split(".", 1)[1] if s.startswith("US.") else s


def payload(raw):
    return raw.get("data") if isinstance(raw.get("data"), dict) else raw


def side_fee(rules, qty):
    f = rules["fees"]
    return f["stock_platform_fee_per_order"] + min(f["stock_transaction_fee_per_share"] * qty, f["stock_transaction_fee_cap"])


def mult_of(symbol):
    """100 for an OSI option code, 1 for a share.

    An option order row prices ONE SHARE in both cases: the 2026-11-20 probe filled `avg_fill_price
    1.40`, `qty 1`, and the position row's `mv` was `122` after the mark moved to 1.22, i.e. premium
    x 100. Reading an option fill as a share makes a 4-contract fly's cash flow and P&L come out 100x
    small, so `reconcile_mismatch` fires on a healthy account and the desk vetoes its own book."""
    return guard.CONTRACT_MULTIPLIER if guard.parse_osi(symbol) else 1


def fee_of(rules, fill):
    """One side of one fill's order, on the schedule that actually applies to that instrument."""
    if mult_of(fill["symbol"]) == guard.CONTRACT_MULTIPLIER:
        return guard.fee_per_option_order(rules, fill["qty"])
    return side_fee(rules, fill["qty"])


def us_time(ts):
    return datetime.fromtimestamp(int(ts) / 1_000_000, tz=timezone.utc)


def fills_of(rows):
    """One row per order_id: partial fills repeat the id as cum_qty grows, so keep the largest."""
    best = {}
    for r in rows:
        cum = num(r.get("cum_qty")) or 0.0
        if cum <= EPS:
            continue
        oid = str(r.get("order_id"))
        if oid not in best or cum > (num(best[oid].get("cum_qty")) or 0.0):
            best[oid] = r
    out = []
    for r in best.values():
        out.append({
            "symbol": r.get("symbol"),
            "side": str(r.get("side")),
            "qty": num(r.get("cum_qty")),
            "price": num(r.get("avg_fill_price")),
            "ts": us_time(r.get("update_time")),
            "order_id": r.get("order_id"),
        })
    out.sort(key=lambda f: f["ts"])
    return out


def reconstruct(pages, cash, positions, now, starting_nav, page_size, rules):
    reasons, warnings = [], []
    rows = []
    for i, page in enumerate(pages):
        data = payload(page)
        page_rows = data.get("orders") or []
        rows.extend(page_rows)
        # OBSERVED 2026-11-20: `sim_trade_history_order_list` nests `pagination` INSIDE `data`, next to
        # `orders`. Reading only the top level makes has_more None on every real page, so a page that is
        # exactly full -- which is what a walk in progress always looks like -- is reported as
        # "completeness unproven", which is a reason, which is state=unavailable, which the auditor
        # vetoes: the desk would refuse to trade on any day with page_size or more order rows.
        pag = data.get("pagination") or page.get("pagination") or {}
        has_more = pag.get("has_more", data.get("has_more"))
        if i < len(pages) - 1:
            if has_more is not True:
                reasons.append(f"page {i + 1} of {len(pages)} says the walk ended (has_more={has_more!r}) before the last saved page")
        elif has_more is True:
            reasons.append("history incomplete: the last page says has_more is true")
        elif has_more is None and len(page_rows) >= page_size:
            reasons.append(f"history completeness unproven: the last page has {len(page_rows)} rows and no has_more")

    fills = fills_of(rows)
    by_day = {}
    for f in fills:
        by_day.setdefault(guard.to_et(f["ts"]).date().isoformat(), []).append(f)

    lots, cum = {}, 0.0
    series = []
    for day in sorted(by_day):
        day_real = 0.0
        for f in by_day[day]:
            if f["price"] is None or f["qty"] is None:
                reasons.append(f"fill without price/qty: order {f['order_id']}")
                continue
            day_real -= fee_of(rules, f)
            if f["side"] == SIDE_BUY:
                direction, remaining = 1, f["qty"]
            elif f["side"] == SIDE_SELL:
                direction, remaining = -1, -f["qty"]
            else:
                reasons.append("unknown side %r on order %s - book.py nets the two sides observed in "
                               "the 2026-11-20 paper fills (1=BUY, 2=SELL); 3=SellShort and 4=BuyBack "
                               "are not modelled because no paper row has ever carried them"
                               % (f["side"], f["order_id"]))
                continue
            mult = mult_of(f["symbol"])
            book = lots.setdefault(f["symbol"], [])
            # Retire whatever stands on the other side first, oldest lot first, then park the leftover
            # as a new lot. A leftover on the sell side is a SHORT, and it used to be a refusal for every
            # symbol: a legged fly sells two shorts and buys two wings, so the first entry day produced
            # "short leg not modeled", which made state unavailable, which the auditor vetoes - the desk
            # would have blocked itself on the very run after its first fly. Only the option leg is now
            # modelled; a share short still refuses, because nothing on this desk is allowed to be short
            # a share, so that leftover can only be an unauthorised ticket, an over-sell, or a new side code.
            for lot in list(book):
                if abs(remaining) <= EPS or lot[0] * direction >= 0:
                    continue
                take = min(abs(remaining), abs(lot[0]))
                day_real += (f["price"] - lot[1]) * take * mult * -direction
                lot[0] += direction * take
                remaining -= direction * take
                if abs(lot[0]) <= EPS:
                    book.remove(lot)
            if remaining < -EPS and mult != guard.CONTRACT_MULTIPLIER:
                reasons.append("short leg not modeled for %s: sold %g with no long lot to retire, and only "
                               "the two sold legs of a legged option structure may sit short on this desk"
                               % (bare(f["symbol"]), abs(remaining)))
                continue
            if abs(remaining) > EPS:
                book.append([remaining, f["price"]])
        cum += day_real
        series.append({
            "date": day,
            "realized": round(day_real, 4),
            "cum": round(cum, 4),
            "open": {s: round(sum(l[0] for l in ls), 4) for s, ls in lots.items()
                     if abs(sum(l[0] for l in ls)) > EPS},
        })

    today = guard.to_et(now).date().isoformat()
    prior = [s for s in series if s["date"] < today]
    cum_before = prior[-1]["cum"] if prior else 0.0
    for s in prior:
        if s["open"]:
            warnings.append(f"position open at close {s['date']} ({','.join(s['open'])}): that day's close NAV is marked at cost")

    cash_d = payload(cash)
    nav = num(cash_d.get("total_asset"))
    balance = num(cash_d.get("balance"))
    if nav is None:
        reasons.append("cash.total_asset missing or non-numeric")

    fees_total = sum(fee_of(rules, f) for f in fills if f["qty"] is not None)
    cash_flow = sum(f["qty"] * f["price"] * mult_of(f["symbol"]) * (1 if f["side"] == SIDE_SELL else -1)
                    for f in fills if f["side"] in (SIDE_BUY, SIDE_SELL) and f["price"] is not None and f["qty"] is not None)
    cash_expected = starting_nav + cash_flow - fees_total
    fees_model = "unverified"
    if balance is not None:
        delta = balance - cash_expected
        if abs(delta) <= RECONCILE_TOLERANCE:
            fees_model = "charged"
        elif abs(delta - fees_total) <= RECONCILE_TOLERANCE and fees_total > EPS:
            fees_model = "waived by broker"
            warnings.append(f"broker charged no fees on {len(fills)} fills; realized P&L still nets the rules' {fees_total:.2f}")
        else:
            reasons.append(f"reconcile_mismatch: broker balance {balance:.2f} vs reconstructed {cash_expected:.2f} ({delta:+.2f})")
    broker_realized = num(cash_d.get("realized_profit"))
    if broker_realized is not None and abs(broker_realized - cum) > max(1.0, 0.1 * abs(cum) + 3 * fees_total):
        warnings.append(f"broker realized_profit {broker_realized:.2f} vs reconstructed {cum:.2f}")

    pos = payload(positions).get("positions") or []
    open_now = {bare(s): round(sum(l[0] for l in ls), 4) for s, ls in lots.items()
                if abs(sum(l[0] for l in ls)) > EPS}
    for p in pos:
        sym = p.get("symbol") or p.get("code")
        q = num(p.get("qty") or p.get("quantity")) or 0.0
        ours = open_now.get(bare(sym), 0.0)
        # Magnitudes, not signs: the history now models a SHORT, but no paper position row has ever been
        # observed carrying a negative `qty` (the 2026-11-20 option row read `qty "1"` for a bought wing),
        # so a sign disagreement here would be a convention the broker never stated, not a finding.
        if abs(q) > EPS and abs(abs(q) - abs(ours)) > EPS:
            warnings.append(f"positions_vs_fills: {sym} broker {abs(q):g} vs history {abs(ours):g}")

    orders_today = sum(1 for r in rows if guard.to_et(us_time(r["create_time"])).date().isoformat() == today)

    close_peak = starting_nav + max([0.0] + [s["cum"] for s in prior])
    peak_nav = max(close_peak, nav) if nav is not None else None
    out = {
        "state": "unavailable" if reasons else "ok",
        "source": "never_traded" if not fills else "broker_reconstructed",
        "as_of_et": guard.to_et(now).isoformat(timespec="seconds"),
        "fills": len(fills),
        "orders_seen": len(rows),
        "orders_today": orders_today,
        "orders_today_is_lower_bound": True,
        "realized_pnl": round(cum, 4),
        "fees_total": round(fees_total, 4),
        "cash_expected": round(cash_expected, 4),
        "cash_reported": balance,
        "fees_model": fees_model,
        "daily": series,
        "portfolio": {
            "nav": nav,
            "peak_nav": peak_nav,
            "day_start_nav": round(starting_nav + cum_before, 4),
            "cash": balance,
            "orders_today": orders_today,
        },
        "reasons": reasons,
        "warnings": warnings,
    }
    return out


def main():
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("state")
    s.add_argument("--history", required=True, action="append",
                   help="one saved sim_trade_history_order_list page per flag, in cursor order")
    s.add_argument("--cash", required=True)
    s.add_argument("--positions", required=True)
    s.add_argument("--now", required=True)
    s.add_argument("--starting-nav", type=float, default=None)
    s.add_argument("--page-size", type=int, default=50)
    s.add_argument("--rules")
    a = ap.parse_args()
    rules = guard.load_rules(a.rules)
    starting_nav = a.starting_nav if a.starting_nav is not None else float(rules["competition"]["starting_nav"])
    out = reconstruct(
        [json.loads(Path(p).read_text()) for p in a.history],
        json.loads(Path(a.cash).read_text()),
        json.loads(Path(a.positions).read_text()),
        datetime.fromisoformat(a.now),
        starting_nav,
        a.page_size,
        rules,
    )
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
