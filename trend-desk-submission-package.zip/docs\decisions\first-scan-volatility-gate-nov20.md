# First-scan check after a pre-open Fed speech — design + memo (Tier B)

**Tier B — owner sign-off required before any part of this goes live.**
Nothing in this document was shipped. No template edit, no skill publish or re-pin, no
`rules.json` / `guard.py` / `calendar_rules.py` / `trend_signal.py` edit, no schedule change, no
contact with account 5830104. Cloud access was read-only GETs. Prepared-but-unrun implementation
lives in [`.scratch/firstscan-1120/diff/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/diff)
and every analysis script under
[`.scratch/firstscan-1120/analysis/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/analysis)
is read-only.

Task: `20261120T000632Z-d53f19`. Written 2026-11-20 ~01:3xZ (20:3x ET Nov 19).
Revised 2026-11-20 ~02:0xZ: the live baseline moved to desk-risk-guard `1795138181446404` mid-task, so the
prepared diff was re-forked and re-verified against the published bytes (§9b), and §7's 19 Nov veto list
was corrected to per-ticker attribution. Recommendation unchanged.
Deliverable name follows the spawn prompt (`first-scan-volatility-gate-nov20.md`); the payload asked
for `first-scan-speech-check.md`. Same document, one name — flagged because the ack cites this path.

---

## 1. Answer first

**Recommendation: do not build a first-scan speech/volatility gate.** Three reasons, in order of strength:

1. **The case it was built for is already handled.** On the two in-sample days with a Fed speaker
   before the open (17 Nov Waller 09:10 ET, 18 Nov Waller 07:30–08:25 ET), the 10:05 scan produced
   **zero tickets on all six ticker-days** — see §7. The existing opening-range-width band and the
   breakout-confirmation test did that, and the regime was already `caution` (size_mult 0.75).
2. **The blind spot is real but unpriceable.** The band cannot see a large overnight gap that is
   followed by a *narrow* first half-hour — 29/111 ticker-days (26%). But every attempt to cost a
   gate on that blind spot lands inside the spread of gates that fire at **random** (§5, p. 5).
   On the only 7 first-scan fills in the whole dataset, the gap-based cohort did *better* than the
   calm cohort, and a permutation test says that difference is noise (p = 0.686).
3. **A 1% threshold is not a safety valve, it is a strategy change.** It would fire on 27 of 37
   sessions (73%) at scan level. With ~5 trading days left in the competition, no version of this
   gate can be evaluated before the window closes.

If the owner overrides reasons 1–3, the defensible instrument is **half size at the first scan, never
a veto** (§4 Option 1, §6 why-skip-loses). A 2% threshold — the one that sounds safest — is *inert*:
it removed 0 of 12 first-scan signals in the sample, so it protects nothing while looking protective.

---

## 2. What the opening range actually is (the payload's mandatory first question)

**The opening range is 09:30–10:00 ET of the regular session: the first six 5-minute bars, close-stamped
09:35 through 10:00. It excludes pre-market entirely.** Three independent sources agree:

| source | evidence | label |
|---|---|---|
| live pinned skill | [`.scratch/livestate-1120/trend-signal/trend-signal/SKILL.md:50`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/livestate-1120/trend-signal/trend-signal/SKILL.md#L50) — "Get `or_high`/`or_low` from the first six 5-minute bars (09:30-10:00 ET)" | documented (live bytes, sha `60d5573d…`) |
| live signal code | [`.scratch/livestate-1120/trend-signal/trend-signal/scripts/trend_signal.py:152`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/livestate-1120/trend-signal/trend-signal/scripts/trend_signal.py#L152) docstring "Opening range = first 30 minutes"; `now_m < 10*60` refuses before 10:00 | observed in the shipped file |
| live 19 Nov SCAN dump | `or_bars = today[:6]`, `SESSION_OPEN = datetime(2026,11,19,9,30)`, `assert len(hs)==6`, stamps 09:35→10:00 | observed in a run artifact |
| replay harness | [`.scratch/bt/mkdata.py:163`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/bt/mkdata.py#L163) `derive_session` — `or_bars = bars[:6]`, refuses unless `bars[0]` stamp is "09:35" | observed (harness, not cloud) |

**Does the existing band already do most of this job?** Partly, and asymmetrically by ticker.
The band is `0.15% ≤ (or_high − or_low)/price ≤ 1.5%`
([`trend_signal.py:165`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/livestate-1120/trend-signal/trend-signal/scripts/trend_signal.py#L165)).
Measured over 111 first-scan ticker-days (37 sessions × QQQ/SMH/SPY):

| ticker | band vetoes at 10:05 | median OR width | p90 OR width | median \|gap\| | max \|gap\| |
|---|---|---|---|---|---|
| SMH | 14/37 (38%) | 1.35% | 3.35% | 1.498% | 5.736% |
| QQQ | 3/37 (8%) | 0.61% | 1.41% | 0.640% | 2.534% |
| SPY | 2/37 (5%)* | 0.31% | 0.88% | 0.304% | 1.145% |
| pooled | 18/111 (16%) | 0.691% | 1.889% | 0.665% | — |

\* one of SPY's two vetoes was the **low** edge (0.14% < 0.15%), not a disorderly open.

So the cap is 4.8× SPY's median width and 2.4× QQQ's: it is a real gate on SMH and close to dormant
on the other two. **A speech-whipped open on QQQ or SPY that settles into a narrow first half-hour
passes the band untouched.** That is the genuine gap in today's machinery, and it is exactly the case
the owner was reaching for. It is 29/111 ticker-days (26%) of the sample.

It does **not** duplicate the a2c7f8 VIX-gate work: that investigates the daily regime input
(`trend-signal regime`, VIX/VXN buckets, fail-closed to `bear_high_vol`); this is a per-scan input at
one specific minute. Different file, different cadence. `docs/decisions/vix-gate-and-zero-trades-nov20.md`
did not exist at the time of writing (`docs/decisions/` held only `concurrent-researcher-tickers.md` and
`ticker-universe-nov20.md`; neither mentions the first scan, a gap, or a pre-market field — grepped).

---

## 3. What is measurable at 10:05 ET about an 08:25 event, and what it costs

The speech itself is not measurable after the fact; its *consequence* is, and it is already in the run.

| input | source at 10:05 | cost in a SCAN run | status |
|---|---|---|---|
| pre-market gap % (`pre_market.change_rate`) | inside `quote_stock_quote`, already called in the SCAN pass | **0 extra calls** | observed live |
| pre-market range % (`pre_market.amplitude`), high/low/price | same object | 0 extra calls | observed live |
| pre-market volume/turnover | same object | 0 extra calls | observed live |
| regular-session open vs prior close | `last_close` on any kline bar | 0 extra calls | observed |
| opening range and width | already fetched for the signal | 0 | observed |
| inverse-ETF leg (SQQQ/SOXS/SPXS) pre-market | same `quote_stock_quote` shape | 0 | observed |
| the speech time itself | `quote_economic_calendar_search(search_type=3)` | 1 extra call, unreliable (§3b) | observed, with a caveat |

**The gap measure is already in the desk's own tool output.** From the live 18 Nov SCAN-1005 thread
(`.scratch/flaky/ev-sthr_00vvnekv3ft34vo5jzyb.json`, header "SCAN 10:05 pass 2026-11-18", written 10:15 ET),
`quote_stock_quote` returned, unmodified, exactly the numbers this design needs:

| ticker | live `pre_market.change_rate` | live `pre_market.amplitude` | gap I derived independently from 5-min bars |
|---|---|---|---|
| QQQ | +0.642% | 0.932% | +0.621% |
| SMH | +1.717% | 1.710% | +1.712% |
| SPY | +0.151% | 0.662% | +0.127% |

Agreement to 0.005–0.03 pp against a measure computed from a different endpoint (kline open vs prior
close) — so `change_rate` is a trustworthy gap, it needs no new call, and it was present at the minute
the gate would run. Inverse legs came back too: SQQQ −2.002%, SOXS −4.509%, SPXS −0.395%.

**Two hard caveats on that free input:**

1. **The block can come back all-zero.** Observed on index quotes (`US..SPX` vol, `US..NDX`):
   `{"amplitude":0,"change_rate":0,"high_price":0,"low_price":0,"price":0,…}`. An all-zero `price` is a
   detectable *no-data* sentinel — see §4's fail-closed rule, which depends on distinguishing it.
2. **Do not widen the OR fetch to get pre-market bars.** `derive_session` and the researcher's skill text
   both take "the first six bars" positionally (`bars[:6]`). Adding `extended_time=1` bars to that same
   fetch would silently redefine the opening range as pre-market-inclusive and change every signal. If
   anyone wants pre-market *bars* rather than the summary block, they must be fetched separately and
   never passed to `derive_session`. (Inferred from the code's positional behaviour, not observed as a failure.)

**3b — the speech calendar is not a dependable runtime input.** `quote_economic_calendar_search`
does return machine-readable Fed-speaker events with `event_time` and `star` (observed: Waller 18 Nov
07:30 star 3, Waller 17 Nov 09:10 star 2, Jefferson 19 Nov 09:25 star 1). But in the same probe at
~00:4xZ on 20 Nov the DB carried **no 20 Nov events**. A scan that depends on it would have read
"no event today" on the day the event is the whole reason for the check. Keep the calendar as a
**morning verification** step (which is what `calendar_rules.py`'s `VERIFY` list is for) and the
speaker time as a **config** fact, not a runtime dependency.

**There is no machine-readable event field in the live desk today.** `rules.json` has no event keys;
`calendar_rules.py` per-day keys are only `size_mult`, `no_entry`, `notes`, `entry_start`, `entry_end`,
and every event time ("UMich sentiment 10:00 ET", "Williams speaks 13:30", "PCE inflation and GDP
08:30 ET") lives inside free-text `notes`
([`calendar_rules.py:32-44`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/livestate-1120/desk-risk-guard/desk-risk-guard/scripts/calendar_rules.py#L32)).
So the payload's instruction "reuse whatever calendar_rules.py already tracks, don't build a second
data source" cannot be satisfied as written — there is nothing to reuse. The cheapest honest version is
one new machine-readable key in the same dict that already holds the fact in prose, so the desk has one
source of truth and the researcher's morning re-verification still applies.

---

## 4. Mechanism options, and where the check would live

| # | mechanism | lives in | behaviour | verdict |
|---|---|---|---|---|
| 0 | **nothing** — band + breakout confirmation + Sleeve C timing + regime/calendar `size_mult` already respond to a whipsawed open | — | unchanged | **recommended** |
| 1 | first-scan **half size** when \|gap\| ≥ 1.0% and the pre_market block is non-zero | `desk-risk-guard` (`guard.py check`, new `first_scan` term in the `mult` product) | size_mult ×0.5 on the first scan only; never vetoes | ship this instead, **only if** the owner requires action |
| 2 | **measurement without behaviour**: journal `pre_market.change_rate`/`amplitude` on every SCAN signal record | researcher SCAN step + `decision-journal` | zero decisions change; produces the dataset this memo lacks | recommended alongside 0 |
| 3 | first-scan **veto** on \|gap\| ≥ 1.0% | `guard.py` | removes 4/12 first-scan signals — all 4 became fills, worth +$113.95, none re-fired later | **rejected on evidence** |
| 4 | first-scan veto on \|gap\| ≥ 2.0% | `guard.py` | fires on 0 of 12 signals in sample | rejected — inert, buys false reassurance |
| 5 | treat it as an event blackout (`no_entry`) | `calendar_rules.py` | **structurally impossible**: `no_entry` windows are compared against ET clock minutes inside the entry window, which starts 10:05; an 08:25 event precedes the window it should protect | rejected — this is the owner's own premise, confirmed |
| 6 | put the check in `trend-signal`'s **regime** path | `trend_signal.py regime()` | wrong tool: regime is a once-a-day input; making it scan-level would re-purpose the fail-closed machinery and could not see per-ticker gaps | rejected |
| 7 | **prompt-level instruction** ("skip the first scan if the open looks disorderly") | researcher or coordinator prompt | unverifiable, unauditable, and unenforced — all four templates run `always_allow`, and AUTONOMY_PHASE is prompt text too, so a prompt-level gate has no permission boundary behind it | rejected |

**Where the check must live if shipped: `guard.py check`.** It is the only deterministic, versioned,
sandbox-tested point on the auditor's path; the auditor is the only agent whose output can authorise a
ticket, and everything else (researcher, coordinator, executor prompts) is advisory. Option 1 as written
is a ~20-line change: one `is_first_scan()` helper, one multiplication inside the existing `mult`
product, one warning string, no new file. The prepared version is in §9b and
[`.scratch/firstscan-1120/diff/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/diff).

### Threshold and input set (Option 1, fully specified)

```json
// proposal.json, added by the auditor from data the researcher already puts in its SCAN reply.
// No is_first_scan flag: guard derives it from --now and the day's entry_start.
{"first_scan": {"gap_pct": {"QQQ": 0.642, "SMH": 1.717, "SPY": 0.151},
                "pre_market_amplitude_pct": {"QQQ": 0.932, "SMH": 1.710, "SPY": 0.662},
                "source": "quote_stock_quote.pre_market"}}
```

The auditor puts `null` (not `0.0`) for any ticker whose `pre_market` block came back empty — see the
fail-closed table, because a literal 0.0 is indistinguishable from a genuinely calm pre-open.

- Fires only on the derived first scan, **and** when `|gap_pct[ticker]| >= 1.0`, **and** when the value is
  numeric; `null` means unread, not calm.
- Effect: `mult *= 0.5`, plus `warnings.append("first scan after |gap| 1.7%: half size")`. Never a veto,
  never a new reason string.
- Threshold basis: 1.0% ≈ 1.5× the sample median |gap| (0.665%) and ≈ the p60. It is *not* derived from
  any performance inflection — §5 shows the sample cannot support that claim.
- `is_first_scan_of_day` is **derived inside `guard.py`** from `--now` and `day["entry_start"]`, not
  passed in, so a proposal that forgets or mislabels a field cannot switch the check off, and a day with
  its own `entry_start` override (20 Nov is 10:05) or a half day is handled without a second table. The
  window is 30 minutes — bounded from below by the measured 10–13 min trigger-to-order-ready latency and
  from above by the 55 minutes to the next scan. A 60-minute window, which is the obvious first guess,
  silently haircuts the 11:00 scan too; that is the bug the offline matrix caught (§9b).

### Fail-closed behaviour (the payload's "silently passing on absent data is worse than no gate")

Three states, and they are distinguishable in the payload, so the choice is not a guess:

| state | test | behaviour |
|---|---|---|
| read | `pre_market.price` and `high_price` and `low_price` non-zero | gate evaluates normally |
| calm | non-zero, \|gap\| < threshold | no haircut, no warning |
| **no data** | all-zero block (the observed index-quote shape), or field absent, or a non-numeric string | `warnings.append("first-scan gap unread: pre_market block empty — check did not run, size unchanged")` and a journal record with `first_scan_check: "no_data"` |

The no-data state is deliberately **not** a veto and **not** a silent pass. It is not a veto because a
zero-filled field is indistinguishable from a market that had no pre-market session, and vetoing on it
would idle the desk on any API hiccup — worse than the disease. It is not a silent pass because the
verdict JSON carries an explicit `no_data` marker, so the absence is visible in the log and countable in
the REPORT. This is the one place where I disagree with the payload's framing: fail-closed-to-skip is
correct for a *limit* (guard's `state_unavailable`, the cash rule) and wrong for an *advisory haircut*,
where the failure mode of "closed" is "the desk stops trading for no reason". If the owner wants the
stricter reading, the correct version is: no data → refuse to treat the day as gated **and** escalate to
the human, which is one extra line in the auditor prompt, not a guard.py change.

---

## 5. What it would have cost — and what cannot be measured

### 5a. Removal cost at ticket level (measurable)

12 first-scan signals over 37 sessions; 7 became fills; realised P&L of all first-scan fills = **+$28.06**
of the shipped $572.83. Detail in
[`crossTab.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/analysis/crossTab.json):

| gate | first-scan signals removed | of those, fills | combined P&L | would have re-fired at 11:00? |
|---|---|---|---|---|
| \|gap\| ≥ 1.0% | 4/12 (33%) | 4 | **+$113.95** | 0 of 4 |
| \|gap\| ≥ 1.5% | 1/12 | 1 | +$229.26 | 0 of 1 |
| \|gap\| ≥ 2.0% | **0/12** | 0 | $0.00 | — |

The four removed by a 1% gate: 29 Oct SMH LONG +$229.26 (gap −1.54%), 28 Oct SMH LONG +$95.90 (+1.14%),
16 Nov QQQ SHORT −$49.47 (−1.30%), 2 Oct QQQ LONG −$161.74 (+1.25%). Grouped by the hypothesis's own
terms: gap-heavy first-scan fills mean **+$28.49/trade (2 of 4 wins)**, gap-light **−$28.63/trade
(1 of 3)**. The association runs *opposite* to the owner's premise, and an exact permutation test over
all 35 ways to split 7 fills 4/3 puts that difference at **p = 0.686** — i.e. wholly indistinguishable
from shuffling the labels. So: the removal arithmetic is real, the direction is not established, and the
honest reading is "this gate would have deleted trades without a demonstrated reason to".

### 5b. Whole-path replay cannot price it (this is the "say plainly you cannot")

[`counterfactual2.py`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/analysis/counterfactual2.py)
gates the harness in memory (validated first: it reproduces the shipped AS_RUN exactly — 46 trades,
$572.83, `harness reproduces shipped AS_RUN: True`) and lets the later scans substitute:

| gate (scan-level) | sessions fired | net | Δ vs baseline |
|---|---|---|---|
| skip every 10:05 | 37/37 | $374.27 | −$198.56 |
| \|gap\| ≥ 1.0% | 27/37 | $166.51 | **−$406.32** |
| \|gap\| ≥ 1.5% | 18/37 | $261.52 | −$311.31 |
| \|gap\| ≥ 2.0% | 12/37 | $519.17 | −$53.66 |
| width ≥ 1.0% | 26/37 | $684.49 | **+$111.66** |

Non-monotonic: a gate that fires *less* often costs *twice* what a gate that fires always costs. That
cannot be an economic effect; it is reshuffling. Killing one scan frees the one-position-per-scan slot
and the 35%/cash-floor/open-risk caps, so a different ticker at a different minute takes the trade and
the entire remaining path moves. [`nullcontrol.py`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/analysis/nullcontrol.py)
prices that noise by running 15 gates that fire on the **same number of sessions chosen at random**:

| gate | N | real net | null median | null range | null sd | real inside null range? |
|---|---|---|---|---|---|---|
| skip every 10:05 | 37 | 374.27 | 374.27 | degenerate (N = all) | 0.00 | yes (trivially) |
| \|gap\| ≥ 1.0% | 27 | 166.51 | 364.16 | 0.74 … 1013.88 | 266.35 | **yes** |
| \|gap\| ≥ 1.5% | 18 | 261.52 | 638.93 | −17.95 … 1034.70 | 348.78 | **yes** |
| \|gap\| ≥ 2.0% | 12 | 519.17 | 620.70 | 0.74 … 961.31 | 250.59 | **yes** |
| \|gap\| ≥ 1.0 AND width ≤ 1.5 | 23 | 166.51 | 620.70 | 147.82 … 913.29 | 235.00 | **yes** |
| width ≥ 1.0% | 26 | 684.49 | 469.45 | 207.60 … 1013.88 | 287.57 | **yes** |

**Every gap-based delta lands inside what a random gate of the same frequency produces.** The null spread
is ±$250–350 on a $573 baseline. Conclusion, stated plainly as the payload asked: **the replay cannot
price a first-scan gate, and I will not quote −$406 or +$112 as if either were a cost or a benefit.**

### 5c. The paired measure that *is* usable: what waiting actually does

Because the path measure is hopeless, [`delay_penalty.py`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/analysis/delay_penalty.py)
holds everything fixed and asks only "same signal, entered 55 minutes later":

| pair | signals at the earlier scan | still fire at the next scan | median entry cost of waiting | worse / better |
|---|---|---|---|---|
| **10:05 → 11:00** | 12 | **4 (33.3%)** | +0.307% | 2 worse / 2 better |
| 11:00 → 12:30 and 12:30 → 14:00 | 70 | 37 (52.9%) | +0.046% | 23 worse / 14 better |

Two findings, both relevant to skip-vs-size:
- **The first scan's edge is existence, not price.** Two-thirds of first-scan breakouts do not re-fire
  at 11:00 (33% vs 53% persistence for later scans). A veto therefore *deletes* an opportunity rather
  than deferring it; only 4 of 12 would have been recovered by the next scan, and the 4 that a 1% gate
  would have removed are precisely the non-persisting ones (0 of 4).
- **Where a trade is recoverable, the price penalty is small** (median 0.307%, split 2/2) — so the cost
  of a *size* haircut is genuinely just the notional, which is why size dominates skip as an instrument.

### 5d. What data would make the open questions answerable

1. **~5–10× more first-scan fills** (7 today). At the observed cadence that is months of sessions —
   not obtainable inside the competition window, which has ~5 trading days left. This is the binding
   constraint, not a tooling gap.
2. **A pre-open-speech sample with trades in it** — today there are 2 such days in-sample and the desk
   took no first-scan ticket on either, so "did the gate's absence cost us anything on speech days" has
   no observations to answer with. Fwd: 20 Nov (Waller 08:25) is the next chance to log it — under
   Option 2 that day's journal would carry the gap numbers without any behaviour change.
3. **`sim_trade_position_list` and order rows persisting across run boundaries** — the desk's monitored
   doctrine cannot recover a recorded stop level after a run ends (proven, `.scratch/p0/P04-runbook.md`
   step 5a), so first-scan exits are "close at next check" (all 7 fills exited at 11:15 for exactly that
   reason). Until that is fixed, first-scan P&L is a 55-minute hold by construction, which caps how much
   any first-scan gate can be expected to do.
4. Nothing here needs new data infrastructure. It needs either more days or a smaller claim.

---

## 6. Skip vs reduced `size_mult` — argued, not defaulted

The payload asked for this argument rather than a reflexive skip. Skip loses on three counts:

1. **Irreversibility.** 33% persistence at the first scan means a skip destroys 2 of every 3 signals;
   a haircut keeps the signal and reduces the stake. The asymmetry is largest exactly where the gate
   bites — the 4 gap-heavy signals were 0/4 persistent.
2. **Evidence direction.** Gap-heavy first-scan fills were the better group (+$28.49 vs −$28.63 mean,
   p = 0.686). To skip on that data is to act on a sign the data does not support; to halve on it is to
   accept the uncertainty. Under evidence this weak, the size of the intervention must be proportional
   to what is unknown, and a veto asserts more than we know.
3. **Blast radius.** A 1% veto fires on 73% of sessions at scan level — the desk would run roughly one
   entry opportunity a day instead of four, silently redefining the strategy 5 days before judging.
   The same threshold as a haircut leaves every ticket on the table and touches only size.
4. And the caps already do gate-level work: `max_open_risk_pct` 1.5%, `trade_risk_pct` 0.35%, the 10%
   cash floor and the 35% single-asset target bind before the risk budget does on most scans
   (guard's `binding` field reports which), so an extra veto is redundant with a limiter that is
   already deterministic and already logged.

Skip is preferable only if the concern is *quote validity* rather than disorder — i.e. if the fear is
that a 10:05 price on a gapped-open day is not tradable. That is a fair worry and it is a different,
smaller claim; it belongs with the executor's existing "price moved >0.3% from the ticket's entry ⇒
cancel" rule, not in a new volatility gate.

---

## 7. Backtest against pre-open-speech days (the days that motivated this)

Replaying the pinned signal engine over the actual speech-day bars, first scan only:

| day | pre-open speaker (moomoo calendar) | regime at BRIEF | QQQ | SMH | SPY | tickets at 10:05 |
|---|---|---|---|---|---|---|
| Tue 17 Nov | Waller 09:10 ET, star 2 | caution, mult 0.75 | 0.56% no-breakout | 1.47% no-breakout | 0.31% no-breakout | **none** |
| Wed 18 Nov | Waller 07:30–08:25 ET, star 3 | caution, mult 0.75 | 1.34% no-breakout | **3.39% band veto** | 0.88% no-breakout | **none** |
| Thu 19 Nov | Jefferson 09:25 ET, star 1 | (live run, outside bar window) | refused at 11:00 on "no confirmed breakout… right side of VWAP" — **not** a width veto | **width veto at every scan: 1.83–1.84% @10:05, 1.857% @11:00, 1.8985% @12:30, 1.9153% @14:00** | — | **none for SMH** (live NONE dumps) |

**Correction recorded (2026-11-20, during the final accuracy audit).** An earlier draft of this row said
"1.83/1.84/1.86/1.90/1.92% band vetoes at every scan" with no ticker attached, because it was lifted from
a `grep -o` over the archived SCAN dumps. That was wrong twice: the four vetoes are **all SMH's**, not a
desk-wide refusal, and 1.83/1.84 are the *same* 10:05 scan seen two ways — 1.83% is the auditor's
regimeA-vs-regimeB comparison block, 1.84% is the row actually journaled (`vintage_et
2026-11-19 10:26:29`, `gate: "range filter"`). Attribution method: `analysis/widthveto.py` attaches each
veto to the nearest preceding symbol in the dump, which by itself produced false pairs such as
`SOXS 1.84%` and a QQQ pairing at 12:30; each pair was therefore read in context by hand, and the 12:30
QQQ pairing was **rejected** — that block carries `price: 455.08, or_high: 479.96`, which is SMH's quote,
so 12:30 is SMH alone. The quoted 1.857/1.8985/1.9153 are the auditor's own unrounded figures; the 1.86/
1.90/1.92 in the journal are the same numbers rounded by the signal script. The same dumps
carry notes that matter to this memo: 11:00 "1.857% > 1.5% band (**3rd event-gap day
running**; veto is width, not sign — extension only 0.69x, all other gates pass)" and 14:00 "1.8985% →
1.9153% is **denominator drift, not a widening range**… **Routed to Sleeve C**". So the live desk already
(i) reads a width veto as a gap-day symptom, (ii) knows the band's denominator moves under it, and
(iii) hands these days to Sleeve C — which is §8's design trap, confirmed from production rather than from
my reasoning. Also note the journaled 10:05 signal carries `vintage_et 10:26`: the run's own evidence is
21 minutes old by the time it is written, which is §5c's latency measured on the live desk, not simulated.

19 Nov remains the strongest natural experiment and it is *live*, not simulated: SMH came back NONE at the
width band at 10:05, 11:00, 12:30 and 14:00. The gate did not need a speech flag because the width
measurement is downstream of the speech and does not care what caused the whipsaw.

What this shows: **the mechanism the owner wanted exists, it is measured in price space rather than
event space, and on all three speech days it produced no first-scan ticket.** What it does not show:
that this is *good* — 17/18/19 all declined, and none of those three days later produced a first-scan
profit to regret, so there is no counterfactual loss to weigh.

---

## 8. Interaction with the gates that already exist

| existing gate | where | how it interacts | consequence for the design |
|---|---|---|---|
| `entry_start` 10:05 (20 Nov override) | `calendar_rules.py` DAYS[20 Nov] | the check can only ever run at the 10:05 scan | the "first scan" must be derived from `day["entry_start"]`, not hard-coded 10:05, or a half-day/override day silently disables it |
| `no_entry` blackouts | same dict | structurally cannot reach 08:25 (§4 opt 5) | do not extend it; **and see the in-flight collision below** |
| daily `size_mult` (1.0 on 20 Nov) | `guard.py:167` | multiplicative with a haircut: a 0.5 day + 0.5 gate = 0.25 | state the composition in the warning text so the auditor sees the product, not two halves |
| expectancy gate (`closed_trades[sleeve]`) | `guard.py:170-177` | also a multiplier; with 46 trades total, sleeve samples are ~12 | a third multiplier stack is unmeasurable; this is a second argument for Option 2 over 1 |
| OR-width band 0.15–1.5% | `trend_signal.py:165` | **upstream**: the gate only sees what the band passed | no duplication for wide opens; the 26% blind spot is the only added coverage |
| **Sleeve C (vwap-chop)** | researcher SCAN step 3 + pinned `1795095917868411` | C fires *only* where A says NONE **for the width reason**, and C's own window starts at 10:30 | **design trap**: a scan-level gate placed *before* `trend-signal` would suppress the width-NONE reason and blind Sleeve C on exactly the disorderly days it was built for. Any gate must run after the signal call, and must not alter A's reason string |
| regime fail-closed → `bear_high_vol` | `trend_signal.py:43`, `113-148` | already removes longs and halves size when index reads are bad | a vol gate on missing data is taken; Option 1's no-data state must not re-implement it |
| auditor veto chain + `AUTONOMY_PHASE=bounded` | coordinator/auditor prompts | `bounded` means approved tickets go straight through with no human step; all templates are `always_allow` | the gate must be inside `guard.py check` or it is not a gate at all |
| executor re-quote rule (>0.3% move ⇒ cancel ticket) | executor prompt | overlaps the "stale quote on a gapped open" concern | if quote validity is the real worry, this rule is where to raise the threshold — a smaller, honest change |
| **`2026-11-20-calendar-noentry`** | **SHIPPED while this memo was being written** — desk-risk-guard v13 `1795138181446404`, published 2026-11-20T01:29:41.464633Z, pinned on all three templates | added `no_entry: [("11:45","12:30")]` (Cook 12:15) to the **same** `DAYS[date(2026,11,20)]` block, with the note verbatim "Waller 08:25 is before entry_start 10:05" — i.e. **the owner explicitly declined a Waller window** | collision **resolved in their favour**: this task's `before/` was re-forked from the live v13 package (see §9b). `guard.py`, `rules.json` and `levels.py` are byte-identical between v12 and v13 — only `calendar_rules.py` moved, and my patch touches no line of it |

---

## 9. Change-control plan (only if the owner directs Option 1 or 2)

Nothing here was executed. Prepared files are in
[`.scratch/firstscan-1120/diff/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/diff).

### Option 1 — first-scan half-size (Tier B: it changes how a risk limit behaves)

| item | detail |
|---|---|
| files | `desk-risk-guard/scripts/guard.py` (+20 lines: `is_first_scan()` helper + a 3b block in the `mult` product), `references/rules.json` (+1 key `risk.first_scan_gap_pct: 1.0`, `version` → `2026-11-20.1`), `SKILL.md` (input table), `tests/scenarios` (+14) |
| skill | desk-risk-guard **`1795138181446404`** (live as of 2026-11-20T01:29:41Z, published by the sibling `2026-11-20-calendar-noentry` change while this memo was being written) → a new published version (multipart POST; versions supersede, never unpublish) |
| templates to re-pin | researcher, risk_auditor, executor — **all three are already pinned to `1795138181446404`**, so the edit is a pin bump, not a first pin; coordinator has no skills and needs none |
| auditor prompt | step 2 gains `proposal.first_scan` built from the `quote_stock_quote` pre-market block it already receives, with `null` for an empty block; one sentence, one template, one write |
| verify before publish | **done offline against the live v13 bytes, 2026-11-20 09:4xZ** — see §9b. Still outstanding: `py_compile` and the matrix re-run against the *published* bytes in a sandbox probe before the pin moves |
| change window | not tonight (the 20 Nov desk is unattended and runs the FLAT/REPORT on the current pin). The `calendar-noentry` precondition that this row previously named **is now satisfied** — that change shipped first, as v13 |
| rollback | re-pin all three templates to `1795138181446404` (the current pinned bytes, = tonight's live behaviour including the Cook blackout); or publish a follow-up with `first_scan_gap_pct: null`, which §9b shows makes the code path byte-for-byte inert |
| cost | ~1 publish + 4 template writes; no new credit load at runtime (0 extra tool calls) |

### 9b Offline verification that has already happened (candidate only, nothing live)

[`diff/verify/offline-check.py`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/diff/verify/offline-check.py)
runs the candidate `guard.py` and the live bytes side by side over the same fixtures
([`offline-matrix.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/firstscan-1120/diff/verify/offline-matrix.json)):

```
$ <py312> -m py_compile candidate/skill/desk-risk-guard/scripts/guard.py   -> OK
$ <py312> verify/offline-check.py                                         -> RESULT: all pass, exit=0
```

14/14 cases pass, and the equivalence regression — 4 proposals x 4 timestamps, including a closed day
(26 Nov) and a half day (27 Nov) — returns **16/16 byte-identical verdicts** between candidate and live
whenever `first_scan_gap_pct` is `null`. That is the property that lets the code be published ahead of a
decision without changing behaviour, if the owner ever prefers that ordering.

Two findings worth the owner's attention before approving anything:

1. **The obvious window was wrong.** The first `is_first_scan` used 60 minutes from `entry_start`. The
   guard's own `--now` at the first scan is already ~10:15–10:20 (measured trigger-to-order-ready 10–13
   min), so a 60-minute window also haircuts the **11:00** scan. Case 2 caught it; the window is now 30
   minutes with both edges asserted (10:34 haircut, 10:35 not). A prompt-level version of this rule
   (§4 option 7) would have shipped that defect unnoticed.
2. **Four multipliers can now stack on one line of `guard.py`.** calendar `size_mult` x drawdown
   `half_size` x `regime_mult` x this haircut. On a 27 Nov-style half day with a 1.7% gap the matrix
   shows `size_mult` 0.25 and qty 8 from a $100k book. If that is not intended, the haircut should be
   `mult = min(mult, 0.5)` rather than `mult *= 0.5` — a one-character decision that belongs to the
   owner, not to me.

**Re-verified against the live v13 bytes at 09:4xZ, after the sibling change published.** Because
`1795138181446404` moved while this memo was open, everything above was re-checked rather than trusted:

* downloaded the published package (`GET …/versions/1795138181446404/content`, 18,045 B) and hashed all
  six files — `guard.py 8fe26118b2a8a3fd…`, `rules.json 49dbeaf4d2d21278…`, `levels.py 746a01510d00a78e…`
  **byte-identical** to the `before/` this diff was built on; `calendar_rules.py` is the only delta
  (`9e57f3c8…` → `557c3cf2dad77b85…`, +2 lines, exactly the Cook `no_entry` and notes);
* the two `.diff` files apply cleanly to the downloaded package with **`patch -p2`** and reproduce my
  candidate bytes sha-for-sha — so the prepared diff is valid against *tonight's* live code, not just the
  v12 snapshot I forked from;
* the whole offline matrix re-run against the **live** calendar: **all 15 cases + the 16/16 equivalence
  regression pass, unchanged** — none of its cases sit inside the new 11:45–12:30 blackout, so the two
  changes do not interact;
* end-to-end on the patched live package: 10:05 with `gap 1.7%` → qty 17 / `size_mult` 0.5 with the
  haircut warning; 12:00 → `["event blackout 11:45-12:30 ET"]`, proving the patched tree carries v13's
  calendar and that my patch did not disturb it.

One correction to §9's own apply text: `patch -p1` is right only against this scratch tree's labels
(`a/skill/desk-risk-guard/...`); against a **downloaded package** the path has one level less and it is
`-p2`. Use `--dry-run` first either way.

### Option 2 — measurement only (Tier B by file class, Tier A by effect)

| item | detail |
|---|---|
| files | researcher prompt SCAN step 1 (append `pre_market.change_rate`/`amplitude` per ticker to the numbers it already sends); `decision-journal` signal-record schema gains two optional numeric fields |
| templates | researcher + (journal doc) risk_auditor; no skill publish if the journal tolerates extra fields (verify against the live `journal.py` before assuming) |
| risk | zero decision change; the only hazard is prompt-token growth in the busiest run |
| rollback | revert the one prompt sentence |

### Option 0 — ship nothing

Zero writes. The `2026-11-20-calendar-noentry` change (Cook 12:15 ⇒ 11:45–12:30 blackout) shipped
independently as desk-risk-guard `1795138181446404` at 01:29:41Z and is not affected by this
recommendation. Note how that change handled the very event this memo was commissioned over: its calendar
note records "Waller 08:25 is before entry_start 10:05" and takes **no action** — Option 0, already in
force on the live desk, arrived at by a different route.

---

## 10. What would flip this recommendation

1. **A first-scan entry actually loses big on a gapped open.** One observation is not a pattern, but a
   single dated case — 20 Nov, Waller 08:25, a ticket taken into a gap that then fills its stop — is the
   kind of evidence that would move Option 1 from "not supported" to "supported and worth the risk".
   Under Option 2 that day's journal carries the gap numbers needed to test it.
2. **`pre_market` turns out to disagree with reality.** The three-point agreement in §3 is n=1 day. If a
   second day shows `change_rate` lagging or zero-filled on an ETF (not just indices), the input is not
   trustworthy and Option 1 dies on inputs rather than on economics.
3. **Sleeve C's wide-open book goes negative.** C exists precisely for these sessions; if its first ~10
   closed trades have negative expectancy, the "the desk already has an answer to disorderly opens"
   premise weakens, and a veto becomes more attractive than a haircut.
4. **Monitored-stop persistence gets fixed** (P0.4 / `book.py` state), because today's first-scan P&L is
   a forced 55-minute hold. If a first-scan entry can run to target instead of closing at the next check,
   its distribution changes enough that all §5 numbers need re-running.
5. **A larger first-scan fill sample.** With 7 fills and a null spread of ±$250–350, no threshold choice
   is defensible on this data; the arithmetic that would settle it is 40–60 first-scan fills, which is a
   post-competition job.

---

## 11. Reproduction

```
PY=/c/Users/tteh/AppData/Local/Programs/Python/Python312/python.exe
cd .scratch/firstscan-1120/analysis
$PY orgapanalysis.py        # OR definition + 111 ticker-day gap/width table  -> rows.json
$PY delay_penalty.py        # paired 10:05 vs 11:00 persistence and entry cost  -> delay_penalty.json
$PY crosstab.py             # 12 first-scan signals x gap x fill x gate          -> crossTab.json
$PY counterfactual2.py      # gated replay, validated against shipped AS_RUN     -> counterfactual2.json
$PY nullcontrol.py          # random-gate null distribution (15 draws/gate)      -> nullcontrol.json

cd ../diff
$PY verify/offline-check.py # 14 cases + 16-pair live-equivalence regression, candidate only
```

All five are read-only: they import the replay harness, monkeypatch it in memory at most, and write only
into `.scratch/firstscan-1120/analysis/`. Nothing touches a live endpoint, and `.scratch/` is gitignored.

Module provenance recorded by `delay_penalty.py` at run time, because `engine.py:28` puts
`C:\Users\tteh\Downloads` on `sys.path` and the replay numbers depend on which copy resolves:

```
engine        .scratch/bt/engine.py
mkdata        .scratch/bt/mkdata.py
trend_signal  .scratch/p0/allver/1795047415929677/trend-signal/scripts/trend_signal.py   (sha 60d5573d… == live pinned bytes)
desk_sleeves_v2  C:\Users\tteh\Downloads\desk_sleeves_v2.py                               (OUTSIDE the repo — reproducibility flag)
```

Two things to know before quoting any replay number as durable: the design-logic module the harness
sizing depends on is a loose file in Downloads with no hash on record, and the harness's own first-scan
exits are all "close at next check" (monitored-stop doctrine), so its first-scan P&L is a 55-minute hold
by construction rather than a general result about first-scan trades.
