---
name: desk-risk-guard
description: Deterministic pre-trade gate for the Moomoo x Qoder paper-trading challenge. Approves, sizes or vetoes every proposed order against the competition rules, event calendar, drawdown ladder, fees and expectancy gate. Use before any order and for the pre-market day plan.
---

# desk-risk-guard

Plain Python (stdlib only). It never places orders. It returns one JSON verdict. Keep risk checks here, not in model reasoning.

## Commands (run from this skill's folder)

Day plan (calendar, size multiplier, windows, items to verify):
```
python3 scripts/guard.py day --now 2026-11-18T09:00:00-05:00
```

Check one proposal:
```
python3 scripts/guard.py check --proposal proposal.json --portfolio portfolio.json --now <ISO time with offset> --phase approval|bounded [--allow-unknown-cash]
```

Rebuild the account state from the broker, once per run:
```
python3 scripts/book.py state --history page1.json [--history page2.json ...] --cash cash.json --positions positions.json --now <ISO time with offset> --page-size <page size you requested>
```
Save every page verbatim to its own file first: `sim_trade_history_order_list` with no time window, following `pagination.next_key` until `has_more` is false, plus `sim_trade_cash_info` and `sim_trade_position_list`. Pass the page files in cursor order with one `--history` flag each; `--page-size` must be the `page_size` you asked the tool for (default 50). Do not merge the pages by hand. `state:"ok"` carries `portfolio` (nav, peak_nav, day_start_nav, cash, orders_today) plus `reasons` and `warnings`; `state:"unavailable"` means the history cannot support an exact answer, so use its `reasons` as the veto reason and do not trade. `peak_nav` is close-based: the high-water mark of realized NAV while the desk is flat, so an intraday spike above the close is not captured. `fees_model` says whether the broker actually charged the modelled fees or waived them; a waiver is a warning, not a failure. Nothing is persisted; the next run recomputes from the broker.

Anchor a ticket's stop and take-profit on the actual fill, once the order query confirms it:
```
python3 scripts/levels.py anchor --fill <avg_fill_price> --entry <ticket entry> --stop <ticket stop>
```
guard.py sized the order from the TICKET's `entry - stop`, but the ladder can fill up to entry x 1.002 away. Anchoring both levels on the price actually paid measures the same risk distance `r` from the same place: `stop = fill - r`, `tp_limit = fill + 1.5r`, `r` unchanged, and `drift` (fill minus ticket entry) is reported. Rest the take-profit at `tp_limit` and record that `stop` as the position's `stop_level`. Left on the ticket's prices instead, every later recovery lands `drift/3` away -- 21% of `r` on yesterday's 0.31 drift.

Recover a stop from broker state alone, so no session memory is needed:
```
python3 scripts/levels.py stops --positions positions.json --orders page1.json [--orders page2.json ...]
```
Per open position (`qty` > 0 -- a closed row persists with `qty:"0"` and is not a position) it takes `cost` from the filled BUY's `avg_fill_price`, `tp_limit` from the single resting SELL limit's `price`, and inverts to the stop. `missing_fill` or `missing_tp` means the stop cannot be recovered: treat the position as unmonitored and exit it on an approved ticket. `recover --cost --tp` does one symbol.

`proposal.json` for shares (we only BUY; bearish ideas buy an inverse ETF such as SQQQ or SOXS):
`{"sleeve":"trend","ticker":"SQQQ","kind":"share","entry":30.10,"stop":29.20,"target":31.50,"regime_mult":0.75}`

For a long option: `{"sleeve":"option"|"hedge","ticker":"SPY","kind":"option","underlying":"SPY","option":{"premium":2.10,"dte":1,"delta":0.3},"regime_hedge_mult":1.5}`

For a sleeve B 0DTE legged iron fly (`"sleeve":"B","kind":"iron_fly"`) the proposal is a *structure*, not a price. The frozen shape is `schema/fly-proposal.example.json` in the change package; abbreviated here, every field required (that file predates `max_loss_usd` and so carries the warning for it, and `fee_per_order_by_hand`/`max_loss_usd_by_hand` are hand-check artifacts, not proposal fields):

```
{"sleeve":"B","kind":"iron_fly","ticker":"SPY","underlying":"SPY","venue":"SPY",
 "expiry":"2026-11-23","dte":0,"now":"2026-11-23T10:12:00-05:00",
 "legs":[{"seq":1,"code":"US.SPY261123P682000","right":"P","strike":682.0,"side":"BUY_TO_OPEN",
          "qty":1,"bid":0.69,"ask":0.69,"offset":-9.0}, ...seq 2,3,4...],
 "atm_strike":691.0,"width":9.0,"em":8.72,"iv":0.212,"spot":690.85,
 "credit":5.55,"debit_at_ask":5.63,"credit_crossed":5.55,"credit_basis":"leg_books",
 "max_loss_per_lot":345.0,"max_loss_usd":690.0,"qty":2,"legs_per_lot":1,
 "structure_key":"fly:SPY261123C691000x1|SPY261123C700000x1|SPY261123P682000x1|SPY261123P691000x1",
 "orders_planned":6,"orders_if_stopped":8,"size_basis":"max_loss",
 "fee_model":"moomoo_page_s8_per_order",
 "regime_gate":{"window_et":["09:30","10:00"],"bars_required":6,"stamps":["09:35","10:00"],
               "stamp_convention":"close",
               "move_0930_1000":-0.13,"range_0930_1000":3.95,
                "threshold":2.18,"range_threshold":7.84,"em_basis":8.72,"dir":-1,"pass":true},
 "book":{"all_legs_two_sided":true,"empty_legs":[]},
 "iv_source":"atm_combo","dte_source":"osi_expiry"}
```

`fee_model` has exactly one accepted value, `moomoo_page_s8_per_order` = `max(1.99, 0.65n) + 0.318n` per order.

What is different about the credit branch, and why:

- **Sizing basis.** A fly has no premium to divide by: it is paid a credit. Lots come from
  `floor(structure.max_loss_pct_of_nav / 100 x nav x size_mult / max_loss_per_lot)`, and the verdict's
  `risk_usd` **equals `max_loss_usd`**, never the money deployed. `max_loss_per_lot = (width - credit) x 100`
  is re-derived here and *used*; a proposal that understates it inside 2% is sized on the derived figure
  and reports `max_loss_per_lot_claimed`. A proposal carrying `max_loss_usd` has it checked against
  `max_loss_per_lot x lots` as a second identity, and one carrying `max_loss_usd_by_hand` has it ignored:
  the `_by_hand` fields are hand-check arithmetic in the fixture's parent, not proposal fields.
- **Geometry is body-at-ATM.** Both shorts sit at `atm_strike` (one C, one P) and the long wings at
  `atm_strike +/- width`, so `width` is the short-to-long distance and the loss bound. `strike`, `right`
  and the expiry of every leg are re-read from its OSI code and must agree with the sibling fields; a leg
  whose fields disagree with its own code is a veto, not a rounding difference. Legs must be 2 shorts and
  2 longs, one expiry, equal quantities, on the venue's `strike_grid`.
- **DTE band.** `risk.dte_min`/`dte_max` (1-5) govern the debit paths and do **not** apply here: the fly is
  banded by `structure.dte` (0) and the legs' expiry is re-derived against `--now`. `structure.dte` is the
  only place to change this, so the two families cannot decide each other's band by accident.
- **Fees per order.** `max(1.99, 0.65n) + 0.318n` for `n` = contracts in that order (= verdict lots x
  `legs_per_lot`, which is the lots alone while every leg is 1 contract), charged once per leg-order, so a
  4-leg open is 4 orders and a stopped day is up to 8. The fee is linear in lots and was never quadratic:
  the `qty^2` reading came from a legs-qty-2 proposal, which the leg convention now vetoes outright. The
  legacy `2 x (1.99 + 0.30n)` still backs `guard.py fee` and the single-leg option paths. The fee gate's
  denominator is the **credit received**, and its ceiling is the fly's OWN key,
  `structure.fee_max_pct_of_credit` (**12.5** since the owner ruling of 2026-11-25; 10.0 from 2026-11-23).
  The number lives in `references/rules.json`, which is what `guard.py` reads at check time - this line is a
  comment, not the authority, and a rules.json that says otherwise wins. The single-leg paths keep
  `fees.option_fee_max_pct_of_premium` (3.0); if the fly's key is absent the fly falls back to 3.0, never up.
- **Fly entry cut-off — one authority.** `rules.json structure.entry_window_et[1]` (11:00 ET, owner
  decision B7, half-open: 11:00:00 itself is refused) is enforced HERE and nowhere else; the builder
  applies no time-of-day cut-off, so there is no second copy to drift. It is narrower than the desk's own
  `timing.entry_start_et`/`entry_end_et`, which the shared calendar check still applies on top.
- **D4 measurement window — a different key.** `regime_gate.pass` is re-derived from the gate's own
  move/range/em numbers against TWO ceilings, `move_max_frac_of_em` (0.35) and `range_max_frac_of_em`
  (1.0), measured over `structure.regime_window_et` (09:30-10:00 ET, B6). Owner ruling 2026-11-23 raised
  both from 0.25/0.9 for Nov 23-24 only, and the keep-or-revert decision is due before Wed 25 08:30 ET;
  the numbers below are read from rules.json at check time, never from this sentence. A `pass` that contradicts them
  is a veto; a gate that names a `window_et` other than the rules' is a veto; a gate that names no window
  approves with a warning. **The window is six bars, stamped 09:35 through 10:00**: moomoo stamps a
  5-minute bar at its CLOSE (regular sessions carry 09:35..16:00, 78 rows, no 09:30 row), so the guard
  also checks the builder's coverage attestation - `bars_required` must equal `(hi-lo)/5`, the last stamp
  must be the window's end, and a `stamp_convention` other than `close` is a veto. A gate that reports no
  coverage at all approves with a warning, because that field exists only in the staged builder and two
  publishes must not be able to veto a real structure by slipping past each other.
- **Once per day, and it is not a hedge.** A second fly is refused while one is open and after one has been
  closed today. Sleeve B is new risk: `kill_switch`, `hedges_and_closes_only` and `daily_halt` all veto it,
  and no hedge exemption is read on this path.
- **Calendar.** `guard.py day` also returns `fly_off` (a date the fly is banned outright - Fri 27 is the
  only one) and `releases` (name, ET time). A release whose time lands inside
  `structure.release_window_et` (10:00-15:30 ET) vetoes that day's fly: that is the desk-wide rule, and
  B7 withdrew only the Wednesday-25 CONDITIONAL that was attached to it. Nothing scheduled for Wed 25 can
  fire it - PCE, GDP and jobless claims are all 08:30 ET - so Wed 25 flies unconditionally.
- **Exit thresholds are the rules', not the proposal's.** `verdict.exit` carries `structure.exit` plus
  per-lot USD (`target_credit_usd_per_lot` = 25% of the credit, `stop_loss_usd_per_lot` = 50% of the max
  loss, `strike_breach_points` = width x 0.5), the venue's `american` truth, and any `disagreements` with a
  proposal that tried to carry its own `exit_policy`.
- **No resting stop, and no `stop_level` key at all.** A single level would be read as "the stop" of a
  four-leg structure, which has none; `protection.mechanism` stays `monitored` and the wings are the bound.
  Send `order.contracts_per_leg_order` contracts on each of the four leg orders -- that is `qty` lots times
  the `legs_per_lot` the proposal declares (1 today), so it is never `legs[].qty` on its own and never the
  proposal's lot count if the verdict reduced it. See the identity/units bullets below.
- **Identity is a key, not a price, and it is size-independent by design.** `structure_key` is `"fly:"` +
  the sorted leg codes with each leg's contract count (`SPY261123C691000x1|...`): a pure function of the
  legs, so a re-quote keeps it and an amended wing or rolled expiry breaks it. Because the leg convention
  pins every `legs[].qty` at 1, the suffix is always `x1` and **two sizes of the same fly DO share one
  key** -- that is branch 2, chosen after a size-bearing key made every 2-lot fly read as "a leg was
  amended". It is not a loss of information: `qty`, `lots` and `order.contracts_per_leg_order` carry the
  size, and the key's job is only to tie one approval to four leg orders and one journal `close` row.
  The verdict echoes the claimed key, adds `structure_key_now` re-derived from the legs, and puts the same
  string on `order.structure_key`. A claim that does not match its own legs is a veto; no claim at all is
  derived here and warned about. The algorithm is duplicated from `option-adapter/sleeve_b_fly.py` because
  skills cannot import each other, so `c2/test_credit.py` group d asserts byte-parity on six leg sets.
- **A leg's `qty` is contracts, and one lot is one contract per leg.** The producer's convention: legs
  describe ONE lot (`legs[].qty == 1`), and size travels only as the top-level `qty` in lots, with
  `legs_per_lot` declaring the contracts-per-leg figure beside it. So `max_loss_per_lot` must equal
  `(width - credit) x 100`, and a leg carrying more than one contract is a **veto**, not something to
  divide away: it halves the declared bound against the real one and makes one key describe two sizes.
  A declared `legs_per_lot` that contradicts the legs is also a veto -- the field and the contracts cannot
  both be believed. `max_loss_usd`, when the proposal carries one, must equal `max_loss_per_lot x qty`;
  a per-lot figure passed as the structure risk is refused rather than silently resized.
- **`credit`, `debit_at_ask` and `credit_crossed` are three books, not an ordering.** credit is sold bids
  minus bought bids, debit_at_ask is the buy-back at asks, `credit_crossed` (always <= credit) is the
  credit that survives lifting your own wings at the ask. A wide wing market legitimately puts credit
  above the ask-based debit, so no ordering between them is checked; what is checked is that no leg is
  quoted through itself (`ask < bid` vetoes -- `bid == ask`, a locked wing, does not) and that
  `credit_crossed` is positive, because a non-positive crossed credit means there is nothing to collect.
  An absent `credit_crossed` is warned as a test that could not run, and one larger than `credit` is
  warned as a stale book, not vetoed.
- **Prices on this path are dollars.** The combo payload quotes 1e9-scaled values (5550000000 = $5.55 per
  share); a fly proposal must not. `credit`, `debit_at_ask` or `credit_crossed` above `spot` is refused as
  a unit error instead of being sized as an enormous premium.

- Every veto reason on this path starts with `iron_fly: ` so the coordinator cannot mistake a malformed
  structure for a market veto. Shared rules (account, calendar, ladder, order budget, universe) still
  apply first and keep their own wording.

For a closing order add `"is_close": true` together with `sleeve` and `ticker` (both are read before the close shortcut, so a close proposal without them fails): `{"sleeve":"trend","ticker":"QQQ","kind":"share","is_close":true}`. Always approved.

This is how a monitored stop breach is authorised. When an open position trades at or below its recorded `stop_level`, run the check with `is_close: true`, log the verdict, and the approved close ticket *is* the exit -- there is no resting stop to fall back on.

`portfolio.json`: `{"account_name":"<exact name shown by moomoo>","account_mode":"SIMULATE","nav":..,"peak_nav":..,"day_start_nav":..,"cash":..,"orders_today":..,"positions":[{"ticker","kind","market_value","open_risk","cost","sleeve"}],"closed_trades":{"trend":{"n":..,"expectancy":..}}}`
Take nav, peak_nav, day_start_nav, cash and orders_today from the `portfolio` block of `book.py state` and add the positions yourself (market value from the account, `open_risk` from the recorded `stop_level`). Never hand-seed peak_nav or day_start_nav from a previous run: nothing written last run exists now, so a seeded NAV reports a drawdown that was never measured. `closed_trades` can only come from this session's decision-journal `stats`; when that is empty tell the caller the expectancy gate is unavailable instead of passing zeros. `cash` must be a number; if the account tools did not give you one, the check declines with "cash missing from portfolio.json" rather than assuming 0.

## What the verdict means
- `approved:false` means do not send the order. Log the `reasons` with decision-journal (kind `verdict`).
- `qty` is the size to send, already reduced by event-day size, drawdown state, regime and caps. Never send more. For `"kind":"iron_fly"` it is **lots of the structure**; each leg order is `order.contracts_per_leg_order` contracts, and `risk_usd` is the structure's maximum loss, not the cash committed.
- `needs_human_approval:true` means show the ticket (symbol, side, qty, limit, stop, rationale) and wait for an explicit yes.
- `protection.stop_level` is the TICKET's level. The level actually monitored is the fill-anchored one from `levels.py anchor` (or recovered by `levels.py stops`): it is a level the desk enforces at the next scheduled check, not an order. The paper accounts accept LIMIT and MARKET only and fill a sell limit priced below the last price immediately, so submitting the stop as an order self-liquidates the position. `order.take_profit` does rest, because it sits above the market.
- `warnings` must be copied into the journal. One of them asks the organisers to confirm the "3+ distinct tickers" rule.

## Rules baked in (references/rules.json, from the organisers' decks)
Eligible: US stocks/ETFs/options, price at least $1, market cap at least $500M. Single asset at most 40% (we use 35%). Max 200 executed orders a day (we stop at 150). Overnight financing 4.8% long and 6% short, none intraday. ETF and stock options auto-exercise after 16:00 ET, so flat before the close. Options fees: the legacy single-leg estimate is $1.99 minimum plus $0.30 per contract; the sleeve B credit branch charges `max(1.99, 0.65n) + 0.318n` once per leg-order (0.318 = 0.30 platform + 0.00279 activity + 0.015 regulatory), which is what `guard.py fee` does NOT report. No reset card: drawdown is permanent. Paper-account limits (moomoo paper-trading rules 7 and 17 plus the API limitations list): order types are limit and market, validity is day only, no stop/stop-limit/MIT/LIT/trailing order can be placed or modified into existence, and a limit that crosses the market is matched at once. Do not edit rules.json at run time; only the human owner changes limits.
