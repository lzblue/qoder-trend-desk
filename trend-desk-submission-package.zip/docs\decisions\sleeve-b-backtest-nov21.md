# Sleeve B (option overlay) backtest, 2026-11-06 → 2026-11-18, against moomoo history

Written 2026-11-21. Evidence labels: **[measured]** = computed by the scripts named below from
moomoo `quote_history_kline` payloads archived under `.scratch/bt-sleeveb/opt/`;
**[documented]** = text in the live skill tree or `docs/contest-rules-notes.md`;
**[inferred]** = my reasoning; **[undiscoverable]** = I could not get the number at all.

## 1. What was backtested, and whether it is the live thing

Sleeve B = the option overlay in the `option-adapter` skill: it takes one **already guard-approved
Sleeve A equity entry** and proposes a short-dated option on the same underlying as a size add-on.
It is **not in production**: `GET /forward/skills` today reports `option-adapter`
(`skill_00w0ip0yri8sgag736ks`) with `binding_info.agent_template_count = 0`, latest version
`1795137189020914` **[measured]**. `docs/agent-handover-2026-11-21.md:95-96` says the same.

Provenance of every constant used (all re-read today, not from memory):

| item | live now | note |
|---|---|---|
| `sleeve_b.py` | `1795137189020914` | md5 `8841758501bd0f0a…` — **byte-identical** to the module I backtested **[measured]** |
| `desk-risk-guard` | `1795159349266852` (2026-11-20T07:22Z) | moved since my 2026-11-20 snapshot; the **only** rules.json delta is SPXS removed from `universe.shares` and `universe.leverage` **[measured]** |
| `trend-signal` | `1795160305077544` (07:38Z) | bearish SPY now returns `NONE` ("no eligible bearish ETF"); 1.5R target untouched **[measured]** |
| `vwap-chop` | `1795160305163946`, bound to 3 templates | new Sleeve C; not part of this backtest |
| risk-reward requirement | A's target = entry + 1.5 × (entry − stop); overlay TP = premium + \|Δ\| × that move | `trend_signal.py:182`, `sleeve_b.py select` |

Signals are the desk's own engine output (`../bt/engine.py`) for the two execution variants, so the
overlay rides exactly the entries the desk would have taken: 8 trades (`ladder/signal/next/etf`) and
11 (`marketable/fill/mon/etf`) = **19 Sleeve A entries, 11 unique events** across 2026-11-09…11-18.
`engine.py:26` imports trend-signal `1795047415929677`, one version older than live; the only
behavioural difference is bearish-SPY, which is handled by excluding those legs in §3.

Pipeline (all re-runnable): `manifest.py` → `price.py` → `manifest_lowdelta.py` → `price.py` again →
`report.py`. Option contracts were selected with BSM on the real strike ladder ($1 SPY/QQQ, $2.50
SMH) and the real expiry calendar (SPY/QQQ Mon–Fri, SMH Mon/Wed/Fri), then priced against the
**actual 5-min option bars**, using each bar's own `implied_volatility` field, and skipping
zero-volume bars as unfillable.

## 2. Confluence gate — the reason there is almost nothing to measure

The published gate is "prior session range ≥ 1.5× its 20-session average **and** close in the top
third (+1) / bottom third (−1)". Applied to the desk's own entries **[measured]**:

```
20261109 SPY LONG   0.97x, close 9%     closed      20261113 QQQ SHORT  1.15x, close 57%   closed
20261110 SPY LONG   1.76x, close 81%    OPEN        20261113 SPY SHORT  1.04x, close 37%   closed
20261111 QQQ LONG   1.14x, close 55%    closed      20261116 QQQ SHORT  1.31x, close 48%   closed
20261111 SPY LONG   0.82x, close 70%    closed      20261116 SPY SHORT  1.33x, close 53%   closed
20261112 QQQ LONG   0.93x, close 57%    closed      20261117 SMH SHORT  0.72x, close 10%   closed
20261112 SPY LONG   0.83x, close 65%    closed
```

1 event of 11 passes. **The binding term is the close-location, not the ratio**: dropping
`ratio_min` from 1.5 to 1.2 adds nothing (the next-highest ratios are 1.31–1.33 but their closes sit
at 48–53%, mid-range). Events opened by threshold **[measured]**:

| ratio | close-loc 0.66/0.34 | 0.60/0.40 | 0.75/0.25 |
|---|---|---|---|
| 1.5 (live) | 1 | 1 | 1 |
| 1.2 | 1 | 1 | 1 |
| 1.0 | 1 | 2 | 1 |
| 0.8 | 2 | 4 | 1 |

The desk's own `expectancy_gate` needs 10 trades to half-size and 20 to trust a sleeve
(`rules.json`). The published path produced **1** in two weeks, so the gate is not merely
conservative, it is unmeasurable at contest cadence.

## 3. Performance

Overlay legs priced with live sizing (`option_trade_risk_pct 0.5%` of NAV × regime `size_mult`,
capped at 1.5% NAV), live fee model, and three exit paths: own TP touched → exit; else parent's
close; else FLAT 15:45.

Shipped delta band \|Δ\| ∈ [0.25, 0.50] **[measured]**:

| subset | n | net $ | win % | avg realised R | avg planned R:R | legs ≥1.5R |
|---|---|---|---|---|---|---|
| all buyable legs | 15 | **−789.90** | 33.3 | −0.106 | 0.90 | **0/15** |
| excluding bearish-SPY (unproducible live now) | 11 | −848.98 | 27.3 | −0.184 | 1.08 | 0/11 |
| the gate-open event (2026-11-10 SPY LONG) | 2 | −350.36 | 0 | −0.506 | 0.83 | 0/2 |
| `ladder/signal/next/etf` variant | 6 | −42.28 | 50.0 | +0.071 | — | 0/6 |
| `marketable/fill/mon/etf` variant | 9 | −747.62 | 22.2 | −0.225 | — | 0/9 |

Cheaper band \|Δ\| ∈ [0.10, 0.25] (strikes 3–5 points further OTM) **[measured]**:

| subset | n | net $ | win % | avg realised R | avg planned R:R | legs ≥1.5R |
|---|---|---|---|---|---|---|
| all legs | 19 | −861.22 | 26.3 | −0.083 | 1.09 | 6/19 |
| excluding bearish-SPY | 15 | −718.10 | 26.7 | −0.086 | 1.24 | 6/15 |
| legs whose planned R:R ≥ 1.5 | 6 | **+594.32** | 50.0 | — | — | — |
| legs whose planned R:R < 1.5 | 9 | −1 312.42 | 11.1 | — | — | — |

Four things the tables say that the headline does not:

1. **The overlay is a leveraged copy of its parent, not a second edge.** Per leg, realised option R
   tracks parent R (e.g. +0.349 vs +0.317, +0.777 vs +0.784, −0.651 vs −0.917) **[measured]**. Sleeve
   A's own expectancy in this window is −0.073 (ladder) / −0.177 (marketable) avg R, so there is
   nothing for the overlay to add to.
2. **The overlay's target assumes a move the parent almost never delivers.** TP is
   premium + \|Δ\| × (full 1.5R move), yet **0 of 15 legs saw the parent reach 1.5R** (max parent_R
   +1.49) and only **2 of 15 option legs reached their own TP** — both the 2026-11-16 SPY PUT, which
   is now unproducible. Parent exits: 5 "unmonitored → close at next check", 5 "FLAT 15:45",
   3 "stop breached at monitor check", 2 "take_profit" **[measured]**.
3. **Dropping bearish-SPY makes it worse, not better**: the two legs that hit TP were SPY puts
   (+193.42 each). The live universe change (SPXS removed as below the contest's $500M eligibility
   floor) takes away the overlay's only completed trades **[measured]**.
4. **4 legs were silently unbuyable** — the 0.5%-of-NAV budget ($375 at `size_mult 0.75`) is smaller
   than one contract: 2026-11-16 QQQ PUT at 5.34 ($534, 42% short, day volume 14 779) and 2026-11-17
   SMH PUT at 8.67 ($867, 131% short, day volume 303) **[measured]**. Those are exactly the high-vol
   days the sleeve exists for.

## 4. Rule verification

Contest terms from `docs/contest-rules-notes.md` (read 2026-11-19), desk caps from the live
`rules.json`. Status is computed from the priced legs, not asserted.

| rule | limit | result |
|---|---|---|
| orders/day | 200 executed (contest), 150 engine | **PASS** — 2 orders per leg (entry + exit) × ≤4 scans, nowhere near **[measured]** |
| concurrent positions | 100 | **PASS** **[measured]** |
| contracts per single contract | 1 000 | **PASS** — max 8 (cheap band), 2 (shipped) **[measured]** |
| 40% single-name cap | stocks/ETFs only, **options excluded** | **PASS by rule text**; no leg's equity parent came close **[documented + measured]** |
| trading window | 04:00–20:00 ET | **PASS** — overlay entries 10:20–12:45 ET **[measured]** |
| desk entry window / FLAT | 10:00–15:00, flat 15:45 | **PASS** **[measured]** |
| DTE band | `dte_min 1`, `dte_max 5` | **PASS** — DTE values seen {1, 3} **[measured]** |
| delta band | \|Δ\| ∈ [0.25, 0.50] | **PASS 15/15** shipped; **1/19 outside** in the cheap band (by construction) **[measured]** |
| fee gate | 2 × (1.99 + 0.30 q) ≤ 3% of premium | **PASS 15/15**, worst 2.36% (cheap band 19/19, worst 2.49%) **[measured, modelled fee]** |
| ITM auto-exercise after 16:00 | expiry never coincides with a same-day hold | **NOT APPLICABLE** — every leg is 1–3 DTE and flat by 15:45 **[measured]** |
| Reset Card / revival | disqualification | **NO EXPOSURE** — nothing in `sleeve_b.py` or `guard.py` references it **[documented]** |
| fill vs market volume (qty > 20× volume → partial) | — | **PASS** — min day volume on any shipped-band contract 8 171; but the cheap band's SMH series prints **448** and the shipped 8.67 SMH put **303** contracts/day total **[measured]** |
| "nothing priced under $1" eligibility | `competition.min_price 1.0` | **AMBIGUOUS / FAIL under a per-share reading** — 8 of 19 cheap-band legs priced 0.47–0.61. Shipped band 0/15. **[undiscoverable]** whether the contest means the per-share quote or the contract value for options |
| 10% max spread, 5% slippage | `sleeve_b.py` pre-trade checks | **[undiscoverable]** — moomoo historical klines carry no bid/ask, so this can only ever be verified live |
| option fees as modelled | `option_min_commission 1.99` + `0.30/contract` | **[undiscoverable]** — `account_order_fees` failed 3× with `-32603`; the real paper-account option fee has never been measured |
| desk `max_effective_gross_pct` 120 | guard.py:214 | **HOLE** — `eff_now` is built from equity notional × leverage only; option delta never enters it. Yet the overlay's own delta exposure is 22.7%–61.1% of NAV (shipped) and up to **110.2%** (cheap band), and on **6/15** legs it *exceeds the parent position's own effective exposure* (median 0.67×, max 1.78×). Adding parent + overlay crosses 120% on 1/15 shipped-band legs and 4/19 cheap-band legs **[measured]** |

The exposure finding is the one I would act on first: the budget rule sizes by **premium at risk**
(0.19%–0.49% of NAV) while creating **directional** exposure two orders of magnitude larger, and no
live check sees it.

## 5. Is the risk/reward ratio met? No.

**0 of 15 shipped-band legs reach 1.5R** (average planned 0.90). The reason is arithmetic, not
tuning:

    planned R:R = |Δ| × move_A / premium  =  move_A / (premium / |Δ|)

`premium / |Δ|` is what a short-dated contract charges per unit of delta, and it is stubbornly
large in this window **[measured]**:

| family | P/\|Δ\| min | median | max | A move needed for 1.5R | that as % of spot | A moves actually planned |
|---|---|---|---|---|---|---|
| SPY (shipped band) | 3.94 | 5.60 | 7.69 | 8.40 | 1.12% | 1.31, 4.33, 4.39, 4.47, 5.09, 7.51 |
| SPY (cheap band) | 2.96 | 4.02 | 6.83 | 6.03 | 0.80% | same |
| QQQ (shipped band) | 5.90 | 8.21 | 11.49 | 12.32 | 1.78% | 6.75, 8.01, 10.98 |
| QQQ (cheap band) | 3.90 | 7.96 | 10.28 | 11.93 | 1.73% | 6.19, 6.75, 8.01, 10.98 |
| SMH (cheap band) | 16.49 | 16.49 | 16.49 | 24.74 | 5.42% | 6.38 |

So the requirement is met only when A's own 1.5R target is ≥ ~0.8% of spot for SPY, ≥ ~1.7% for
QQQ, and ~5.4% for SMH — i.e. **on these underlyings the sleeve is ratio-eligible on a minority of
days, and never on SMH**. Widening the band does not help: \|Δ\| and premium move together, which is
why the shipped 0.25–0.50 band averages 0.90 and the 0.10–0.25 band only 1.09.

## 6. Adjustments, ranked by measured effect

**A. Add a pre-trade R:R gate in `sleeve_b.select`: compute \|Δ\| × move / premium and return NONE
below 1.5.** This is the only change that is both cheap and evidentially supported. Effect on the
sample: it vetoes **all 15** shipped-band legs (so it cannot make the shipped sleeve profitable, it
makes it honest) and, in the cheap band, isolates 6 legs at **+$594.32 vs −$1 312.42** for the ones
it rejects **[measured]**. Caveats I will not hide: those 6 rows are only 4 unique events, 3 of the
4 winning rows are one day (2026-11-09 marketable +607.82), **all 6 are gate-vetoed by the confluence
filter**, and none of it clears the desk's own 10-trade threshold. Treat as a direction, not an edge.

**B. Size the overlay by delta exposure, not premium.** Add an option term to `guard.py`'s
`eff_now` (or a new `max_overlay_delta_exposure_pct`) before any option path is wired. Today
`guard.py:214` would let a $490 premium buy 110% of NAV in directional exposure **[measured]**.
This is a rule-completeness fix, not a P&L fix.

**C. Make the unbuyable legs visible.** Raise `option_trade_risk_pct` from 0.5 to ~1.0, or require
`q ≥ 1` to be satisfiable as a precondition so the leg returns NONE with a reason instead of silently
vanishing. Fixes 4/19 legs **[measured]**; also halves the fee-per-exposure drag (fees are 2.4% of a
1-contract ticket vs ~1.2% of a 2-contract one).

**D. Drop SMH from `universe.option_underlyings`.** 303–448 contracts/day on the series the desk
would pick, P/\|Δ\| 16.5 ⇒ needs a 5.4% underlying move for 1.5R, and its IV prints 90–114% which I
suspect is a moomoo data-quality artifact rather than reality **[measured + inferred]**. Keep
SPY/QQQ only for now; IWM/XSP untested.

**E. Require a bigger parent move instead of a cheaper contract.** The table in §5 turns the
question around: gate on `move_A / spot ≥ 0.8%` (SPY) / `≥ 1.7%` (QQQ) as the entry condition for the
overlay. This is the same information as A but expressed where it is knowable without an option
quote, so it also survives the missing-bid/ask problem.

**F. Exit the overlay when the *underlying* touches A's stop, not when the parent closes.** With
that denominator the shipped band's average improves from −789.90 to −616.90 and 5/15 legs express
≥1.5R **[measured]**. Two honest warnings: the improvement is only $173 over 15 legs, and
`rr_with_stop` is computed from the *observed* option price at the stop, i.e. partly path-dependent —
a tradeable version needs `levels.py`-style BSM at entry, which does not exist yet. Also note 11/10
satisfies 1.5R on this definition (1.78) and **still lost $175**, because the ratio was bought by
shrinking the denominator, not by the idea working. Do not present this as a fix.

**G. Do not loosen the confluence gate alone.** §2 shows the ratio threshold is not what blocks it,
and every leg the cheap-band ratio gate likes is currently gate-vetoed. Loosening must be paired with
A or E, and even then 4 events in two weeks cannot clear `expectancy_gate.min_trades_half_size` = 10.

**Not tested, and what it would take:** IV-ranked contract choice (chains can return 1.2 MB of
greeks/IV, so it is fetchable); spread/slippage compliance (needs live book snapshots — historical
bid/ask does not exist); option fees (needs `account_order_fees` to work, 3/3 failures so far); a
same-day-only hold (every leg here was held ≤ one session already, so the contest's ITM-exercise rule
stays non-binding).

## 8. Solving "what change makes the ratio met" per event

Follow-up 2026-11-21, same window. Because A's target is `1.5 × dist` and the overlay's ratio is
`|Δ| × move / premium`, the requirement collapses to an exact pre-trade inequality:

    ratio >= 1.5   <=>   dist_underlying >= premium / |delta|

`dist` is the parent's stop distance converted into underlying dollars (÷ leverage for the 3x
bearish legs). Scripts: `ratio_ceiling.py` (ceiling per event, BSM at each event's measured IV,
validated against the two strikes actually fetched → fit error 6–21%), `eligibility.py` (the two-sided
window), `fix_measure.py` (structure and horizon variants).

| day | fam | act | dist | dist/spot | P/\|Δ\| best in band, premium ≥ $1 | ratio | clears 1.5R |
|---|---|---|---|---|---|---|---|
| 1109 | SPY | LONG | 5.01 | 0.67% | 4.83 | **1.56** | **YES** |
| 1110 | SPY | LONG | 2.89 | 0.38% | 4.74 | 0.91 | no |
| 1111 | QQQ | LONG | 5.34 | 0.77% | 5.55 | 1.44 | no |
| 1111 | SPY | LONG | 3.39 | 0.45% | 3.78 | 1.35 | no |
| 1112 | QQQ | LONG | 7.32 | 1.06% | 6.55 | **1.68** | **YES** |
| 1112 | SPY | LONG | 2.93 | 0.38% | 4.12 | 1.07 | no |
| 1113 | QQQ | SHORT | 4.50 | 0.67% | 10.08 | 0.67 | no |
| 1113 | SPY | SHORT | 0.87 | 0.12% | 5.61 | 0.23 | no |
| 1116 | SPY | SHORT | 2.98 | 0.40% | 5.93 | 0.75 | no |

**2 of 9 events clear 1.5R, and both are LONGs.** ⚠ That row is computed from a BSM ladder, not from
real option bars. §9 re-runs the same question on fetched 5-min bars for the two clearing strikes and
the count becomes **1 of 9** — read §9 as the result and this table as the model that predicted it.

Relaxing the delta band to any \|Δ\| ≥ 0.05 lifts it
to 5/9, but every one of those contracts prices at $0.15–0.35 per share — under the contest's $1
floor — so that route is not available as written **[measured, subject to the floor's interpretation]**.

Two more results that close off the obvious ideas:

* **A 1×1 vertical makes the ratio worse, not better** (premium-per-net-delta 4.35–12.12 vs 3.78–10.08
  naked, i.e. −10% to −21% on the ratio; 0/9 clear). In flat-IV BSM the short leg is *more* delta
  efficient than the in-band long, so netting it degrades the ratio; the width cap then truncates the
  payoff. Fees also double (4 order fees per round trip), which breaks the 3% fee gate at q = 1.
* **Stretching the horizon cannot open the window, because both bounds scale as σ·√T·S.** `P/|Δ|` and
  the ex-ante available range grow at the same rate, so the two constraints move together. With a
  3–5 DTE contract and a multi-day target, 0/9 events satisfy both bounds even allowing the target to
  be as large as the median remaining range.

The window itself, per event **[measured]**: `dist` must be ≥ P/\|Δ\| (4.1–10.1) *and* ≤ ⅔ of the
ex-ante remaining-session range (1.2–2.4 at `RANGE_MULT` 1.0). The interval is **empty on 9/9 events**
at `RANGE_MULT` 1.0, and only opens if the target is allowed to be ~1.2× a typical remaining range —
i.e. the payoff requires a move in the tail. Consistent with that: the underlying only reached
6–50% of the required 1.5R move between entry and the parent's exit on 7 of 9 events, and A's target
was touched intraday on 2 of 9 (both the now-untradeable SPY shorts).

### The change I would actually make

1. **Gate on the inequality, in the code that already picks the contract.** In `pick()`
   ([sleeve_b.py:269](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/sleeveb/build/option-adapter/scripts/sleeve_b.py#L269)),
   take the parent's `dist` in underlying dollars, and inside the candidate loop reject
   `c["premium"] / abs(c["delta"]) > dist`, plus `c["premium"] < rules.competition.min_price`.
   Change the sort key in `candidates()` from `-abs(delta)` to `premium/abs(delta)` so the cheapest
   per-delta in-band leg is tried first — the current order deliberately picks the *most* expensive
   per-delta contract available. Result on this window: 2 overlay tickets in two weeks instead of 1.
2. **Refuse bearish overlays** until an eligible bearish option exists. Their `dist` is divided by the
   3x leverage while the premium is quoted on the unleveraged underlying, so the ratio ceiling is
   ~⅓ of the long side (best 0.75 vs best 1.68). This mirrors what `trend-signal` already does for
   bearish SPY, just one layer up.
3. **Fix the parent, not the option, for the rest.** If the owner wants more eligible overlays, the
   lever is Sleeve A's stop width and holding time: eligible events are those whose stop sits ≥ ~0.65%
   of spot *and* whose 1.5R target is inside what the session can still deliver. That is a Sleeve A
   change (sizing and FLAT doctrine), and it must be backtested on its own — it is not something an
   option parameter can substitute for.
4. If the owner's intent is convexity rather than an R-multiple, then the honest change is to
   **reclassify the overlay as a hedge** and score it on \|Δ\|-weighted payoff per premium dollar with
   max-loss = premium, which needs a `rules.json` edit by the owner — the 1.5R expectation is what
   sleeve B currently fails, and short-dated index premium is what makes it fail.

## 7. Bottom line

Sleeve B is correctly specified against every cap I can verify, and it is **not** delivering the
desk's 1.5R: 0/15 legs in the shipped band, average 0.90, net −$789.90 over two weeks (−$849 once
the now-impossible bearish-SPY legs are removed), and its one gate-open event lost −$175 per
execution variant. The root cause is two-layer: short-dated index-options on this account charge
4–12 (SPY/QQQ) to 16 (SMH) dollars of premium per unit of delta, and the parent idea that supplies
the move itself never reached 1.5R in this window. **No configuration I tested turned the expectancy
positive.** The defensible next step is A + E (a hard ratio gate expressed on the underlying move),
B (delta-exposure sizing before any wiring) and C/D (stop silently unbuyable legs and drop SMH) —
and accepting that with 1–4 overlay events per two weeks, sleeve B cannot be evaluated inside the
contest window at all. §9 puts the ratio gate on measured bars: it approves **1 event in 9**, and the
recommended package there supersedes item A here.

## 9. The measured answer to "what change makes the ratio met" (2026-11-21, real bars)

§8's clearing count came from a BSM ladder. Two strikes were then fetched as real 5-min bars and
priced through the same pricer as everything else, so this section has no model in the ratio bound:

| event | contract chosen by best P/\|Δ\| | prem | \|Δ\| | P/\|Δ\| | dist | **planned ratio** | old pick (highest \|Δ\| first) |
|---|---|---|---|---|---|---|---|
| 1109 SPY LONG | `US.SPY261110C755000` DTE 1 | 1.39 | 0.263 | 5.29 | 5.01 | **1.42** | K754: 1.73/0.309 → 1.34 |
| 1112 QQQ LONG | `US.QQQ261113C700000` DTE 1 | 1.63 | 0.254 | 6.42 | 6.48 | **1.51** ~~1.71~~ | K695: 3.54/0.431 → 1.34 |

BSM said 1.56 and 1.68; the bars say 1.42 and 1.51. So **1 of 9 events clears 1.5R on real data, not
2 of 9**, and the strike scan over every measured leg (`ratio_measured.py`, all three priced leg sets,
premium ≥ $1) reproduces it: best measured ratio per event = 1.42, 0.83, 1.36, 1.29, **1.71**, 0.93,
0.64, 0.19, 0.63. The bearish events are 0.19–0.64 and are not close.

The realised legs of the one clearing event were also priced: net +$92.82 / +$390.82 for the 1109 SPY
leg under its two exit variants and −$362.78 for 1112 QQQ (it exited with the parent at premium 0.44
against a 1.63 entry), i.e. `avgR +0.33`, 3 rows. Meeting the planned ratio did not make the trade
win, and 3 rows is not evidence either way.

### What the ratio gate would have to look like

`sleeve_b.py` currently sorts candidates by *highest* \|Δ\| first, which is the most expensive-per-delta
contract in the band, and applies no ratio test at all. The minimal change is a sort key plus a filter:

```diff
-    return sorted(out, key=lambda c: (-abs(c["delta"]), c["dte"], c["strike"]))
+    return sorted(out, key=lambda c: (c["premium"] / abs(c["delta"]), c["dte"], c["strike"]))


 def pick(contracts, right, dte_min, dte_max, budget_usd, fee_ok,
-         delta_lo=DELTA_LO, delta_hi=DELTA_HI, entry_tol_pct=ENTRY_TOL_PCT):
+         delta_lo=DELTA_LO, delta_hi=DELTA_HI, entry_tol_pct=ENTRY_TOL_PCT,
+         move_usd=None):
     trace = []
     for c in candidates(contracts, right, dte_min, dte_max, delta_lo, delta_hi):
+        if move_usd is not None and c["premium"] / abs(c["delta"]) > move_usd:
+            trace.append({"symbol": c["symbol"], "fate": "ratio_gate",
+                          "need": round(move_usd, 2), "pd": round(c["premium"] / abs(c["delta"]), 2)})
+            continue
```

`move_usd` is the parent's 1.5R target already converted into underlying dollars, so the test is
exactly `ratio >= 1.5` with no new constant, and a refused ticket is a `skipped` record, not an error.

### What it costs, measured

| change | events clearing 1.5R | verdict |
|---|---|---|
| as shipped (highest-\|Δ\| first, no ratio test) | 0/9 | the status quo being fixed |
| + sort by P/\|Δ\| and gate on `premium/\|Δ\| ≤ move` | **1/9** | works, but approves ~1 overlay per 2 weeks |
| + drop the delta band to \|Δ\| ≥ 0.10 | 4/9 | **contest-illegal**: 3 of the 4 price at $0.47–0.58, under the $1 floor |
| + keep the floor, allow \|Δ\| ≥ 0.10 | 1/9 | same as the gate alone — the floor, not the band, is what binds |
| 1×1 vertical instead of naked | 0/9 | net P/\|Δ\| 4.35–12.12 vs 3.78–10.08 naked: 10–21% worse, and 4 order fees break the 3% gate at q=1 |
| DTE 3–5 with a multi-day target | 0/9 | both bounds ∝ σ√T·S, so they move together; vol cancels and only √(T_option/T_remaining) is left |
| bearish overlay (either family) | 0/3 | \|Δ\| is priced on the unleveraged underlying while `dist` is divided by 3x |

And the bound that no contract choice can move: with the gate on, the one approved event still needs a
target **1.41× the ex-ante remaining range** (1109 SPY 1.95×, 1113 SPY SHORT 2.76×, 1116 SPY SHORT
2.91×). `eligibility.py`'s window `[P/|Δ|, 0.5·remRng/1.5]` is empty on 9/9. That is a property of
A's holding period versus a day of option time, not of the strike, and it is why A's own equity legs
missed their intraday targets on 7 of 9 events.

### So, the change I would actually ship

1. The `pick()` diff above (sort key + `move_usd` gate). It is 6 lines, it makes every overlay ticket
   the desk takes satisfy 1.5R **by construction**, and it cannot buy something unbuyable because the
   existing `qty<1` and fee gates still run.
2. Bearish overlay off — `0/3`, and the numbers are not close.
3. Sleeve B stays unbound. One eligible event per two weeks against `expectancy_gate.min_trades_half_size
   = 10` means the gate can never be satisfied inside the contest window; wiring it now would put an
   unmeasurable sleeve into the live account.
4. If the owner wants overlay *volume*, the lever is not in this file: it is the parent's stop width
   and holding time (item 3 of §8), and the honest reclassification is a hedge on \|Δ\|-weighted payoff
   per premium dollar, which needs a `rules.json` edit and drops the 1.5R requirement.


## 10. Regime test: does the gate survive bullish / bearish / sideways tape? (2026-11-21)

Widened the sample from the desk's 9 signals to **every entry the live engine would have printed**
over the whole 38-session bar corpus, then replayed both versions of `pick()` on the 24 option
series already on disk. Scripts: `regime_stage1.py` (bucket + fire `trend_signal.signal()` at
10:05/11:00/12:30/14:00 for SPY/QQQ/SMH), `regime_stage2.py` (both picks, same contract dicts),
`sleeve_b_gated.py` = a copy of the published `sleeve_b.py` with the diff applied. 34 signals fired,
**22 of them have real option bars**.

### First, a correction that the test forced

The gate as I wrote it in §9 (`premium/|delta| > move_usd` → refuse) enforces ratio **>= 1.0, not
>= 1.5**: the ratio is `move / (premium/|delta|)`, so 1.5 needs `pd <= move/1.5`. The stage-2 run
exposed it (it "picked" legs printing R:R 1.02-1.34). Fixed by computing the ratio itself:

```python
rr = abs(c["delta"]) * move_usd / c["premium"] if c["premium"] > 0 else 0.0
if rr < req_ratio:        # req_ratio default 1.5, mirrors trend_signal's `target = price + 1.5*dist`
    trace.append({..., "fate": "ratio_gate", "planned_rr": round(rr, 2)})
    continue
```

Second error, same cause: `move` must be `1.5 x r_unit`, not `|tp - sig_entry|`. The recorded `tp` is
anchored on the **fill** while `sig_entry` is the **signal** price, so mixing them inflated the move
whenever the fill was above the signal (1112 QQQ: 10.98 vs the correct 9.72) and deflated it when the
fill was below (1109 SPY: 5.81 vs 7.51). On the clean anchor **§9's one clearing event drops from
1.71 to 1.51** - it still clears, by 1%.

### Result, by market phase

| tape the trade faced | events | OLD picked | OLD net $ | NEW picked | NEW refusals |
|---|---|---|---|---|---|
| ALIGNED (went its way) | 2 | 0 | - | **0** | 2 ratio_gate |
| ADVERSE (went against) | 9 | 5 | **-1,002.10** (0/5 wins) | **0** | 7 ratio_gate, 2 no-candidate |
| RANGE (sideways) | 11 | 9 | -146.42 (44% win) | **0** | 10 ratio_gate, 1 no-candidate |
| **all** | 22 | 14 | **-1,148.52** | **0** | - |

Session character says the same thing: UP 5 events (OLD -165.50, NEW 0 picks), DOWN 5 (OLD -283.16,
NEW 0), RANGE 12 (OLD -699.86, NEW 0). Ex-ante phase: **the corpus contains no bullish market at all** -
every one of the 38 sessions closed within 0.5% of or below its 20-day mean, so 0 events fall in a
BULL bucket and the bullish case is answered only by the UP/DOWN proxy above.

### What the tape can actually pay

| required ratio | approved of 22 | avg planned ratio | net $ | median shortfall |
|---|---|---|---|---|
| 1.00R | 9 | 1.20 | -739.42 | 1.19x too expensive |
| 1.25R | 2 | 1.34 | +112.84 (2 trades) | 1.49x |
| **1.50R** | **0** | - | 0 | **1.79x** |
| 2.00R | 0 | - | 0 | 2.38x |

### Verdict on the change

* **It is direction-blind and regime-blind by construction**, and that is what makes it safe: the test
  is `premium/|delta|` vs the parent's own target distance, so it behaves identically in a bull, bear or
  chop tape. It never approved a losing leg (0 of the 5 ADVERSE ones) and never crashed - every refusal
  is a clean `fate` record.
* **It is also a near-total veto in this tape.** It refused both events where the trade would have
  worked (ALIGNED 2/2 had their parent target touched, MFE/target 1.20) because a day of index premium
  simply is not available at <= 1/1.5 of these moves. Median contract was **1.79x too expensive** for
  1.5R.
* So: it "still works" in the sense that it does exactly what it claims everywhere it was tested, and it
  would have saved **-1,148.52** against the published order. It does not "work" in the sense of
  producing eligible trades - 0 of 22, in every regime.
* The bullish gap is real and cheap to close: ~10-14 `quote_history_kline` calls against a trending-up
  window (say Aug-Sep 2026) would give the first measured bull-phase sample. Not run yet.

**SUPERSEDED, two paragraphs above and this one:** the claim "the corpus contains no bullish market at
all" was an artifact of `regime_stage1.py`, which skips any session whose 21-day lookback is not
satisfiable inside the bar store - and the store *begins* in the bull window. There are 32 ex-ante BULL
family-sessions in it, and the live engine fires 133 signals in them (§11). The "cheap to close, not run
yet" line is also no longer true: it was run (§11), cost ~500 kline calls, and the measured option
premiums it needed turned out to be unrecoverable for any pre-November date.

## 11. Bull / sideways re-test on dated macro windows (2026-11-21)

Question: does the 1.5R gate change still work outside the November bear tape? Answer: **the gate
behaves identically in every regime (that is its good property), and it approves almost nothing in any
of them (that is its fatal property). The binding constraint is not the regime and not the pricing - it
is the mismatch between the option's expiry horizon and the desk's own holding horizon.**

### What is measured vs modelled

Measured with **real traded premiums**: only 2026-11-02..17. `quote_history_kline` answers for expired
option symbols for roughly 3-4 weeks after expiry, then the security cache drops them (`ret_code=-7`,
`invalid_symbol`, "symbol not found in security cache"), and sleeve B's own DTE 1-5 band means every
contract it could have traded before November is already gone. Verified by direct probe, not inferred.

So bull and sideways are **modelled**, with the model fitted to those November real bars and validated
out-of-sample:

```
sigma_hat    = transfer[fam] x index_vol(day)      VIX for SPY, VXN for QQQ/SMH
(P/delta)_hat = rho[delta bin] x sigma_hat x sqrt(T) x S
transfer 0.812 (SPY) / 0.978 (QQQ) / 2.898 (SMH);  rho 0.551 / 0.635 / 0.764 by delta bin
leave-one-day-out on 848 live-band rows: predicted/real median 1.029, p10 0.719, p90 1.403
```

Why the model is defensible for a *dollars-vs-ratio* question: `P/delta` scales with `sigma sqrt(T) S`
and the usable move scales with `sigma sqrt(T_remaining) S`, so sigma cancels in the ratio and what is
left is geometry. Scripts: `hist_test.py` (gate), `horizon.py` (expiry ladder), `minbias.py`
(model-vs-real correction). Inputs: 5-min bars 2025-09-02..2026-11-20 (`reach3/` + the `bt/` corpus),
`idx/` NDX/SPX/SOX/VIX/VXN dailies - the index dailies are load-bearing because `trend_signal.regime()`
**fails closed** to `bear_high_vol / allow_long=false` on a missing input, which would have silently
vetoed every bull long. Fail-closed rows in this run: **0 of 245**.

### Windows, and what the narrative check did to them

Labels are the desk's own ex-ante rule (close vs the mean of the prior 20 completed sessions, +/-0.5%),
because that is what the desk would have seen. The web check (`MACRO_WINDOWS.md`) corroborates four and
contradicts two:

| window | label | narrative check |
|---|---|---|
| 2025-09-08..10-10 | BULL | corroborated (Fed cut Sep 16-17, shutdown rally to records); the last two sessions are the Oct-10 tariff turn |
| 2025-10-13..10-24 | SIDEWAYS | **contradicted** - a V-recovery to record closes Oct 23-24, max drawdown -0.68% |
| 2026-04-17..06-05 | BULL | corroborated (S&P 7,000 Apr 15 -> 7,600 Jun 2, SOX +69% Apr-May), very high daily vol |
| 2026-07-17..07-31 | SIDEWAYS | corroborated for SPY only; SMH -2.9% with a -14% drawdown |
| 2026-08-03..08-20 | BULL | weakly (SPY +0.65%, all of it on Aug 3-4) |
| 2026-08-21..09-11 | SIDEWAYS | corroborated cleanly (SPY -0.19%, lowest vol in the sample) |
| 2026-10-13..11-17 | BEAR | corroborated (AI-capex unwind, midterms Nov 3, SPY -11.3%) |

Two structural notes the research produced: sideways labels land **right after** shocks because the
20-day mean still contains the pre-shock highs; and a defect in the data path worth remembering - every
`num=370` kline window's *oldest* session is truncated mid-session at 11:15 ET, so reading a day from
one file hands the opening-range rule a 58-bar day. `hist_test.load_hist()` unions bars by `time_key`,
which heals it; one SMH session (2025-09-12) is still missing because that fetch agent hit its 150-turn
cap.

### Result 1 - with today's DTE 1-5 band, the gate is regime-blind and near-total

| tape | signals | best P/delta in band, as a ratio | clears 1.5R (cheap / fit / dear) | parent's own 1.5R target hit intraday |
|---|---|---|---|---|
| BULL | 133 | median 0.59 (p25 0.40, p75 0.80) | 7 / **1** / 0 | 38 / 133 |
| SIDEWAYS | 61 | median 0.65 (p25 0.50, p75 0.87) | 1 / **0** / 0 | 4 / 61 |
| BEAR (modelled) | 51 | median 0.67 (p25 0.47, p75 1.14) | 9 / **3** / 0 | 8 / 51 |
| BEAR (real premiums, 3 matched scans) | 3 | median 0.67 | **0 / 3** | - |

The three regimes are within 0.08R of each other. **4 approvals out of 245 signals** at the fitted
point. And note the bull tape is not silent at the signal layer - 133 signals fire, 38 of them reach
their parent's 1.5R target intraday; the option simply cannot express them. `OLD`'s chosen contract
prints a median ratio of 0.30-0.45 because it minimises *premium*, which selects the longest-dated,
thinnest-delta leg available - the opposite of what the ratio needs.

### Result 2 - the lever is the expiry horizon, not the gate

Holding the stop exactly where the live engine puts it and changing only time-to-expiry (pure `sqrt(T)`
rescale; calibration reproduces `best_pd` at h=1D to 1.000):

| tape | median ratio h=0D | 1D | 2D | 3D | 5D | % clearing 1.5R at h=0D | at h=1D |
|---|---|---|---|---|---|---|---|
| BULL | 1.63 | 0.59 | 0.40 | 0.32 | 0.25 | 60.2% | 3.0% |
| SIDEWAYS | 1.84 | 0.65 | 0.45 | 0.39 | 0.27 | 67.2% | 0.0% |
| BEAR | 2.00 | 0.67 | 0.47 | 0.38 | 0.27 | 72.5% | 11.8% |

Same finding stated as the parent strategy's burden: to satisfy 1.5R at **h=1D** the stop must be
**2.4-2.6x wider** than the engine sets it (a $4.67 stop where it computes $2.03), i.e. the parent has
to make ~1.0% intraday beyond the stop when it actually made 0.45%. At **h=0D** the multiplier is
**0.83x** - no widening at all, slightly narrower than the live stop.

The mechanism is a horizon mismatch the desk creates itself: it buys 1-5 days of theta on a position its
own FLAT rule forbids holding past 15:45 ET. Time you are not allowed to hold is time you should not pay
for, and the ratio is exactly the quantity that punishes it.

### Result 3 - how much to discount Result 2 (`minbias.py`)

Comparing the model against real premiums at the *band minimum* rather than row-wise:

```
row-wise predicted/real P/delta            median 0.856   (the level fit)
dense-grid band-min / real band-min        median 0.828   -> true ratio = 0.83 x modelled ratio
worst cell matched to real scan stamps     0.484          -> true ratio = 0.48 x modelled
```

Correcting Result 2's h=0D pass rates by those two factors: bull 60% -> **44%** (or 12%), sideways
67% -> **53%** (or 16%), bear 72% -> **55%** (or 26%). The relative step from 1D to 0D, ~2.8x, is a
`sqrt(T)` consequence and is unaffected by the level correction, which is the part worth acting on; the
absolute pass rate is only known to lie between roughly 12% and 55%.

A related trap found while measuring this: the min-over-observed-chain statistic is dominated by single
bad cheap prints (a 0.05 premium at delta 0.16 prints a P/delta of 0.31 that nobody could trade), so a
gate scored against a raw chain minimum can be "beaten" by a print. Scoring against the modelled band
is the more honest of the two bad options available.

### Verdict

1. The gate change does **not** survive the regime test as a strategy fix. It is direction- and
   regime-blind by construction (its behaviour is the same in bull, sideways and bear within noise), it
   never approves a leg whose ratio is under requirement, and it never crashes - but at 1.5R with DTE
   1-5 it approves 4 of 245 signals. It converts a losing book into silence.
2. The measured reason the R:R is not met is **expiry horizon**, and that is now quantified in all three
   regimes rather than asserted from November. `dte_min: 1 -> 0` (same-day expiry, aligned to the
   session the signal covers) is the single highest-leverage change: it multiplies the achievable ratio
   ~2.8x with no change to the parent strategy at all, and it removes theta the desk is banned from
   holding.
3. Still undiscoverable, and it must be said plainly: **no real 0DTE premium is retrievable** (never in
   the cache for any historical date, and expired symbols age out), so the 0DTE number rests on the
   `sqrt(T)` model plus a factor known only to 0.48-0.83. `rho` is extrapolated below its fitted 1-5 DTE
   range. Whether moomoo offers 0DTE SPY/QQQ/SMH on the contest account, and their bid/ask depth, are
   unverified. The live probe that would settle it is owner-attended only.
4. Independent of the gate: 69.5% of bull-phase scans refuse on "no confirmed breakout" (median breakout
   margin -0.485 rng). The desk's entry rule is tuned to the November tape; a bullish regime mostly does
   not reach the option layer at all.
