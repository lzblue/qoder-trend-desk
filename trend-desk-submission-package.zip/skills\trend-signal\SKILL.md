---
name: trend-signal
description: Opening-range breakout plus VWAP trend signal and market-regime filter for liquid ETFs (QQQ, SMH, SPY). Takes a few numbers per ticker, returns LONG, SHORT (via inverse ETF) or NONE with entry, stop and target.
---

# trend-signal

One trigger for the whole desk: price must break the first-30-minute range and sit on the same side of VWAP.
Plain Python (stdlib only). It proposes; it never trades. Every proposal still goes through desk-risk-guard.

## Regime (run once pre-market, again at 12:00 if VIX moves more than 3 points)
```
python scripts/trend_signal.py regime --input snapshot.json
```
`snapshot.json` required numeric fields, each sourced natively from a moomoo day-kline using the **double-dot
index format** (a bare `VIX`/`NDX`/`SPX` returns `invalid_symbol`; the index symbol is `US..INDEX`):

| field | source symbol | how to get it |
|---|---|---|
| `vix` | `US..VIX` | last daily close |
| `vxn` | `US..VXN` | last daily close |
| `ndx_close` | `US..NDX` | last daily close |
| `ndx_sma200` | `US..NDX` | mean of the last 200 daily closes |
| `spx_close` | `US..SPX` | last daily close |
| `spx_sma200` | `US..SPX` | mean of the last 200 daily closes |
| `sox_5d_return_pct` | `US..SOX` | `(close_today / close_5_sessions_ago − 1) × 100` |
| `as_of_et` / `now_et` | — | `YYYY-MM-DD`: newest session the numbers are from / today. |

`nasdaq_highs_minus_lows` (new-highs minus new-lows breadth) is **optional**: it is a count, not a quote, so it
has no moomoo price source. Add it only when you have a real number; omit it otherwise — its absence never
degrades the regime, which still computes from the seven fields above.

Output includes `regime`, `size_mult`, `allow_long`, `allow_bearish_etf`, `hedge_mult`, the bear-watch flags
(trend break below the 200-day, VXN over VIX, semis breakdown, breadth, VIX 30+), and `source`. Always show the
flags in the daily brief.

**Fail-closed:** if any required field is missing, non-numeric, out of range, or older than the freshness window
(default 4 calendar days between `as_of_et` and `now_et`; override with `stale_max_days`), `regime()` returns the
conservative `bear_high_vol` bucket (`allow_long=false`, shorts still allowed) with `source: "fail_closed"` and a
`degraded_reasons` list instead of raising. **Never substitute a made-up regime when data is missing — pass the
snapshot as-is and the fallback fires on its own.** Treat `source: "fail_closed"` as a degraded read (a real
`bear_high_vol` prints `source: "computed"`).

## Signal (after 10:00 ET, at most every 30 minutes)
```
python scripts/trend_signal.py signal --input signal_input.json
```
`signal_input.json`: `{"summary":{"ticker":"QQQ","time_et":"10:35","price":..,"vwap":..,"or_high":..,"or_low":..,"inverse_price":<SQQQ last, needed for SHORT>},"regime":<regime output>}`

Get `or_high`/`or_low` from the first six 5-minute bars (09:30-10:00 ET) and `vwap` from the moomoo indicator tools. Send these few numbers only, not whole bar series.

Output `action` is `LONG` (buy the 1x ETF), `SHORT` (buy the 3x inverse ETF: SQQQ for QQQ, SOXS for SMH) or `NONE` with the reason. SPY has no bearish instrument configured right now (SPXS was removed as ineligible), so a SPY breakdown returns `NONE` — report that as the result and do not substitute a fund of your own choosing.
The instrument-level `entry`, `stop` and `target` already account for 3x leverage. Missing data means NONE, never a guess.

## Notes for the auditor
Expect few trades. The edge claim is simple: confirmed breakouts from a normal-sized opening range, with the stop at VWAP/range midpoint and 1.5R target, flat by 15:45 ET. Invalidated if after 20 closed trades the net expectancy (after fees) is negative.
