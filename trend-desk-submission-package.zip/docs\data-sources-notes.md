# Regime-gate data sourcing — moomoo fallback research (2026-11-18, night before SCAN-1100/1230/1400)

## Problem
moomoo MCP returns `invalid_symbol` for VIX, VXN, NDX, SPX — these are index
tickers, not tradable instruments on the paper account — so the regime gate
(VIX/VXN level, SPX/NDX vs 200-day SMA, market breadth) has been permanently
UNVERIFIED for the whole competition window. Researcher has WebFetch/WebSearch
already enabled (Tools tab, Auto-allow) but nothing wires these sources in yet.

## Confirmed, free, no-auth sources (verified live tonight via WebFetch)

- **`https://wallstreetnumbers.com/indexes/{symbol}/moving-average`**
  Gives current index level, 200-day SMA value, and the % the price is
  above/below it, in plain numeric form. Confirmed working for `vix` and
  `spx` (e.g. SPX 200-day SMA = 7,024.11, price -7.62% below it). Same URL
  pattern should work for `ndx` and `vxn` — not yet individually confirmed,
  worth a quick WebFetch check before wiring in.

- **`https://chartrow.com/sp500/market-breadth`**
  Gives % of S&P 500 constituents above 200-day MA, % above 50-day MA, and
  advancers/decliners. Confirmed working. CAVEAT: the page's own timestamps
  disagree with each other (header said "Nov 17, 4:00 PM ET" while the
  advance/decline block said "Nov 17 · live" and the MA chart showed "Nov 16")
  — treat the breadth % as the prior full trading day's close unless a fresher
  per-field timestamp is visible at fetch time, and don't trust the page's own
  "live" label at face value.

## Not yet done
- Confirm NDX and VXN individually on wallstreetnumbers.com (same URL pattern,
  just need one WebFetch each).
- SPX/NDX's own index level vs 200-day SMA is covered above; that's distinct
  from the breadth % of constituents above their own 200-day MAs — both are
  available, just make sure researcher's logic doesn't conflate the two.

## Recommended next step (not started — deliberately deferred)
Wire these into `researcher` as a fallback path: when moomoo returns
`invalid_symbol` for one of VIX/VXN/NDX/SPX, fall back to a WebFetch of the
matching wallstreetnumbers.com page for price-vs-200-SMA, and chartrow.com for
breadth. This is a change to the regime-decision logic itself, not a config
toggle — treat it with the same care as the stop-doctrine fix (draft, verify
against a probe session, confirm it doesn't regress the conservative-default
behavior when a fetch fails) rather than pushing it live same-day as a SCAN
window. Good candidate for tomorrow's first daytime task.
