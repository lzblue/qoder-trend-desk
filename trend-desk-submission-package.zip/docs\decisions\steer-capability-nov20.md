# Steering an in-flight child: what the 'Steer' button mechanically is, and what the mailbox can call

**Verdict: 'Steer' is a real, named capability, but it is a Desktop *queue-management* action, not a
message-delivery action — and it is not reachable from any tool a session can call. The modest
version the owner wants (an amendment landing the instant the child's turn ends) IS reachable today
via `send_message_to_chat_session`, but only from a conversation that is permitted to message that
child — which a stateless cron wake is not. So tonight's blocker is routing authority, not the Steer
button.**

- Task: mailbox item `20261120T041044Z-f82bc0` (Tier A, mailbox/orchestration infrastructure),
  worker session `60a71d03-997a-5ad9-a26b-9fc5279aa3e0`, delegated from wake conversation
  `076e89c7-8901-4f4e-bc8d-232544a09206` ("Mailbox wake check").
- Window: 2026-11-20, ~04:10Z onward (20:10 ET Fri).
- Claim tags: **[documented]** a tool description or official page read this turn, quoted;
  **[observed]** a command I actually ran this turn, with its output; **[inferred]** derived from
  those; **[undiscoverable]** not establishable from what I can reach.
- Safety: read-only throughout. No message sent to, and no stop of, any session; the three live
  children were touched only by `read_chat_session`. No new session created. No cloud write of any
  kind (no template, skill, rules.json, schedule, AUTONOMY_PHASE). No moomoo call at all, nothing
  against `5830104`. No git write. No secret quoted; `.env` referenced by path only.
- This memo is the file I own. Shared files (`CONTRACT.md`, `DRIVER.md`, `plan.mjs`, `mbx.mjs`,
  `check.sh`) were **not** edited; the change I would make is staged in
  `.scratch/steer-f82bc0/` as STAGED, NOT APPLIED.

---

## 1. Which surface the 'Steer' button belongs to

Three different surfaces were conflated in the request. They are not the same system:

| Surface | 'Steer' exists? | Callable by the orchestration? |
|---|---|---|
| **Qoder Desktop app UI** (composer + queue) | yes — documented, and implemented as a named App-layer RPC | **no** — not in any MCP tool schema |
| **Desktop-local chat-session builtin tools** (`send_message_to_chat_session`, `stop_chat_session`, …) | no steer verb; the tool defers to "its normal steering or queueing policy" | yes, but only queue-or-start, and only for a permitted target |
| **Cloud Agents Events API** (`POST …/sessions/{id}/events`) | no `steer` event type at all; `user.message` → 409 while running, `user.interrupt` exists | yes (qca MCP / HTTP), but that is the *cloud* desk, not tonight's children |

The owner's 'Steer' button is the **first** row. Tonight's mailbox children are **Desktop-local chat
sessions** **[observed]** — `list_chat_sessions` returns them with `executionHostLabel:"Local"`,
`runtimeState` in {`running`,`ready`,`cold`} and `sessionRef.authorityEndpointId`
`8c5304e1-8dcb-4148-a426-bef3b7bca5ad`. So the requester's Cloud-Agents premise about the 409 does
**not** transfer; see §4.

## 2. Item 1 — what 'Steer' actually does (mechanically, not by guess)

**2.1 Official behaviour, verbatim** **[documented]**
[https://docs.qoder.com/qoder/conversation-input.md](https://docs.qoder.com/qoder/conversation-input.md),
section "Queue and steer messages":

> | Queue  | Handle another request after the current work | Keeps the message in the pending queue. |
> | Steer  | Correct the direction or add constraints | Delivers input at a safe execution boundary without directly stopping the current run. |
>
> Choose the default under **Settings → General → Input while running**. When steering is supported,
> use `⌘+Enter` on macOS or `Ctrl+Enter` on Windows. Steering is not necessarily immediate. Check
> composer hints when the environment does not support it, context is being compacted, or requests
> are pending. Use the stop button to stop execution.

Section "Manage queued messages" is the decisive sentence: *"Queued messages appear above the
composer. Choose **Steer**, or **Move back to the composer to edit**…"* — i.e. **you steer a
message that is already in the queue.** Steer is a queue→turn transition, not an input channel.
That page is the only place `steer` appears in the whole docs index
**[observed]**: `curl --compressed https://docs.qoder.com/llms.txt` (95,913 bytes) → exactly one hit,
line 77. Occurrence counts on the fetched pages (`grep -o -i steer | wc -l`):
`qoder/conversation-input.md` 8, `cloud-agents/api/sessions/events/send.md` 0,
`cli/cross-session-messaging.md` 0, `cli/sdk/session-control.md` 0. The CLI cross-session path is explicitly
next-turn and approval-gated: *"Approving queues the message for the next turn. Declining drops it…"*
and *"it never interrupts a permission confirmation or a dialog you are part-way through"*
**[documented]** [https://docs.qoder.com/cli/cross-session-messaging.md](https://docs.qoder.com/cli/cross-session-messaging.md).

**2.2 The implementation, from the shipped bundle** **[observed]** —
`C:\Users\tteh\AppData\Local\Programs\Qoder\resources\app.asar` (174,421,893 bytes, mtime Nov 16 20:43),
read with `grep -a -b -o` + `dd` windows. Plain (unobfuscated) chunks give verbatim identifiers:

- The App-layer RPC registry, verbatim:
  `chatSessionControlMethods = { readControl, watchControl, snoozeUserQuestion, dismissSuggestedPrompts,
  editAndResend, mutateQueue, steerQueuedTurn, interruptAndRunQueuedTurn, withdrawQueuedTurn }`,
  each with a capability token, e.g. `steerQueuedTurn:"chatSessions.steerQueuedTurn.v1"`,
  `interruptAndRunQueuedTurn:"chatSessions.interruptAndRunQueuedTurn.v1"`,
  `mutateQueue:"chatSessions.mutateQueue.v1"`; the mutating ones carry scope
  `APPLICATION_SCOPES.chatSessionsSubmit`, and the error set includes
  `APPLICATION_CAPABILITY_UNAVAILABLE`, `CHAT_SESSION_QUEUE_CHANGED`, `CHAT_SESSION_QUEUE_BUSY`.
- The steer result is a typed enum (codec over `steerResultSchema`):
  `{status:["steered","unchanged"]}`; on `steered` → `{activeTurnId, inputId}`; on `unchanged` →
  `reason:["runtime-unsupported","active-turn-ended","waiting-user","queue-changed","control-command"]`.
  A sibling RPC `interruptAndRunQueuedTurn` returns
  `{status:["started","unchanged"], turnId, interruptedTurnId}` /
  `reason:["runtime-unsupported","queue-changed","control-command","source-mismatch"]`.
- The input wire object takes `dispatchMode:["start","steer","queued","batched","replace"]` and
  `inputSource:["composer","peer_control","agent"]`, and an actor-attribution map whose keys include
  `composer, mcp_app, desktop_pet, dynamic_island, remote_control, peer_control, automation, plugin,
  goal, agent, handoff, internal`. **So `steer` is a per-input dispatch mode the platform already
  models for agent-originated input — it simply is not exposed on the tool façade.**
- A per-session capability object (`readAvailableActions`): `canQueueInput`, `canSteerInput`,
  `interruptTurnId`, `cancelStartingTurnId`, `respondableInteractionToolUseIds`,
  `stoppableBackgroundAgentTaskIds`, `stoppableBackgroundProcessTaskIds`, `goalAction`. This is what
  the UI uses to grey the button out.
- The composer's own mode picker: `function RB0(e){ if (e.isRunning && e.allowSubmitWhileRunning &&
  e.steerSubmitEnabled) return "steer" }` — steer is chosen only when those three hold **[observed]**,
  and `steerSubmitEnabled` is the user setting.
- The setting, verbatim UI strings: `defaultInputDispatchMode:"Input while running"`,
  `defaultInputDispatchModeDescription:"Choose whether new input from the main composer or desktop
  pet waits in the queue or steers the active turn."`, `…Queued:"Queue"`, `…Steer:"Steer"`.
  Note the scope it states: **"from the main composer or desktop pet"** — tool-driven input is not in
  that sentence **[documented/observed]**.
- The refusal tooltips, verbatim, which are the operational rules:
  `steerTip:"Send to the Agent at the next safe execution boundary without stopping the current run;
  while running, press {{shortcut}} in the composer to steer directly"`,
  `steerUnsupportedTip:"This runtime does not support steering; the message will stay queued"`,
  `steerWaitingTip:"Respond to the Agent's pending request before steering"`,
  `steerInactiveTip:"There is no running turn; the message will stay queued"`,
  `steerControlCommandTip:"Context compression runs after the current turn and cannot steer into it"`,
  `sendNowTip:"Move to the front of the queue and run next"`.

**2.3 So, in one sentence** **[inferred from 2.1+2.2]**: 'Steer' asks the runtime to admit an
*already-queued* input into the *active* turn at the next safe execution boundary (a tool-call
boundary inside the turn), without stopping that turn; it can be refused for five concrete reasons,
and when refused the message simply stays queued.

## 3. The Cloud Agents half of the premise — checked, and correct, for the cloud only

**[documented]** [https://docs.qoder.com/cloud-agents/api/sessions/events/send.md](https://docs.qoder.com/cloud-agents/api/sessions/events/send.md):

> While a Session is `running` or `rescheduling`, a new `user.message` is **not queued behind the
> current turn** and returns `409`. Wait for `session.status_idle`, or cancel the current turn first:
> `"Session is currently processing a turn. Cancel the current turn or wait for completion."`

and the error table row: `409 | invalid_request_error | Session is currently processing a turn, or
other Session state conflict`. Supported event types there include **`user.interrupt`** (no payload,
optional `session_thread_id`) and **`system.message`** (at most one per request, must be last).
The Forward variant agrees: `409 invalid_request_error — The current Session is processing a Turn and
cannot start a new Turn yet`
**[documented]** [https://docs.qoder.com/cloud-agents/api/forward/sessions/send-events.md](https://docs.qoder.com/cloud-agents/api/forward/sessions/send-events.md).

So the requester's finding is accurate **as written**: the documented Cloud API has no mid-turn
injection — `user.message` is rejected outright (not queued), and the only in-flight levers are
`user.interrupt` (destroy the turn), `user.tool_confirmation` (`allow` / `deny` + `deny_message`),
and `user.tool_result`. The qca MCP façade confirms the same set **[observed]**:
`mcp_get mcp__qca__send_session_events` → events oneOf `user.message | user.interrupt |
user.tool_confirmation | user.tool_result | user.custom_tool_result | user.define_outcome | system.message`.
There is **no `steer`** event type in the cloud schema — the word appears nowhere in it.

What the request got wrong (or rather, what it risked over-generalising): none of this applies to
tonight's mailbox children, which are Desktop-local sessions with a real pending-input queue
(**[observed]** `read_chat_session` returns `queuedTurnCount`, which the cloud API has no analogue
for). The two surfaces must be documented separately, which is what §7 does.

## 4. Item 2 — what the orchestration can actually call

Evidence, all read this turn:

1. `mcp_list({keyword:"steer"})` → `{"tools":[],"total":0}`. `mcp_list({keyword:"interrupt queue input message"})`
   → 20 hits, none a steer verb. **[observed]**
2. `mcp_get mcp__builtin__send_message_to_chat_session` → `properties: {sessionId, sessionRef,
   prompt, attachments, callbackMode}`; `required: [sessionId, prompt]`. **There is no `dispatchMode`,
   no `mode`, no `steer`, no `queue` field.** The façade cannot ask for steer even in principle. **[observed]**
3. The same tool's description contains the only statement of policy: *"If the target is running, its
   normal steering or queueing policy applies."* **[documented]** — it defers, and names no default.
4. What "normal policy" resolves to, from the bundle: the submit router calls a decision function with
   `{activeTurnState, requestedMode, supportsSteer, hasPendingInteraction, controlInput}` and returns
   either `{inputId, disposition, turnId}` or `{inputId, disposition, queuedTurnId, fallbackReason}`
   **[observed, strings obfuscated]**. `requestedMode` is `dispatchMode`, which the tool never sets.
   Therefore a tool-driven input to a **running** target is admitted as a *queued* turn, and only the
   composer path can select `steer` — the three-term guard
   `isRunning && allowSubmitWhileRunning && steerSubmitEnabled` is composer UI code.
   **[inferred]**, and it is the one claim here I would most like a write-test to confirm (§6).
5. Detectability is better than expected — **[observed]**, read-only against live child
   `1d76dc2b-81c4-56d0-a4db-24d2da929072`:
   `{"runtimeState":"running","activeTurnId":"aa0ccf8e-e2d4-5264-ab07-452296f03a5e","queuedTurnCount":0,
   "pendingInteractionCount":0,"backgroundAgentCount":0,"backgroundProcessCount":0,"revision":38}`.
   A wake can therefore tell *running vs idle*, *how many inputs are already waiting*, and *whether the
   child is blocked on a human* — exactly the three facts the steer tooltips key off. What it cannot see
   is `canSteerInput`: `list_chat_sessions` returns only `sessionId, sessionRef, executionHostLabel,
   title, cwd, updatedAt, runtimeState, pendingInteractionCount, archived, unread` **[observed]**, and
   the steer-result reason enum is never surfaced by any tool.

**Answer to item 2, in two halves.**
- *Modest version (queue now, land at the boundary):* **achievable, no new capability needed** —
  `send_message_to_chat_session` against a running child is accepted, not 409'd, and lands at a turn
  boundary. The gate is not the platform, it is *who is allowed to send* (§5).
- *Full version (inject mid-turn, i.e. what the button does):* **not achievable** from any surface a
  session can call. It lives on `chatSessions.steerQueuedTurn.v1`, an App-layer method with a submit
  scope and no tool façade. Forcing it would mean driving the app's private IPC from outside the
  supported surface — I did not investigate that and do not recommend it (see conflict control and
  §6). The only tool-callable mid-turn redirection is destructive: `stop_chat_session` —
  *"Interrupts any active turn and cancels queued inputs"*, returning `canceled | interrupted | idle`
  **[documented]** — then send. Cost: the turn's uncommitted work and any queued inputs are dropped,
  and the child resumes cold from the new prompt. That is a *re-dispatch with extra steps*, not a steer.

## 5. The reframing I was told to test, and it holds

Two structural facts, both worth more than any wiring:

1. **A delegated turn's messaging authority is scoped.** **[documented]**
   `mcp_get mcp__builtin__create_chat_session` → *"During a delegated turn, follow-up messages may go
   only to conversations created in that same turn, or back to its initiating or root conversation."*
   Tonight's wake dispatches children and then **its turn ends** — that is the whole design of
   `CRON_PROMPT.txt` and of CONTRACT rule 4a, and `docs/decisions/wake-delegation-nov20.md` measured
   it (each tick is its own conversation; 7 children were `running` across ticks at 03:47Z). So the
   tick-N wake is messaging children created on tick N−1, which the rule does not permit. **If that
   rule is enforced, no amendment routing added to `check.sh`/`plan.mjs` can ever work from the wake —
   the requester's suspicion is right, and it is a structural limit, not a missing branch.**
   Enforcement itself is **[undiscoverable]** tonight: testing it means a write to a child I am
   forbidden to touch, or creating a session, which I am also forbidden to do.
2. **The rule is stated unevenly, which is why I flag it rather than rely on it.** The *send* façade
   carries no such sentence; the *stop* façade says the target must be *"a session you previously
   created or are supervising"* **[documented]** — a wider grant ("previously", "supervising") than
   "created in that same turn". The wire schema has the machinery to enforce either: agent-originated
   input must carry `inputProvenance` (`action` ∈ create|send, validated against `newSession`) plus
   `inheritSourceContext` **[observed]**. So the host has the provenance it needs to decide. Whether it
   does, and how strictly, is the first thing to measure when writes are allowed (§6).

The consequence for the design: **the router must live in a conversation that created the children and
is still inside its turn.** That is the missing component, and it is an orchestration-shape change, not
a patch to a script.

## 6. Design: where the amendment path would attach (staged, not applied)

Nothing in `.scratch/mailbox/` was edited. Staged in `.scratch/steer-f82bc0/` with before-sha256 of the
target files and the exact apply command:

- `plan.mjs` gains one **read-only** line type, `amend:` — it can print a routing verdict but must not
  act, because plan.mjs's own header is explicit that the component deciding who works must be unable
  to work, and a script has no session tools. The block keys off what `plan.mjs` already has: the ack
  for `reply_to` → its `session_id` (the live child) → so an `ask`/`notify` whose `reply_to` names a
  non-terminal spawn claim is *not* a wake-inline reply. Today that case falls through `plan.mjs:71-73`
  (`reply: … bookkeeping only, this wake may answer it inline`) and is answered by the wrong party.
- `amend.mjs` — a new helper (new file, so no shared-file conflict): given an inbox id, resolve
  `reply_to` → `acks/<reply_to>.json` → `session_id` + ack status, and print exactly one of
  `route-to-child <session_id> running|idle|blocked-on-human|gone` or `no-live-child`. It reads files
  only. It is the part that *can* be trusted; the delivery stays with a session.
- The delivery step has to be a **persistent dispatcher**, and this is the real proposal:
  1. One long-lived conversation per batch (not the cron tick) creates each child with
     `callbackMode:"supervise"`, which is documented to call back exactly when a child "needs a
     permission decision or asks a question, or completes its turn".
  2. That conversation stays in-turn across the batch using `wait_chat_sessions` (≤8 targets, ≤60s per
     call) as the pump, and on each wake runs `node .scratch/mailbox/amend.mjs`.
  3. Amendments it finds are delivered with `send_message_to_chat_session` from *that* conversation —
     the one place the same-turn rule is satisfied.
  4. `pendingInteractionCount > 0` is the case that today silently needs a human: per
     `steerWaitingTip`, steering is refused until the pending request is answered, and the only
     programmatic answer is `respond_chat_session_interaction`, which needs the `interactionRef` that
     **only supervise callbacks produce**. Children dispatched by a tick that ends are therefore
     unreachable while blocked. This is the highest-value piece of the finding: the fix is
     `callbackMode:"supervise"` + a supervisor that outlives the dispatch, and it buys both the
     unblock path and the queue path.
- **Do not** add mid-turn injection, and do not attempt the private IPC. If a correction genuinely must
  interrupt, `stop_chat_session` + re-dispatch is the supported route, with its cost stated to the
  child ("your previous turn was interrupted; re-read your workspace").
- **Holder and conflict check before staging** **[observed]** — `acks/20261120T030605Z-9c417b.json`
  (`done` 04:08:12Z, session `f144c7da-…`) lists `.scratch/mailbox/plan.mjs` in `files_changed`, so that
  is the author to ask. `plan.mjs` still hashes `30e0fe09b6a6a4b5…`, 6,652 bytes, so the staged anchor is
  current. Separately, `acks/20261120T040303Z-91c5de.json` is an `accepted` **serial** claim at 05:29:47Z
  with `session_id:null` that quotes `plan.mjs` in its claim text — a possible next writer; noted in the
  staging README rather than ignored.
- **Tested, on a fixture root rather than the live mailbox** **[observed]** —
  `node apply.mjs --check` → `anchor OK (1/1)`, live file untouched (re-verified by sha afterwards).
  Baseline `plan.mjs` on a fixture where an `ask`'s `reply_to` names an open claim prints
  `reply: … bookkeeping only, this wake may answer it inline` — i.e. the wrong party is authorised, which
  is the bug reproduced. The patched copy prints
  `amend: … child=sess-synthetic-child-… do NOT answer inline; hand to the dispatcher that created that
  child`, and falls back to the old `reply:` line for the two negatives (`reply_to` → a `done` ack;
  `reply_to` → a claim with no `session_id`). `amend.mjs` classifies all four cases
  (`child-live` / `child-done` / `claimed-without-session` / no-claim) and against the **live** mailbox it
  correctly reported `amend: none - no inbox item names a live child`. 3/3 routing assertions pass.
- Verification I could not run tonight, and what it costs: one throwaway conversation (model `efficient`)
  to test (a) whether a wake may send to a child created on a previous tick, (b) whether a send to a
  `running` child increments `queuedTurnCount` (read-back is free), (c) whether the queued input is then
  steerable only from the UI. Each is a write; each is one cheap session. Worth scheduling for a
  non-desk night, not for tonight.
- I did **not** append to `DRIVER.md` even though the brief permits one append-only block: §9 of it
  already routes defects via `reply_to`, the memo is the durable record, and a second writer into a
  shared file on a night with known double-write damage is the wrong trade. The one line I would add is
  quoted in `.scratch/steer-f82bc0/README.md` for whoever holds the file.

## 7. Item 4 — the capability record for future dispatches

Copy-into-a-brief version:

> **Steering an in-flight child: NOT AVAILABLE to a worker/wake.** `send_message_to_chat_session` has
> no steer argument **[documented, schema read 2026-11-20]**; a message to a `running` Desktop child is
> accepted and **queued to land at the next turn boundary**, it does not interrupt the turn
> **[inferred from the bundle's dispatch router; unverified by a write]**. There is no mid-turn
> injection surface for a session to call. To a **blocked** child (`pendingInteractionCount > 0`) there
> is no programmatic path at all unless the sender created that child under `callbackMode:"supervise"`
> and still holds the `interactionRef`. Cloud Agents is a different rulebook: a `user.message` to a
> `running` session returns **409, and is not queued** — use `user.interrupt` (destroys the turn) or
> wait for `session.status_idle` **[documented]**. Detect state read-only with `read_chat_session`
> (`runtimeState`, `activeTurnId`, `queuedTurnCount`, `pendingInteractionCount`). **Corrections to a
> running child therefore go by file + next boundary, or by stop-and-redispatch — never by pretending a
> steer call exists.**

## 8. Appendix — the commands that produced the above

```bash
# docs
curl -s --compressed https://docs.qoder.com/llms.txt            # 95,913 B; 'steer' at line 77 only
curl -s --compressed https://docs.qoder.com/qoder/conversation-input.md      # 6,002 B, §"Queue and steer"
curl -s --compressed https://docs.qoder.com/cloud-agents/api/sessions/events/send.md          # 10,762 B, 409 at :226
curl -s --compressed https://docs.qoder.com/cloud-agents/api/forward/sessions/send-events.md  # 8,056 B
curl -s --compressed https://docs.qoder.com/cli/cross-session-messaging.md                    # 12,023 B, next-turn + approval

# app bundle (read-only)
ls -la .../Qoder/resources/app.asar                              # 174,421,893 B
grep -a -b -o -i "steer" app.asar | wc -l                      # 259 occurrences (on 53 lines — -c counts lines)
grep -a -o "steerQueuedTurn" app.asar | wc -l                  # 29 occurrences of the RPC/capability name
grep -a -o -E "[a-zA-Z]{2,20}\.steer[a-zA-Z]{0,20}" app.asar   # chatSessions.steerQueuedTurn etc.
dd if=app.asar bs=1 skip=61972900 count=2900 | tr -cd '\11\12\15\40-\176'   # RPC registry + enums
dd if=app.asar bs=1 skip=73930468 count=1400 …                   # defaultInputDispatchMode ("Input while running")
dd if=app.asar bs=1 skip=91799853 count=…                        # RB0(): isRunning && allowSubmitWhileRunning && steerSubmitEnabled
dd if=app.asar bs=1 skip=81214900 count=2900 …                   # readAvailableActions: canSteerInput / canQueueInput

# tools, read-only
mcp_list {keyword:"steer"}                                        # -> total 0
mcp_get  mcp__builtin__{send_message_to_chat_session,read_chat_session,stop_chat_session,
           list_chat_sessions,wait_chat_sessions,create_chat_session,respond_chat_session_interaction}
mcp_get  mcp__qca__send_session_events                            # event-type union, no steer
mcp_call mcp__builtin__list_chat_sessions {limit:50}              # children are Local, running/ready/cold
mcp_call mcp__builtin__read_chat_session {sessionId:"1d76dc2b-…",turnLimit:1}   # queuedTurnCount 0, activeTurnId present
```

Not run and deliberately excluded: any `send_message_to_chat_session`, any `stop_chat_session`, any
`create_chat_session`/`fork_chat_session`, any `sim_trade_*`/`account_*`, any cloud POST/PUT/DELETE.

## 9. What this memo does not establish

- Whether the same-turn/root-only messaging rule is **enforced** or merely prompted — needs one write
  test that tonight's limits forbid (§5.1, §6).
- Whether a tool-sent message to a running child ever resolves to `steer` rather than `queued`: the
  decision function's string constants live in an obfuscated chunk I did not decode. The composer-only
  guard is real, but "the tool path is never steer" is an inference, not a read.
- Whether steering works for `runtimeState:"cold"` and `"ready"` sessions at all — the tooltips say the
  refusal reason is `active-turn-ended` / "no running turn; the message will stay queued", which
  implies queue-not-fail, but no non-`running` child was probed.
- Whether the cloud `system.message` event reaches a running turn as a soft injection — the docs bind
  it to "the final event of the batch" alongside a `user.message`, which the same page says is refused
  while `running`; I read the rule, I did not test it, and it is the wrong surface for these children.
- One sample: `queuedTurnCount:0` on one running child proves the field exists, not that queueing
  happens for tool input. That is exactly the §6 test.
