# Tier B decision memo — tradable ticker universe expansion

**Status: proposal only. Nothing was applied.** No rules.json edit, no skill publish, no template write or
re-pin, no schedule change, no order or account action on 5830104. Every cloud call made for this memo was a
`GET`; every moomoo call was a quote-side read (`quote_market_snapshot`, `quote_stock_basicinfo`,
`quote_history_kline`). The paired apply script is a draft that has never been run
(`.scratch/t20-5e8c3a/proposal/apply-universe-draft.sh`).

- Task: `20261119T235025Z-5e8c3a` (mailbox wake, Tier B memo) · written 2026-11-20 · live reads 00:09–00:47Z,
  offline verification runs 00:52–01:05Z (no network)
- Requested deliverable name in the payload was `docs/decisions/ticker-expansion.md`; the spawn instruction
  named `ticker-universe-nov20.md`. This file is the instructed path; treat the two as the same document.
- Claim tags used throughout: **[documented]** = written in a file in this repo or an official page I read;
  **[observed]** = something I read from a live system this session; **[undiscoverable]** = not knowable from
  what I can reach.

---

## 0. Bottom line

1. **Blocker (a) — "ERY/GLL configured as 2x when they are actually 3x" — is not a live gap, and as stated it
   is inverted.** Live `rules.json` contains no ERY and no GLL at all, and its `leverage` map holds only 3×
   values. The 2× numbers live in a *local backtest fixture*, and they are **correct**: ERY and GLL are both
   −2× funds. Acting on the reported "fix to 3×" would have introduced a 1.5× over-sizing bug in the stop math.
2. **Blocker (b) — "none of the 12 symbols exist in rules.json's universe" — is partly real but mis-shaped.**
   IWM *is* in the live `universe.shares`, and it is still untradeable, for a reason that has nothing to do with
   rules.json. The other candidates are genuinely absent, but adding them to rules.json changes nothing.
3. **The real gate is three hardcoded ticker tables sitting in three published skills
   (`trend_signal.PAIRS`, `chop.INVERSE`, desk-risk-guard's `references/rules.json`) plus two prompt sentences —
   five artifacts, two of which must ship as new skill versions now (desk-risk-guard, trend-signal) and a third if
   Sleeve C follows.** Expanding the universe is a multi-artifact release, not
   a config edit. **Yes, a new trend-signal version is required** (its `PAIRS` table is inside the published
   bytes), and a matching vwap-chop version if Sleeve C is to follow.
4. **A bigger eligibility exposure surfaced while checking the candidates: `SPXS`, already live and already in
   the engine's short leg for SPY, has net assets of $322.7M** — below the [documented] "market cap under $500M
   is not eligible" bar [docs/contest-rules-notes.md:42-43]. Every *new* candidate bearish vehicle is also below
   it (SRTY $75.7M, ERY $50.3M, GLL $93.2M, FAZ $94.1M, TZA $197.6M, TMV $200.2M, SDOW $160.9M, TBT $267.5M,
   EPV $10.2M); of the bear vehicles only the two already-live SQQQ ($1.76B) and SOXS ($1.36B) clear the bar.
   This question outranks universe expansion, because it can invalidate trades the desk has already made.
5. **Recommendation: do not expand the universe inside this contest window** (last tradable day likely Fri
   27 Nov). Resolve the eligibility question first, then measure the incremental-ticket value with a 6-ticker
   replay, then ship — if at all — as one atomic 5-artifact release in a change slot *before* the next window.

---

## 1. Live state used for this memo (and proof the local dumps are that state)

| artifact | id | live `latest_version` | `updated_at` (Z) | bytes verified this session | sha256 of the file I read |
|---|---|---|---|---|---|
| desk-risk-guard | `skill_00vqwa9tq5szk3y13lg4` | `1795100050849622` | 2026-11-19T14:54:10.869882 | downloaded 00:09Z, unpacked | `guard.py` `8fe26118…25d5` · `rules.json` `49dbeaf4…fff4b` |
| trend-signal | `skill_00vqvkdtlzojk2xg1rku` | `1795047415929677` | 2026-11-19T00:16:55.945 | downloaded 00:09Z | `trend_signal.py` `60d5573d…bed8` |
| vwap-chop | `skill_00vz0dq461mv4e5iv1p3` | `1795095917868411` | 2026-11-19T13:45:17.906 | downloaded 00:39Z | `chop.py` `43810bd7…72e9` |
| decision-journal | `skill_00vqvbzcimznkggtyd1t` | `1795094895883552` | 2026-11-19T13:28:15.904 | not read (not relevant) | — |
| option-adapter | `skill_00w0ip0yri8sgag736ks` | `1795134420311970` | 2026-11-20T00:27:00.331 | metadata only | — |

- The number in the task spec (desk-risk-guard `1795100050849622`) **was still current when I re-read
  `GET /forward/skills` at 00:38Z** [observed], matching the spec's own 23:57Z reading [documented] and the
  `updated_at` of 2026-11-19T14:54:10Z. I did not rely on AGENTS.md.
- Byte-match proof for the dumps I analysed: `diff` of the live-downloaded `chop.py` against
  `.scratch/livestate-1120/vwap-chop/vwap-chop/scripts/chop.py` → **identical**; `rules.json` and `guard.py`
  hashes above are the hashes of files unpacked from the live-published zips, and they equal the
  `.scratch/livestate-1120/…` copies. So every line reference in this memo is a live line reference.
- Template pins read 00:30–00:31Z (four full template dumps) and 00:41Z (the five-template listing) [observed];
  the API reports `updated_at` in +08:00, so UTC is shown in the table below:

| template | id | last written | pinned skills |
|---|---|---|---|
| researcher | `tmpl_d7df3829ed5d73548bb5e9ed` | 2026-11-19T14:56:08Z | desk-risk-guard@1795100050849622 · trend-signal@1795047415929677 · decision-journal@1795094895883552 · vwap-chop@1795095917868411 |
| risk_auditor | `tmpl_bf2c477c0fba1a3363833f91` | 2026-11-19T14:55:21Z | desk-risk-guard · decision-journal · vwap-chop (same versions) |
| executor | `tmpl_6c3c42cc4500efcbd6d60309` | 2026-11-19T14:55:21Z | decision-journal · desk-risk-guard · vwap-chop (same versions) |
| coordinator | `tmpl_19f984c8f0fd516965b63998` | 2026-11-19T14:05:04Z | none (0 skill bindings) |
| executor-gating-rehearsal | `tmpl_f3214189de633d9d34ce77b6` | **2026-11-20T00:31:29Z** | 2 bindings, incl. **option-adapter@1795134420311970** |

- Concurrency note, because it changes what "live" means: `option-adapter` was created 2026-11-19T23:54:09Z and
  re-published at 00:27:00Z, and the rehearsal template was written at 00:31:29Z — i.e. **another session was
  actively shipping while I worked**. Nothing in the four production templates moved. Every claim below is
  anchored to the five version numbers in this table, not to "latest".

---

## 2. Blocker (a): the ERY/GLL leverage claim — verdict: not live, and the diagnosis is backwards

**What is actually in live config [observed, live bytes `49dbeaf4…fff4b`]:**

```json
"shares":            ["SPY","QQQ","IWM","SMH","TQQQ","SQQQ","SOXL","SOXS","SPXS"],
"option_underlyings":["SPY","QQQ","IWM","SMH","XSP"],
"leverage":          {"TQQQ":3,"SQQQ":3,"SOXL":3,"SOXS":3,"SPXS":3}
```

Live desk-risk-guard contains ten tradable symbol literals in total — SPY QQQ IWM SMH TQQQ SQQQ SOXL SOXS SPXS
XSP — of which **five** carry a leverage entry, and every one of those five is 3. **There is no `2` anywhere in
the live leverage map, and there is no ERY or GLL key to correct.** Blocker (a) as reported is describing a file
that is not live.

A grep over every `.py`/`.json`/`.md` in the live package (run 00:57Z, re-run 01:10Z) is what makes that
airtight. Enumerating all 2–5 character uppercase tokens returns, besides ordinary prose and constants
(`NAV DTE LIMIT LONG SHORT SIMULATE UTC JSON PAIRS BOUNDS FAIL…`), exactly the ten tradable symbols above plus the
five regime index symbols `VIX VXN NDX SPX SOX`. The only other ticker-shaped tokens are event-note company names
in `calendar_rules.py:18-53` — `NVDA TGT LOW ANT WMT INTU ROST` — which are text, not config. **DIA XLF XLE TLT
GLD SRTY SDOW FAZ TZA ERY GLL TMV TBT EPV appear zero times**, so all fourteen are absent from desk-risk-guard
entirely. IWM is the exception the enumeration makes visible: it is the only candidate with live presence (2 hits:
`shares` and `option_underlyings`), which is exactly why §3 puts it in a different category from the rest.

**Where the "2x" numbers really come from [documented, local only]:**
`.scratch/fixb/dv2-before.py:46-52` (mirrored in `.scratch/bt-regime-1120/desk_sleeves_v2_VENDORED.py` and
`.scratch/fixb/dte-test/fixtures/dv2.py`) holds a backtest fixture:

```python
CANDIDATES = {"IWM":("TZA",3,"US_EQUITY"), "DIA":("SDOW",3,…), "XLF":("FAZ",3,…),
              "XLE":("ERY",2,"ENERGY"),    "TLT":("TMV",3,"RATES"), "GLD":("GLL",2,"GOLD")}
```

The fixture's `2` values are **right**. The report that called them wrong is the error
[documented-as-false: `docs/sleeve-b-findings-nov19.md:29` says "ERY/GLL are 2x leverage not 3x as assumed" —
that sentence has the polarity inverted; the underlying assumption being corrected was in the fixture, and the
fixture was already correct].

**Truth of the two ratios, three independent ways:**

1. Names from live quote reads [observed — kline `name`/`sc_name` at 00:44–00:46Z this session;
   `quote_stock_basicinfo` names earlier in the same task]:
   `US.ERY` → "Direxion Daily Energy Bear **2X** Shares" / `2倍做空能源ETF-Direxion`;
   `US.GLL` → "ProShares UltraShort Gold" / `2倍做空黄金ETF-ProShares` ("2倍" = 2×).
2. Measured daily-return ratios, 6 completed sessions to 2026-11-19, forward-adjusted klines
   [observed, reproducible: `quote_history_kline` `ktype=2 num=6 end=2026-11-19`]:

   | date | XLE % | ERY % | ERY/XLE | GLD % | GLL % | GLL/GLD |
   |---|---|---|---|---|---|---|
   | Nov 12 | +1.5149 | −2.8441 | −1.88 | −2.8151 | +5.5371 | −1.97 |
   | Nov 13 | +0.9793 | −1.7564 | −1.79 | +0.1578 | −0.0700 | −0.44 (noise: 0.16% underlying move) |
   | Nov 16 | −1.9550 | +3.6949 | −1.89 | −0.7090 | +1.4001 | −1.98 |
   | Nov 17 | −0.5181 | +1.2644 | −2.44 | −0.1275 | +0.2416 | −1.90 |
   | Nov 18 | −3.2670 | +6.4699 | **−1.98** | −3.2030 | +6.4394 | **−2.01** |
   | Nov 19 | −0.6526 | +1.2793 | −1.96 | −1.7615 | +3.5264 | −2.00 |

   On the two large-move days — where a 2× vs 3× mistake cannot hide inside rounding — ERY delivered 1.98× the
   inverse of XLE and GLL 2.01× the inverse of GLD. A 3× fund would have printed ≈+9.8% and ≈+9.6%. It didn't.
3. Public fund descriptions [documented, external]: ERY listed as "Bear 2X / −2.00", GLL as "UltraShort Gold,
   inverse 2x / −2.00" ([thebalancemoney list](https://www.thebalancemoney.com/list-of-inverse-and-leveraged-commodity-etfs-1214759),
   [fourpercentrule geared table](https://www.fourpercentrule.com/etfs/browse/geared),
   [Nasdaq Dorsey Wright 2X tag](https://www.chartlogs.com/)).

**Why the direction of the error matters.** If ERY/GLL were ever added with `3`:

- `trend_signal.py:195-196` turns an underlying-level stop distance into instrument levels —
  `inst_stop = entry*(1 - lev*pct)`, `inst_target = entry*(1 + lev*1.5*pct)`. With `lev=3` on a 2× fund the
  recorded stop and target are **1.5× too far out**, so the ticket's risk per share is understated against the
  real protection level (and, since protection is *monitored* rather than resting, the error is never corrected
  by the broker).
- `guard.py:213-214` books effective gross as `market_value × leverage`; a 3 recorded for a 2 over-states gross
  and shrinks `q_gross`, so that direction is fail-safe on the aggregate cap while being unsafe on the levels.
- `docs/sleeve-b-findings-nov19.md:29`'s proposed fix therefore had to be checked, not applied.

**Method caveat I am flagging rather than hiding:** moomoo's static name/label table is known to be wrong at
least once in this project's records (EDZ labelled "EM Bear 3X" — see project memory on the moomoo connector),
which is why I did not stop at the name strings and ran the regression instead. For the five leverage entries
that *are* live, name and value agree (SPXS/SQQQ/SOXS/SDOW-style "UltraPro"/"Bear 3X"/"3倍" naming, value 3)
[observed], and SPXS/SQQQ/SOXS are additionally exercised by the engine every day the desk trades a bearish idea.

---

## 3. Blocker (b): missing universe entries — verdict: real for the absent names, irrelevant for IWM, and not a rules.json problem

- `universe.shares` **already contains IWM** [observed, live bytes]. So "none of the 12 symbols exist" is false
  for one of them, and IWM's untradeability has a different cause (next bullet).
- The universe list is a **veto list, not a generator**. `guard.py:188` only rejects a ticket whose ticker is
  absent (`"{ticker} not in the approved share universe"`). It never proposes one. The symbols the desk can act
  on are produced upstream by two tables that no rules.json key reaches:

```python
# trend-signal (live 1795047415929677) trend_signal.py:18-22  — gate at :153-155
PAIRS = {"QQQ":{"long":"QQQ","short":"SQQQ","lev":3},
         "SMH":{"long":"SMH","short":"SOXS","lev":3},
         "SPY":{"long":"SPY","short":"SPXS","lev":3}}
if t not in PAIRS: return {"action":"NONE","reason": f"{t} not a signal ticker"}

# vwap-chop (live 1795095917868411) chop.py:28-29 — gate at :77-78
INVERSE = {"QQQ":("SQQQ",3), "SPY":("SPXS",3), "SMH":("SOXS",3)}
if ticker not in INVERSE: return none(f"{ticker} not a Sleeve C ticker")
```

- The mirror image of the reported gap: **three live universe entries are unreachable today — IWM, TQQQ, SOXL.**
  Nothing in either engine emits them. `leverage` even carries TQQQ and SOXL at 3, which is correct but unused.
- vwap-chop's own published description says it in prose, too [observed, live skill metadata]:
  "Sleeve C VWAP-fade signal **for QQQ, SMH and SPY**".

---

## 4. What "expanding the universe" actually requires — 5 artifacts, 2 skill publishes (3 if Sleeve C follows)

| # | artifact | live location | change | release action | blast radius |
|---|---|---|---|---|---|
| 1 | `universe.shares` + `universe.leverage` | desk-risk-guard `references/rules.json` (`49dbeaf4…`) | add each candidate **and** its bear vehicle to `shares`; add the vehicle to `leverage` with its true ratio | **new desk-risk-guard version** (multipart POST; versions can only be superseded, never un-published) + re-pin on **3 templates** (researcher, risk_auditor, executor) | guard's veto + every size cap |
| 2 | `PAIRS` | trend-signal `trend_signal.py:18-22` (`60d5573d…`) | one key per signal ticker: `{long, short, lev}` | **new trend-signal version** + re-pin researcher (the only template that binds it) | which tickets exist at all; stop/target conversion at `:195-196` |
| 3 | `INVERSE` / `FAMILY` | vwap-chop `chop.py:28-29` (`43810bd7…`) | same keys again, for Sleeve C | **new vwap-chop version** + re-pin on **3 templates** | Sleeve C coverage; instrument levels at `:127-132` |
| 4 | researcher SCAN step 1 | `tmpl_d7df3829ed5d73548bb5e9ed`, field `system` | the sentence is a literal scanner list: "For **QQQ, SMH, SPY**: get price, VWAP, and the high and low of the first six 5-minute bars" [observed, live template read 00:30Z] | template `POST /api/v1/forward/templates/{id}` (prompt text) | which symbols the researcher even quotes |
| 5 | coordinator strategy line | `tmpl_19f984c8f0fd56…` (`tmpl_19f984c8f0fd516965b63998`) | "confirmed opening-range breakouts on **QQQ, SMH and SPY** that agree with VWAP" [observed] | template `POST` | the doctrine the auditor reasons from |

Publishing a skill version is `POST /api/v1/forward/skills/{id}/versions` with form field **`files`** — either one
zip or a bare file tree, exactly one top-level directory whose name comes from `SKILL.md` `name`, ≤50 MB; the
legacy singular `file` field is not accepted and omitting `files` returns 400 [documented,
`docs.qoder.com/cloud-agents/api/forward/skills/versions/create.md`, read 00:50Z]. The generated `version` is a
16-digit Unix-microsecond timestamp and `latest_version` moves to it, which is why every binding must be re-pinned
rather than left to resolve "latest".

**Direct answer to the payload's question: yes — a new trend-signal version must ship.** There is no
configuration-only path. And because items 1, 2 and 3 are three copies of one mapping held in two different
published skills plus the prompts, they must ship as **one atomic set**: any intermediate state is a desk that
either vetoes everything it emits (rules.json ahead of PAIRS) or emits tickets it cannot size (PAIRS ahead of
rules.json, which `guard.py:188` catches — that pairing is the safe direction, worth noting).

Also required, and easy to miss: the desk's moomoo watchlist / `quote_user_security` set the researcher pulls
from, and `toolset` symbol lists — I saw `code_list=["US.QQQ"]` style arguments in live session records, so the
data-fetch step is per-symbol in prompts as well as tables. **[undiscoverable]** how many prompt sentences name
tickers without a targeted grep of all five templates' `system` fields; the apply script does that scan before
proposing anything.

---

## 5. Candidates, with the evidence each one needs

Prices, AUM, volumes and turnover from one live `quote_market_snapshot` read, `data_date` 2026-11-19, taken at
~00:14Z [observed]. Leverage truth = name strings plus the regression method of §2. Coverage = present in
`PAIRS` / `chop.INVERSE` / `universe.shares`.

### 5.1 Candidate signal tickers (the 1× names) — eligibility all pass

| sym | last | net assets | circ. mcap | day volume | day turnover | amplitude (session) | in `shares` | in `PAIRS` | verdict |
|---|---|---|---|---|---|---|---|---|---|
| IWM | 264.22 | $74.96B | $73.08B | 31.4M | $8.37B | 2.98% | **yes** | no | ready except for code |
| DIA | 490.79 | $43.97B | $42.55B | 4.90M | $2.43B | 2.73% | no | no | needs §1+§2 |
| XLF | 55.58 | $51.91B | $51.30B | 58.0M | $3.23B | 2.37% | no | no | needs §1+§2 |
| XLE | 60.89 | $39.74B | $39.42B | 30.9M | $1.89B | 1.97% | no | no | needs §1+§2 |
| TLT | 80.35 | $47.35B | $47.09B | 38.6M | $3.10B | 0.80% | no | no | needs §1+§2; low-amplitude risk (§6) |
| GLD | 335.18 | $126.17B | $123.31B | 11.2M | $3.77B | 1.60% | no | no | needs §1+§2; low-amplitude risk |

All six clear the [documented] $1 price floor and the $500M bar, and all trade ≥$1.9B/day, so a risk-sized
ticket is <0.1% of daily volume — the [documented] "qty > 20× actual market volume ⇒ partial fill" rule is not
in play at our sizes.

### 5.2 Bear vehicles (the short leg each one needs)

| sym | last | net assets | day volume | day turnover | true leverage | passes $500M bar? | liquid enough? |
|---|---|---|---|---|---|---|---|
| SQQQ | 49.42 | $1.76B | 90.3M | $4.24B | 3× | yes | yes (live) |
| SOXS | 63.14 | $1.36B | 99.6M | $5.76B | 3× | yes | yes (live) |
| **SPXS** | 29.71 | **$322.7M** | 21.5M | $618M | 3× | **NO — already live** | yes |
| SRTY | 30.53 | $75.7M | 3.50M | $104M | 3× | no | yes at our size |
| SDOW | 28.82 | $160.9M | 7.62M | $214M | 3× | no | yes |
| FAZ | 34.74 | $94.1M | 3.64M | $124M | 3× | no | yes |
| ERY | 9.50 | $50.3M | 23.3M | $220M | **2×** | no | yes |
| TZA | 54.20 | $197.6M | 5.38M | $282M | 3× | no | yes |
| TMV | 44.81 | $200.2M | 1.19M | $54M | 3× | no | marginal |
| GLL | 32.00 | $93.2M | 1.42–2.5M | $21–71M | **2×** | no | yes but thin |
| TBT | 39.46 | $267.5M | 0.15M | $6.1M | 2× | no | **no — exclude** |
| EPV | 19.80 | $10.2M | 0.015M | $0.3M | 2× (and it is UltraShort **FTSE Europe**, not energy) | no | **no — exclude** |

- **The eligibility pattern is structural, not incidental: the two bear vehicles that clear $500M are the two
  already live (SQQQ, SOXS), and SPXS — live and in `PAIRS["SPY"].short` — does not.** So either the $500M bar
  doesn't apply to ETFs, or it isn't enforced on this account, or the desk has been trading an ineligible
  product for three days. I cannot determine which from any interface I have [undiscoverable]; `guard.py` does
  not check it (§7.4), and nothing in the live config or the connector reports an eligibility verdict.
- Fixture correction while we're here: `.scratch/bt/mkdata.py:69` labels ERY "Bear 3X" (wrong) and
  `.scratch/bt-regime-1120/grab.py:26` labels **EPV** "ProShares UltraShort Energy" (wrong — EPV is
  UltraShort FTSE **Europe**; the energy 2× bear is ERY). Any replay built on those fixtures mis-tags at least
  one sleeve.

### 5.3 Per-pair change set (illustrative, the IWM pair)

```jsonc
// rules.json universe.shares       += ["SRTY"]            // TZA is the alternative, SRTY is more liquid
// rules.json universe.leverage     += {"SRTY": 3}          // PAIRED EDIT, never one without the other
// trend_signal.py PAIRS            += {"IWM": {"long":"IWM","short":"SRTY","lev":3}}
// chop.py INVERSE/FAMILY           += {"IWM": ("SRTY",3)}   // via FAMILY's derived map, automatically
// researcher prompt SCAN step 1     "For QQQ, SMH, SPY" → "+ IWM"
// coordinator prompt strategy line  same
```

---

## 6. Signal-quality interaction — would expansion add trades, or just more slots for the same veto?

- **The regime veto is ticker-blind.** `allow_long=False` in `crisis`/`bear_high_vol` and in the fail-closed path
  (`trend_signal.py:43-44, 136-141`) rejects every LONG regardless of symbol, and `allow_bearish_etf` is True in
  every path including fail-closed. So on precisely the days where the desk felt short of ideas, **adding tickers
  adds zero longs**; it can add shorts, which the existing three already provide.
- **The opening-range band is calibrated on index ETFs and is not per-ticker.** `trend_signal.py:165-166`
  requires `0.15% ≤ (or_high−or_low)/price ≤ 1.5%`. Session amplitudes I observed for Nov 19 put TLT at 0.80%,
  XLP 0.97%, GLD 1.60%, XLE 1.97% against SPY 3.32%, SMH 7.13% [observed — full-session, **not** opening-range].
  A low-amplitude candidate can fail the **lower** bound as easily as a high-amplitude one fails the upper.
  **[undiscoverable]** which side bites per ticker without measuring 5-minute OR widths in session; that
  measurement is §10 V-3 and is the single most informative number this memo cannot supply.
- **The payoff shape does not improve.** Every emitted ticket inherits `reward_risk: 1.5`
  (`trend_signal.py:196`, `RR` in chop.py), so expansion multiplies opportunities, it does not raise edge.
- **Correlation.** IWM/DIA/XLF/XLE are US equity beta; on a QQQ/SMH/SPY-confirmed trend day they mostly confirm
  the same direction, so extra tickets arrive clustered — which the *aggregate* caps, not the ticker list,
  controls (§7.2). TLT and GLD are the only genuinely independent slots in the candidate set.
- **Slots are fixed by the schedule, not the universe.** [documented] the coordinator runs one new position per
  SCAN and there are four SCANs — so the ceiling is ~4 entries/day whichever universe is configured. Expansion
  changes *which* ticker fills a slot, not how many slots exist.
- **Counter-argument that is often made and should not be over-credited:** the bearish leg already exists for all
  three current tickers, so "the desk can't express bearishness" is not a live gap; and 3× decay is a *reason to
  prefer* fewer, shorter bearish holds, not more bearish vehicles.

---

## 7. Risk-cap interaction (what expansion does to the numbers, with the live lines)

### 7.1 40% of initial assets per position [documented]
`guard.py:210-212` sizes to `single_asset_target_pct = 35` off **live `nav`**, with `cur` = existing MV in the
same ticker. At the $100k start that is $35k vs the $40k bar — a 12.5% buffer. Two notes:
- Because the base is `nav` and not `competition.starting_nav` ($100k, present in rules.json but unused for this
  cap), a NAV above **$114,286** makes a 35%-of-NAV position exceed 40% of *initial* assets. **[undiscoverable]**
  whether the rule means initial or current assets — if "initial", the target should be anchored to
  `starting_nav`. Worth one question to the organisers, bundled with §5.2.
- The 40% bar is a **market-value** cap, and it is *not* the binding cap for levered names: risk sizing comes out
  smaller. `guard.py:209` `qty = floor(nav*0.35% * mult / dist)` with `dist` = instrument-level stop distance;
  a 3× vehicle's `dist` is ~3× the underlying's, so a typical 3× ticket lands near **$11–13k MV** and a 2× one near
  **$17k** — nowhere near $35k. Adding levered tickers therefore does **not** push the desk toward the 40% ceiling.

### 7.2 Aggregate caps
`max_effective_gross_pct 120` (`guard.py:213-214`) and `max_open_risk_pct 1.5` (`guard.py:217-219`). The risk
budget, not the ticker list, caps concurrency: 1.5% / 0.35% ≈ **4 concurrent risk slots**, so six tickers cannot
create more exposure than three already can.

### 7.3 The sharpest hazard in the whole change: `leverage.get(ticker, 1)`
`guard.py:202, 213, 214` all default a missing leverage entry to **1×**. Adding a levered vehicle to
`universe.shares` without adding it to `universe.leverage` means the effective-gross ledger books a 3× fund at
1×. Three $35k-MV positions of a mislabelled 3× fund compute `eff_now = 105%` (so a fourth is still allowed)
while true gross is **315%** — a 3× understatement, on the one rule whose whole job is to catch exactly that
(reproduced offline in §10.5 C4–C6: same portfolio, same proposal, paired release vetoes at 132%, unpaired
release approves). This is why §1 must ship as one atomic rules.json edit, and why the verification plan includes
a read-back of both maps, not just `shares`.

### 7.4 Order and position caps — no pressure from expansion
`guard.py:180` enforces `engine_orders_per_day_cap 150` against 200 [documented competition limit] with
`planned_orders_per_trade 3` — it trips at ~50 trades/day; the desk does ≤4 entries plus exits and a hedge.
`max_positions 100` (`guard.py:182`). Neither is affected by ticker count. **[observed]** and worth naming: the
[documented] $500M eligibility bar is **not enforced anywhere** — `min_market_cap_usd: 500000000` exists in
rules.json but appears in no code file in live desk-risk-guard (grep over the live bytes returns only the
rules.json line), while `min_price` *is* checked (`guard.py:191`).

### 7.5 `min_distinct_tickers: 3` — the fake requirement
`guard.py:229-230` emits only a warning, never a veto, and its own text says "ASSUMPTION to confirm with
organisers". `docs/contest-rules-notes.md:6-17` already resolved that **no minimum-trades or minimum-ticker rule
exists** in this competition and that sitting flat carries no penalty. **Expanding the universe is not required
for rule compliance**, and framing it as "the 3-ticker rule needs more tickers" would be repeating a claim the
repo has already retired. Reproduced live-offline in §10.6 T4b/T4c: the warning fires on an ordinary approved
ticket even when the universe is unchanged, so it is noise today and would stay noise after any expansion.

One consequence worth naming for the expansion debate: the *warning* pushes toward more distinct tickers while
the *rule* does not exist. If the warning is ever taken as a requirement, universe expansion becomes a way to
silence a message rather than to reduce risk — which is the wrong reason to change what the desk can trade.

---

## 8. Cost of not expanding (and of expanding)

**What I can honestly say about the value of expanding: it is currently unknown, not known-positive.**
- **[documented, but not re-derived by me]** `docs/sleeve-b-findings-nov19.md:26`: across the 38-session
  live-faithful replay, fixing **only** the signal→fill anchor is worth **+$1,016.99 vs +$572.83 as-run**, with
  no new path-dependence — and it needs **no new ticker**. If that number holds, entry-anchor work is a larger,
  cheaper, better-evidenced win in the same window.
- The "+$440/week if longs were vetoed" premise is **already falsified point-in-time** (project memory: the
  Nov-12 real-data regime was `normal` with `allow_long=true`). It should not be re-used as the cost of a narrow
  universe.
- The measurable quantity that would justify expansion — incremental tickets and their net expectancy over the
  38/30-session replay with a 6-ticker `PAIRS` — **has not been computed** [undiscoverable today]. §9 V-1 is that
  computation.
- Non-expansion carries **no compliance or scoring penalty** [documented: no minimum-trade rule; flat is allowed].
  Note the settlement detail that makes late-window activity low-value for weekly scoring: weekly return figures
  use Friday 10:00 PM ET prices, and final settlement uses regular-market closing prices on the final day [documented].

**Cost of expanding (asyl):** a 2-skill publish + 4 re-pins + 2 prompt writes executed inside a live contest
week, with concurrent sibling sessions publishing into the same skill space *today* (option-adapter at 00:27Z),
and with production templates pinned to specific versions — i.e. a partial-release state is reachable, and each
artifact's failure mode is silent (a stale pin means the new ticker still doesn't appear; a paired-edit slip
means §7.3).

---

## 9. Recommendation (Tier B, one recommendation)

**Do not expand the tradable universe for the remainder of the 17–28 Nov window. Ship nothing.** Instead, in
order:

1. **Ask the organisers two questions that outrank this whole memo** (bundle into one message):
   (a) does "market cap under $500M not eligible" apply to **ETF net assets**, and is it enforced on account
   5830104 — given **SPXS ($322.7M) is live in `PAIRS["SPY"].short`**; (b) does the 40% cap measure
   **initial** or **current** assets. If (a) is answered "applies and enforced", the correct action is to
   *shrink* the bearish legs, not expand the universe.
2. **Run the counterfactual measurement** (V-1 below) before writing any candidate into config.
3. **If** both come back clean and the replay shows positive incremental expectancy, release the full 5-artifact
   set (§4) **once**, in a change window before the next contest event, starting with the least-reachable ticker
   (recommend **IWM/SRTY** only: best liquidity of the candidate longs, its bear vehicle trades $104M/day, and
   IWM is already half-wired — it is the single change with the smallest state space). DIA/SDOW second.
   **Exclude TLT/GLD/EPV/TBT from the first release** — TLT/GLD for the unmeasured lower-bound OR-width risk
   (§6), EPV/TBT for liquidity, which is a hard no rather than a judgement call (§5.2).

This keeps the decision with the owner and produces no live change; it is the Tier B posture the contract asks for.

---

## 10. Verification plan (for step 3; V-2 is already executed, see §10.5)

- **V-1 Replay, offline.** 38-session (extend to the full history you have) replay with `PAIRS` at 3 vs 6
  tickers, same regime inputs, same fees, reporting *incremental* tickets only: count, direction, expectancy after
  fees. Fix the fixture bugs first (§5.2: `mkdata.py:69` ERY "3X", `grab.py:26` EPV-as-energy). Gate: expand only
  if incremental expectancy is positive **and** incremental ticket count ≥ ~1/day.
- **V-2 Local offline guard check.** Rebuild rules.json + both scripts in a scratch tree, run `guard.py check`
  against synthetic proposals for each new instrument (share + its bear vehicle), assert: (i) approved, (ii)
  `qty` > 0, (iii) `protection.stop_level` present, (iv) `effective gross` computed with the right `lev`. Include
  a deliberately unpaired case (vehicle in `shares`, missing from `leverage`) and confirm it fails loudly.
- **V-3 Measure the OR-width distribution.** During two live sessions, record the high/low of the first six
  5-minute bars for each candidate and its vehicle, and count how many candidate-ticker slots would hit
  `"opening range x.xx% outside 0.15-1.5%"` on either bound. This is the number §6 cannot produce offline.
  (Budget note: 5-minute klines are token-heavy — ~14k tokens for one 2-day pull — so do this with a scripted
  fetch to disk, not in a conversation turn.)
- **V-4 Sandbox before production.** Publish the candidate skill versions, mount them on
  `executor-gating-rehearsal` **only** (never on a scheduled template), run one SCAN-shaped prompt, and read the
  skill bytes actually mounted (`/data/.qoder/skills/…`, python3, sandbox clock = UTC — recorded in project memory).
- **V-5 Publish integrity.** A version's `content_sha256` is *not* the sha256 of the downloaded zip (memory), so
  verify **per file** after download: the release is accepted only if `chop.py`, `trend_signal.py`, `guard.py`,
  `rules.json` match the reviewed bytes exactly.
- **V-6 Pin read-back.** After re-pinning, `GET /forward/templates/{id}` for all four production templates and
  assert the `skills[].version` values equal the new numbers (pinned bindings carry `version`; unpinned bindings
  omit the key entirely — memory). A missing `version` on any of the 10 bindings means the release did not land.
  Then confirm with the *compiled* view, which is free and read-only [identity `idn_a3c83d8b8fd13c3f158a12c7` read
  from `GET /forward/identities` at 00:47Z — one identity in the account, `identity_type: admin`; endpoint from
  `cloud-agents/api/forward/identities/effective.md`, fetched 00:48–00:50Z]:
  `GET /api/v1/forward/identities/idn_a3c83d8b8fd13c3f158a12c7/templates/{template_id}/effective` — check
  `agent.skills` there rather than trusting the template body alone. Note `session_effective_hash` does not move
  on a template edit (only `agent_effective_hash` does), so hash equality is not a pin check; read the field.
- **V-7 In-window smoke, day one.** One SCAN with the new ticker permitted but `AUTONOMY_PHASE=approval` (a
  temporary prompt rollback, deliberate friction), confirm a ticket for the new symbol reaches a verdict, then
  restore `bounded`.
- **V-8 Post-release check:** confirm no "not a signal ticker" / "not a Sleeve C ticker" / "not in the approved
  share universe" NONE appears for the intended symbols, and confirm no ticket is sized off `leverage` default 1
  (grep the day's `portfolio.json`/decisions log for the new vehicles).

---

### 10.5 Verification already performed (offline, local, no cloud writes)

Three of the structural claims above were executed against the **live bytes** (unpacked to
`.scratch/t20-5e8c3a/live/x/`, hashes as in §1) with the local Python 3.12.10 toolchain, using three rules trees
under `.scratch/t20-5e8c3a/proposal/`: `tree_live` (live bytes), `tree_pair` (proposed: `shares += SRTY` **and**
`leverage.SRTY = 3`), `tree_nopin` (hazard case: `shares += SRTY` only). Command shape:
`python scripts/guard.py check --proposal … --portfolio … --now 2026-11-20T10:35:00-05:00 --rules … --phase bounded`.

| # | case | result | what it proves |
|---|---|---|---|
| C1 | live rules + SRTY ticket | **veto**: `"SRTY not in the approved share universe"` | blocker (b) is real for symbols genuinely absent |
| C2 | live rules + IWM ticket | **approved**, qty 108, risk \$349.78, `protection.stop_level 261` | IWM needs **no** rules.json change — the reported blocker mis-located it |
| C3 | live `trend_signal.py` + IWM | `{"action":"NONE","reason":"IWM not a signal ticker"}` | with C2: guard accepts what the engine cannot emit — **`PAIRS` is the binding gate** |
| C4 | `tree_pair`, portfolio already at 132% true gross | **veto**: `"size rounds to zero (binding: effective gross cap)"` | the paired release enforces `max_effective_gross_pct 120` correctly |
| C5 | `tree_nopin`, **the same** portfolio and proposal | **approved**, qty 194, warning `"size limited by open risk cap"` | the unpaired release admits a 3× fund while believing gross is 108% |
| C6 | same portfolio, ledger recomputed under each map | paired **132,000 = 132%**; unpaired **108,000 = 108%**; truth 132% | quantifies §7.3 — a missing `leverage` entry understates gross by the fund's real ratio |

§7.3 is therefore upgraded from reasoning to **[observed]**: the "universe and leverage must ship together"
requirement is backed by a reproduced failure, not an argument. **Not** done: V-1 (counterfactual replay),
V-3 (in-session opening-range widths), V-4/V-7/V-8 (need a live sandbox or a scheduled run) — those are what a
release decision still lacks.

### 10.6 End-to-end chain, also offline — what one ticker actually needs before a ticket exists

Same method, one step further: the `PAIRS` patch from the draft script (step 3, run verbatim) was applied to a
copy of the live `trend_signal.py`, `py_compile` passed, and the engine output was handed to guard **as a ticket**
under all three rules trees. All prices below are fabricated fixtures, not market data.

| # | input | result |
|---|---|---|
| T1 | live `trend_signal.py`, IWM breakout fixture | `{"action":"NONE","reason":"IWM not a signal ticker"}` |
| T2 | **patched** `PAIRS`, same fixture | `{"action":"LONG","instrument":"IWM","entry":266,"stop":265.48,"target":266.78,"reward_risk":1.5}` |
| T3 | patched `PAIRS`, IWM bearish fixture + `inverse_price` | `{"action":"SHORT","instrument":"SRTY","leverage":3,"entry":31.2,"stop":30.98,"target":31.53}` |
| T4a | T3's ticket → guard, **live** rules | veto: `"SRTY not in the approved share universe"` |
| T4b | same ticket → guard, `tree_pair` | approved, qty 1121, risk \$248.97, warning `"size limited by 35% single-asset target"` |
| T4c | same ticket → guard, `tree_nopin` | approved, **identical** qty 1121 — see the note below |

T4c is the important one for how to read §7.3: on a **flat** account the unpaired release looks completely
harmless — same verdict, same size. It only diverges once gross exposure accumulates (C4/C5, where paired vetoes
and unpaired approves). A release that ships `shares` without `leverage` therefore passes every pre-trade check
you can run on an empty book and fails silently later. That is the definition of a latent risk-control bug, and
it is the strongest single argument for §9's insistence on the atomic paired edit plus C4/C5 being part of the
release test rather than an argument in a memo.

Two side observations from the same runs, both [observed]:
- T3 needed an unusual fixture (VWAP below the opening-range low) before the SHORT leg produced anything, because
  `trend_signal.py:192` rejects any `dist > rng`. Bearish tickets from this engine are structurally harder to
  produce than long ones at the same opening range; worth knowing before assuming a new ticker doubles slots.
- T4b/T4c emitted `"ASSUMPTION to confirm with organisers: competition asks for 3+ distinct tickers"` on **every**
  approved ticket — the dead rule from §7.5 reproduces in practice, and it will keep firing as noise on any
  universe, expanded or not.

## 11. Change surface snapshot and rollback (§6 of DRIVER)

Pre-change anchor (this is the restore source, recorded at 00:09–00:39Z 2026-11-20):
- desk-risk-guard `1795100050849622` — local copy `.scratch/t20-5e8c3a/live/x/` (unpacked from the live zip
  `.scratch/t20-5e8c3a/live/desk-risk-guard-live-1795100050849622.zip`, 17,810 bytes); `rules.json`
  `49dbeaf4d2d21278cf3d90abcbc1e6b3d4d734fcde4e0afe665e3906a5bfff4b`, `guard.py`
  `8fe26118b2a8a3fd40329a0fc5f4fe70eec169d2f5704de42e2afa8756cb25d5`
- trend-signal `1795047415929677` — zip `…/live/trend-signal-live-1795047415929677.zip`; `trend_signal.py`
  `60d5573de1eb139d75378f537b689c733f648ae8dd52e444fd44194e5ba9bed8`
- vwap-chop `1795095917868411` — zip `…/vwap-chop-live-real.zip`; `chop.py` `43810bd7d2ad6e7e9d7338fc74fc9d2e777cee1095f07e67e66a6648db5f72e9`
- prompts — full template objects saved: `.scratch/t20-5e8c3a/tmpl-tmpl_*.json` (4 files, read 00:30Z), plus the
  5-template listing `.scratch/t20-5e8c3a/tmpls-live.json` (00:41Z)

Rollback, in the order that keeps the desk safe:
1. **Immediate brake, no publish needed:** re-pin the 4 production templates to the version numbers above
   (`POST /api/v1/forward/templates/{template_id}`, body `{"skills":[…]}`). **`skills` is replaced as a whole when
   provided** [documented], so the request must carry the complete binding list, not the one entry being reverted;
   omitting the field preserves the current list. A pinned binding is authoritative, so this alone reverts the
   executable code, and it is reversible in one call per template.
2. If a prompt sentence is what broke: `POST` the saved `system` field back verbatim from the `tmpl-*.json` dump
   (`system` is an ordinary scalar field on that endpoint, so an omitted field is left unchanged).
3. Skill versions cannot be un-published, so a "revert" of the *content* means publishing the anchor bytes as a
   new version from the local zips (byte-for-byte, per-file verified) and re-pinning to that.
4. Verify with V-6 read-back plus a `guard.py day`/`check` smoke against a live-read portfolio, and confirm the
   account is flat or hedged before leaving the change window.
5. Record the rollback itself with decision-journal, as a `verdict`/`error` entry, so the next run reads it.

---

## 12. Drafted change, review-only (NOT applied)

`rules.json` universe block, review-only diff (the minimum credible expansion — IWM only, per §9 step 3):

```diff
   "universe": {
-    "shares": ["SPY", "QQQ", "IWM", "SMH", "TQQQ", "SQQQ", "SOXL", "SOXS", "SPXS"],
+    "shares": ["SPY", "QQQ", "IWM", "SMH", "TQQQ", "SQQQ", "SOXL", "SOXS", "SPXS", "SRTY"],
     "option_underlyings": ["SPY", "QQQ", "IWM", "SMH", "XSP"],
-    "leverage": {"TQQQ": 3, "SQQQ": 3, "SOXL": 3, "SOXS": 3, "SPXS": 3}
+    "leverage": {"TQQQ": 3, "SQQQ": 3, "SOXL": 3, "SOXS": 3, "SPXS": 3, "SRTY": 3}
   },
```

Proposed companion edits (also unapplied, shown for review):

```diff
- PAIRS = {"QQQ": {...}, "SMH": {...}, "SPY": {...}}
+ PAIRS = {..., "IWM": {"long": "IWM", "short": "SRTY", "lev": 3}}         # trend_signal.py:18-22
- INVERSE = {"QQQ": ("SQQQ", 3), "SPY": ("SPXS", 3), "SMH": ("SOXS", 3)}
+ INVERSE = {..., "IWM": ("SRTY", 3)}                                      # chop.py:28  (FAMILY derives itself)
- "...first six 5-minute bars. For QQQ, SMH, SPY: ..."                     # researcher prompt, field `system`
+ "...QQQ, SMH, SPY and IWM: ..."
- "confirmed opening-range breakouts on QQQ, SMH and SPY that agree with VWAP"   # coordinator prompt
+ "…QQQ, SMH, SPY and IWM…"
```

Proposed files staged for review, **not applied** (all under `.scratch/t20-5e8c3a/proposal/`, which is gitignored):

| file | what it is |
|---|---|
| `rules.json.before` | verbatim copy of the live rules.json (`49dbeaf4…`) — the rollback source |
| `rules.json.proposed` | the two-line universe patch above; verified to change **only** the `universe` block, and it parses |
| `apply-universe-draft.sh` | draft release script, 14,131 bytes / 216 lines. **Never run.** Passes `bash -n` (re-checked 01:11:45Z after four correctness fixes: two `set -e` short-circuit aborts, a malformed JSON map in `repin`, a `python3` stub call, a placeholder-version guard); body unexecuted. Dry-run by default and refuses to POST without `CONFIRM_APPLY_TIERB=i-understand-this-changes-risk-taking` **and** `DRY_RUN=0`. It snapshots live bytes, aborts if the anchors moved, patches rules.json + `PAIRS`, asserts the paired-leverage edit before publishing anything, runs the offline gate checks, publishes by multipart `POST …/versions`, re-pins with **whole-array** `skills` bodies, and skips the two prompt writes unless owner-reviewed replacement sentences exist as files. Rollback is a commented footer, not an automatic path. |
| `tree_live/ tree_pair/ tree_nopin/ ts_patched/` | the rules/engine trees used by §10.5 C1–C6 and §10.6 T1–T4. `ts_patched` is live trend-signal bytes with the draft script's `PAIRS` patch applied, and it compiles |
| `prop-iwm.json prop-srty.json portfolio-flat.json portfolio-gross.json sig-iwm*.json prop-from-T3b.json` | synthetic gate inputs for those runs — fabricated prices, **not** real tickets or real quotes |

Note on the script's status: its step-3 patch block and its `guard.py`/`trend_signal.py` invocation forms were
**executed verbatim offline** (§10.6), and it passes `bash -n`. Everything that would touch the network — the
snapshot GETs, `publish`, `repin`, the read-back — has still never been run by this script.

Honest scope note on the script: the desk-risk-guard and trend-signal halves are implemented, the vwap-chop half
is a deliberate TODO behind `SLEEVE_C_FOLLOW=1` (it should only ship after the Sleeve C replay, §9 step 3), and the
prompt half is intentionally gated on an owner-authored sentence file rather than invented here.

---

## 13. Open questions for the owner

1. **$500M / SPXS** (§5.2): live bear vehicle below the documented bar, in use for the SPY short leg. Ask
   organisers, or decide the desk's own interpretation and write it into rules.json as an enforced check.
2. **Should `guard.py` enforce market cap at all?** `min_market_cap_usd` is configured and unused (§7.4) — that
   asymmetry with `min_price` looks unintentional.
3. **Does the 40% cap measure initial or current assets?** Guard uses current `nav` (§7.1); divergence starts at
   NAV > $114,286.
4. **`account.account_id` is `""` in live rules.json**, so `guard.py:142`'s id check is inert: nothing
   structurally pins the desk to 5830104 — only `name_contains: ["Qoder"]`, `account_mode: SIMULATE`, and prompt
   text do. Cheap to close; I flag it rather than fix it (Tier B).
5. **Do we want Sleeve C to follow a new ticker at all?** Item 3 of §4 doubles the publish/re-pin cost for a
   sleeve whose own description is 3-ticker-specific; leaving vwap-chop at QQQ/SMH/SPY is a defensible choice,
   provided rules.json/PAIRS ship without pretending Sleeve C covers the new name.
6. **Fixture hygiene**: the backtest fixtures that produced this false blocker should be corrected or clearly
   marked non-authoritative, or the next memo will re-report the same phantom (§5.2, and `docs/sleeve-b-findings-nov19.md:29`).
7. Should `docs/sleeve-b-findings-nov19.md:29` be corrected now? I deliberately did not edit it — the exact
   replacement line is: "Candidate-ticker expansion (IWM/DIA/XLF/TLT/GLD/XLE) blocked: none of these are in the
   engine's `PAIRS`/`INVERSE` tables (IWM is already in `rules.json` but unreachable), ERY and GLL are genuinely
   2× (fixture values were correct), and every candidate bear vehicle including the live SPXS is under the
   documented $500M eligibility bar."

---

## 14. Sources

Repo: `docs/sleeve-b-findings-nov19.md` · `docs/contest-rules-notes.md` · `.scratch/livestate-1120/` ·
`.scratch/t20-5e8c3a/live/` · `.scratch/fixb/dv2-before.py` · `.scratch/bt-regime-1120/` · `.scratch/bt/mkdata.py` ·
`.scratch/mailbox/{CONTRACT,DRIVER}.md`

External [documented, read 2026-11-20]:
- [A List of Inverse and Leveraged Commodity ETFs — thebalancemoney](https://www.thebalancemoney.com/list-of-inverse-and-leveraged-commodity-etfs-1214759) (GLL −2x; ERY Bear 2X)
- [Leveraged and inverse funds: all ETFs compared — fourpercentrule](https://www.fourpercentrule.com/etfs/browse/geared) (GLL Inverse 2x)
- [Chart List Reports — Nasdaq Dorsey Wright](https://www.chartlogs.com/) (ERY 2X, GLL 2X tagged)
- [Enhanced Returns ETFs in RBH and CPM](https://www.msci.com/) (ERY −2.00, GLL −2.00 daily factors)

Live reads (all GET/quote-only, 2026-11-20 00:09–00:47Z): `GET /forward/skills`, `GET /forward/skills/{id}`,
skill content download URL → zip, `GET /forward/templates`, `GET /forward/templates/{id}`;
moomoo `quote_market_snapshot`, `quote_stock_basicinfo`, `quote_history_kline` (day klines, 6 bars, end 2026-11-19).
