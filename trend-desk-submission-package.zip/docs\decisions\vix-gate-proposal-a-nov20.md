# Proposal A, corrected — a sleeve-A-scoped re-quote clause (Nov 20)

**Tier B — owner sign-off required. Nothing in this document has been applied.**

> **§9 amendment, added `2026-11-20T03:45Z` by a second session working the same mailbox task
> (`20261120T023636Z-7b19d4`, Part A) in parallel.** It corrects two things in §1–§7 and offers a
> different package: **(a)** the next-eligible-write time in §1.1/§2.2/§7 is `2026-11-20T21:45:00Z`
> (16:45 ET 20 Nov), not `2026-11-20T05:00:00Z`, because the change window rather than ET midnight is
> the unit §6.4 attributes to — §9.2; **(b)** the routing test as worded in §4.2 is addressed to the
> coordinator in a form the coordinator cannot evaluate — §9.3. §1–§8 are left as that session wrote
> them, with a bracketed pointer wherever a superseded time is quoted. Read §9 before applying.

No template write, no skill publish, no re-pin, no schedule change, no `rules.json` / `guard.py` /
`trend_signal.py` / `calendar_rules.py` edit, no order, cancel or probe, nothing on account `5830104`.
Every cloud call made for this document was a `GET` (two full template/schedule/skill captures plus one
preflight and one skill-content download); every moomoo call was zero — this session made no MCP call.
The live change exists only as a confirm-gated script pair under
[`.scratch/proposal-a-1120/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120),
and its write path was exercised only against a local mock (§6).

Part A of mailbox `20261120T023636Z-7b19d4` (sibling session has Part B). Supersedes the Proposal A
detail in
[`vix-gate-and-zero-trades-nov20.md` §8](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/vix-gate-and-zero-trades-nov20.md#L334);
that memo stays as written, this one is the corrected authority.

Tags are the same as the source memo: **[observed]** = read from a live source this session, command or
file named; **[documented]** = written down by the desk or in a repo doc (it may be wrong about the
world, the claim is only that it said so); **[undiscoverable]** = not determinable from what exists.

---

## 1. Bottom line

1. **The proposal is ready but not eligible tonight.** Every one of the four production templates was
   already written on ET calendar day **2026-11-19**, so the one-change-per-template-per-ET-day slot
   (DRIVER §6.4) is spent. The **next eligible instant is `2026-11-20T05:00:00Z` = 00:00:00 ET on
   20 Nov**, and the change window then runs to **08:30 ET = `13:30:00Z`**. The desk is idle across that
   span (next scheduled run is BRIEF at `2026-11-20T14:00:00Z`), so a write at 05:00Z is ~9 h before
   anything reads the prompts. §2 has the per-template arithmetic.
   **[superseded by §9.2 — that arithmetic counts the ET calendar day; the desk's own precedent counts
   the change window, which puts the next slot at `2026-11-20T21:45:00Z` = 16:45 ET 20 Nov.]**
2. **The clause is now scoped to Sleeve A only.** The earlier draft's coordinator text ("a ticket is
   routed only if its own re-quote stamp is less than 5 minutes old") had no sleeve qualifier, and a
   Sleeve C ticket has **no stamp field at all** — `chop.py`'s ticket dict contains no time key (§3,
   [observed]). Under that wording every C ticket would have failed the test forever. The corrected text
   names the sleeve in both prompts, exempts step 3 explicitly, and was checked against the live
   bytes at the anchor level.
3. **Two templates, one field, one appended sentence each.** Researcher SCAN step 2 (+485 chars) and the
   coordinator SCAN line (+410 chars). `system` field only; nothing else in either object changes
   (§4, §6 read-back asserts it).
4. **Rollback is proven byte-for-byte, offline.** Nine check groups pass (§6): dry runs write nothing, a
   wrong confirm and both budget refusals write nothing, apply lands the built bytes, rollback restores
   the captured bytes with `cmp`, a second rollback is a no-op, and a re-apply is deterministic.

---

## 2. Live state, re-derived from scratch — and the change budget

No sha or byte count from any earlier draft was carried in. Everything below was produced by one
capture script
([`tools/capture.mjs`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/tools/capture.mjs))
run twice, 13 minutes apart.

### 2.1 The five templates [observed]

| template | id | `system` chars / bytes | `system` sha256 | `updated_at` (live) |
|---|---|---|---|---|
| researcher | `tmpl_d7df3829ed5d73548bb5e9ed` | 3,776 / 3,784 (18 lines) | `f4057916db3279448fd5fea7ceb77a7b52e7fa95a167dc8912223116f8e412fd` | `2026-11-20T09:29:44+08:00` = `01:29:44Z` |
| coordinator | `tmpl_19f984c8f0fd516965b63998` | 3,274 / 3,274 (22 lines) | `16572c95062b259fcf43671cd81386488ab9ecca2b5c4e4bce825a8c41fedc84` | `2026-11-19T22:05:04+08:00` = `14:05:04Z` |
| executor | `tmpl_6c3c42cc4500efcbd6d60309` | 4,918 / 4,918 (16 lines) | `84c192f72273592883f2eb0e7338c8c062bf53b72bd4ebb7803b4e3347d653df` | `2026-11-20T09:29:44+08:00` = `01:29:44Z` |
| risk_auditor | `tmpl_bf2c477c0fba1a3363833f91` | 6,606 / 6,606 (19 lines) | `25f673100b2d33bd55b3926142553f3c2a0e7a8118dfb9e949cdfa00290ade57` | `2026-11-20T09:29:44+08:00` = `01:29:44Z` |
| executor-gating-rehearsal | `tmpl_f3214189de633d9d34ce77b6` | 2,420 / 2,420 (15 lines) | `32e9beb182f96de85d8fc86b39acfa3e846e5bf9f58c2904d57d6075c7d0fed2` | `2026-11-20T09:22:41+08:00` = `01:22:41Z` |

Read 1 `2026-11-20T02:55:21Z`, read 2 `2026-11-20T03:08:09Z`: **all five `system` fields byte-identical
between the reads and `updated_at` unchanged** — no other session wrote during this task.
[`.scratch/proposal-a-1120/before/capture-report.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/before/capture-report.json),
[`verify/read2/capture-report.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/verify/read2/capture-report.json).

Pins are all explicit (no binding resolves to `latest`): researcher carries desk-risk-guard
`1795138181446404`, trend-signal `1795047415929677`, decision-journal `1795137748003137`, vwap-chop
`1795095917868411`; coordinator carries **none**; executor and risk_auditor carry guard + journal +
vwap-chop. All 7 schedules are `active` on the coordinator template; next runs: BRIEF `14:00Z`,
SCAN-1005 `15:05Z`, SCAN-1100 `16:00Z`, SCAN-1230 `17:30Z`, SCAN-1400 `19:00Z`, FLAT `20:30Z`,
REPORT `21:15Z` (all 20 Nov). **[observed]**

### 2.2 Change budget: **not eligible now** [observed]

DRIVER §6.4: "One change per template per day so effects can be attributed", change window
16:45 ET → 08:30 ET. Evaluated against the live `updated_at` values, with ET derived via `tzdata`
(EST, UTC−5, DST already over):

| template | last write, ET | ET day | slot for 2026-11-19 |
|---|---|---|---|
| researcher | 2026-11-19 20:29:44 | 2026-11-19 | **spent** |
| executor | 2026-11-19 20:29:44 | 2026-11-19 | **spent** |
| risk_auditor | 2026-11-19 20:29:44 | 2026-11-19 | **spent** |
| coordinator | 2026-11-19 09:05:04 | 2026-11-19 | **spent** |

The three "spent at 20:29" writes are tonight's calendar/journal release (guard v13 `1795138181446404`
and decision-journal v3 `1795137748003137`, pinned `01:29:44Z`). The coordinator's 09:05 ET write is an
earlier one today; it does not need to be re-explained here, only counted.

- Now (`budget.mjs` run): `2026-11-20T02:58:54Z` = ET **2026-11-19 21:58** — inside the window, but on
  the spent ET day.
- **Next slot opens: `2026-11-20T05:00:00Z` = ET 2026-11-20 00:00:00.** The window that started
  16:45 ET on 19 Nov runs to 08:30 ET on 20 Nov, and midnight ET falls inside it, so the new ET day's
  slot is usable immediately at 00:00:00 ET — 05:00Z — until **`13:30:00Z`** (08:30 ET).
  **[superseded by §9.2: a write at 05:00Z and the `01:29:44Z` release both precede the SAME 20 Nov
  BRIEF, so under the window reading this slot is still spent until `2026-11-20T21:45:00Z`.]**
- Nothing scheduled runs in that span: BRIEF is `14:00Z`. A 05:00Z write is therefore picked up by the
  09:00 ET BRIEF with no risk of landing mid-run.

Reproduce: `node --env-file=.env .scratch/proposal-a-1120/tools/budget.mjs` (read-only; exit 3 while
ineligible). The dry-run `apply.sh` runs this gate itself and stops there — see
[`verify/live-dry-apply.txt`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/verify/live-dry-apply.txt),
which exits 3 without writing.

---

## 3. Why the scope must be Sleeve A only — checked, not assumed

The earlier draft's researcher sentence was acceptable (it sits inside step 2), but its coordinator
sentence was in the routing line with no sleeve qualifier:

> "A ticket is routed only if its own re-quote stamp is less than 5 minutes old …" *(old draft)*

[observed] A Sleeve C ticket has nothing to stamp. The pinned `vwap-chop` (`skill_00vz0dq461mv4e5iv1p3`
@ `1795095917868411`, `scripts/chop.py`, sha256 `43810bd7d2ad6e7e9d7338fc74fc9d2e777cee1095f07e67e66a6648db5f72e9`,
downloaded `2026-11-20T03:08:33Z` into
[`.scratch/proposal-a-1120/selcheck/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/proposal-a-1120/selcheck))
returns this ticket dict (`chop.py:141-148`), whose keys are:

```
sleeve, action, signal_ticker, family, instrument, leverage, underlying{price,stop,target},
entry, stop, target, reward_risk, z, vwap_crosses, sigma, reason
```

There is no timestamp, no quote age, no `as_of`. `time_et` is an **input** (the caller's clock), and the
ticket does not echo it. So under the old wording a C ticket can never demonstrate a fresh stamp:
the rule reduces to "never route a C ticket", permanently — exactly the failure the owner caught.

Two further reasons the exemption has to be in the coordinator text, not somewhere else:

- **The auditor cannot express the scope.** [documented, and consistent with the live guard]
  `proposal.json`'s `sleeve` is `trend | option | hedge` and guard only branches on `!= "hedge"` /
  `== "option"`; a Sleeve C ticket is submitted as `sleeve: "trend"`, i.e. A and C are the same value at
  the guard ([`sleeve-c-freshness-nov20.md` §4](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/sleeve-c-freshness-nov20.md#L70)).
- **The coordinator can.** The researcher labels C output ("Report its JSON unchanged, labelled sleeve
  C", live researcher step 3), so the routing decision is made where the label exists.

The coordinator insert therefore ends with an explicit exemption sentence, not an implicit one. A future
reader cannot generalise this rule to C without deleting a sentence that says not to.

---

## 4. The exact change

Two anchor insertions, no other character of either prompt touched. Anchors verified to occur **exactly
once** in the live text (`tools/preflight.mjs`, re-run against the live API at `03:0xZ`: "PREFLIGHT OK —
both prompts are byte-identical to the capture, anchors unique").

### 4.1 researcher — SCAN step 2, appended after

anchor: `If any number is missing, stale (older than 5 minutes) or inconsistent, return NONE with the reason.`

insert (+485 chars):

> A sleeve A (trend-signal) signal is sent only from a fresh reading: if this step produces a LONG or
> SHORT, re-quote the instrument and the underlying once, immediately, and re-run trend-signal `signal`
> on those new numbers before you send - the verdict on the fresh numbers is the one you send, and a
> fresh number that changes the verdict changes the verdict. Stamp every sleeve A JSON with the
> timestamp of that final re-quote. Step 3 (sleeve C) is not covered by this re-quote rule.

3,776 → **4,261 chars / 4,269 B**, sha256 `573c2051551dece96a0f700a4e0499d7721c1ef0cea7636860d93f81783b090e`.

### 4.2 coordinator — SCAN line, appended after

anchor: `Auditor reconciles fills afterwards.`

insert (+410 chars):

> A sleeve A (trend-signal) ticket is routed to the auditor only if its own re-quote stamp is less than
> 5 minutes old when the auditor receives it: route it in that same message, and if it has aged out, say
> so in the summary instead of leaving the reader to guess whether a signal existed. This freshness test
> covers sleeve A tickets only; a sleeve C ticket is not subject to it and is routed exactly as before.

3,274 → **3,684 chars / 3,684 B**, sha256 `4246c3bfeca2582084fecb279e9ad719f2c113765d86f312cdb0ef89056541f3`.

### 4.3 The one-line diff (`node .scratch/proposal-a-1120/tools/payload.mjs show`)

```
- 13| 2. Run trend-signal `signal`. Return one compact JSON per ticker (action, instrument, entry, stop, target, reason). If any number is missing, stale (older than 5 minutes) or inconsistent, return NONE with the reason.
+ 13| 2. Run trend-signal `signal`. Return one compact JSON per ticker (action, instrument, entry, stop, target, reason). If any number is missing, stale (older than 5 minutes) or inconsistent, return NONE with the reason. A sleeve A (trend-signal) signal is sent only from a fresh reading: if this step produces a LONG or SHORT, re-quote the instrument and the underlying once, immediately, and re-run trend-signal `signal` on those new numbers before you send - the verdict on the fresh numbers is the one you send, and a fresh number that changes the verdict changes the verdict. Stamp every sleeve A JSON with the timestamp of that final re-quote. Step 3 (sleeve C) is not covered by this re-quote rule.
```

```
- 11| - SCAN (10:05, 11:00, 12:30, 14:00): the auditor runs the monitoring check on open positions first and sends any close ticket before you ask for signals; then researcher returns signal JSON per ticker. For each LONG or SHORT, auditor runs desk-risk-guard check. Only approved tickets go to the executor, at most ONE new position per scan. Auditor reconciles fills afterwards.
+ 11| - SCAN (10:05, 11:00, 12:30, 14:00): the auditor runs the monitoring check on open positions first and sends any close ticket before you ask for signals; then researcher returns signal JSON per ticker. For each LONG or SHORT, auditor runs desk-risk-guard check. Only approved tickets go to the executor, at most ONE new position per scan. Auditor reconciles fills afterwards. A sleeve A (trend-signal) ticket is routed to the auditor only if its own re-quote stamp is less than 5 minutes old when the auditor receives it: route it in that same message, and if it has aged out, say so in the summary instead of leaving the reader to guess whether a signal existed. This freshness test covers sleeve A tickets only; a sleeve C ticket is not subject to it and is routed exactly as before.
```

One changed line per prompt, prefix and suffix byte-identical, length delta equal to the insert exactly
(asserted in `payload.mjs`, not eyeballed).

### 4.4 What changed versus the earlier draft — and what did not

| | earlier draft | this version |
|---|---|---|
| coordinator wording | "A ticket is routed only if …" — **unqualified** | "A sleeve A (trend-signal) ticket …" + explicit C exemption |
| researcher wording | "If a signal fires, …" (ambiguous between the two sleeves) | "A sleeve A (trend-signal) signal … if this step produces …" + "Step 3 (sleeve C) is not covered" |
| length deltas claimed | +362 / +248 | **+485 / +410** (rebuilt from the live bytes, not re-typed) |
| change-budget step | not present | hard gate, live read, exit 3 (DRIVER §6.4) |
| rollback | described as two PUTs of saved bytes | real script + 9-group round-trip proof (§6) |

The two `system` shas the earlier draft quoted (`f4057916…` researcher, `16572c95…` coordinator) are
**correct** — this session re-derived them independently from two fresh GETs and they match. The draft's
numbers were not wrong; its *scope* was, and the draft never checked the change budget.

---

## 5. What this does and does not fix

- **Intended effect.** It closes the specific failure measured on 2026-11-19: a valid signal emitted 6–9
  minutes stale inside a 21m47s round trip, voided by the researcher's own 5-minute rule with no
  counterpart anywhere downstream. With the clause, a sleeve A signal is either re-confirmed on a fresh
  print and stamped, or reported as aged out — instead of being silently voided.
- **It cannot manufacture trades.** On the two measured days it could only have changed the 10:17
  SQQQ/SPXS pair, and only if a re-quote still confirmed the break; the 10:26 re-quote of that same idea
  already failed `:192`/`:171`, which is exactly why the rule says *re-run `signal()` on the new numbers*
  rather than just re-stamp them.
- **Residual latency stays.** The researcher leg is ~20 min of model rounds
  ([`concurrent-researcher-tickers.md`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/docs/decisions/concurrent-researcher-tickers.md));
  a re-quote at emit plus a ≤5-minute routing test still leaves the auditor and executor legs. This is a
  correctness fix, not a speed fix — the realistic saving on today's plumbing is minutes, not twenty.
- **Chase risk.** A fresh number can *confirm* a chase. Mitigated by re-running `signal()` (a moved
  price fails the extension cap or R/R on its own); a reviewer should check that sentence specifically.
- **Prompt-level only.** Like every other rule on this desk, nothing enforces it mechanically; `guard.py`
  has no freshness input. That is a known property of the whole design, not a new hole.
- **Sleeve C remains unprotected** by this change (it never had freshness logic — `chop.py` inspects no
  timestamps). That is deliberate and out of scope; the exemption makes the gap visible instead of
  silently closing it with a permanent block.

---

## 6. Verification actually performed (offline) and its honest limit

`bash .scratch/proposal-a-1120/tools/roundtrip.sh` — local mock of the documented update endpoint, seeded
from `before/`, no cloud call. Result: **ROUND TRIP: PASS (9/9 groups)**:

| # | check | result |
|---|---|---|
| 1 | dry apply (no `GO`) | exit 0, **0 writes** |
| 2 | dry rollback (no `GO`) | exit 0, **0 writes** |
| 3 | `GO=1` with a wrong `CONFIRM` | refused, exit 2, **0 writes** |
| 4 | budget gate, ET 20 Nov 10:00 — new ET day but outside 16:45–08:30 | refused, exit 3, next slot `21:45Z`, **0 writes** |
| 5 | budget gate, ET 19 Nov 23:59 (same ET day as last write) | refused, exit 3, **0 writes** |
| 6 | apply at `05:00:01Z` | 2 writes; both live texts `cmp`-equal to `after/system-*-new.bin`; other fields unchanged |
| 7 | rollback | 2 writes; both live texts **`cmp`-equal to `before/system-*.bin` byte-for-byte** |
| 8 | rollback again | `NO CHANGE`, 0 extra writes |
| 9 | re-apply | same two shas as run 6 (deterministic) |

Plus, against the **live** API in dry mode: `apply.sh` stops at the budget gate (exit 3, nothing written);
`preflight.mjs` confirms both live prompts hash to `before/` and both anchors are unique (exit 0).

**Limit, stated plainly:** the mock implements the *documented* merge semantics ("fields omitted from the
request are left unchanged"), so the round trip proves the scripts and the byte fidelity of the
apply/rollback pair — not the cloud's merge behaviour. That behaviour is documented and empirically
supported (a partial `{skills}` body merged cleanly on this same template family on 2026-11-20), but it
has never been exercised for `system` on these two templates, which is why apply step 5 re-`GET`s and
asserts both the new sha and "all other top-level fields unchanged" rather than trusting the echo.

---

## 7. Exact owner steps (human-attended session, Rule 8)

Run at or after `2026-11-20T05:00:00Z` (= 00:00 ET) and before `13:30:00Z` (= 08:30 ET). Repo root:
**[superseded — §9.2 says the earliest eligible instant is `2026-11-20T21:45:00Z`; §9.6 is the owner
step list for the alternative package, and §9.3 must be settled before either is applied, because these
two proposals are mutually exclusive for the same two templates.]**

```bash
cd /c/Users/tteh/Documents/qoder-trend-desk-dashboard

# 1. Confirm the slot is open and the anchors still fit the live bytes (read-only).
node --env-file=.env .scratch/proposal-a-1120/tools/budget.mjs        # expect VERDICT: eligible
node --env-file=.env .scratch/proposal-a-1120/tools/preflight.mjs     # expect PREFLIGHT OK

# 2. Dry run: prints the full diff and the CONFIRM value. Writes nothing.
bash .scratch/proposal-a-1120/apply.sh

# 3. Read the two changed lines. If they are what you want, write:
GO=1 CONFIRM=573c2051551d,4246c3bfeca2 bash .scratch/proposal-a-1120/apply.sh

# 4. If anything looks wrong afterwards:
GO=1 bash .scratch/proposal-a-1120/rollback.sh
```

What success looks like: step 3 ends with `VERIFY OK` and both templates reporting the new sha
(`573c2051551d…` researcher, `4246c3bfeca2…` coordinator). The `CONFIRM` value is derived from the built
payload, so if step 1 ever prints a *different* value the live bytes moved — stop and re-read §2 rather
than forcing it.

Afterwards: the next 09:00 ET BRIEF and the SCANs create new sessions from the edited templates
(template edits do not mutate sessions already running). **Acceptance, on the first SCAN that produces a
sleeve A signal:** the researcher's signal JSON carries a re-quote timestamp, and the coordinator either
routes it inside 5 minutes or records it as aged out. Watch one SCAN (15–21 credits); if it produces no
signal, wait for the first one that does rather than concluding from silence.

A partial failure (researcher applied, coordinator failed) is safe to re-run: the applied template prints
`NO CHANGE`, and rollback restores both.

---

## 8. Provenance — what was read, and proof nothing changed

- [observed] Two full captures + one live dry-run + one skill-content download, all `GET`:
  `capture.mjs` `2026-11-20T02:55:21Z` and `03:08:09Z`, dry-run `apply.sh` `03:07:47Z`,
  `preflight.mjs` between the two captures, `chop.py` (pinned `1795095917868411`) fetched `03:08:33Z`.
  Reports: `before/capture-report.json`, `verify/read2/capture-report.json`, `verify/live-dry-apply.txt`,
  `selcheck/vwapchop.zip`.
- [observed] The PAT is read from `./.env` into a variable inside each script and is never printed,
  echoed, logged or copied — no artefact under `.scratch/proposal-a-1120/` contains it.
- [observed] No template `POST`, no skill publish, no re-pin, no schedule change, no `rules.json` edit,
  no moomoo MCP call, no order, cancel or probe, nothing on account `5830104`. The only writes this
  session made are local files under `.scratch/` and this document.
- [observed] The dashboard was never started; nothing listens on :4173 or :4189 from this session.
- [observed] The earlier draft's two prompt shas are confirmed correct against the fresh reads; its
  deltas (+362/+248) are superseded by the rebuilt payload (+485/+410). Its unqualified coordinator
  clause is the defect this document removes.
- [undiscoverable] from anything here: how much of the 21m47s is researcher compute vs scheduling
  overhead (instrumenting one live round trip would settle it), and whether a re-quote at emit would in
  practice have saved either of the two lost tickets on 2026-11-19.

Files: `tools/capture.mjs`, `tools/budget.mjs`, `tools/payload.mjs`, `tools/preflight.mjs`,
`tools/write-system.mjs`, `tools/verify-after.mjs`, `tools/mock-forward.mjs`, `tools/roundtrip.sh`,
`apply.sh`, `rollback.sh`, and the `before/ after/ verify/ proof/ diff/` artefacts beside them.

---

# 9. Second Part A submission for the same task — two corrections and an alternative package

Written by the other session holding mailbox `20261120T023636Z-7b19d4` Part A, working
**in parallel and without coordination**. §1–§8 above are that other session's submission and are left
untouched apart from three bracketed pointers where a time has been superseded.

**Nothing was written to the cloud by either session.** Every cloud call made for §9 was a `GET`; every
write was a local file under `.scratch/`. No order, cancel, probe or account call of any kind — this
session made zero moomoo MCP calls. Package for §9:
[`.scratch/changes/2026-11-20-scan-staleness/`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-scan-staleness).

The two proposals are **alternatives, not additions**: both rewrite researcher line 13 and coordinator
line 11 of the same two `system` fields, so applying one makes the other's anchors unmatchable. The
owner picks one. §9.8 states which and why.

Tags as in §1-8: **[observed]** / **[documented]** / **[undiscoverable]**.

## 9.1 Independent re-derivation of the live bytes — and where the two sessions agree [observed]

No sha from §2 was carried in; `tools/fetch-live.mjs` read the template list, then every id it found,
twice.

| read | time (UTC) | result |
|---|---|---|
| capture 1 | `2026-11-20T02:57:27.439Z` | 5 templates HTTP 200, all bindings pinned, `unpinned=0` on all five |
| capture 2 | `2026-11-20T03:27:44.600Z` | **no drift** — `system_sha256`/chars/bytes identical to capture 1 for all five |

All five `system` digests match §2.1 exactly (`f4057916db327944…` researcher, `16572c95062b259f…`
coordinator, `84c192f722735928…` executor, `25f673100b2d33bd…` risk_auditor, `32e9beb182f96de8…`
executor-gating-rehearsal), across ~32 minutes and two sessions. **The before-bytes are not in dispute
between the two submissions** — no other session wrote during either. What is in dispute is §9.2 and
§9.3.

Reports:
[`before/live-read.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-scan-staleness/before/live-read.json),
[`verify/recheck/live-read.json`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/changes/2026-11-20-scan-staleness/verify/recheck/live-read.json).

## 9.2 Correction 1 — the next eligible instant is `2026-11-20T21:45:00Z`, not `05:00:00Z`

DRIVER §6.4: *"Apply in the change window only. One change per template per day so effects can be
attributed."* §2.2 reads "per day" as the **ET calendar day**, so midnight ET 20 Nov re-opens the slot.
The desk's own precedent, written hours earlier about the identical collision, reads it as the **change
window**. [documented, `researcher-write-once-nov20.md` §6]

> - DRIVER §6.4 allows **one change per template per day** so effects can be attributed. That allowance
>   is consumed, by a change this task was not told about.
> - Adding my line on top means **Nov 20's runs would carry two unattributable researcher changes at
>   once.** … recovering it by argument is exactly what §6.4 exists to avoid.
> - the decision — "accept two writes in one window, or **hold this to the next change window (16:45 ET
>   20 Nov**, before the 21 Nov BRIEF)" — belongs to the driver who wrote the rule.

The precedent is decisive on the facts, not just the wording. The 01:22:41Z/01:29:44Z calendar and
decision-journal writes are *overnight* writes, and the change window is overnight precisely so a change
lands before the next trading day's runs. Those writes therefore precede the **20 Nov BRIEF at
`2026-11-20T14:00:00Z`**. A write at `05:00:00Z` (= 00:00 ET 20 Nov) also precedes that same BRIEF. So
the calendar-day reading permits two researcher changes in front of one trading day's runs — the precise
outcome §6.4 exists to prevent and that §6 of the precedent named as its reason to stop. §1.1 and §2.2
answer a different question ("is the desk idle?") than the rule asks ("is the effect attributable?").

Corrected arithmetic, from `tools/check-window.mjs` at `2026-11-20T03:38:29Z`:

```
now            2026-11-20T03:38:29Z UTC  =  2026-11-19 22:38 ET
in change window YES   (this window: 2026-11-19 16:45 ET -> 2026-11-20 08:30 ET)
  window open  2026-11-19T21:45:00Z  = 2026-11-19 16:45 ET
  window close 2026-11-20T13:30:00Z  = 2026-11-20 08:30 ET
  next window opens 2026-11-20T21:45:00Z = 2026-11-20 16:45 ET   closes 2026-11-21T13:30:00Z = 08:30 ET next day
budget per template (written inside the CURRENT window?):
  researcher    updated_at 2026-11-20T09:29:44+08:00 = 2026-11-19 20:29 ET  -> SPENT in this window
  risk_auditor  ... 20:29 ET -> SPENT     executor  ... 20:29 ET -> SPENT     executor-gating-rehearsal ... 20:22 ET -> SPENT
  coordinator   updated_at 2026-11-19T22:05:04+08:00 = 2026-11-19 09:05 ET  -> slot open - last write predates this window
```

- **Earliest eligible apply: `2026-11-20T21:45:00Z` = 16:45 ET 20 Nov**, until `2026-11-21T13:30:00Z`
  (08:30 ET 21 Nov). That is ~18 h after this document was written, and it lands before the **21 Nov
  BRIEF**, mirroring the precedent exactly.
- The coordinator's slot is the one place the two readings give opposite answers, and the *permissive*
  one is the dangerous direction: under the window reading the coordinator alone is eligible **now**
  (`09:05 ET` predates this window). Applying the coordinator without the researcher would install a
  routing test that demands a field the live researcher is never told to emit — see §9.3 — and every
  Sleeve A ticket would fail as missing evidence. Hence the pairing is deliberate, not convenience:
  `write-system.mjs` treats researcher + coordinator as one unit and refuses to write half of it.

### The bug in my own gate, found while writing this

[observed] `check-window.mjs` before this fix converted a wall time to a UTC instant by sampling three
candidates (`naive−12h`, `naive`, `naive+12h`) and **falling back to the naive value on no match**.
America/New_York is UTC−5 in November, so none of the three ever matched and the tool silently returned
`2026-11-19T16:45:00Z` for "16:45 ET" — five hours early, printing a window the desk does not have — and
its "next window" line added a day to the close date, skipping an entire eligible window.

Both SPENT/OPEN verdicts above happen to be unchanged (the two errors cancel for these inputs), and my
§9.2 conclusion was reached by hand before the tool was fixed. But the printed boundary was wrong, and
this is the file an owner would run to decide when to write. It now searches every whole-hour offset
from UTC+14 to UTC−12, raises if a wall time maps to no instant (spring-forward gap) instead of guessing,
takes the earlier instant for a fall-back hour, and carries 9 known-answer checks
(`node tools/check-window.mjs --selftest`, all PASS), including the `2026-11-01` EDT→EST switch and the
`2026-03-08` gap. Exit codes are unchanged (`0` in-window, `3` out), so `apply.sh`'s use of it is
unaffected — re-verified by §9.5.

## 9.3 Correction 2 — the §4.2 routing test cannot be evaluated by the agent it is addressed to

§4.2's insert, quoted from above:

> "A sleeve A (trend-signal) ticket is routed to the auditor only if its own re-quote stamp is less than
> 5 minutes old **when the auditor receives it** …"

[observed, from the live coordinator template read at 02:57:27Z and again at 03:27:44Z] The coordinator
has `mcp_servers: []`, `skills: []`, and one toolset whose `enabled_tools` are
`Bash, Read, Write, Edit, Glob, Grep, WebFetch, WebSearch, ImageSearch, ImageGen, VideoGen, DeliverArtifacts`.
It has no market-data access and no way to observe the auditor. The instant named as the measurement
point — when *the auditor* receives the ticket — is not available to the agent told to test it. The
coordinator does hold one clock time it can use: the time of the trigger it received and is working
through. §4.2's sleeve qualifier (added in response to the owner's caught gap) is correct and stays; this
is a separate defect in the same sentence.

Two further gaps in §4.1/§4.2, visible in §4.3's own diff:

1. **The stamp has no name.** §4.1 says "Stamp every sleeve A JSON with the timestamp of that final
   re-quote", but §4.3 shows researcher line 13's output contract still reads
   `(action, instrument, entry, stop, target, reason)` — no key added — while §4.2 routes on "its own
   re-quote stamp". An agent can probably infer a field, but a routing rule that blocks trades should
   not depend on two prompts independently inventing the same key name.
2. **No fail-closed path for a missing stamp.** §4.2 says to record an aged-out ticket in the summary,
   which is right, but neither text says what the researcher does when the re-quote itself cannot be
   sourced. The live trend-signal already fails closed on exactly this class of problem
   (`NONE` with a `reason`), so the clause should follow the same shape rather than leave a new gap.

The §9.4 wording fixes all three: the test is against the coordinator's own receipt time and says so
("a clock test, not a price test, and you hold no market-data tools"), `re_quote_et` is added to the
output tuple so both prompts name one key, a missing re-quote returns `NONE` with reason
`re_quote_unavailable`, and a Sleeve A ticket with no stamp is refused **and named in the summary** — the
silent-zero-trade failure the source memo measured is reported, not repeated.

## 9.4 The alternative package — exact text [observed: built from the 02:57:27Z bytes]

| | template | anchor (occurs exactly once) | added chars | line |
|---|---|---|---|---|
| R1-shape | researcher | `(action, instrument, entry, stop, target, reason).` | **+13** | 13 of 18 |
| R2-rule | researcher | `If any number is missing, stale (older than 5 minutes) or inconsistent, return NONE with the reason.` | **+531** | 13 of 18 |
| C1-route | coordinator | after `then researcher returns signal JSON per ticker.` | **+535** | 11 of 22 |

(Per-replacement counts come from `candidate/patch.json`, built `2026-11-20T03:11:10.865Z`; 13 + 531 =
the +544 researcher total, and the coordinator's single edit is its whole +535 delta.)

researcher 3,776 → **4,320 chars / 4,330 bytes** (`f4057916db327944…` → `c1baf3fe55d66b971c8c14b81259258673bffcd4aac98e64e7eae32221b8fe60`)
coordinator 3,274 → **3,809 chars / 3,811 bytes** (`16572c95062b259f…` → `8932eb164a8e69021e4d92a2662890f4ef5e4535bcbd2dd96f441a333282ff0e`)

**researcher line 13 becomes** (step 2 only; line 14 — Sleeve C — is untouched byte-for-byte, asserted):

> 2. Run trend-signal `signal`. Return one compact JSON per ticker (action, instrument, entry, stop,
> target, reason, **re_quote_et**). If any number is missing, stale (older than 5 minutes) or
> inconsistent, return NONE with the reason. **This step-2 rule is Sleeve A only: never re-quote or stamp
> a step-3 Sleeve C result, whose own rule governs it. When a step-2 result is not NONE, re-quote the
> instrument and its underlying once, immediately, and re-run trend-signal `signal` on those fresh
> numbers before you send — the verdict on the fresh numbers is the one you send, including a changed
> one; never stamp a stale one. Set `re_quote_et` to the HH:MM ET of that final re-quote; if the
> re-quote cannot be sourced, return NONE with the reason `re_quote_unavailable`.**

**coordinator line 11 becomes** (BRIEF/FLAT/REPORT lines untouched, asserted):

> - SCAN (10:05, 11:00, 12:30, 14:00): the auditor runs the monitoring check on open positions first and
> sends any close ticket before you ask for signals; then researcher returns signal JSON per ticker.
> **A Sleeve A (trend-signal) ticket is routed only if its `re_quote_et` is less than 5 minutes old
> against the clock time you received it — this is a clock test, not a price test, and you hold no
> market-data tools. Route it in that same message. A Sleeve A ticket with no `re_quote_et` is missing
> evidence: do not route it, and name it in the three-line summary instead of leaving the reader to guess
> whether a signal existed. This test does not apply to Sleeve C, which carries no `re_quote_et`: route C
> on its existing rule, unchanged.** For each LONG or SHORT, auditor runs desk-risk-guard check. Only
> approved tickets go to the executor, at most ONE new position per scan. Auditor reconciles fills
> afterwards.

Same sleeve-scoping conclusion as §3 — reached independently from the pinned
`vwap-chop@1795095917868411` bytes (`scripts/chop.py`, sha256 `43810bd7d2ad6e7e9d7338fc74fc9d2e777cee1095f07e67e66a6648db5f72e9`,
agreeing with §3's digest): `chop.py` reads no bar timestamp and its ticket dict carries no time key, so
C has nothing to stamp; and A and C are the *same* `sleeve` value at the guard, so the exemption can only
live in the prompts.

## 9.5 Verification performed for §9, offline [observed]

`bash .scratch/changes/2026-11-20-scan-staleness/roundtrip-test.sh` → **PASS=28 FAIL=0** against
`tools/mock-forward.mjs` (loopback only, seeded from `before/`). The checks that matter for the owner's
caught gap:

- researcher step 3 (Sleeve C) line **byte-identical after apply**; Sleeve C carries **no** `re_quote_et`
  requirement; coordinator BRIEF/FLAT/REPORT lines byte-identical.
- dry run writes nothing; apply = exactly 2 writes; after-bytes equal the candidate; skills array intact
  (4 bindings, all explicitly pinned); re-apply is a no-op (`skip-already-at-target`, `failures=0`).
- rollback restores **`f4057916db3279448fd5fea7ceb77a7b52e7fa95a167dc8912223116f8e412fd`** and
  **`16572c95062b259fcf43671cd81386488ab9ecca2b5c4e4bce825a8c41fedc84`** — the live bytes, byte-for-byte.
- injecting drift through the mock's own API aborts with a non-zero exit and **no further write**.
- a non-loopback `FORWARD_BASE` is refused before any fetch.

Plus **39/39** offline build assertions (`verify/build-assertions.txt`, `BUILD OK`), including the
read-only proofs: `fetch-live.mjs`, `fetch-skill.mjs`, `edits.mjs` contain no POST/PUT/PATCH/DELETE.
One of those assertions was itself wrong until this document was written: it tested
`src.includes('127.0.0.1')` against the writer's loopback guard, which is spelled as a *regex*
(`127\.0\.0\.1|localhost`), so `build-after.mjs` reported `BUILD FAILED` while the guard worked — the
behaviour was proven by the round trip all along. It now asserts the guard's three real parts (reads
`FORWARD_BASE`, names both loopback forms, aborts with the non-loopback message). The lesson is the same
one as §9.2's tool bug: a source-grep tripwire fails in both directions, and a green one proves less than
a behavioural check.

**Writer shape, stated without overselling.** `tools/write-system.mjs` is two-phase: it preflights and
gates *every* template and prints `ABORT BEFORE ANY WRITE` if any gate fails, so the half-applied pair is
structurally impossible. §7's design tolerates a partial apply and recovers by re-running; because it
writes the researcher first, the *harmful* half (coordinator without researcher) is unreachable there too.
The difference is ordering-versus-construction, not safety-versus-unsafety.

**Mock limit, same as §6's:** the loopback mock implements the documented merge semantics, so the round
trip proves the scripts and the apply/rollback byte fidelity, not the cloud's merge behaviour. The real
apply re-`GET`s and asserts the new sha, the untouched siblings, and the effective config.

**A provenance hazard this session found and §4.4 does not cover.** [observed]
`.scratch/vixgate-1120/apply/before-researcher-system.txt` is **3,801 B, sha256 `933806002455798f…`** and
`before-coordinator-system.txt` is **3,295 B, sha256 `17ff20fd5a67d719…`** — neither is a live byte
capture. Each holds only CRLF line endings (17 and 21 pairs, zero lone `\r`), and LF-normalising each
reproduces `f4057916db327944…` / `16572c95062b259f…` exactly. `vix-gate-and-zero-trades-nov20.md` §8
names those two files as the rollback source while quoting the digests of the *other* pair, so a literal
rollback from them injects `\r` into every line of two production prompts. §4.4's claim that the earlier
draft's *quoted shas* were correct stands — the rollback artefacts are the problem. This package
snapshots and restores only from its own `before/system_*.bin`, re-verified against a live read at apply
time.

## 9.6 Exact owner steps, this version

Human-attended session, at or after `2026-11-20T21:45:00Z` (= 16:45 ET 20 Nov) and before
`2026-11-21T13:30:00Z`. Repo root:

```bash
cd /c/Users/tteh/Documents/qoder-trend-desk-dashboard

# 1. Window + budget gate, and drift gate against the bytes this was built from (read-only).
node .scratch/changes/2026-11-20-scan-staleness/tools/check-window.mjs          # expect in change window YES
node .scratch/changes/2026-11-20-scan-staleness/tools/check-window.mjs --selftest   # expect SELFTEST OK
node --env-file=.env .scratch/changes/2026-11-20-scan-staleness/tools/fetch-live.mjs .scratch/changes/2026-11-20-scan-staleness/roundtrip/live-check
node .scratch/changes/2026-11-20-scan-staleness/tools/diff-check.mjs \
     .scratch/changes/2026-11-20-scan-staleness/before .scratch/changes/2026-11-20-scan-staleness/roundtrip/live-check
# 2. Offline: rebuild the candidate from the current before/ and re-run the assertions.
node .scratch/changes/2026-11-20-scan-staleness/tools/build-after.mjs           # expect BUILD OK
bash .scratch/changes/2026-11-20-scan-staleness/roundtrip-test.sh               # expect PASS=28 FAIL=0
# 3. Read the two diffs it prints. If they are what you want, write (double gate):
GO=1 IN_WINDOW_ACK=Y bash .scratch/changes/2026-11-20-scan-staleness/apply.sh
# 4. Undo:
GO=1 IN_WINDOW_ACK=Y bash .scratch/changes/2026-11-20-scan-staleness/rollback.sh
```

Step 3 re-reads live bytes and aborts before any write if they moved; a drift abort is not a failure to
force, it means another session changed the prompt and §9.1 must be re-run first. A rollback is itself a
write into a window and consumes its slot again, and no API restores `created_at`/`updated_at`.
**Acceptance, on the first SCAN after the apply that produces a Sleeve A signal:** the researcher JSON
carries `re_quote_et`; the coordinator either routes it within 5 minutes of its own receipt time or names
it in the three-line summary; and a Sleeve C ticket routes exactly as it did before the change. If a SCAN
produces no signal, that is not evidence either way — wait for one that does.

## 9.7 Not settled by either session [undiscoverable]

- Whether either wording would actually have saved the `10:17` SQQQ/SPXS pair. Both add a re-quote at
  emit; the 10:26 re-quote of that same idea already failed `trend_signal.py:171`/`:192`, so a fresh
  print can equally confirm the NONE. Only a live SCAN with a Sleeve A signal answers it (15–21 credits).
- How the 21m47s round trip divides between researcher compute and scheduling. Neither session
  instrumented a live run.
- The residual latency stays: this is a correctness fix, not a speed fix, and the auditor and executor
  legs are untouched by either proposal.
- Sleeve C remains unprotected by freshness in both proposals, deliberately — `chop.py` inspects no
  timestamps and this task adds none.
- Chase risk is unchanged and shared: a fresh number can confirm a chase. Both wordings mitigate it the
  same way (re-run `signal()`, so a moved price fails the extension cap or R/R on its own).

## 9.8 Recommendation

The eligibility answer in §9.2 should be adopted regardless of which text is chosen — it is a reading of
DRIVER §6.4 that the desk has already applied once on the same facts, and the alternative permits two
unattributable researcher changes in front of one BRIEF. On the wording, prefer §9.4 over §4, because
§4.2's test depends on an instant the coordinator cannot observe and §4.1 defines no field for the stamp
that §4.2 then routes on. If the owner prefers §4's shorter phrasing, at minimum change "when the auditor
receives it" to the coordinator's own receipt time and name the stamp key in the tuple.
