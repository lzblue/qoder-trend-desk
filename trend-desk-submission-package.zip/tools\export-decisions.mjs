#!/usr/bin/env node
// Export the desk's decision/fill/equity evidence out of Forward session events into
// repo files, because the skill ledger lives in a per-session sandbox that does not
// survive the run. Reads only; writes under logs/.
//
//   node tools/export-decisions.mjs            # extract from cache (no API calls)
//   node tools/export-decisions.mjs --fetch    # refresh the event cache first
//
import fs from 'node:fs';
import path from 'node:path';

const ROOT = path.resolve(import.meta.dirname, '..');
const RAW = path.join(ROOT, '.scratch', 'raw-events');
const OUT = path.join(ROOT, 'logs');
const BASE = 'https://api.qoder.com/api/v1/forward';

const TEMPLATES = {
  coordinator: 'tmpl_19f984c8f0fd516965b63998',
  researcher: 'tmpl_d7df3829ed5d73548bb5e9ed',
  executor: 'tmpl_6c3c42cc4500efcbd6d60309',
  risk_auditor: 'tmpl_bf2c477c0fba1a3363833f91',
};

function pat() {
  const f = fs.readFileSync(path.join(ROOT, '.env'), 'utf8');
  const m = f.match(/^QODER_PAT=(\S+)/m);
  if (!m) throw new Error('QODER_PAT not found in .env');
  return m[1];
}
const TOKEN = pat();

async function req(p, tries = 3) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(BASE + p, { headers: { Authorization: `Bearer ${TOKEN}` } });
      const body = await r.text();
      let j;
      try { j = JSON.parse(body); } catch { return { __status: r.status, __bad_json: true, __head: body.slice(0, 160) }; }
      if (j.__raw || j.error) return { __status: r.status, __err: JSON.stringify(j).slice(0, 160) };
      if (!r.ok) return { __status: r.status, __err: body.slice(0, 160) };
      return j;
    } catch (e) {
      if (i === tries - 1) return { __status: 0, __throw: String(e).slice(0, 160) };
      await new Promise((res) => setTimeout(res, 1200 * (i + 1) * (i + 1)));
    }
  }
}

// A list call the API rejects comes back with no `data` key, which is indistinguishable
// from "no sessions" unless the status is checked first.
async function listSessions(templateId) {
  const out = [];
  for (const limit of [50, 20]) {
    const j = await req(`/sessions?template_id=${encodeURIComponent(templateId)}&limit=${limit}`);
    if (Array.isArray(j.data)) {
      if (j.data.length) console.log(`  list ${templateId.slice(0, 12)}.. limit=${limit} -> ${j.data.length}`);
      return j.data;
    }
    console.log(`  list limit=${limit} REJECTED (${j.__status} ${j.__err || j.__head || 'no data'}) — retrying smaller`);
  }
  return out;
}

// Forward's event paging, verified against the live API 2026-11-26: the envelope carries
// data/first_id/last_id/has_more and NO next_cursor, and the only cursor parameter the API
// accepts is after_id (`after`, `cursor`, `starting_after` are ignored and re-return page 1).
// The old `&after=` + next_cursor loop therefore re-fetched page 1 up to 30 times, so every
// cached session longer than 100 events was truncated to its first 100 — and the duplicates
// hid it. limit is capped at 100; more is an HTTP 400 with no data key.
async function pageEvents(url) {
  const all = [];
  const seen = new Set();
  let after = '';
  for (let page = 0; page < 30; page++) {
    const j = await req(url + (after ? `&after_id=${after}` : ''));
    const d = Array.isArray(j.data) ? j.data : null;
    if (!d) { console.log(`  events ${url} page ${page} REJECTED (${j.__status})`); break; }
    let fresh = 0;
    for (const ev of d) {
      if (!ev || !ev.id || seen.has(ev.id)) continue;
      seen.add(ev.id);
      all.push(ev);
      fresh++;
    }
    if (!j.has_more || !d.length || !fresh || !j.last_id) break;
    after = j.last_id;
  }
  return all;
}

async function listEvents(sessionId) {
  const top = await pageEvents(`/sessions/${sessionId}/events?limit=100`);
  // Guard verdicts, journal records and broker rows are produced in child threads; the
  // coordinator's own stream only carries its tool calls.
  const t = await req(`/sessions/${sessionId}/threads`);
  const threads = Array.isArray(t.data) ? t.data : [];
  const out = new Map(top.map((ev) => [ev.id, ev]));
  for (const th of threads.slice(0, 8)) {
    const tid = th.id || th.session_thread_id;
    if (!tid) continue;
    for (const ev of await pageEvents(`/sessions/${sessionId}/threads/${tid}/events?limit=100`)) {
      if (!out.has(ev.id)) out.set(ev.id, ev);
    }
  }
  return [...out.values()];
}

async function fetchCache(sessions) {
  fs.mkdirSync(RAW, { recursive: true });
  let done = 0;
  const queue = sessions.slice();
  async function worker() {
    while (queue.length) {
      const s = queue.shift();
      const file = path.join(RAW, `${s.id}.jsonl`);
      if (!fs.existsSync(file) || process.env.FORCE) {
        const evs = await listEvents(s.id);
        fs.writeFileSync(file, evs.map((e) => JSON.stringify(e)).join('\n') + '\n');
      }
      done++;
      if (done % 20 === 0) console.log(`  cached ${done}/${sessions.length} sessions`);
    }
  }
  await Promise.all(Array.from({ length: 6 }, worker));
  console.log(`event cache: ${done} sessions`);
}

function textOf(ev) {
  const bits = [];
  const walk = (v) => {
    if (typeof v === 'string') bits.push(v);
    else if (Array.isArray(v)) v.forEach(walk);
    else if (v && typeof v === 'object') Object.values(v).forEach(walk);
  };
  // Walk the whole event: `payload` is sometimes an empty object, which `??` would
  // treat as present and stop at, silently losing the text under `content`/`data`.
  walk(ev);
  return bits.join('\n');
}

const VERDICT_RE = /"(?:approved|admissible)"\s*:/;
const CSV_HEAD = /^(et_date,nav,spy_close|et_date,sleeve,ticker)/m;

function extract(sessions) {
  const decisions = [], orders = [], fills = [], closes = [], errors = [];
  const equity = new Map(), closesCsv = new Map();
  const typeCount = new Map();

  for (const s of sessions) {
    const file = path.join(RAW, `${s.id}.jsonl`);
    if (!fs.existsSync(file)) continue;
    const evs = fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l));
    for (const ev of evs) {
      const t = ev.type || ev.event_type || 'unknown';
      typeCount.set(t, (typeCount.get(t) || 0) + 1);
      // Two layers of escaping are common (a JSON string inside a JSON string), so drop
      // doubled backslashes first, then turn the remaining literal \n into a real newline.
      const txt = textOf(ev).replace(/\\\\/g, '').replace(/\\r/g, '').replace(/\\n/g, '\n')
        // The journal is read back through the Read tool, so every line arrives prefixed
        // with its line number and a tab; that alone defeats every line anchor.
        .replace(/^\s*\d+\t/gm, '');
      if (txt.length > 300_000) continue;
      const stamp = { session_id: s.id, template: s._agent, session_created_at: s.created_at, event_id: ev.id, event_type: t, at: ev.created_at || ev.processed_at || null };

      if (VERDICT_RE.test(txt)) for (const m of txt.matchAll(/\{[^{}]*"(?:approved|admissible)"[^{}]*\}/g)) {
        try { decisions.push({ ...stamp, record: JSON.parse(m[0]) }); } catch { /* nested; skip */ }
      }
      if (CSV_HEAD.test(txt)) for (const line of txt.split('\n')) {
        if (/^20\d\d-\d\d-\d\d,/.test(line)) {
          const f = line.split(',');
          if (f.length >= 12) equity.set(f[0], line);
          else closesCsv.set(`${f[0]}|${f[1]}|${f[2]}`, line);
        }
      }
      // `"order_id":"3401916"` — quote and colon sit between key and value, so match
      // on "whatever non-digits come next" instead of a fixed `:` separator.
      const om = txt.match(/order(?:_id)?[^0-9]{0,6}\d{6,9}/gi);
      if (om) {
        const ids = [...new Set(om.map((x) => x.match(/(\d{6,9})/)[0]))];
        // A fill needs a fill receipt, not just the word "fill" near a number: the
        // broker's own rows carry avg_fill_price/cum_qty.
        const isFill = /avg_fill_price[^0-9\-]{0,4}\d|cum_qty[^\d]{0,4}[1-9]/i.test(txt);
        if (isFill) fills.push({ ...stamp, order_ids: ids, excerpt: txt.replace(/\s+/g, ' ').match(/.{0,150}(avg_fill_price|cum_qty).{0,150}/)?.[0] || '' });
        else if (/submit|place|cancel/i.test(txt)) orders.push({ ...stamp, order_ids: ids, excerpt: txt.replace(/\s+/g, ' ').slice(0, 200) });
      }
      if (/Traceback|ret_code['"]?\s*:\s*-|ERROR|error_i18n/.test(txt)) {
        const flat = txt.replace(/\s+/g, ' ');
        const hit = flat.match(/.{0,200}(Traceback|ret_code|ERROR|error_i18n).{0,200}/);
        errors.push({ ...stamp, excerpt: hit ? hit[0] : flat.slice(0, 200) });
      }
    }
  }
  return { decisions, orders, fills, closes, errors, equity, closesCsv, typeCount };
}

fs.mkdirSync(OUT, { recursive: true });
const sessions = [];
for (const [name, id] of Object.entries(TEMPLATES)) {
  console.log(`template ${name}`);
  for (const s of await listSessions(id)) sessions.push({ ...s, _agent: name });
}
sessions.sort((a, b) => String(a.created_at).localeCompare(String(b.created_at)));
console.log(`sessions listed: ${sessions.length}`);

if (process.argv.includes('--fetch')) await fetchCache(sessions);
else if (!fs.existsSync(RAW)) throw new Error(`no event cache at ${RAW} — run with --fetch first`);

const x = extract(sessions);
// The same tool output surfaces in the coordinator's session and in the agent thread it
// drives; a counted-twice verdict reads as two decisions.
const write = (name, rows) => {
  const seen = new Set();
  const uniq = rows.filter((r) => {
    const k = JSON.stringify({ ...r, session_id: 0, event_id: 0, event_type: 0, at: 0, session_created_at: 0 });
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
  fs.writeFileSync(path.join(OUT, name), uniq.map((r) => JSON.stringify(r)).join('\n') + '\n');
  return uniq.length;
};

write('decisions.jsonl', x.decisions);
write('fills.jsonl', x.fills);
write('orders.jsonl', x.orders);
write('errors.jsonl', x.errors);
fs.writeFileSync(path.join(OUT, 'equity.csv'), [...x.equity.values()].sort().join('\n') + '\n');
fs.writeFileSync(path.join(OUT, 'closes.csv'), [...x.closesCsv.values()].sort().join('\n') + '\n');

console.log('--- event type distribution (top 15) ---');
for (const [t, n] of [...x.typeCount].sort((a, b) => b[1] - a[1]).slice(0, 15)) console.log(`${n}\t${t}`);
console.log(`decisions=${x.decisions.length} fills=${x.fills.length} orders=${x.orders.length} errors=${x.errors.length} equity_rows=${x.equity.size} close_rows=${x.closesCsv.size}`);
console.log('equity:'); for (const [, line] of [...x.equity].sort()) console.log('  ' + line);
