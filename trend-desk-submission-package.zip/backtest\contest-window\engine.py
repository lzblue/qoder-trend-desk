"""Live-faithful Sleeve A execution backtest (P1.6/P1.7).

Nothing here re-decides what the desk decides: signals come from the live trend_signal
module, size and fees from live guard.py's rules.json arithmetic, and the fill-anchored
levels from desk_sleeves_v2.levels_from_fill. This file supplies only the broker
simulation (matching, timing, monitoring) that no live component contains.

Variant axes (2x2 so each defect's cost is attributable on its own):
  anchor   signal = today's live path: levels anchored on the signal-time price
           fill   = design path: levels_from_fill() on the actual fill
  protect  next_check = no protective stop survives the run boundary, so an open position
                        is closed at the next scheduled run (tonight's real behaviour)
           monitored  = stop compared against a fresh quote at every run boundary
  vehicle  etf   = buy the 3x/2x inverse (live and design)
           short = short the underlying directly (engine-side comparison; live guard.py
                   vetoes stop-above-entry, so shorts are NOT expressible as shipped)
"""
import json
import math
import os
import sys
import datetime as dt

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, "mounted"))

import mkdata                    # noqa: E402
import trend_signal as ts        # noqa: E402  live signal engine
import desk_sleeves_v2 as dv2    # noqa: E402  authoritative design logic

RULES = json.loads(open(os.path.join(HERE, "mounted", "rules.json"), encoding="utf-8").read())
TICKERS = ["QQQ", "SMH", "SPY"]
SCANS = ["10:05", "11:00", "12:30", "14:00"]
FLAT_AT = "15:45"
OPEN_AT = "09:30"
NAV0 = RULES["competition"]["starting_nav"]
LADDER_STEP, LADDER_CAP_PCT, LADDER_MIN = 0.01, 0.2, 10
ENTRY_TOL_PCT = 0.10  # desk_sleeves_v2: 0.10% through the market for equities


def mins(s):
    h, m = s.split(":")
    return int(h) * 60 + int(m)


def _tzoff(bar):
    """UTC offset for a bar. The merged store carries no time_zone field, and this
    window crosses the 2026-11-01 DST end: assuming one offset stamps every October
    session an hour early, which the alignment guard then reads as 'does not start at
    the open' and silently drops the entire extension."""
    if "time_zone" in bar:
        return bar["time_zone"]
    try:
        from zoneinfo import ZoneInfo
        utc = dt.datetime.fromtimestamp(bar["time_key"] / 1000.0, dt.timezone.utc)
        return int(utc.astimezone(ZoneInfo("America/New_York")).utcoffset().total_seconds() // 3600)
    except Exception:
        raise SystemExit("cannot resolve the exchange UTC offset for %s: install tzdata "
                         "rather than trusting a hardcoded -5" % bar["time_key"])


def stamp_of(bar):
    tz = _tzoff(bar)
    return (dt.datetime.fromtimestamp(bar["time_key"] / 1000.0, dt.timezone.utc)
            + dt.timedelta(hours=tz)).strftime("%H:%M")


def fee_side(qty):
    f = RULES["fees"]
    return f["stock_platform_fee_per_order"] + min(
        f["stock_transaction_fee_per_share"] * qty, f["stock_transaction_fee_cap"])


def lev_of(instrument):
    return RULES["universe"]["leverage"].get(instrument, 1)


def size_long(nav, cash, book, entry, stop, instrument, mult):
    """guard.py:198-211 verbatim: risk-per-trade size, then four caps, take the binding min."""
    rk, comp = RULES["risk"], RULES["competition"]
    dist = entry - stop
    if dist <= 0:
        return 0, "stop must be below entry for a BUY"
    qty = math.floor(nav * rk["trade_risk_pct"] / 100 * mult / dist)
    cap = nav * comp["single_asset_target_pct"] / 100
    cur = sum(p["mv"] for p in book if p["instrument"] == instrument)
    q_cap = math.floor(max(cap - cur, 0) / entry)
    eff_now = sum(p["mv"] * lev_of(p["instrument"]) for p in book)
    q_gross = math.floor(max(nav * rk["max_effective_gross_pct"] / 100 - eff_now, 0)
                         / (entry * lev_of(instrument)))
    q_cash = math.floor(max(cash - nav * rk["min_cash_pct"] / 100, 0) / entry)
    open_risk = sum(p["qty"] * (p.get("risk_share") or abs(p["fill"] - p["stop"])) for p in book)
    q_risk = math.floor(max(nav * rk["max_open_risk_pct"] / 100 - open_risk, 0) / dist)
    binding = min((qty, "risk per trade"), (q_cap, "35% single-asset target"),
                  (q_gross, "effective gross cap"), (q_cash, "10% cash floor"),
                  (q_risk, "open risk cap"))
    return binding[0], binding[1]


class Sim:
    """One simulation over the available sessions; positions are always flat by 15:45."""

    def __init__(self, entry, anchor, protect, vehicle, cadence=30, latency=11):
        self.entry, self.anchor, self.protect, self.vehicle = entry, anchor, protect, vehicle
        self.cadence, self.latency = cadence, latency
        self.trades, self.rejected = [], []
        self.cash, self.nav = NAV0, NAV0

    # -- portfolio marks -----------------------------------------------------------
    def nav_now(self, book):
        v = self.cash
        for p in book:
            v += p["mv"] if p["dir"] > 0 else -p["mv"]
        return v

    def _mark(self, book, px):
        for p in book:
            p["mv"] = p["qty"] * px[p["instrument"]]

    # -- one session ---------------------------------------------------------------
    def run_day(self, day, bars, reg):
        ref = bars[TICKERS[0]]
        n = min(len(b) for b in bars.values())
        stamps = [stamp_of(ref[i]) for i in range(n)]

        def at(target):
            return next((i for i in range(n) if mins(stamps[i]) >= target), None)

        # An early-close session is a different trading day, not a short full one, and
        # rules.json carries its own timings. The session length is taken from the bars
        # themselves, so this never needs a holiday table.
        T = RULES["timing"]
        half = mins(stamps[-1]) < 15 * 60 + 55
        flat_at = T["half_day_flat_by_et"] if half else T["flat_by_et"]
        entry_end = mins(T["half_day_entry_end_et"] if half else T["entry_end_et"])
        scans = [s for s in SCANS if mins(s) <= entry_end]
        scan_i = {s: at(mins(s)) for s in scans}
        entry_i = {s: at(mins(s) + self.latency) for s in scans}
        flat_i = at(mins(flat_at))
        close_i = set()
        for b in self._boundaries(stamps, flat_at):
            i = at(mins(b) + self.latency)
            if i is not None:
                close_i.add(i)
        if flat_i is not None:
            close_i.add(flat_i)

        book, families_today = [], set()
        for i in range(n):
            px = {t: bars[t][i]["close"] for t in bars}
            self._mark(book, px)

            # 1. scheduled exits first (CLOSE_SEQUENCE step 1 cancels the working take-profit)
            if i in close_i:
                for p in list(book):
                    why = None
                    if i == flat_i:
                        why = "flat_by %s" % flat_at
                    elif self.protect == "next":
                        why = "unmonitored: no recorded stop level -> close at next check"
                    else:
                        last = px[p["instrument"]]
                        if (p["dir"] > 0 and last <= p["stop"]) or (p["dir"] < 0 and last >= p["stop"]):
                            why = "stop breached at monitor check"
                    if why:
                        self._close(day, p, px[p["instrument"]], stamps[i], why, book)

            # 2. resting take-profit limits fill on touch, on every bar
            for p in list(book):
                b = bars[p["instrument"]][i]
                if (p["dir"] > 0 and b["high"] >= p["tp"]) or (p["dir"] < 0 and b["low"] <= p["tp"]):
                    self._close(day, p, self._touch(b, p["tp"], -p["dir"]),
                                stamps[i], "take_profit", book)

            # 3. new entries
            for s, tgt in entry_i.items():
                if tgt != i:
                    continue
                self._entries(day, s, scan_i[s], i, bars, px, stamps, book, families_today, reg)
        for p in list(book):
            self._close(day, p, px[p["instrument"]], stamps[-1], "session_end_forced", book)

    def _boundaries(self, stamps, flat_at):
        if self.protect == "next":
            return list(SCANS)
        out, t = set(), mins(OPEN_AT) + self.cadence
        while t <= mins(flat_at):
            near = next((s for s in stamps if mins(s) >= t), None)
            if near:
                out.add(near)
            t += self.cadence
        return sorted(out)

    def _entries(self, day, scan, i_scan, i_exec, bars, px, stamps, book, families_today, reg):
        for t in TICKERS:
            summ = mkdata.derive_session(bars[t], scan)
            if summ is None:
                continue
            summ.update({"ticker": t, "time_et": scan})
            if i_scan is not None and i_scan < len(bars[dv2.INVERSE[t]]):
                summ["inverse_price"] = bars[dv2.INVERSE[t]][i_scan]["close"]
            sig = ts.signal(summ, reg)
            if sig["action"] == "NONE":
                continue
            res = (self._enter_short(day, t, sig, bars, i_exec, stamps, book, families_today, reg)
                   if (self.vehicle == "short" and sig["action"] == "SHORT")
                   else self._enter_etf(day, t, sig, bars, i_exec, stamps, book, families_today, reg))
            if res.get("entered"):
                return  # at most ONE new position per scan (coordinator rule)
            if res.get("why"):
                self.rejected.append([day, scan, t, sig["action"], res["why"]])

    # -- entry paths ---------------------------------------------------------------
    def _levels(self, sig_entry, sig_stop, sig_target, fill):
        """(stop, tp, entry_used_for_sizing).

        guard.py:195 takes dist from the TICKET (entry - stop), so that is what sizes
        the order even when the fill lands somewhere else; at signal anchor the fill
        moving while the levels stay is the anchoring defect itself, and it shows up in
        the dollars, not in the size.
        """
        r = abs(sig_entry - sig_stop)
        if self.anchor == "fill":
            lv = dv2.levels_from_fill(fill, r)
            return lv["stop"], lv["tp_limit"], fill
        return sig_stop, sig_target, sig_entry

    def _enter_etf(self, day, t, sig, bars, i_exec, stamps, book, families_today, reg):
        inst = sig["instrument"]
        intent = {"family": t, "dir": 1, "kind": "equity"}
        open_ex = [{"family": p["family"], "dir": p["dir"], "kind": "equity"} for p in book]
        ok, why = dv2.portfolio_gate(intent, open_ex, families_today)
        if not ok:
            return {"why": "gate: " + why}
        b = bars[inst]
        fill, fstamp = self._buy_limit(b, sig["entry"], i_exec)
        if fill is None:
            return {"why": "no fill within %d min of the ladder" % LADDER_MIN}
        stop, tp, entry_ref = self._levels(sig["entry"], sig["stop"], sig["target"], fill)
        qty, binding = size_long(self.nav_now(book), self.cash, book, entry_ref, stop, inst,
                                 reg["size_mult"])
        if qty < 1:
            return {"why": "size zero (%s)" % binding}
        book.append({"family": t, "instrument": inst, "dir": 1, "qty": qty, "fill": fill,
                     "stop": stop, "tp": tp, "mv": qty * fill, "fee_in": fee_side(qty),
                     "opened": fstamp, "sig_entry": sig["entry"], "action": sig["action"],
                     "risk_share": abs(entry_ref - stop)})
        families_today.add(t)
        self.cash -= qty * fill
        return {"entered": True}

    def _enter_short(self, day, t, sig, bars, i_exec, stamps, book, families_today, reg):
        u = sig["underlying"]
        intent = {"family": t, "dir": -1, "kind": "equity"}
        open_ex = [{"family": p["family"], "dir": p["dir"], "kind": "equity"} for p in book]
        ok, why = dv2.portfolio_gate(intent, open_ex, families_today)
        if not ok:
            return {"why": "gate: " + why}
        b = bars[t]
        fill, fstamp = self._sell_limit(b, u["price"], i_exec)
        if fill is None:
            return {"why": "short not filled within %d min" % LADDER_MIN}
        dist = abs(u["stop"] - u["price"])
        if self.anchor == "fill":
            stop, entry_ref = fill + dist, fill
            tp = round(fill - 1.5 * dist, 2)
        else:
            stop, tp, entry_ref = u["stop"], u["target"], u["price"]
        # live size_long() vetoes stop-above-entry, so the short reuses the same arithmetic
        # on the mirrored distance; caps other than risk-per-trade are unchanged.
        qty, binding = self._size_short(self.nav_now(book), book, entry_ref, stop, t,
                                        reg["size_mult"])
        if qty < 1:
            return {"why": "size zero (%s)" % binding}
        book.append({"family": t, "instrument": t, "dir": -1, "qty": qty, "fill": fill,
                     "stop": stop, "tp": tp, "mv": qty * fill, "fee_in": fee_side(qty),
                     "opened": fstamp, "sig_entry": u["price"], "action": "SHORT",
                     "risk_share": abs(entry_ref - stop)})
        families_today.add(t)
        self.cash += qty * fill
        return {"entered": True}

    def _size_short(self, nav, book, entry, stop, instrument, mult):
        rk, comp = RULES["risk"], RULES["competition"]
        dist = stop - entry
        if dist <= 0:
            return 0, "stop must be above entry for a short"
        qty = math.floor(nav * rk["trade_risk_pct"] / 100 * mult / dist)
        cap = nav * comp["single_asset_target_pct"] / 100
        cur = sum(p["mv"] for p in book if p["instrument"] == instrument)
        q_cap = math.floor(max(cap - cur, 0) / entry)
        eff_now = sum(p["mv"] * lev_of(p["instrument"]) for p in book)
        q_gross = math.floor(max(nav * rk["max_effective_gross_pct"] / 100 - eff_now, 0) / entry)
        open_risk = sum(p["qty"] * (p.get("risk_share") or abs(p["fill"] - p["stop"])) for p in book)
        q_risk = math.floor(max(nav * rk["max_open_risk_pct"] / 100 - open_risk, 0) / dist)
        binding = min((qty, "risk per trade"), (q_cap, "35% single-asset target"),
                      (q_gross, "effective gross cap"), (q_risk, "open risk cap"))
        return binding[0], binding[1]

    # -- matching ------------------------------------------------------------------
    # A resting BUY limit fills on a dip (low reaches it); a SELL limit fills on a
    # rally (high reaches it). Fill price is the limit itself, never the better open,
    # so the model cannot flatter the desk.
    def _touch(self, bar, lim, side):
        """Fill price of a RESTING limit that is reached inside `bar`.

        The open is the first print, so it is all the information needed: if the bar
        opens on our side of the limit the order is already marketable and fills at the
        open; if it opens beyond the limit, price had to walk to it and we fill at the
        limit. Filling at the limit unconditionally is pessimistic for a buy that opened
        lower and optimistic for one that opened higher.
        """
        o = bar["open"]
        return min(lim, o) if side > 0 else max(lim, o)

    def _buy_limit(self, bars, ticket_entry, i_exec):
        if self.entry == "marketable":
            return self._marketable(bars, i_exec, +1)
        cap = round(ticket_entry * (1 + LADDER_CAP_PCT / 100), 2)
        n = len(bars)
        for off in range(LADDER_MIN):
            i = i_exec + off // 5
            if i >= n:
                break
            lim = min(round(ticket_entry + LADDER_STEP * off, 2), cap)
            if bars[i]["low"] <= lim:
                return self._touch(bars[i], lim, +1), stamp_of(bars[i])
        return None, None

    def _sell_limit(self, bars, ticket_px, i_exec):
        if self.entry == "marketable":
            return self._marketable(bars, i_exec, -1)
        floor_px = round(ticket_px * (1 - LADDER_CAP_PCT / 100), 2)
        n = len(bars)
        for off in range(LADDER_MIN):
            i = i_exec + off // 5
            if i >= n:
                break
            lim = max(round(ticket_px - LADDER_STEP * off, 2), floor_px)
            if bars[i]["high"] >= lim:
                return self._touch(bars[i], lim, -1), stamp_of(bars[i])
        return None, None

    def _marketable(self, bars, i_exec, side):
        """desk_sleeves_v2 entry: a limit through the market at order-ready time, so it
        matches now instead of waiting for a pullback. The fill is the market at that
        moment - the close of the order-ready bar. The half-spread a crossing order
        actually pays is NOT in the bar data and is therefore not charged here; it is
        listed as an unmodelled cost, not guessed. The 0.10% tolerance only ever acts as
        a ceiling/floor, so it cannot change the price, only reject a runaway market."""
        n = len(bars)
        if i_exec >= n or i_exec < 0:
            return None, None
        ref = bars[i_exec]["close"]
        lim = (dv2.marketable_buy_limit(ref, ENTRY_TOL_PCT) if side > 0
               else round(ref * (1 - ENTRY_TOL_PCT / 100), 2))
        px = min(ref, lim) if side > 0 else max(ref, lim)
        return round(px, 2), stamp_of(bars[i_exec])

    # -- exit ----------------------------------------------------------------------
    def _close(self, day, p, exit_px, at_stamp, why, book):
        qty = p["qty"]
        gross = (exit_px - p["fill"]) * qty * p["dir"]
        fee = p["fee_in"] + fee_side(qty)
        fin = 0.0
        if p["dir"] < 0:
            # financing accrues daily after close; the desk is flat by 15:45 the same
            # session, so the holding period is under one day and this stays zero.
            self.cash -= qty * exit_px
        else:
            self.cash += qty * exit_px
        pnl = gross - fee - fin
        self.nav += pnl
        # R denominator = the ticket's planned risk (what sizing was computed from), so a
        # fill that drifted from the entry cannot print an absurd R.
        r_unit = p.get("risk_share") or abs(p["fill"] - p["stop"]) or 1e-9
        book.remove(p)
        self.trades.append({"day": day, "family": p["family"], "instrument": p["instrument"],
                            "action": p["action"], "dir": "SHORT" if p["dir"] < 0 else "LONG",
                            "qty": qty, "fill": p["fill"], "exit": round(exit_px, 4),
                            "stop": p["stop"], "tp": p["tp"], "sig_entry": p["sig_entry"],
                            "r_unit": round(r_unit, 4),
                            "risk_at_fill": round(abs(p["fill"] - p["stop"]), 4),
                            "gross": round(gross, 2),
                            "fees": round(fee + fin, 2), "net": round(pnl, 2),
                            "R": round(pnl / (qty * r_unit), 3), "why": why,
                            "opened": p["opened"], "closed_at": at_stamp,
                            "nav_after": round(self.nav, 2)})


def metrics(trades):
    if not trades:
        return {"trades": 0}
    n = len(trades)
    curve, peak, dd = NAV0, NAV0, 0.0
    for t in trades:
        curve += t["net"]
        peak = max(peak, curve)
        dd = min(dd, curve - peak)
    return {"trades": n, "win_pct": round(100.0 * sum(1 for t in trades if t["net"] > 0) / n, 1),
            "avg_R": round(sum(t["R"] for t in trades) / n, 3),
            "net_usd": round(sum(t["net"] for t in trades), 2),
            "fees_usd": round(sum(t["fees"] for t in trades), 2),
            "maxDD_usd": round(dd, 2), "maxDD_pct": round(100.0 * dd / NAV0, 3),
            "sig_long": sum(1 for t in trades if t["action"] == "LONG"),
            "sig_short": sum(1 for t in trades if t["action"] == "SHORT"),
            "tp_exits": sum(1 for t in trades if t["why"] == "take_profit"),
            "stop_exits": sum(1 for t in trades if t["why"].startswith("stop")),
            "forced_exits": sum(1 for t in trades if t["why"].startswith("unmonitored")),
            "flat_exits": sum(1 for t in trades if t["why"].startswith("flat"))}


def _vname(entry, anchor, protect, vehicle):
    return "%s/%s/%s/%s" % (entry, anchor, protect, vehicle)


VARIANTS = []
for _entry in ("ladder", "marketable"):
    for _anchor in ("signal", "fill"):
        for _protect in ("next", "mon"):
            VARIANTS.append((_vname(_entry, _anchor, _protect, "etf"),
                             dict(entry=_entry, anchor=_anchor, protect=_protect, vehicle="etf")))
VARIANTS.append((_vname("ladder", "signal", "next", "short"),
                 dict(entry="ladder", anchor="signal", protect="next", vehicle="short")))
VARIANTS.append((_vname("marketable", "fill", "mon", "short"),
                 dict(entry="marketable", anchor="fill", protect="mon", vehicle="short")))

AS_RUN = _vname("ladder", "signal", "next", "etf")        # what runs tonight
DESIGN = _vname("marketable", "fill", "mon", "etf")       # what desk_sleeves_v2 specifies
AS_RUN_SHORT = _vname("ladder", "signal", "next", "short")
DESIGN_SHORT = _vname("marketable", "fill", "mon", "short")
# one axis moved at a time, everything else left at the live setting
ONLY_ENTRY = _vname("marketable", "signal", "next", "etf")
ONLY_ANCHOR = _vname("ladder", "fill", "next", "etf")
ONLY_PROTECT = _vname("ladder", "signal", "mon", "etf")


def week_of(day):
    y, m, d = int(str(day)[:4]), int(str(day)[4:6]), int(str(day)[6:8])
    iso = dt.date(y, m, d).isocalendar()
    return "%d-W%02d" % (iso[0], iso[1])


def session_stamps(bars_for_day, need):
    """Return the shared stamp timeline for one session, or (None, reason).

    Indexing instruments by bar position silently compares different clocks if any
    ticker's day is cut (observed: all six begin 11:15 on 20261111 because a page
    boundary ate the morning). So a day is traded only when every instrument has the
    SAME stamps, they start at the open, and they are contiguous at five minutes.
    Length is not pinned to 78: an early-close session is legitimately short, and the
    desk has its own half-day timings in rules.json.
    """
    maps = {t: {stamp_of(b): b for b in bars_for_day[t]} for t in need}
    common = sorted(set.intersection(*[set(m) for m in maps.values()]), key=mins)
    if not common or common[0] != "09:35":
        return None, "session does not start at the open (first common stamp %s)" % (
            common[0] if common else "none"), maps, common
    holes = [common[i] for i in range(1, len(common))
             if mins(common[i]) - mins(common[i - 1]) != 5]
    if holes:
        return None, "%d gap(s) in the shared timeline (first at %s)" % (
            len(holes), holes[0]), maps, common
    uneven = {t: len(maps[t]) for t in need if len(maps[t]) != len(common)}
    if uneven:
        return None, "instrument(s) out of step with the common timeline: %s" % uneven, maps, common
    return common, "ok", maps, common


def run(days=None, cadence=30, latency=11, tickers=None):
    global TICKERS
    if tickers:
        TICKERS = tickers
    allb = mkdata.load_all()
    regs = json.load(open(os.path.join(HERE, "regimes.json"), encoding="utf-8"))
    need = TICKERS + [dv2.INVERSE[t] for t in TICKERS]
    have = sorted(int(d) for d in regs if all(int(d) in allb.get(t, {}) for t in need))
    if days:
        have = [d for d in have if d in days]
    if not have:
        raise SystemExit("no overlapping sessions: bars have %s, regimes %s"
                         % (sorted({k for t in need if t in allb for k in allb[t]})[:8],
                            sorted(regs)[:8]))
    usable = []
    for d in have:
        day_bars = {t: allb[t][d] for t in need}
        stamps, why, _maps, _c = session_stamps(day_bars, need)
        if stamps is None:
            print("  drop %s: %s  [%s]" % (d, why,
                  " ".join("%s:%d" % (t, len(day_bars[t])) for t in need)))
            continue
        usable.append((d, {t: [_maps[t][s] for s in stamps] for t in need}))
    if not usable:
        raise SystemExit("no complete sessions survived the alignment check")
    out = {}
    for name, kw in VARIANTS:
        s = Sim(cadence=cadence, latency=latency, **kw)
        for d, bars in usable:
            s.run_day(d, bars, regs[str(d)]["regime"])
        out[name] = {"metrics": metrics(s.trades), "trades": s.trades, "rejected": s.rejected,
                     "params": dict(kw, cadence=cadence, latency=latency)}
    return [d for d, _ in usable], out


def main():
    have, out = run()
    json.dump({"sessions": have, "out": out},
              open(os.path.join(HERE, "sim_out.json"), "w", encoding="utf-8"), indent=1)
    g = lambda name: out[name]["metrics"].get("net_usd", 0.0)
    print("sessions simulated:", have)
    print("\n%-28s %-7s %-7s %-7s %-10s %-11s %-9s %s" % (
        "entry/anchor/protect/veh", "trades", "win%", "avg_R", "net$", "maxDD$", "fees$",
        "tp/stop/forced/flat"))
    for name, _ in VARIANTS:
        m = out[name]["metrics"]
        if not m.get("trades"):
            print("%-28s no trades (rejected %d)" % (name, len(out[name]["rejected"])))
            continue
        print("%-28s %-7d %-7s %-7s %-10s %-11s %-9s %s/%s/%s/%s" % (
            name, m["trades"], m["win_pct"], m["avg_R"], m["net_usd"], m["maxDD_usd"],
            m["fees_usd"], m["tp_exits"], m["stop_exits"], m["forced_exits"], m["flat_exits"]))
    print("\n  AS RUN (what runs tonight) = %-26s %+9.2f" % (AS_RUN, g(AS_RUN)))
    print("  DESIGN (sleeves_v2)        = %-26s %+9.2f" % (DESIGN, g(DESIGN)))

    print("\n=== cost of each defect ALONE: one axis moved, the other two left at live ===")
    print("entry  ladder -> marketable   : %+9.2f   [%s]"
          % (g(ONLY_ENTRY) - g(AS_RUN), ONLY_ENTRY))
    print("anchor signal -> fill         : %+9.2f   [%s]"
          % (g(ONLY_ANCHOR) - g(AS_RUN), ONLY_ANCHOR))
    print("stop   next-check -> monitored: %+9.2f   [%s]"
          % (g(ONLY_PROTECT) - g(AS_RUN), ONLY_PROTECT))
    print("all three (as-run -> design)  : %+9.2f" % (g(DESIGN) - g(AS_RUN)))

    print("\n=== same axes moved at the OTHER entry setting (interaction check) ===")
    mkt = _vname("marketable", "signal", "next", "etf")
    print("anchor at marketable entry    : %+9.2f   (ladder-entry equivalent %+9.2f)"
          % (g(_vname("marketable", "fill", "next", "etf")) - g(mkt),
             g(ONLY_ANCHOR) - g(AS_RUN)))
    print("stop   at marketable entry    : %+9.2f   (ladder-entry equivalent %+9.2f)"
          % (g(_vname("marketable", "signal", "mon", "etf")) - g(mkt),
             g(ONLY_PROTECT) - g(AS_RUN)))
    print("entry  at fill+monitored      : %+9.2f   (ladder-entry equivalent %+9.2f)"
          % (g(DESIGN) - g(_vname("ladder", "fill", "mon", "etf")),
             g(ONLY_ENTRY) - g(AS_RUN)))

    print("\n=== inverse ETF vs shorting the underlying (bearish signals) ===")
    print("as-run corner: etf %+9.2f | short %+9.2f | short - etf %+9.2f"
          % (g(AS_RUN), g(AS_RUN_SHORT), g(AS_RUN_SHORT) - g(AS_RUN)))
    print("design corner: etf %+9.2f | short %+9.2f | short - etf %+9.2f"
          % (g(DESIGN), g(DESIGN_SHORT), g(DESIGN_SHORT) - g(DESIGN)))

    print("\n=== per week (net$ / trades) ===")
    weeks = sorted({week_of(t["day"]) for name in (AS_RUN, DESIGN)
                    for t in out[name]["trades"]})
    print("%-28s %s" % ("variant", " ".join("%-13s" % w for w in weeks)))
    for name in (AS_RUN, ONLY_ENTRY, ONLY_ANCHOR, ONLY_PROTECT, DESIGN):
        row = ["%+9.2f/%d" % (sum(t["net"] for t in out[name]["trades"]
                                   if week_of(t["day"]) == w),
                              sum(1 for t in out[name]["trades"] if week_of(t["day"]) == w))
               for w in weeks]
        print("%-28s %s" % (name, " ".join("%-13s" % r for r in row)))

    print("\n=== per ticker ===")
    for name in (AS_RUN, DESIGN):
        print(" ", name, "trades", out[name]["metrics"].get("trades", 0),
              "rejected", len(out[name]["rejected"]))
        for t in TICKERS:
            sub = [x for x in out[name]["trades"] if x["family"] == t]
            if sub:
                print("    %-5s %s" % (t, json.dumps(metrics(sub))))

    print("\n=== rejection reasons ===")
    from collections import Counter
    for name, _ in VARIANTS:
        c = Counter(r[4].split(" (")[0] for r in out[name]["rejected"])
        if c:
            print("  %-28s %s" % (name, dict(c)))


if __name__ == "__main__":
    main()
