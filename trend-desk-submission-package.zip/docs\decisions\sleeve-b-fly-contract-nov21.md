# Sleeve B iron-fly — frozen C1 ↔ C2 JSON contract

Frozen 2026-11-21 (Sat, ET day 2026-11-21) by the Desktop build session, before any C1 or C2
code was written. Nothing here is applied to the cloud.

Why it is frozen first: C1 (`option-adapter/scripts/sleeve_b.py`) writes the proposal, C2
(`desk-risk-guard/scripts/guard.py`) reads it, and every test either side writes is worthless if
the two ends disagree about a key name. The brief's field list is honoured except where it names
a key guard.py cannot read — those deviations are in §9, each labelled.

Claim labels used throughout (handover §5.1): **OBSERVED** (read off a live payload or a real
file), **DOCUMENTED** (a doc/schema says so), **INFERRED** (reasoned from evidence, not proven),
**UNDISCOVERABLE** (no read available that would settle it).

---

## 1. Vocabulary (closed set — no new strings)

| field | allowed values | notes |
|---|---|---|
| `sleeve` | `"B"` | **only** when `kind == "iron_fly"`. The legacy single-leg path keeps `sleeve: "option"`, `kind: "option"` unchanged, so the published v4 behaviour is not disturbed. |
| `kind` | `"share"` (default), `"option"`, `"iron_fly"` | `guard.py:122` `kind = proposal.get("kind", "share")` is the branch driver; the fly branch is taken when `kind == "iron_fly"`. |
| `venue` | `"SPY"` \| `"SPXW"` | D1's rule result. Not a guard input; carried for the record. |
| `action` (C1 output) | `"BUY_TO_OPEN"` \| `"NONE"` \| `"STATE_UNAVAILABLE"` | unchanged from v4 `sleeve_b.py:77,84,592`. D3's "qty 0 ⇒ `no_trade`" is expressed as `action: "NONE"` + `reason: "no_trade ..."`, **not** a fourth action — see §9-D4. |
| `right` (leg) | `"C"` \| `"P"` | OSI letter, matches `parse_osi`. |
| `side` (leg) | `"BUY_TO_OPEN"` \| `"SELL_TO_OPEN"` | **not** `"BUY"`/`"SELL"`: `moomoo.quote_combo_option_quote` requires `side ∈ {"BUY","SELL"}`, so `to_combo_request()` maps it. Using a different word in the two spaces is deliberate — the leg records desk intent, the request records API enum. |
| `order_side` (ticket) | `1` buy, `2` sell | **OBSERVED only for buys.** `TICKET_TEMPLATE` (`sleeve_b.py:57`) hardcodes `order_side: 1`. SELL_TO_OPEN = 2 is INFERRED from order rows' `side` values 1/2 and is exactly what D8/U1 exists to prove. Do not let it into the cloud before U1 passes. |

`"STOP"` never appears in any emitted field — no stop order exists on this account (handover §6).

## 2. Structure proposal — C1 → C2

One object, one file. Fixture (drives both test suites):
`.scratch/changes/2026-11-22-sleeveb-fly/schema/fly-proposal.example.json`.

```jsonc
{
  "sleeve": "B", "kind": "iron_fly", "ticker": "SPY", "underlying": "SPY",
  "venue": "SPY", "expiry": "2026-11-23", "dte": 0, "now": "2026-11-23T10:12:00-05:00",

  "legs": [
    {"seq": 1, "code": "US.SPY261123P682000", "right": "P", "strike": 682.0,
     "side": "BUY_TO_OPEN",  "qty": 1, "bid": 0.70, "ask": 0.75, "offset": -9.0},
    {"seq": 2, "code": "US.SPY261123P691000", "right": "P", "strike": 691.0,
     "side": "SELL_TO_OPEN", "qty": 1, "bid": 3.75, "ask": 3.85, "offset": 0.0},
    {"seq": 3, "code": "US.SPY261123C691000", "right": "C", "strike": 691.0,
     "side": "SELL_TO_OPEN", "qty": 1, "bid": 3.60, "ask": 3.70, "offset": 0.0},
    {"seq": 4, "code": "US.SPY261123C700000", "right": "C", "strike": 700.0,
     "side": "BUY_TO_OPEN",  "qty": 1, "bid": 0.68, "ask": 0.73, "offset": 9.0}
  ],

  "atm_strike": 691.0, "width": 9.0, "em": 8.72, "iv": 0.212, "spot": 690.85,
  "credit": 5.82, "debit_at_ask": 6.06, "max_loss_per_lot": 318.0,
  "qty": 2, "orders_planned": 6, "orders_if_stopped": 8,
  "size_basis": "max_loss", "fee_model": "moomoo_page_s8_per_order",
  "regime_gate": {"move_1000_1030": 1.10, "range_1000_1030": 2.40, "threshold": 1.89, "pass": true},
  "book": {"all_legs_two_sided": true, "empty_legs": []},
  "iv_source": "atm_combo", "dte_source": "osi_expiry",
  "note": "Sleeve B 0DTE iron fly. credit from the combo bid; sizes on max loss, not premium."
}
```

| key | type | guard.py reads it? | authority / source |
|---|---|---|---|
| `sleeve`, `kind`, `ticker`, `underlying` | str | **yes** | `:120`, `:121` (KeyError if absent), `:122`, `:194` |
| `expiry` | `"YYYY-MM-DD"` | no (cross-check) | the chosen expiry; `dte` derived from it |
| `dte` | int, **must equal 0** | yes, in the fly branch | recomputed from the OSI expiry against `rules["structure"]["dte"]`; `expiry_date_distance` is present on live rows and is *not* trusted (same rule as v4 `SKILL.md:140-142`) |
| `now` | ISO-8601 with offset | no — `--now` is the CLI authority | carried so the record is self-describing; guard uses `args.now` |
| `legs` | array, **exactly 4** | yes | C1 `build_fly` ①②③④ (§4) |
| `legs[].seq` | int 1-4 | yes (shape only) | the fill order from source-of-truth §4 |
| `legs[].code` | OSI `US.{T}{YYMMDD}{C/P}{strike×1000}` (5-8 digits) | yes | `parse_osi`/`build_osi` (`sleeve_b.py:96-118`) |
| `legs[].right`, `strike`, `qty` | str, float, int | **yes — verified, not trusted** | §5 check (c) |
| `legs[].side` | see §1 | **yes** | (c) + (f) |
| `legs[].bid`, `ask` | float ≥ 0 or null | no | per-leg `quote_stock_quote`/`quote_order_book` — **OBSERVED**: the combo tool returns no per-leg bid/ask (it echoes leg 1), so per-leg prices come from a separate read |
| `legs[].offset` | float | no | signed strike − `atm_strike`; audit of D2 (0.0 on both shorts, ±`width` on the wings) |
| `atm_strike`, `spot` | float | no | `atm_strike` = strike closest to the underlying's last (ties → higher) |
| `width` | float > 0 | **yes** | D2: `round_to_grid(em)`, grid 5.00 SPXW / 1.00 SPY (`rules["strike_grid"]`). Never a fixed point count. |
| `em` | float | yes (warning if `width < em`) | D2 formula, `minutes_to_close` from `rules["structure"]["minutes_to_close_et"]` |
| `iv` | float, fraction | **yes** — must be > 0, else no width exists | ATM combo mid IV; never the 162–209 % 0DTE junk from `option_ex_data` (§9-D7) |
| `credit` | float ≥ 0 | **yes** | combo **bid** (`sell_to_open_mid.bid_price`) — "credit from the live combo quote bid side" |
| `debit_at_ask` | float ≥ 0 | **yes** | combo **ask** — the fill worst case; `width − debit_at_ask` bounds the loss before slippage |
| `max_loss_per_lot` | float > 0 | **yes — the denominator** | `(width − credit) × 100` |
| `qty` | int ≥ 1 | yes (guard re-derives it) | D3: `floor(structure.max_loss_pct_of_nav × nav / 100 / max_loss_per_lot)` |
| `orders_planned`, `orders_if_stopped` | int ≥ 1 | **yes** (fee × orders; order budget) | planned path 4 open + 2 buy-back = 6; stop path 4 + 4 = 8 |
| `size_basis` | `"max_loss"` | yes — guard refuses anything else | the whole point of C2: no premium sizing on a credit structure |
| `fee_model` | string id | yes — guard refuses an unknown id | `"moomoo_page_s8_per_order"` = `max(1.99, 0.65n) + 0.318n` per order |
| `regime_gate` | object | **yes** — `pass` must be boolean true | D4, §7 |
| `book.all_legs_two_sided`, `book.empty_legs` | bool, array | **yes** — false ⇒ veto | D1: "price legs off last when the book is empty" is a Never item |
| `iv_source`, `dte_source` | string | no | provenance, fail-closed style |
| `note` | string | no | free text, never parsed |

**Guard declines the fly branch — before any sizing — when:** `legs` is missing/not a list/length
≠ 4; two legs share a `code`; `seq` is not exactly `{1,2,3,4}`; `right ∉ {C,P}` or a right
disagrees with `parse_osi(code)`; `strike ≤ 0`; `qty < 1`; a leg's `side` is not a parseable
number or its sign disagrees with `parse_osi(code)` (`parse_osi` returns a signed strike — §9-D1);
leg quantities are not all equal; leg expiries are not all equal to `expiry`; `dte` ≠ 0; `width`,
`credit`, `debit_at_ask` or `max_loss_per_lot` missing/non-numeric/negative; `max_loss_per_lot ≤ 0`
(that is a negative-width structure, i.e. a mis-price); `iv ≤ 0`; `size_basis ≠ "max_loss"`;
`fee_model` unknown; `sleeve ≠ "B"`; `regime_gate.pass` is not boolean `true`;
`book.all_legs_two_sided` is not boolean `true`.

Each reason string is exactly `"iron_fly: " + what is wrong` so the coordinator cannot mistake a
malformed structure for a market veto. Every other guard rule (account `:139-145`, calendar and
entry window `:148-162`, ladder `:165-167`, order budget `:180-183`, universe `:194`) applies
**before** the fly branch, unchanged.

## 3. Fly verdict — C2 → C1/coordinator (guard's own output keys)

```jsonc
{"approved": true, "reasons": ["ok"], "warnings": [],
 "qty": 3, "lots": 3, "max_loss_usd": 585.0, "max_loss_pct_of_nav": 0.585,
 "credit_usd": 915.0, "risk_usd": 585.0, "fees_usd": 13.85,
 "orders_planned": 6, "size_mult": 1.0, "size_basis": "max_loss",
 "drawdown_pct": 0.0, "day_loss_pct": 0.0, "state": "normal", "time_et": "2026-11-23 10:12",
 "sleeve": "B", "kind": "iron_fly", "underlying": "SPY", "venue": "SPY", "expiry": "2026-11-23",
 "width": 5.0, "credit": 3.05, "debit_at_ask": 3.32, "max_loss_per_lot": 195.0, "iv": 0.212,
 "legs": [ ... echoed verbatim ... ],
 "order": {"type": "LEGGED_IRON_FLY", "mode": "combo_or_legged", "legs": [ ...ticket field sets... ]},
 "protection": {"max_loss_per_lot": 195.0, "max_loss_usd": 585.0,
                "mechanism": "monitored",
                "exit_targets": {"target_credit_pct": 25.0, "stop_credit_pct": 50.0,
                                 "shorts_flat_by_et": "15:30", "checks_et": "every 15 min from 10:15"},
                "no_resting_stop": "paper accounts take LIMIT and MARKET only, DAY validity; a sell limit below the last price fills at once, so this is a monitored level enforced by the next scheduled check, not a resting order",
                "enforcement_lag_min": [12, 22], "backstop": "max_loss"},
 "needs_human_approval": false, "notes": []}
```

Contract obligations C2 must keep:
* `risk_usd` **equals `max_loss_usd`** (not premium deployed) — the dashboard's only loss field is
  `risk_usd` (`sleeveb.js` reads no `max_loss`), so this is how max loss reaches the panel.
* `approved` and `drawdown_pct` stay present — `GUARD_KEYS` (`server.js:171`) recognises a verdict
  by ANY of them; if both disappeared the verdict would fall through `classify()` and its `legs`
  would be harvested as broker rows (§8).
* `protection.mechanism` stays `"monitored"`; the word `stop` appears only inside prose fields
  (`no_resting_stop`, `stop_credit_pct`), never as an order type.
* The legacy `protection.stop_level` key is **absent** for a fly: a single level would be read as
  "the stop" of a four-leg structure, which has none.

## 4. `select` output — C1's envelope (what the desk prints)

```jsonc
{"sleeve": "B", "action": "BUY_TO_OPEN", "underlying": "SPY", "dir": -1,
 "structure": { ...the §2 proposal... },
 "guard_verdict": { ...§3, or approved:false with reasons... },
 "tickets": [ {"seq": 1, "acc_id": "3732983", "market": 100, "order_type": 1,
               "order_side": 2, "order_trade_time_type": 0,
               "symbol": "US.SPY261123P680000", "qty": "1", "price": "1.34"}, ...4... ],
 "combo_request": {"combo_list": [{"legs": [{"code": "...", "side": "SELL", "quantity": 1}, ...]}]},
 "mark": {"basis": "quote", "close_mid": 2.30, "pnl_usd": 225.0, "pnl_pct_of_max_loss": 38.5},
 "exit_policy": {...§7...},
 "journal": [{"kind": "signal", ...}, {"kind": "verdict", ...}],
 "warnings": [...], "reasons": [...]}
```

`action: "NONE"` and `action: "STATE_UNAVAILABLE"` carry `structure: null` plus a reason, exactly as
v4 does. Tickets are proposals: this skill has no order path (that line stays true).

**`acc_id` is an input** (`--acc-id`), defaulting to `5830104` = the cloud desk's contest account.
`TICKET_TEMPLATE` hardcodes it (`sleeve_b.py:57`); a ticket aimed at any account other than the contest book —
the D8/U1 probe on `3732983` was such a ticket, and is now withdrawn — must not inherit the default.
**OBSERVED** in v4, and the reason C1 changes it.

## 5. Leg-order arithmetic (the part most likely to be silently wrong)

The desk trades **short strikes at ATM ± width/2** and **long wings ± 3W/2**, so `width` IS the
short-strike-to-short-strike distance. A worked example, SPY spot 690.85, `atm_strike` 691.0,
`width` 5.00, IV 21.2 %:

| seq | leg | side | strike | ATM−W | ATM+W | ATM−3W | ATM+3W |
|---|---|---|---|---|---|---|---|
| ① | buy put | BUY_TO_OPEN | `atm − 3W` | | | 676.0 | |
| ② | sell call | SELL_TO_OPEN | `atm − W` | | 686.0 | | |
| ③ | sell put | SELL_TO_OPEN | `atm + W` | | 696.0 | | |
| ④ | buy call | BUY_TO_OPEN | `atm + 3W` | | | | 706.0 |

Two-sided `|C| + |P|` at each distance. 24 prices are read and **exactly 10 are used** (6 for the
structure + 4 for the ATM combo IV); the rest are the cost of a readable rule, and the rejected
quotes must be printed in the trace, not discarded silently. **INFERRED, and it is a decision the
owner may overturn:** the short strikes straddle spot (spot 690.85 sits between the 686 short call
and the 696 short put) rather than one short pair being at-the-money. If the owner wants a
classic body-at-ATM fly, that is a one-line change in `build_fly`, and §5's numbers are the reason
it is called out instead of shipped.

## 6. Fees and the credit denominator

Per order, `n` = total contracts that order touches (`= qty` here, quantities are equal):

```
fee_per_order(qty) = max(1.99, 0.65 × qty) + 0.318 × qty
fees_total         = fee_per_order(qty) × orders_planned
fee_pct            = 100 × fees_total / (credit × 100 × qty)
```

**OBSERVED (rules-source-of-truth §2.3):** the live model `2 × (1.99 + 0.30 n)` understates a
10-contract round trip by $3.74, and the 0.00279 activity / 0.015 regulatory components are
missing entirely. `0.318 = 0.30 platform + 0.00279 activity + 0.015 regulatory` rounded.

The gate stays `option_fee_max_pct_of_premium = 3.0` but its **denominator becomes the credit**
(§9-D5: "premium" does not exist on a credit structure). At `width` 5, `credit` 3.05, `qty` 3:
fees $13.85 against $915 credit = 1.5 % → passes; against a 1-lot $445.75 credit (source-of-truth
§5.3) = 3.1 % → vetoes, which is the same number that doc printed and the reason the gate is on
credit rather than max loss.

## 7. D4 regime gate (reconstructed) and the exit rule

**The brief truncates D4 mid-sentence**: it ends "At entry (10:00–10:30 ET) trade only if \`".
This is the reconstruction, and it is a proposal, not a decision — flagged in the memo and the
runbook for the owner to confirm or replace before Monday 09:00 ET.

`pass = (move_1000_1030 ≤ threshold) AND (range_1000_1030 ≥ threshold)` where
`threshold = 0.39 × em` (`structure.move_max_frac_of_em 0.39`, `structure.range_min_frac_of_em 0.39`).

Two reasons for the paired form over the obvious single test `move ≤ 0.39 × em`: the pair is
**scale-invariant** (it compares shape to expected size, not to a constant that silently changes
with VIX) and it is a **direction** test as well as a size test — the move is
`close_1030 − open_1000` signed against `dir`, so a 0.5 σ rally vetoes a bearish fly instead of
"passing because the market is quiet". The 0.39 constant was picked so that in the backtest corpus
the fly is refused on days where its own measured expectancy was negative (INFERRED from
report-oos.txt's regime split: BULL +$403.76 / SIDEWAYS +$527.35 / BEAR +238.89 at breach-off, and
the §2 model's "edge only sideways"). It is **not** an optimised threshold and it has **not** been
re-fitted on 0DTE fly numbers; with `em` ≈ $4.83 at VIX 21 the gate opens for a move up to $1.89
in 30 min.

`exit_policy` (source-of-truth §4, unchanged, with the SPY-only American additions):

```jsonc
{"target_credit_pct": 25.0, "stop_credit_pct": 50.0,
 "checks_every_min": 15, "first_check_et": "10:15", "last_check_et": "15:30",
 "shorts_flat_by_et": "15:30", "wing_min_bid": 0.05,
 "stop_on_strike_breach_beyond": 0.5, "assignment_guard_after_et": "15:00",
 "assignment_itm_min": 0.50, "near_money_by_et": "15:30", "near_money_band": 2.0,
 "no_spy_leg_itm_at_close": true}
```

`stop_on_strike_breach_beyond: 0.5` × `width` = the brief's "a close beyond a short strike by more
than W/2", i.e. the threshold is in price units per venue (2.5 SPY, 75 SPXW at `width` 5).
`no_spy_leg_itm_at_close` is vacuous for SPXW (European, cash-settled) and must print that way.

## 8. Dashboard consequence of this shape (C5's reason for existing)

**OBSERVED (server.js:179-193, 253-288; sleeveb.js:86-117, 237-247):** a blob with `legs` matches
none of `GUARD_KEYS`/`SIGNAL_KEYS`/`blobKind`, so `classify()` returns null and `collectFromEvents`
runs `candidateRows()` on it, pushing every top-level array's objects as candidate broker rows. A
leg object passes `looksLikePositionRow` (has `qty`, no `cum_qty`, a decodable `code`, and none of
the `AGENT_RECORD_MARKERS`), so **one unclassified structure would paint four phantom exposures**
and inflate `premium_at_risk` — the exact failure the `POSITION_HINTS`/marker guard was added for
("which is exactly what the first live run of this panel did before the rule existed",
sleeveb.js:98-100).

Fix, in order of cheapness: (1) the §2 proposal never appears alone in an event — C1 prints the §4
envelope, whose `guard_verdict` carries `approved`, so the enclosing blob classifies as `guard` and
line 278's `if (kind) continue` keeps `candidateRows` off it entirely; (2) still add
`structure` recognition (`kind == "iron_fly" && Array.isArray(legs)`) so a structure printed
without a verdict is shown as a structure rather than as exposure. C5 also swaps the panel's
denominator to max loss and `SLEEVEB_CAP_PCT` default to 0.75, and must update
`.scratch/dashboard-d2c86f/fixtures-test.cjs:209-212`, which pins `cap = 1.5% of NAV = 1500`.

## 9. Deviations from the brief's field list

| # | brief said | contract says | why |
|---|---|---|---|
| D1 | `legs[].side`, `legs[].qty`, `legs[].limit` | `side`, `qty`, and `bid`/`ask` instead of `limit` | `parse_osi` returns a **signed** strike, so a `side` of `"BUY"`/`"SELL"` is checkable against it; `limit` is an *output* (it depends on `acc_id`, `venue` and the U1 result) so it lives in `tickets`, not in the proposal guard validates |
| D2 | `sleeve:"B"` | kept, and `kind:"iron_fly"` requires it | guard.py's own vocabulary at `:120` is `trend\|option\|hedge`; `expectancy_gate` exemption falls out for free because `closed_trades["B"]` has no history |
| D3 | `fees_model` | `fee_model` + `size_basis` | both are guard *inputs*, and the underscore pattern is the rest of the file's (`max_loss_per_lot`, `orders_planned`); the pair makes the sizing basis explicit rather than implied |
| D4 | "qty 0 ⇒ `no_trade`" | `action:"NONE"`, `reason:"no_trade: ..."` | a fourth action string would break every consumer of v4's closed set for no new information |
| D5 | `credit` | `credit` + **`debit_at_ask`** | sizing off the bid and filling at the ask is a real 5 %-of-width error on a tight-width fly; guard must be able to veto on the price it may actually pay |
| D6 | `max_loss` (brief §1 D3 wording) | `max_loss_per_lot` in the proposal, `max_loss_usd` in the verdict | "max loss" is ambiguous between per-lot and structure-level, and §3.4 of the source of truth was a *units* bug; the two names make every test state which one it means |
| D7 | `regime_gate` | + explicit sources `dte_source`, `iv_source`, `book`, `expiry` | DTE and IV both have a tempting wrong live field (`expiry_date_distance`; 162–209 % 0DTE `option_ex_data.implied_volatility`), so the provenance is part of the contract, per the `premium` precedent at `SKILL.md:19-24` |
| D8 | — | **`dte` must equal 0 for a fly** | `rules.risk.dte_min = 1` (OBSERVED live) would veto every fly at the shared DTE check; the fly gets its own `structure.dte: 0` constant and `dte_min/dte_max` stay 1–5 for the debit paths (brief C2). Without the equality rule the two bands fight each other. |

## 10. What still has to be proven before Monday (unchanged by this file)

* **U1** — SELL_TO_OPEN on a sim account (D8 of the brief): the `order_side: 2` encoding and
  whether a 4-leg combo sells to open at all. ← **CLEARED 2026-11-22, DOCUMENTED by owner attestation; the
  probe is withdrawn and no order will be placed on `3732983`.** Still not **OBSERVED** on `5830104`, which is
  why a refusal there is answered by `sleeve_b.py abort` + the sleeve-B disable flag instead of a retry
  (`sleeve-b-fly-build-nov22.md` §15).
* Whether `quote_combo_option_quote`'s `bid_price`/`ask_price` for a 4-leg combo is **per share or
  per contract** — the same ambiguity rules-source-of-truth §2.3 flags for "option premium"
  (**UNDISCOVERABLE** from a doc; settles with one live read in M3).
* The `US..SPX` + `index_option_type = 1000` chain for Monday's expiries, and whether all four
  SPXW legs have a two-sided book (D1's fallback predicate) — **OBSERVED**: empty books on Sat 21.
