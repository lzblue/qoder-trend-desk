# Trend Desk Dashboard

Local-only dashboard for the Moomoo x Qoder trend desk. Reads live Forward
Session + Event history from Qoder Cloud Agents and extracts the structured
output our three skills (`desk-risk-guard`, `trend-signal`, `decision-journal`)
print during each run: drawdown state, sizing, signal regime, equity curve,
and a running decision log. It also lists recent agent sessions so you (and a
judge) can see the desk running unattended on its schedule.

## Setup

```bash
cd qoder-trend-desk-dashboard
npm install
cp .env.example .env
```

Open `.env` and paste in your Qoder PAT (created at
https://qoder.com/cloud/pat-keys — copy it immediately, it's shown once).
Never commit `.env` or put the token in any file that gets committed; it's
already in `.gitignore`.

## Run

```bash
npm start
```

Then open http://localhost:4173.

The page polls `/api/overview` and `/api/sessions` every 30 seconds. Both
endpoints call `api.qoder.com` server-side only, using the PAT from `.env` —
the browser never sees the token.

## Screen capture

`deliverables/dashboard-capture.gif` is the running page, captured on
2026-11-26 (the 2026-11-25 trading day, the desk's most recent session set).
Every frame is a screenshot of this codebase running locally — served on port
4174 so the already-open 4173 instance stayed untouched — in a real browser
window driven over the Chrome DevTools Protocol. the clip scrolls the page
and presses **Refresh now**, which re-mines the cloud sessions and moves the
footer clock. No frame is a mockup and no number in it was authored for the
capture: the NAV, the 22 decision-journal records, the vetoed iron fly and the
cancelled option order are all mined output.

## How it works

- `GET /api/sessions` — lists Forward sessions for all four templates
  (coordinator, researcher, executor, risk_auditor), newest first.
- `GET /api/overview` — pulls the event history for the 40 most recent sessions
  and mines it for JSON blobs matching our skills' known output shapes
  (guard verdicts, signal regimes, stats), then assembles the drawdown,
  latest NAV, win rate, decision log and recent signals from them. Two things
  the miner has to do to be honest about what it shows:
  - **Child threads, not just the top-level stream.** The scheduled runs fire
    on the coordinator, and the researcher and risk_auditor work as *threads
    inside* that session, so their `guard.py check` and signal output never
    appears in `GET /sessions/{id}/events`. `mineSession` reads
    `/sessions/{id}/threads` and each thread's events too; a top-level-only
    pass reported "unknown" for a day that contained nine guard verdicts.
  - **Documentation reads are dropped.** An agent that opens a `SKILL.md`, a
    `references/*` file or one of the desk's own markdown notes gets back text
    full of JSON *examples*, and those bytes are verdict-shaped. Each tool
    result is attributed to the call that produced it, and a result whose call
    read a markdown document is excluded — unless the command also ran desk
    code (`python3`, `guard.py`, `journal.py`, …), because losing a real verdict
    would be worse than keeping an example. The count is reported as
    `mining.doc_read_events_skipped` and stated in the panel footer.
- The equity curve has two sources, merged per date: `logs/equity.csv` — the
  auditor's own ledger, written by `journal.py equity` at each REPORT — and
  any `equity_row` the miner finds in the event log. The ledger wins for a
  date it covers; mined rows only fill dates the ledger is missing.

No separate Moomoo credential is needed here: the trading agents already
have Moomoo MCP access and their tool calls/results are what gets mined out
of the session event log, so the dashboard only ever needs the Qoder PAT.

## Troubleshooting

- "No data yet" everywhere → no session has produced output yet (the guard/
  signal/journal scripts are only called *during* a BRIEF/SCAN/FLAT/REPORT
  run). Check `/api/sessions` — if it's empty too, no schedule has fired
  yet.
- 401/403 from the API → the PAT is missing, wrong, or expired; create a new
  one and update `.env`.
- If you change a template's skill output format, update `GUARD_KEYS` /
  `SIGNAL_KEYS` / `JOURNAL_EQUITY_KEYS` / `JOURNAL_STATS_KEYS` (`server.js:262-265`)
  so the miner still recognizes it.
- If the equity curve is empty while the rest of the page fills in, the
  curve is coming from neither source: `logs/equity.csv` is absent or its
  rows no longer have the 12 comma-separated columns `EQUITY_LEDGER_COLS`
  expects (the live ledger is headerless, date first), and no REPORT session
  emitted a JSON equity row. A REPORT that only *narrates* NAV in prose
  updates nothing — the numbers have to be a row in the file or a JSON blob
  in a tool result.
