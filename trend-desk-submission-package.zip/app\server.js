// Trend desk dashboard — local-only server.
//
// Reads Forward Session + Event history from Qoder Cloud Agents (server-side,
// using QODER_PAT from .env) and extracts the structured JSON that our
// deterministic skills (desk-risk-guard / trend-signal / decision-journal)
// print as tool output inside each session: drawdown state, sizing, signals,
// equity curve and the decision log. Nothing here talks to Moomoo directly —
// the agents already do that via their MCP connector, and this dashboard
// just reads back what they recorded.
//
// Run: npm install && npm start   (then open http://localhost:4173)

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const express = require('express');
const fetch = require('node-fetch');
// UMD module shared with the browser (public/index.html loads it as window.SleeveB), so
// the fixture test below exercises the same parsing and rendering the page runs.
const SleeveB = require('./public/sleeveb.js');

const PAT = process.env.QODER_PAT;
const PORT = process.env.PORT || 4173;
const API_BASE = 'https://api.qoder.com/api/v1/forward';
const MAILBOX_DIR = process.env.MAILBOX_DIR || path.join(__dirname, '.scratch', 'mailbox');
const MAILBOX_INTERVAL_ENV = Number(process.env.MAILBOX_NOMINAL_INTERVAL_MIN);
const MAILBOX_INTERVAL_FALLBACK_MIN = 10;

// Sleeve B has two risk currencies, so it has two display caps. Both are LOCAL constants, not live
// reads; the env keys exist so the panel can be told the truth when a rule moves.
//
// 1. PREMIUM cap — the legacy single-leg debit path: money deployed to put the option on.
//    Authority: desk-risk-guard references/rules.json risk.max_open_option_premium_pct = 1.5,
//    read from the bytes of the pinned version 1795580552453332 (rules version 2026-11-25.2,
//    sha256 060fc5b572d6…, re-read 2026-11-25T06:40Z). The pins and hashes are recorded in
//    AGENTS.md, which is the in-repo snapshot of the cloud config.
// 2. MAX-LOSS cap — the 0DTE iron fly (a credit structure): its risk is
//    max_loss_per_lot x qty = (width - credit) x 100 x lots, never a premium. Owner brief D3 set
//    the per-structure budget at 0.75 % of NAV, and the field that carries it is
//    rules.json structure.max_loss_pct_of_nav. That block IS live now: a rules-only publish
//    raised structure.max_loss_pct_of_nav from 0.75 to 1.5 on 2026-11-25 and the pinned version
//    mounts it. The two caps happen to share the number 1.5 while gating different quantities —
//    a fly priced against the premium cap would still be measured in a currency it does not use.
const SLEEVEB_CAP_PCT = Number(process.env.SLEEVEB_CAP_PCT) > 0
  ? Number(process.env.SLEEVEB_CAP_PCT)
  : 1.5;
const SLEEVEB_MAX_LOSS_CAP_PCT = Number(process.env.SLEEVEB_MAX_LOSS_CAP_PCT) > 0
  ? Number(process.env.SLEEVEB_MAX_LOSS_CAP_PCT)
  : 1.5;

// How many of the newest sessions one desk build mines. The 25 Nov run produced 30 sessions
// (7 coordinator + 23 executor), so a 20-session window dropped the morning, and the panels
// that read "no data today" were reading a truncated window rather than an empty desk. 40
// covers a trading day; each session costs one paged event fetch plus its child threads, and
// an idle session is memoised, so the widening is paid once per day rather than per poll.
const MINE_SESSION_LIMIT = Number(process.env.MINE_SESSION_LIMIT) > 0
  ? Number(process.env.MINE_SESSION_LIMIT)
  : 40;

// The real tick length lives in the mailbox's own cron.json, which is the only place a
// wake session can state it (no cron tool is reachable from there). Falling back to a
// hardcoded 10 made a dead */2 schedule read as healthy for up to 20 minutes.
function nominalIntervalMin(mailboxDir) {
  if (MAILBOX_INTERVAL_ENV > 0) return MAILBOX_INTERVAL_ENV;
  const cj = readJsonFile(path.join(mailboxDir, 'cron.json'));
  const n = cj ? Number(cj.interval_min) : NaN;
  return n > 0 ? n : MAILBOX_INTERVAL_FALLBACK_MIN;
}

const TEMPLATES = {
  coordinator: process.env.TMPL_COORDINATOR,
  researcher: process.env.TMPL_RESEARCHER,
  executor: process.env.TMPL_EXECUTOR,
  risk_auditor: process.env.TMPL_RISK_AUDITOR,
};

if (!PAT) {
  console.warn(
    '\n[WARN] QODER_PAT is not set in .env — API calls to Qoder will fail.\n' +
    'Create one at https://qoder.com/cloud/pat-keys and put it in .env (never commit it).\n'
  );
}

const app = express();
app.use(express.static('public'));

// ---------- tiny in-memory cache so we don't hammer the API on every poll ----------
const cache = new Map();
const inflight = new Map();
async function cached(key, ttlMs, fn) {
  const hit = cache.get(key);
  const now = Date.now();
  if (hit && now - hit.at < ttlMs) return hit.value;
  // A 30 s UI poll and a manual Refresh can land together; without this both pay for a
  // build that fans out over dozens of sessions and their child threads.
  const running = inflight.get(key);
  if (running) return running;
  const p = (async () => {
    try {
      const value = await fn();
      cache.set(key, { value, at: Date.now() });
      return value;
    } finally {
      inflight.delete(key);
    }
  })();
  inflight.set(key, p);
  return p;
}

// ---------- Qoder API helpers ----------
// One desk build fans out over ~20 sessions and, since child-thread mining, ~9 requests
// per session. Without a ceiling the first poll after the cache expires fires 180 parallel
// fetches at the API.
const API_MAX_IN_FLIGHT = 6;
let apiInFlight = 0;
const apiWaiters = [];
async function apiSlot() {
  if (apiInFlight < API_MAX_IN_FLIGHT) { apiInFlight++; return; }
  await new Promise((resolve) => apiWaiters.push(resolve));
  apiInFlight++;
}
function releaseApiSlot() {
  apiInFlight--;
  const next = apiWaiters.shift();
  if (next) next();
}

async function qoderGet(path) {
  await apiSlot();
  try {
    const res = await fetch(`${API_BASE}${path}`, {
      headers: { Authorization: `Bearer ${PAT}` },
    });
    if (!res.ok) {
      const text = await res.text().catch(() => '');
      throw new Error(`Qoder API ${res.status} on ${path}: ${text.slice(0, 300)}`);
    }
    return res.json();
  } finally {
    releaseApiSlot();
  }
}

async function listSessions(templateId, limit = 30) {
  if (!templateId) return [];
  const data = await qoderGet(
    `/sessions?template_id=${encodeURIComponent(templateId)}&limit=${limit}`
  );
  return data.data || [];
}

// Forward's event paging, verified against the live API on 2026-11-26: the page envelope
// carries data/first_id/last_id/has_more and NO next_cursor, `limit` is capped at 100, and
// the only accepted cursor parameter is after_id — cursor/after/starting_after are silently
// ignored and re-return page 1. The previous `data.next_cursor` test therefore stopped after
// page 1 for every session, so any run longer than 100 events (BRIEF = 124, SCAN-1005 = 117)
// silently lost its tail, which is where the guard verdicts and fills land.
async function listAllEvents(sessionId, maxPages = 20, basePath = null) {
  const events = [];
  const seen = new Set();
  let afterId = null;
  for (let i = 0; i < maxPages; i++) {
    const qs = new URLSearchParams({ limit: '100' });
    if (afterId) qs.set('after_id', afterId);
    const data = await qoderGet(`${basePath ?? `/sessions/${sessionId}/events`}?${qs.toString()}`);
    const page = Array.isArray(data.data) ? data.data : [];
    let fresh = 0;
    for (const ev of page) {
      if (!ev || !ev.id || seen.has(ev.id)) continue;
      seen.add(ev.id);
      events.push(ev);
      fresh++;
    }
    if (!data.has_more || !page.length || !fresh || !data.last_id) break;
    afterId = data.last_id;
  }
  return events;
}

// The coordinator's own event stream carries only the coordinator's tool calls. Guard
// verdicts, journal records and the broker's position/order rows are produced inside the
// child threads (researcher / risk_auditor / executor), which live behind a separate
// endpoint. Mining top-level events alone is what made a day where the coordinator only
// delegated render as status.state "unknown" and an empty decision log.
async function listThreadEvents(sessionId) {
  const data = await qoderGet(`/sessions/${sessionId}/threads`).catch(() => null);
  const threads = Array.isArray(data?.data) ? data.data : [];
  const events = [];
  for (const t of threads.slice(0, 8)) {
    const tid = t.id || t.session_thread_id;
    if (!tid) continue;
    const more = await listAllEvents(sessionId, 20, `/sessions/${sessionId}/threads/${tid}/events`)
      .catch(() => []);
    events.push(...more);
  }
  return events;
}

// ---------- JSON mining: find structured skill output inside event payloads ----------
// We don't rely on a fixed event envelope shape (Forward's event schema can
// nest tool input/output in a few different ways). Tool output text lives as
// STRING VALUES inside the event object; guard.py/etc print their JSON on one
// line of that string. Walking the decoded object tree and parsing each
// string value's balanced {...} blocks directly (rather than re-stringifying
// the whole event and rescanning the escaped result, which turns every
// embedded `"` into `\"` and makes every candidate fail JSON.parse) is what
// actually recovers them.
function findBalancedBraceBlobs(text) {
  const blobs = [];
  for (let i = 0; i < text.length; i++) {
    if (text[i] !== '{') continue;
    let depth = 0;
    for (let j = i; j < text.length; j++) {
      if (text[j] === '{') depth++;
      else if (text[j] === '}') {
        depth--;
        if (depth === 0) {
          const candidate = text.slice(i, j + 1);
          try {
            blobs.push(JSON.parse(candidate));
          } catch (_) {
            /* not valid JSON, skip */
          }
          i = j;
          break;
        }
      }
    }
  }
  return blobs;
}

function extractJsonBlobsFromEvent(ev) {
  const blobs = [];
  const seen = new Set();
  function walk(node) {
    if (node == null) return;
    if (typeof node === 'string') {
      if (node.indexOf('{') === -1) return;
      for (const blob of findBalancedBraceBlobs(node)) {
        const key = JSON.stringify(blob);
        if (!seen.has(key)) {
          seen.add(key);
          blobs.push(blob);
        }
      }
      return;
    }
    if (Array.isArray(node)) {
      node.forEach(walk);
      return;
    }
    if (typeof node === 'object') {
      Object.values(node).forEach(walk);
    }
  }
  walk(ev);
  return blobs;
}

const GUARD_KEYS = ['approved', 'drawdown_pct', 'day_loss_pct', 'risk_usd', 'needs_human_approval'];
const SIGNAL_KEYS = ['regime', 'size_mult', 'bear_flags'];
const JOURNAL_EQUITY_KEYS = ['nav', 'bench'];
const JOURNAL_STATS_KEYS = ['win_rate', 'expectancy', 'profit_factor'];
// decision-journal's nine kinds (scripts/journal.py header). Kept here so a `note` or
// `signal` record cannot be mistaken for a guard verdict by the key-set tests above.
const JOURNAL_KINDS = new Set(['signal', 'verdict', 'order', 'fill', 'close', 'skip', 'error', 'note']);

function classify(blob) {
  const keys = Object.keys(blob || {});
  // Two fly records reach here and must land in different buckets. The verdict (§3 of
  // docs/decisions/sleeve-b-fly-contract-nov21.md) carries `approved` and `risk_usd`, so GUARD_KEYS
  // claims it below and its `legs` array is never row-scanned. The proposal/envelope (§2/§4)
  // carries neither, so it is only safe because SleeveB.blobKind recognises `kind:"iron_fly"` with
  // a leg set and returns 'structure' — without that, `if (kind) continue` below would not fire and
  // candidateRows() would push all four legs (and all four tickets) in as live exposures.
  // A journal record carries kind + ts and is read by the activity strip and the sleeve B
  // timeline, so it has to be claimed before the key-set tests: a `close` record embeds
  // realized_pnl and fees, and a `verdict` embeds approved — both would otherwise be
  // harvested as guard output and double-count in the decision log.
  if (typeof blob.kind === 'string' && JOURNAL_KINDS.has(blob.kind) && (blob.ts || blob.at)) return 'journal';
  // Equity rows carry drawdown_pct too, so they must be claimed before the guard test or
  // every `journal.py equity` line lands in the decision log as a blocked verdict and the
  // equity curve stays empty. Nothing in guard.py's output has a `bench` field.
  if (JOURNAL_EQUITY_KEYS.every((k) => keys.includes(k))) return 'equity_row';
  if (GUARD_KEYS.some((k) => keys.includes(k))) return 'guard';
  if (SIGNAL_KEYS.some((k) => keys.includes(k))) return 'signal';
  if (JOURNAL_STATS_KEYS.some((k) => keys.includes(k))) return 'stats';
  // journal.py stats prints {"all":{"n":..,"win_rate":..,"profit_factor":..},"vetoes":0,...} —
  // the metrics sit one level down, so the top-level key test above matched none of the
  // real blobs and the Win Rate card stayed "—" even in sessions that ran the command.
  if (blob.all && typeof blob.all === 'object' && !Array.isArray(blob.all)
    && JOURNAL_STATS_KEYS.some((k) => Object.keys(blob.all).includes(k))) return 'stats';
  return SleeveB.blobKind(blob);
}

// Everything a moomoo tool result can wrap its rows in: the row arrays sit one or two
// levels under the envelope ({ret_code, data:{list|rows|...: [...]}} or a bare array of
// objects at the top). Deliberately shallow — a deep walk over every nested object turns
// a guard proposal's `positions` array into candidate broker rows.
function candidateRows(blob) {
  const out = [];
  if (!blob || typeof blob !== 'object') return out;
  const pushArray = (arr) => {
    for (const item of arr) {
      if (item && typeof item === 'object' && !Array.isArray(item)) out.push(item);
    }
  };
  if (typeof blob.symbol === 'string' || typeof blob.code === 'string') out.push(blob);
  for (const v of Object.values(blob)) {
    if (Array.isArray(v)) pushArray(v);
  }
  if (blob.data && typeof blob.data === 'object' && !Array.isArray(blob.data)) {
    for (const v of Object.values(blob.data)) {
      if (Array.isArray(v)) pushArray(v);
    }
  }
  return out;
}

function eventAt(ev) {
  const raw = ev.created_at || ev.createdAt || ev.processed_at || null;
  if (!raw) return null;
  const t = Date.parse(raw);
  return Number.isNaN(t) ? null : raw;
}

// Pure: takes one session's event list, returns every structured record the desk prints.
// Split out of mineSession so the offline fixture test runs the real collection path.
//
// The same record can surface in several events of one session (a skill's stdout echoed
// into the agent's own message, an MCP result re-quoted by the next tool call). Activity
// counts are arithmetic, so a duplicate inflates them, and every bucket now dedupes on the
// blob content itself, ignoring the event timestamp we attach (see the loop at the end of
// collectFromEvents for why that is session-scoped rather than global).
function recordKey(item) {
  const { at, event_id, session_id, ...rest } = item;
  try {
    return JSON.stringify(rest);
  } catch (_) {
    return null;
  }
}

function pushUnique(list, seen, item) {
  const key = recordKey(item);
  if (key !== null) {
    if (seen.has(key)) return;
    seen.add(key);
  }
  list.push(item);
}

// An agent that opens SKILL.md, a references/*.json, or a docs/*.md file gets back text that
// contains JSON *examples*. Those bytes are documentation of a format, not something the desk
// decided, but they are verdict-shaped, and on 2026-11-26 they made 8 of the 14 rows in the
// Decision Log read "BLOCKED · event blackout 13:45-14:30 ET" — a string that exists only in
// decision-journal's SKILL.md example command. So a tool_result is attributed to the call that
// produced it, and a call that read a document disqualifies the whole reply.
// Pairing is by tool_use_id, which is only present when both sides are in the same event list,
// so this is fail-open: an unpaired result is kept. Dropping a real verdict would be worse than
// keeping an example, and the count of what was dropped is reported (mining.doc_read_events_skipped).
const DOC_FILE_RE = /(\.md\b|\.markdown\b|references\/|docs\/)/i;

function docReadCallIds(events) {
  const ids = new Map();
  for (const ev of events) {
    const type = typeof ev.type === 'string' ? ev.type : '';
    if (type !== 'agent.tool_use' && type !== 'agent.mcp_tool_use') continue;
    const id = ev.id || ev.tool_use_id;
    if (!id) continue;
    const inp = ev.input || (ev.payload && ev.payload.input) || {};
    const file = inp.file_path || inp.path || null;
    if ((ev.name === 'Read' || ev.name === 'Grep' || ev.name === 'Glob') && DOC_FILE_RE.test(String(file || ''))) {
      ids.set(id, ev.name + ' ' + file);
      continue;
    }
    // `cat`/`sed`/`head` of a markdown file leaks the same examples through a different tool.
    // But a shell command is also how the desk runs code, and one command line often does both
    // (`python3 - <<'EOF'` that loads references/rules.json, or `sed -n … guard.py; cat notes.md`),
    // so a call that invoked the interpreter or a desk script is never suppressed: losing a real
    // verdict is worse than keeping an example. Measured on the 26 Nov window, this exemption
    // removes no documentation-only read.
    const cmd = String(inp.command || '');
    const runsDeskCode = /\bpython3?\b|\bnode\b|guard\.py|journal\.py|chop\.py|sleeve_b/.test(cmd);
    if (ev.name === 'Bash' && !runsDeskCode && DOC_FILE_RE.test(cmd) && /\b(cat|sed|head|tail|grep|less)\b/.test(cmd)) {
      ids.set(id, 'Bash ' + cmd.slice(0, 80));
    }
  }
  return ids;
}

function collectFromEvents(events) {
  const findings = {
    guard: [], signal: [], equity_row: [], stats: [],
    journal: [], ticket: [], classify: [], reconcile: [],
    order_row: [], position_row: [], structure: [],
    raw_event_count: events.length,
    last_agent_event_at: null,
  };
  const docCalls = docReadCallIds(events);
  const seenRowKeys = new Set();
  let skipped = 0;
  for (const ev of events) {
    const at = eventAt(ev);
    if (at && typeof ev.type === 'string' && ev.type.indexOf('agent.') === 0) {
      if (!findings.last_agent_event_at || Date.parse(at) > Date.parse(findings.last_agent_event_at)) {
        findings.last_agent_event_at = at;
      }
    }
    const srcId = ev.tool_use_id || ev.mcp_tool_use_id || (ev.payload && ev.payload.tool_use_id) || null;
    if (srcId && docCalls.has(srcId)) {
      skipped++;
      continue;
    }
    for (const blob of extractJsonBlobsFromEvent(ev)) {
      const kind = classify(blob);
      if (kind) {
        findings[kind].push({ at: at, event_id: ev.id, ...blob });
      }
      // A §4 envelope carries the journal lines it also wrote inside its own `journal` array.
      // Those are desk records, not leg rows, so they are lifted out here; the rest of the
      // envelope's nested arrays stay off-limits to the row scanner below.
      if (kind === 'structure' && Array.isArray(blob.journal)) {
        for (const j of blob.journal) {
          if (j && typeof j === 'object' && typeof j.kind === 'string') {
            findings.journal.push({ at: j.ts || at, event_id: ev.id, ...j });
          }
        }
      }
      // The broker rows live inside a tool-result envelope. An event blob that is itself an
      // agent record (journal line, ticket, guard verdict) is never a broker envelope: its
      // nested arrays hold the record's own sub-objects, and reading those as positions
      // invented exposure out of a log line.
      if (kind) continue;
      for (const row of candidateRows(blob)) {
        const rk = SleeveB.looksLikeOrderRow(row) ? 'order_row'
          : SleeveB.looksLikePositionRow(row) ? 'position_row' : null;
        if (!rk) continue;
        // An order id already names the row, so symbol adds nothing to an order key and only
        // splits one order across two endpoints that spell `symbol` differently. `status` is
        // `5` on one endpoint and `"5 cancelled"` on another, so the code is what dedupes.
        const oid = row.order_id ?? row.id ?? '';
        const sym = oid ? '' : (row.symbol || row.code || '');
        const code = SleeveB.orderStatusCode(row.status);
        const key = rk + '|' + oid + '|' + sym + '|' + (row.qty ?? '') + '|' + (code === null ? (row.status ?? '') : code);
        if (seenRowKeys.has(key)) continue;
        seenRowKeys.add(key);
        findings[rk].push({ at, event_id: ev.id, ...row });
      }
    }
  }
  // Dedupe is scoped to ONE session, which is where the echo lives: the coordinator quotes
  // the auditor's verdict (and the researcher's signal block) into its own messages, and with
  // child threads mined now, the same record also arrives as a thread event and as a
  // coordinator event. Two copies of one decision read as two decisions in the log.
  // Distinct sessions still contribute their own rows, so a repeat verdict from a later scan
  // is not lost.
  for (const bucket of ['guard', 'signal', 'equity_row', 'stats', 'journal', 'ticket', 'classify', 'reconcile', 'structure']) {
    const rows = findings[bucket];
    const seen = new Set();
    findings[bucket] = [];
    for (const r of rows) pushUnique(findings[bucket], seen, r);
  }
  findings.doc_read_events_skipped = skipped;
  return findings;
}

async function mineSession(sessionId) {
  const [top, threaded] = await Promise.all([
    listAllEvents(sessionId),
    listThreadEvents(sessionId).catch(() => []),
  ]);
  // The thread list includes the coordinator's own root thread, so the same event id can
  // arrive from both endpoints; a doubled event would double every non-deduped count.
  const byId = new Map();
  for (const ev of [...top, ...threaded]) {
    const key = ev && ev.id ? ev.id : `noid:${byId.size}`;
    if (!byId.has(key)) byId.set(key, ev);
  }
  const events = [...byId.values()].sort((a, b) =>
    String(eventAt(a) || '').localeCompare(String(eventAt(b) || '')));
  return collectFromEvents(events);
}

// guard.py's proposal carries sleeve 'shares'/'option'/'hedge'; the journal's close
// records carry the desk's A/B/C. Both spellings fold onto the same three lanes so the
// strip cannot count one trade twice under two names.
function normalizeSleeve(value) {
  const s = String(value == null ? '' : value).trim().toLowerCase();
  if (s === 'a' || s === 'shares' || s === 'equity' || s === 'etf') return 'A';
  if (s === 'b' || s === 'option' || s === 'options') return 'B';
  if (s === 'c' || s === 'hedge') return 'C';
  return 'unknown';
}

// First argument that is an actual number; used when a field has more than one honest
// source and the fallbacks must not overwrite a stated value.
function firstNumber(...values) {
  for (const v of values) {
    const n = SleeveB.num(v);
    if (n != null) return n;
  }
  return null;
}

function latestOf(rows, field) {
  let best = null;
  for (const r of rows || []) {
    const v = r[field] || r.at;
    if (!v) continue;
    const t = Date.parse(v);
    if (Number.isNaN(t)) continue;
    if (!best || t > best.t) best = { t, value: v, row: r };
  }
  return best;
}

// The activity strip. Entries/exits/rejections come from decision-journal records because
// those are what the desk is told to write for every order, fill, close and skip; when no
// journal record exists yet the strip says so instead of printing a confident zero.
function activityView(findings, etDay) {
  const today = etDay || SleeveB.etDayNow();
  const sleeves = { A: {}, B: {}, C: {}, unknown: {} };
  const blank = () => ({ entries: 0, exits: 0, rejections: 0, records: 0, entry_legs: 0, exit_legs: 0, structures: 0 });
  for (const k of Object.keys(sleeves)) sleeves[k] = blank();

  // A four-leg structure is ONE trade. The desk journals it per leg (memo §2, "per-leg
  // journaling"), so counting `fill` records would read a single fly as four entries and a single
  // close as four exits — four trades and four units of expectancy. Attribute each fill/close to
  // its structure (an explicit id if one was written, otherwise the leg set of the mined
  // structure that contains that contract) and count the distinct keys.
  const normStructures = (findings.structure || []).map((blob) => SleeveB.normalizeStructure(blob, blob.at || blob.ts));
  // Same identity rule the panel uses: an emitted `structure_key` wins, and a record that predates it
  // is folded under the emitted key of the identical leg set, so a fly is never counted once by its
  // proposal and once by its mark.
  const emittedByDerived = {};
  for (const st of normStructures) {
    if (st.key && st.derived_key && st.key !== st.derived_key) emittedByDerived[st.derived_key] = st.key;
  }
  const identityOf = (st) => (st.key && st.key === st.derived_key && emittedByDerived[st.derived_key])
    ? emittedByDerived[st.derived_key] : st.key;
  // `structure_key` is size-INDEPENDENT by contract (c1/.../sleeve_b_fly.py:115-119: a size-bearing key
  // is vetoed by guard.py:321/:666, which mirror it from the legs alone), so two sizes of one leg set
  // legitimately share a key and grouping on the key alone would file them as one trade. Lane on a
  // stated LOT count only — `lots`/`qty_lots`. A per-order `qty` is contracts (legs_per_lot x lots, so
  // 2 for a 2-lot single-contract leg) and using it as the lane would split one trade across lanes 1
  // and 2 depending on which row arrived.
  const lotsOf = (rec) => (rec.lots !== undefined && rec.lots !== null ? Number(rec.lots)
    : rec.qty_lots !== undefined && rec.qty_lots !== null ? Number(rec.qty_lots) : null);
  const legOwner = {};
  for (const st of normStructures) {
    const id = identityOf(st);
    if (!id) continue;
    for (const code of st.leg_keys) if (!legOwner[code]) legOwner[code] = id;
  }
  const ownerBase = (rec) => rec.structure_id || rec.structure_key
    || legOwner[SleeveB.legKey(rec.symbol || rec.ticker || '')] || null;

  const entryKeys = { A: new Set(), B: new Set(), C: new Set(), unknown: new Set() };
  const exitKeys = { A: new Set(), B: new Set(), C: new Set(), unknown: new Set() };

  const allRecords = (findings.journal || []).filter((r) => typeof r.kind === 'string');
  // The strip is labelled "today", so a record from an earlier session must not age into it.
  const records = allRecords.filter((r) => SleeveB.sameDay(r.ts || r.at, today));
  // Lane after the day filter, so the "single stated lot count" fold sees the rows actually counted.
  const laneOfRow = SleeveB.laneFolder(records, ownerBase, lotsOf);
  const ownerOf = (rec) => laneOfRow(rec) || ownerBase(rec);
  for (const r of records) {
    const laneName = normalizeSleeve(r.sleeve);
    const lane = sleeves[laneName];
    lane.records += 1;
    if (r.kind === 'fill') {
      lane.entry_legs += 1;
      entryKeys[laneName].add(ownerOf(r) || 'unattributed:' + String(r.ts || r.at) + '|' + String(r.symbol || r.ticker || '') + '|' + String(r.qty));
    } else if (r.kind === 'close') {
      lane.exit_legs += 1;
      exitKeys[laneName].add(ownerOf(r) || 'unattributed:' + String(r.ts || r.at) + '|' + String(r.symbol || r.ticker || ''));
    } else if ((r.kind === 'verdict' && r.approved === false) || r.kind === 'skip') lane.rejections += 1;
  }
  for (const k of Object.keys(sleeves)) {
    sleeves[k].entries = entryKeys[k].size;
    sleeves[k].exits = exitKeys[k].size;
  }
  // Structures are counted from the structure records themselves, so a fly that has filled two of
  // four legs still reads as one trade rather than two. Same dedupe as the panel: one leg set, one
  // trade, dated today (the strip is labelled "today").
  const structureKeys = { A: new Set(), B: new Set(), C: new Set(), unknown: new Set() };
  let structuresToday = 0;
  // Same (key, lots) lane the panel groups on: one key at two sizes is two structures today.
  const laneOfStructure = SleeveB.laneFolder(normStructures, identityOf, (st) => st.qty);
  for (const st of normStructures) {
    const day = SleeveB.isoOf(st.at);
    if (day && !SleeveB.sameDay(day, today)) continue;
    // A veto or an action "NONE" envelope is a plan that was refused, not a trade taken.
    if (st.approved === false || String(st.action || '') === 'NONE') continue;
    const laneName = normalizeSleeve((st.raw && st.raw.sleeve) || st.sleeve);
    const key = laneOfStructure(st) || 'unkeyed:' + String(st.at || '') + ':' + st.leg_count;
    if (structureKeys[laneName] && structureKeys[laneName].has(key)) continue;
    if (structureKeys[laneName]) structureKeys[laneName].add(key);
    structuresToday += 1;
  }
  for (const k of Object.keys(sleeves)) sleeves[k].structures = structureKeys[k].size;

  // Fill rows from the broker are a second source of entries: use them only where the
  // journal is silent, so a desk that forgot to log still shows activity.
  for (const row of findings.order_row || []) {
    const c = SleeveB.classifyOrderRow(row);
    if (c.state !== 'filled') continue;
    if (!SleeveB.sameDay(SleeveB.isoOf(row.update_time || row.create_time), today)) continue;
    const lane = sleeves[normalizeSleeve(row.sleeve)];
    if (lane.entries === 0 && lane.records === 0) lane.entries += 1;
  }

  const lastRecord = latestOf(allRecords, 'ts');
  const lastEvent = findings.last_agent_event_at
    ? { value: findings.last_agent_event_at, row: { kind: 'agent event', agent: null } }
    : null;
  const last = lastRecord && lastEvent
    ? (Date.parse(lastRecord.value) >= Date.parse(lastEvent.value) ? lastRecord : lastEvent)
    : lastRecord || lastEvent;

  const anyCounts = Object.values(sleeves).some((s) => s.entries || s.exits || s.rejections);
  // When a lane's fill/close records collapse, say so in the note: a reader who sees "1 entry"
  // while the desk logged four fills must be able to tell grouping from missing data.
  const collapsed = Object.keys(sleeves)
    .filter((k) => sleeves[k].entry_legs !== sleeves[k].entries || sleeves[k].exit_legs !== sleeves[k].exits)
    .map((k) => `${k}: ${sleeves[k].entry_legs} fill record(s) = ${sleeves[k].entries} trade(s), ${sleeves[k].exit_legs} close record(s) = ${sleeves[k].exits} trade(s)`);
  return {
    et_day: today,
    sleeves,
    structures_today: structuresToday,
    leg_collapse_note: collapsed.length
      ? 'entries/exits are counted per trade; multi-leg structures collapse: ' + collapsed.join(' · ')
      : null,
    last_action_at: last ? last.value : null,
    last_action_kind: last && last.row ? last.row.kind || null : null,
    last_action_agent: last && last.row ? last.row.agent || null : null,
    journal_records: records.length,
    coverage_note: records.length === 0
      ? allRecords.length
        ? `no decision-journal record dated ${today} — ${allRecords.length} older record(s) exist, so today's counts are absent, not zero`
        : 'no decision-journal record mined in the scanned sessions — counts are not zero, they are absent'
      : anyCounts
        ? `${records.length} decision-journal record(s) dated ${today}`
        : `${records.length} decision-journal record(s) dated ${today}, none of them an entry, exit or rejection yet`,
  };
}

// The snapshot the panel renders. Field names mirror what option-adapter / decision-journal
// actually print, so an empty array here means "not seen in the mined events", never "flat".
function sleeveBView(findings, nav) {
  const tickets = (findings.ticket || []).filter((b) => b && typeof b === 'object');
  const structures = (findings.structure || []).filter((b) => b && typeof b === 'object');
  const stateRecords = []
    .concat((findings.classify || []).map((b) => ({ at: b.at || b.ts, source: 'option-adapter classify', raw: b, action: b.action, reason: b.reason })))
    .concat((findings.reconcile || []).map((b) => ({ at: b.at || b.ts, source: 'option-adapter reconcile', raw: b, action: b.action, reason: b.reason })));
  return {
    et_day: SleeveB.etDayNow(),
    nav: nav,
    // `premium_cap_*` keeps its old meaning exactly: the DEBIT-path premium ceiling. It is not the
    // fly's risk limit and must not be read as one — the two `max_loss_cap_*` fields below are.
    premium_cap_pct: SLEEVEB_CAP_PCT,
    premium_cap_source: 'dashboard constant (SLEEVEB_CAP_PCT) — authority is desk-risk-guard references/rules.json risk.max_open_option_premium_pct = 1.5, read from the pinned skill bytes 2026-11-25',
    max_loss_cap_pct: SLEEVEB_MAX_LOSS_CAP_PCT,
    max_loss_cap_source: 'dashboard constant (SLEEVEB_MAX_LOSS_CAP_PCT) — authority is desk-risk-guard references/rules.json structure.max_loss_pct_of_nav = 1.5 in the pinned version (rules 2026-11-25.2). Owner brief D3 set it at 0.75 % of NAV; a rules-only publish raised it to 1.5 on 2026-11-25, so the live ceiling is the wider one.',
    positions: findings.position_row || [],
    orders: findings.order_row || [],
    tickets,
    structures,
    journal: findings.journal || [],
    state_records: stateRecords,
    freshness: {
      latest_position_row_at: (latestOf(findings.position_row, 'at') || {}).value || null,
      latest_order_row_at: (latestOf(findings.order_row, 'at') || {}).value || null,
      latest_ticket_at: (latestOf(tickets, 'ts') || {}).value || null,
      latest_structure_at: (latestOf(structures, 'at') || {}).value || null,
    },
  };
}

// ---------- routes ----------

app.get('/api/health', (req, res) => {
  res.json({ ok: true, hasPat: Boolean(PAT), templates: TEMPLATES });
});

// ---------- mailbox heartbeat ----------
// Everything here is a filesystem read of .scratch/mailbox, which the wake
// script already touches: no cloud API call, no agent session, no per-wake
// write step. The panel is therefore free, and it goes stale instead of
// costing tokens.
function readJsonFile(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return null;
  }
}

// The desk's own equity ledger, written by the REPORT run and mirrored locally by
// tools/export-decisions.mjs. Headerless, and its columns are the ones the awareness
// journal prints: et_date,nav,spy_close,peak_nav,signals,vetoes,approvals,fills,closes,
// net_realized_pnl,expectancy,n. Mined events do not carry this: a live REPORT surfaces
// the equity as prose inside a tool_result, so the curve has to come from the ledger or
// it stays empty. `bench` is the shape /api/overview already exposes, filled by spy_close.
const EQUITY_LEDGER_COLS = ['date', 'nav', 'bench', 'peak_nav', 'signals', 'vetoes',
  'approvals', 'fills', 'closes', 'net_realized_pnl', 'expectancy', 'n'];

function readEquityLedger(file = path.join(__dirname, 'logs', 'equity.csv')) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (_) {
    return [];
  }
  const rows = [];
  for (const line of text.split(/\r?\n/)) {
    const cells = line.split(',');
    if (cells.length !== EQUITY_LEDGER_COLS.length) continue;
    if (!/^\d{4}-\d{2}-\d{2}$/.test(cells[0].trim())) continue; // a header row, if one ever lands
    const row = {};
    EQUITY_LEDGER_COLS.forEach((k, i) => { row[k] = cells[i].trim(); });
    const nav = SleeveB.num(row.nav);
    const peak = SleeveB.num(row.peak_nav);
    row.nav = nav;
    row.bench = SleeveB.num(row.bench);
    row.drawdown_pct = nav != null && peak ? Number(((nav / peak - 1) * 100).toFixed(2)) : null;
    row.source = 'ledger';
    rows.push(row);
  }
  return rows.sort((a, b) => a.date.localeCompare(b.date));
}

function listJsonNames(dir) {
  try {
    return fs.readdirSync(dir).filter((f) => f.endsWith('.json'));
  } catch (_) {
    return null;
  }
}

const round1 = (n) => Number(n.toFixed(1));

// One line per wake, written atomically by check.sh / check.ps1.
function wakeStamps(file) {
  let text = '';
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (_) {
    return [];
  }
  const stamps = [];
  for (const line of text.split('\n')) {
    let ts = null;
    try {
      ts = JSON.parse(line).ts;
    } catch (_) {
      continue;
    }
    const at = new Date(ts).getTime();
    if (!Number.isNaN(at)) stamps.push(at);
  }
  return stamps;
}

function median(values) {
  const s = values.slice().sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 ? s[mid] : (s[mid - 1] + s[mid]) / 2;
}

function mailboxState() {
  const hbFile = path.join(MAILBOX_DIR, 'heartbeat.json');
  const hb = readJsonFile(hbFile);
  const lastWake = hb && hb.ts ? new Date(hb.ts) : null;
  const validWake = Boolean(lastWake) && !Number.isNaN(lastWake.getTime());
  const ageMin = validWake ? Math.max(0, (Date.now() - lastWake.getTime()) / 60000) : null;

  let hbMtime = null;
  try {
    hbMtime = fs.statSync(hbFile).mtime.toISOString();
  } catch (_) {
    /* heartbeat absent: state below already reports red */
  }

  const stamps = wakeStamps(path.join(MAILBOX_DIR, 'wakes.jsonl'));
  const recent = stamps.sort((a, b) => a - b).slice(-20);
  const gaps = [];
  for (let i = 1; i < recent.length; i++) gaps.push((recent[i] - recent[i - 1]) / 60000);
  const observedMin = gaps.length ? Number(median(gaps).toFixed(2)) : null;

  // Back-to-back manual ticks make the observed spacing far smaller than the
  // schedule, and 2x of that would flag a healthy desk as stale, so the
  // declared interval is the floor of what the staleness test uses.
  const nominalMin = nominalIntervalMin(MAILBOX_DIR);
  const effectiveMin = observedMin === null
    ? nominalMin
    : Math.max(observedMin, nominalMin);

  const inboxNames = listJsonNames(path.join(MAILBOX_DIR, 'inbox'));
  const ackNames = listJsonNames(path.join(MAILBOX_DIR, 'acks'));
  const doneNames = listJsonNames(path.join(MAILBOX_DIR, 'done'));

  const ackIds = ackNames && ackNames.map((f) => f.replace(/\.json$/, ''));
  const doneIds = doneNames && new Set(doneNames.map((f) => f.replace(/\.json$/, '')));
  const ackedNotClosed = ackIds && doneIds ? ackIds.filter((id) => !doneIds.has(id)).length : null;

  const recentAcks = (ackNames || [])
    .map((f) => readJsonFile(path.join(MAILBOX_DIR, 'acks', f)))
    .filter((a) => a && a.id)
    .sort((a, b) => new Date(b.ts || 0) - new Date(a.ts || 0))
    .slice(0, 5)
    .map((a) => ({
      id: a.id,
      status: a.status || 'unknown',
      ts: a.ts || null,
      error: a.error || null,
      files_changed: Array.isArray(a.files_changed) ? a.files_changed.length : 0,
    }));

  const inboxCount = inboxNames === null ? null : inboxNames.length;
  const wokeInTime = ageMin !== null && ageMin <= effectiveMin * 2;
  const noBacklog = inboxCount === 0;

  let state;
  let why;
  if (!validWake || inboxCount === null || ackNames === null || doneNames === null) {
    state = 'red';
    why = !validWake ? 'no readable heartbeat.json' : 'mailbox directories unreadable';
  } else if (wokeInTime && noBacklog) {
    state = 'green';
    why = `woke ${round1(ageMin)} min ago, inbox empty`;
  } else if (wokeInTime) {
    state = 'amber';
    why = `woke ${round1(ageMin)} min ago, but ${inboxCount} message(s) still in inbox`;
  } else if (noBacklog) {
    state = 'amber';
    why = `inbox empty, but last wake ${round1(ageMin)} min ago is over 2x the ${round1(effectiveMin)} min interval`;
  } else {
    state = 'red';
    why = `last wake ${round1(ageMin)} min ago and ${inboxCount} message(s) still in inbox`;
  }

  return {
    generated_at: new Date().toISOString(),
    mailbox_dir: MAILBOX_DIR,
    state,
    why,
    last_wake: validWake ? hb.ts : null,
    last_wake_mtime: hbMtime,
    last_wake_age_min: ageMin === null ? null : round1(ageMin),
    wake_count_observed: stamps.length,
    nominal_interval_min: nominalMin,
    observed_interval_min: observedMin,
    effective_interval_min: round1(effectiveMin),
    inbox_count: inboxCount,
    acks_total: ackNames === null ? null : ackNames.length,
    acked_not_closed: ackedNotClosed,
    recent_acks: recentAcks,
  };
}

app.get('/api/mailbox', (req, res) => {
  res.json(mailboxState());
});

app.get('/api/sessions', async (req, res) => {
  try {
    const result = await cached('sessions', 15_000, async () => {
      const entries = await Promise.all(
        Object.entries(TEMPLATES).map(async ([name, id]) => {
          const sessions = await listSessions(id, 20);
          return sessions.map((s) => ({
            agent: name,
            id: s.id,
            status: s.status,
            source_type: s.source_type,
            created_at: s.created_at,
            title: s.title,
          }));
        })
      );
      return entries.flat().sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
    });
    res.json(result);
  } catch (err) {
    res.status(502).json({ error: String(err.message || err) });
  }
});

// One mining pass feeds every panel. /api/overview keeps the shape it always had and the
// two routes below read slices of the same cached object, so adding the sleeve B views
// costs zero extra API calls.
//
// A finished session never changes, so its mined findings are memoised per session id and
// only a still-running session is re-fetched. That is what makes the window wide enough to
// cover a whole trading day: on 25 Nov the desk ran 30 sessions, and the old newest-20
// window cut off everything before 19:00Z — including the 10:08 ET fly veto, which is why
// Sleeve B read zero records for a day that had one.
const MINE_TTL_IDLE_MS = 10 * 60_000;
const MINE_TTL_RUNNING_MS = 20_000;
const mineCache = new Map();
async function minedSession(session) {
  const running = session.status === 'running' || session.status === 'active';
  const hit = mineCache.get(session.id);
  if (hit && Date.now() - hit.at < (running ? MINE_TTL_RUNNING_MS : MINE_TTL_IDLE_MS)) return hit.value;
  const value = await mineSession(session.id);
  if (mineCache.size > 300) mineCache.clear();
  mineCache.set(session.id, { at: Date.now(), value });
  return value;
}

async function buildDesk() {
  // The scheduled runs fire on the coordinator, and the four OPT-* runs fire directly on
  // the executor, so all four templates are listed. The children (researcher,
  // risk_auditor) are NOT separate sessions — they are threads inside the coordinator's
  // session, which is why mineSession has to read the thread endpoint as well: the
  // coordinator's own stream carries only its delegation calls, and a top-level-only pass
  // reported "unknown" for a day that contained nine guard verdicts.
  const perTemplate = await Promise.all(
    Object.entries(TEMPLATES).map(([name, id]) => listSessions(id, 30).then((s) => ({ name, sessions: s })))
  );
  const allSessions = perTemplate.flatMap((t) => t.sessions.map((s) => ({ ...s, _agent: t.name })));
  allSessions.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

  const recentSessions = allSessions.slice(0, MINE_SESSION_LIMIT);
  const mined = await Promise.all(recentSessions.map(async (s) => {
    const f = await minedSession(s).catch(() => null);
    return f ? { session: s, f } : null;
  })).then((rows) => rows.filter(Boolean));

  const merged = {
    guard: [], signal: [], equity_row: [], stats: [], journal: [], ticket: [],
    classify: [], reconcile: [], order_row: [], position_row: [], structure: [],
    last_agent_event_at: null, sessions_seen: recentSessions.length, doc_read_events_skipped: 0,
  };
  const seenPerBucket = { journal: new Set(), ticket: new Set(), classify: new Set(), reconcile: new Set(), order_row: new Set(), position_row: new Set(), structure: new Set() };
  for (const { session, f } of mined) {
    for (const g of f.guard) merged.guard.push({ ...g, session_id: session.id, agent: session._agent });
    for (const s of f.signal) merged.signal.push({ ...s, session_id: session.id, agent: session._agent });
    for (const r of f.equity_row) merged.equity_row.push({ ...r, session_id: session.id });
    for (const st of f.stats) merged.stats.push({ ...st, session_id: session.id });
    for (const key of ['journal', 'ticket', 'classify', 'reconcile', 'order_row', 'position_row', 'structure']) {
      // Cross-session dedupe too: the coordinator's session and the agent thread it drives
      // both surface the same tool output, and a counted-twice fill reads as two entries.
      for (const r of f[key]) {
        const item = { ...r, session_id: session.id, agent: session._agent };
        pushUnique(merged[key], seenPerBucket[key], item);
      }
    }
    const at = f.last_agent_event_at;
    if (at && (!merged.last_agent_event_at || Date.parse(at) > Date.parse(merged.last_agent_event_at))) {
      merged.last_agent_event_at = at;
    }
    // Sum the doc-read suppressions so the panel can state how much was filtered out; a
    // number nobody can see is not evidence that the filter ran.
    merged.doc_read_events_skipped += f.doc_read_events_skipped || 0;
  }

  const guardEvents = merged.guard.slice().sort((a, b) => new Date(a.at || 0) - new Date(b.at || 0));
  // Ledger first, mined rows only for dates the ledger does not have: the two sources
  // disagree on the benchmark field, and a duplicate date would draw the curve twice.
  const ledgerRows = readEquityLedger();
  const equitySeen = new Map();
  for (const r of ledgerRows) equitySeen.set(String(r.date).slice(0, 10), r);
  for (const r of merged.equity_row) {
    const d = String(r.date || r.at || '').slice(0, 10);
    if (d && !equitySeen.has(d)) equitySeen.set(d, { ...r, source: 'mined' });
  }
  const equityRows = [...equitySeen.values()].sort((a, b) =>
    String(a.date || a.at || 0).localeCompare(String(b.date || b.at || 0)));

  const latestGuard = guardEvents[guardEvents.length - 1] || null;
  const latestEquity = equityRows[equityRows.length - 1] || null;
  const nav = latestEquity ? SleeveB.num(latestEquity.nav) : null;
  // A guard verdict only carries the fields the proposal needed: the fly envelope verdict
  // prints approved/reasons/qty and no drawdown_pct, so reading every field off the single
  // newest row left the Drawdown and Day Loss cards blank on a day the desk had printed
  // both. Take the newest row that actually states the field, within the same ET day as the
  // newest verdict — a stale Monday drawdown must not age into today's card.
  const etDayOf = (v) => {
    const t = Date.parse(String(v));
    return Number.isNaN(t) ? null : SleeveB.toEtDate(new Date(t));
  };
  const guardDay = latestGuard ? etDayOf(latestGuard.at) : null;
  const newestGuardField = (field) => {
    for (let i = guardEvents.length - 1; i >= 0; i--) {
      const g = guardEvents[i];
      if (guardDay && g.at && etDayOf(g.at) !== guardDay) continue;
      if (g[field] != null) return g[field];
    }
    return null;
  };
  // nav and peak_nav as the desk last recorded them, in journal.py's convention:
  // (peak - nav)/peak, a positive percent shortfall. The drawdown CHART keeps the signed dip
  // from readEquityLedger.
  const ledgerNav = latestEquity ? SleeveB.num(latestEquity.nav) : null;
  const ledgerPeak = latestEquity ? SleeveB.num(latestEquity.peak_nav) : null;
  const ledgerDrawdown = ledgerNav != null && ledgerPeak ? Number(((1 - ledgerNav / ledgerPeak) * 100).toFixed(2)) : null;
  const ledgerRow = latestEquity && latestEquity.source !== 'mined' ? latestEquity : null;
  const ledgerEquityDate = ledgerRow ? String(ledgerRow.date).slice(0, 10) : null;
  const ledgerDayPnl = ledgerRow ? SleeveB.num(ledgerRow.net_realized_pnl) : null;
  // A day's realised loss only means anything for the day the row is stamped, and before the
  // REPORT run there is no row for today — reading yesterday's would label it as today's.
  const ledgerIsToday = ledgerRow ? String(ledgerRow.date).slice(0, 10) === SleeveB.etDayNow() : false;
  const ledgerDayLoss = ledgerIsToday && ledgerDayPnl != null && ledgerNav
    ? Number(Math.max(0, (-ledgerDayPnl / ledgerNav) * 100).toFixed(2)) : null;
  const guardDrawdown = newestGuardField('drawdown_pct');
  const guardDayLoss = newestGuardField('day_loss_pct');
  // The cards read the ledger first. guard.py computes drawdown_pct and day_loss_pct against
  // the nav AND peak_nav the PROPOSER'S OWN envelope declares, and on 25 Nov the fly
  // envelope declared peak_nav = nav, so the verdict stated 0.0 while the auditor's
  // broker-derived anchor read 0.174. A risk card must not inherit a self-declared peak, so
  // the verdict's own numbers stay alongside as guard_verdict_* for the note under the card.
  const drawdown = firstNumber(ledgerDrawdown, guardDrawdown);
  const dayLoss = firstNumber(ledgerDayLoss, guardDayLoss);

  const overview = {
    generated_at: new Date().toISOString(),
    sessions_scanned: recentSessions.length,
    mining: {
      sessions_scanned: recentSessions.length,
      doc_read_events_skipped: merged.doc_read_events_skipped,
      note: 'Verdicts, signals and order rows are mined from cloud session events. An event whose source call read a markdown document — a skill SKILL.md or the desk\'s own notes — is dropped, because text copied out of a document is an example rather than a desk decision; a call that ran desk code is never dropped.',
    },
    status: {
      // The header chip names the desk's risk state, which is what guard.py prints as `state`
      // (normal / caution / daily_halt / hedges_and_closes_only / kill_switch). A verdict's
      // approve/block answer is about ONE proposal, so it must never name the chip: a vetoed
      // structure on an otherwise normal day rendered the header as BLOCKED, which a reader
      // takes to mean the whole desk is blocked. Same reason the field is taken from the newest
      // verdict that states it — the coordinator echoes the verdict again without the state.
      state: newestGuardField('state') || (latestGuard ? 'no risk state printed today' : 'no guard verdict mined'),
      drawdown_pct: drawdown,
      day_loss_pct: dayLoss,
      needs_human_approval: latestGuard ? Boolean(latestGuard.needs_human_approval) : false,
      drawdown_source: drawdown == null ? null
        : ledgerDrawdown != null ? `equity ledger nav vs peak_nav${ledgerEquityDate ? ` (as of ${ledgerEquityDate})` : ''}`
          : 'guard verdict (peak_nav as declared by the proposal)',
      day_loss_source: dayLoss == null ? null
        : ledgerDayLoss != null ? 'equity ledger net_realized_pnl for today, realised only'
          : 'guard verdict (nav as declared by the proposal)',
      guard_verdict_drawdown_pct: guardDrawdown == null ? null : Number(guardDrawdown),
      guard_verdict_day_loss_pct: guardDayLoss == null ? null : Number(guardDayLoss),
    },
    // The desk ledger's own lifetime numbers, so the summary card can state the sample size
    // instead of a bare "no closes" when the day had none.
    ledger: ledgerRow ? {
      date: ledgerRow.date,
      nav: ledgerRow.nav,
      net_realized_pnl: ledgerRow.net_realized_pnl,
      expectancy: ledgerRow.expectancy,
      n: ledgerRow.n,
      source: 'logs/equity.csv (decision-journal equity ledger)',
    } : null,
    equity_curve: equityRows.map((r) => ({
      date: r.date || r.at,
      nav: r.nav,
      bench: r.bench,
      drawdown_pct: r.drawdown_pct,
    })),
    latest_nav: latestEquity ? latestEquity.nav : null,
    // merged[] follows the session iteration order, which is newest-session-first, so the
    // last element is the OLDEST record. journal.py stats ran on both 24 and 25 Nov; reading
    // [length-1] showed the 24 Nov tally as if it were today's.
    stats: (latestOf(merged.stats, 'at') || {}).row || null,
    decision_log: guardEvents
      .slice()
      .reverse()
      .slice(0, 50)
      .map((g) => ({
        at: g.at,
        agent: g.agent,
        approved: g.approved,
        reasons: g.reasons,
        warnings: g.warnings,
        qty: g.qty,
        risk_usd: g.risk_usd,
        order: g.order,
        state: g.state,
      })),
    signals: merged.signal.slice().reverse().slice(0, 30),
    sessions: recentSessions.map((s) => ({
      id: s.id,
      agent: s._agent,
      status: s.status,
      created_at: s.created_at,
      source_type: s.source_type,
    })),
  };

  return {
    ...overview,
    sleeveb: sleeveBView(merged, nav),
    activity: activityView(merged),
    running_sessions: recentSessions.filter((s) => s.status === 'running' || s.status === 'active').length,
  };
}

function getDesk() {
  return cached('desk', 20_000, buildDesk);
}

app.get('/api/overview', async (req, res) => {
  try {
    res.json(await getDesk());
  } catch (err) {
    res.status(502).json({ error: String(err.message || err) });
  }
});

// The sleeve B panel: open option positions and structures, today's order/fill timeline, realised
// P&L, premium deployed on the debit path and max loss at risk on the credit path. Derived from the
// same mined events — this server never calls Moomoo.
app.get('/api/sleeveb', async (req, res) => {
  try {
    const desk = await getDesk();
    res.json({
      generated_at: desk.generated_at,
      sessions_scanned: desk.sessions_scanned,
      sleeveb: desk.sleeveb,
      activity: desk.activity,
      running_sessions: desk.running_sessions,
    });
  } catch (err) {
    res.status(502).json({ error: String(err.message || err) });
  }
});

// The desk activity strip on its own, so the header can be refreshed by a cheaper route.
app.get('/api/activity', async (req, res) => {
  try {
    const desk = await getDesk();
    res.json({
      generated_at: desk.generated_at,
      activity: desk.activity,
      running_sessions: desk.running_sessions,
    });
  } catch (err) {
    res.status(502).json({ error: String(err.message || err) });
  }
});

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Trend desk dashboard running at http://localhost:${PORT}`);
    if (!PAT) console.log('(QODER_PAT missing — set it in .env to see live data)');
  });
}

module.exports = {
  app,
  classify,
  candidateRows,
  collectFromEvents,
  docReadCallIds,
  readEquityLedger,
  activityView,
  sleeveBView,
  normalizeSleeve,
  buildDesk,
  SLEEVEB_CAP_PCT,
  SLEEVEB_MAX_LOSS_CAP_PCT,
};
