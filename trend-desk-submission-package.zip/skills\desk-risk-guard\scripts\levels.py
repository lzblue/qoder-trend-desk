#!/usr/bin/env python3
"""levels: anchor a ticket's stop/take-profit on the ACTUAL fill, and recover either
one from broker state alone (stdlib only).

Why: guard.py sizes from the TICKET (entry - stop), but the ladder-chase can fill
anywhere inside entry x 1.002. If the stop and target stay on the signal price while
cost is the fill, every later stop recovery is wrong by delta/3 -- a systematic
4-5% of the risk distance. Anchoring both levels on the fill keeps r exact: the same
r the order was sized with, measured from the price that was actually paid.

Usage:
  python levels.py anchor  --fill 353.59 --entry 353.90 --stop 352.90 [--rr 1.5]
  python levels.py recover --cost 353.59 --tp 355.09 [--rr 1.5]
  python levels.py stops   --positions positions.json --orders page1.json [--orders page2.json ...]
Prints one JSON object. Places nothing; every exit still needs an auditor-approved ticket.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from book import fills_of, num, payload  # noqa: E402  single source of truth for fill extraction

RR = 1.5
EPS = 1e-9
SIDE_BUY = "1"
SIDE_SELL = "2"
STATUS_RESTING = "2"


def levels_from_fill(fill, entry, stop, rr=RR):
    """(stop, tp_limit, r) for a long position opened at `fill` on a ticket built at `entry`/`stop`.
    Refuses when the ticket is not a valid long or the fill is unusable -- never guesses a level."""
    f, e, s = num(fill), num(entry), num(stop)
    if f is None or e is None or s is None:
        return {"ok": False, "reason": "fill/entry/stop must be numeric"}
    r = e - s
    if not (math.isfinite(r) and r > 0):
        return {"ok": False, "reason": f"ticket stop {s} must be below entry {e} (we only BUY)"}
    if not (math.isfinite(f) and f > 0):
        return {"ok": False, "reason": f"fill price {f} is not a usable price"}
    stop_a = f - r
    if stop_a <= 0:
        return {"ok": False, "reason": f"anchored stop {stop_a:.2f} is not positive: fill {f} is below the ticket's risk distance {r:.2f}"}
    return {"ok": True, "stop": round(stop_a, 2), "tp_limit": round(f + rr * r, 2),
            "r": round(r, 2), "rr": rr, "fill": round(f, 2),
            "drift": round(f - e, 4)}


def recover_stop(cost, tp_limit, rr=RR):
    """Inverse of levels_from_fill: every live equity position is long with a resting SELL limit at
    cost + rr*r, so r -- and the stop -- follow from broker state alone. None when it cannot."""
    c, t = num(cost), num(tp_limit)
    if c is None or t is None or c <= 0 or t <= c:
        return None
    return round(c - (t - c) / rr, 2)


def stops(pages, positions):
    """Per open position (qty > 0 -- a closed row persists with qty:"0" and is NOT a position):
    cost from the filled BUY's avg_fill_price, tp_limit from the one resting SELL limit, stop by
    inversion. Anything ambiguous or missing is reported, never filled in by a guess."""
    rows = []
    for page in pages:
        rows.extend(payload(page).get("orders") or [])
    fills = fills_of(rows)

    out, reasons = [], []
    for p in payload(positions).get("positions") or []:
        sym = p.get("symbol") or p.get("code")
        qty = num(p.get("qty") if p.get("qty") is not None else p.get("quantity")) or 0.0
        if qty <= EPS or not sym:
            continue
        buys = [f for f in fills if f["symbol"] == sym and f["side"] == SIDE_BUY]
        resting = [r for r in rows if r.get("symbol") == sym and str(r.get("side")) == SIDE_SELL
                   and str(r.get("status")) == STATUS_RESTING]
        rec = {"symbol": sym, "qty": qty, "cost": None, "tp_limit": None, "stop": None}
        if not buys:
            rec.update(status="missing_fill", reason="no filled BUY row for this symbol in the history")
        elif len(resting) != 1:
            rec.update(status="missing_tp",
                       reason=f"{len(resting)} resting SELL limits for this symbol, need exactly 1")
        else:
            # one position per family per day, so a single BUY is the normal case; a second one
            # means the cost basis is ambiguous and the stop must not be invented
            if len(buys) != 1:
                rec.update(status="missing_fill",
                           reason=f"{len(buys)} filled BUYs for this symbol, cost basis ambiguous")
            else:
                cost = buys[0]["price"]
                tp = num(resting[0].get("price"))
                stop = recover_stop(cost, tp)
                rec.update(cost=cost, tp_limit=tp, stop=stop)
                tp_qty = num(resting[0].get("qty"))
                if tp_qty is not None and abs(tp_qty - qty) > EPS:
                    rec["warning"] = f"resting TP qty {tp_qty:g} != open qty {qty:g}"
                if stop is None:
                    rec.update(status="missing_tp",
                               reason=f"tp_limit {tp} does not sit above cost {cost}, so no stop can be recovered")
                else:
                    rec["status"] = "ok"
        if rec["status"] != "ok":
            reasons.append(f"{sym}: {rec['status']} - {rec['reason']}")
        out.append(rec)
    return {"positions": out, "reasons": reasons}


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("anchor")
    a.add_argument("--fill", required=True)
    a.add_argument("--entry", required=True)
    a.add_argument("--stop", required=True)
    a.add_argument("--rr", type=float, default=RR)
    r = sub.add_parser("recover")
    r.add_argument("--cost", required=True)
    r.add_argument("--tp", required=True)
    r.add_argument("--rr", type=float, default=RR)
    s = sub.add_parser("stops")
    s.add_argument("--positions", required=True)
    s.add_argument("--orders", required=True, action="append")
    x = ap.parse_args()
    if x.cmd == "anchor":
        out = levels_from_fill(x.fill, x.entry, x.stop, x.rr)
    elif x.cmd == "recover":
        st = recover_stop(x.cost, x.tp, x.rr)
        out = ({"ok": True, "stop": st} if st is not None else
               {"ok": False, "reason": f"cannot recover a stop from cost {x.cost} and tp {x.tp} (tp must sit above cost)"})
    else:
        out = stops([json.loads(Path(p).read_text()) for p in x.orders],
                    json.loads(Path(x.positions).read_text()))
    print(json.dumps(out, ensure_ascii=False))


if __name__ == "__main__":
    main()
