#!/usr/bin/env python3
"""decision-journal: append-only decision log, expectancy statistics and daily report (stdlib only).

Usage:
  python journal.py log   --file logs/decisions.jsonl --kind verdict --agent risk_auditor --json '{"approved":false,...}'
  python journal.py stats --file logs/decisions.jsonl
  python journal.py equity --csv logs/equity.csv --date 2026-11-17 --nav 100250 --bench 6720.5
  python journal.py report --file logs/decisions.jsonl --csv logs/equity.csv --date 2026-11-17
--date is optional on report and equity: omitted, both use the current day in America/New_York.
Kinds: signal, verdict, order, fill, close, skip, error, note. A 'close' record carries sleeve, realized_pnl and fees.
Rejections and skips are first-class records: judges ask what failed and why.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import statistics
from datetime import datetime, timedelta, timezone
from pathlib import Path


def append(path: str, kind: str, agent: str, fields: dict | None = None) -> dict:
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    rec = {"ts": datetime.now(timezone.utc).isoformat(timespec="seconds"), "kind": kind, "agent": agent, **(fields or {})}
    with p.open("a") as f:
        f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return rec


def read(path: str) -> list[dict]:
    p = Path(path)
    if not p.exists():
        return []
    return [json.loads(x) for x in p.read_text().splitlines() if x.strip()]


def today_et() -> str:
    """The current calendar day in America/New_York -- the day every desk run is dated by."""
    try:
        from zoneinfo import ZoneInfo
        return datetime.now(ZoneInfo("America/New_York")).strftime("%Y-%m-%d")
    except Exception:  # no tz database: EST, the same fallback desk-risk-guard's to_et() uses
        return datetime.now(timezone(timedelta(hours=-5))).strftime("%Y-%m-%d")


def valid_date(value: str) -> str:
    """Accept only a real YYYY-MM-DD day: a date that cannot match a ts prefix yields a silently empty report."""
    try:
        datetime.strptime(value, "%Y-%m-%d")
    except ValueError:
        raise SystemExit(f"--date must be YYYY-MM-DD, got {value!r}")
    return value


def _stats(pnls: list[float]) -> dict:
    n = len(pnls)
    if n == 0:
        return {"n": 0, "win_rate": None, "avg_win": None, "avg_loss": None, "expectancy": 0.0, "profit_factor": None}
    wins = [x for x in pnls if x > 0]
    losses = [x for x in pnls if x <= 0]
    wr = len(wins) / n
    aw = sum(wins) / len(wins) if wins else 0.0
    al = sum(losses) / len(losses) if losses else 0.0
    # Expectancy = win% x average win - loss% x average loss (Van Tharp / the kickoff deck's formula)
    exp = wr * aw + (1 - wr) * al
    gl = -sum(losses)
    pf = (sum(wins) / gl) if gl > 0 else None
    return {"n": n, "win_rate": round(wr, 3), "avg_win": round(aw, 2), "avg_loss": round(al, 2),
            "expectancy": round(exp, 2), "profit_factor": None if pf is None else round(pf, 2)}


def stats(records: list[dict]) -> dict:
    closes = [r for r in records if r["kind"] == "close"]
    by: dict[str, list[float]] = {}
    for r in closes:
        net = r.get("realized_pnl", 0.0) - r.get("fees", 0.0)   # costs included: model execution friction
        by.setdefault(r.get("sleeve", "unknown"), []).append(net)
    out = {s: _stats(v) for s, v in by.items()}
    out["all"] = _stats([x for v in by.values() for x in v])
    out["vetoes"] = sum(1 for r in records if r["kind"] == "verdict" and not r.get("approved", True))
    out["skips"] = sum(1 for r in records if r["kind"] == "skip")
    out["fills"] = sum(1 for r in records if r["kind"] == "fill")
    return out


def equity_update(csv_path: str, date: str, nav: float, bench: float | None = None) -> list[dict]:
    p = Path(csv_path)
    rows = list(csv.DictReader(p.open())) if p.exists() else []
    rows = [r for r in rows if r["date"] != date]
    rows.append({"date": date, "nav": f"{nav:.2f}", "bench": "" if bench is None else f"{bench:.2f}"})
    rows.sort(key=lambda r: r["date"])
    peak = 0.0
    for r in rows:
        peak = max(peak, float(r["nav"]))
        r["drawdown_pct"] = f"{(peak - float(r['nav'])) / peak * 100:.3f}"
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["date", "nav", "bench", "drawdown_pct"])
        w.writeheader()
        w.writerows(rows)
    return rows


def sharpe(rows: list[dict]) -> dict:
    navs = [float(r["nav"]) for r in rows]
    rets = [b / a - 1 for a, b in zip(navs, navs[1:])]
    if len(rets) < 2 or statistics.pstdev(rets) == 0:
        return {"days": len(rets), "sharpe": None, "note": "need 3+ sessions"}
    s = statistics.mean(rets) / statistics.stdev(rets) * math.sqrt(252)
    return {"days": len(rets), "sharpe": round(s, 2), "note": "annualised from daily returns; indicative only at this sample size"}


def report(records: list[dict], rows: list[dict], date: str) -> str:
    st = stats(records)
    today = [r for r in records if r["ts"].startswith(date)]
    nav = float(rows[-1]["nav"]) if rows else None
    start = float(rows[0]["nav"]) if rows else None
    lines = [f"# Daily report {date}", ""]
    if nav is not None:
        ret = (nav / start - 1) * 100
        lines.append(f"NAV ${nav:,.2f} ({ret:+.2f}% since start), max drawdown {max(float(r['drawdown_pct']) for r in rows):.2f}%")
        if rows[0].get("bench") and rows[-1].get("bench"):
            b = (float(rows[-1]["bench"]) / float(rows[0]["bench"]) - 1) * 100
            lines.append(f"Baseline (SPY buy and hold): {b:+.2f}%")
        lines.append(f"Sharpe: {sharpe(rows)}")
    lines += ["", "## Expectancy after costs (per trade)"]
    for k, v in st.items():
        if isinstance(v, dict):
            lines.append(f"- {k}: n={v['n']} win%={v['win_rate']} avg win={v['avg_win']} avg loss={v['avg_loss']} "
                         f"expectancy={v['expectancy']} PF={v['profit_factor']}")
    lines += ["", f"Vetoes: {st['vetoes']}  Skips: {st['skips']}  Fills: {st['fills']}", "", "## Rejected and skipped today"]
    rej = [r for r in today if (r["kind"] == "verdict" and not r.get("approved", True)) or r["kind"] == "skip"]
    lines += [f"- {r['ts'][11:16]}Z {r.get('ticker', '')} {r.get('reasons') or r.get('reason')}" for r in rej] or ["- none"]
    lines += ["", "## What worked / what failed / why", "- (auditor fills in from today's closes)"]
    return "\n".join(lines)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("cmd", choices=["log", "stats", "equity", "report"])
    ap.add_argument("--file", default="logs/decisions.jsonl")
    ap.add_argument("--csv", default="logs/equity.csv")
    ap.add_argument("--kind")
    ap.add_argument("--agent", default="unknown")
    ap.add_argument("--json", default="{}")
    ap.add_argument("--date", help="YYYY-MM-DD; on report and equity defaults to the current day in America/New_York")
    ap.add_argument("--nav", type=float)
    ap.add_argument("--bench", type=float)
    a = ap.parse_args()
    if a.cmd in ("report", "equity"):
        # report filters per-day records by a ts prefix and equity keys a row by it, so both need a real date
        a.date = valid_date(a.date) if a.date else today_et()
    if a.cmd == "log":
        try:
            payload = json.loads(a.json)
        except json.JSONDecodeError as exc:
            raise SystemExit(f"--json is not valid JSON ({exc.msg} at char {exc.pos}): pass one object, e.g. --json '{{\"ticker\":\"QQQ\"}}'")
        if not isinstance(payload, dict):
            raise SystemExit(f"--json must be a JSON object, got {type(payload).__name__}")
        # kind and agent name the record and are set from the flags, so the payload is merged as plain
        # fields rather than splatted into the call: a pasted record that repeats "kind" used to raise
        # "append() got multiple values for argument 'kind'" and lose the verdict entry. Same value is
        # redundant and dropped; a different value is ambiguous, so refuse instead of picking silently.
        flags = {"kind": a.kind, "agent": a.agent}
        for key in flags:
            if key not in payload:
                continue
            if flags[key] is None:
                flags[key] = payload[key]
            elif payload[key] != flags[key]:
                raise SystemExit(f"--json {key}={payload[key]!r} conflicts with --{key}={flags[key]!r}: set it in the flag only")
        fields = {k: v for k, v in payload.items() if k not in flags}
        print(json.dumps(append(a.file, flags["kind"], flags["agent"], fields), ensure_ascii=False))
    elif a.cmd == "stats":
        print(json.dumps(stats(read(a.file)), ensure_ascii=False))
    elif a.cmd == "equity":
        print(json.dumps(equity_update(a.csv, a.date, a.nav, a.bench)[-1]))
    else:
        rows = list(csv.DictReader(Path(a.csv).open())) if Path(a.csv).exists() else []
        print(report(read(a.file), rows, a.date))


if __name__ == "__main__":
    main()
