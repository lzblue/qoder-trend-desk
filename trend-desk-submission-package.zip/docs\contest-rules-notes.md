# Competition rules — Moomoo x Qoder AI Trading Agent Challenge

Source: official rules page (`moomoo-qoder-challenge-rgkelnyuzbm.qoder.website`), read
2026-11-19 and re-read in full at 2026-11-25T07:21Z. Account 5830104, $100,000 virtual
funds, window 17–28 Nov 2026. Everything in the two sections marked *observed 2026-11-25*
is quoted from that re-read; the judging criteria appear twice on the page (event section and Terms &
Conditions clause 2), and all four bullets match on 2026-11-25 once the event copy's bold markup is stripped.

## Submission mechanics — observed 2026-11-25

> Submit by **30 November 2026, 11:59 PM SGT** through the submission link on the [Luma
> event page](https://luma.com/oezyv35j): a Qoder-generated presentation deck together with
> a runnable trading-agent package. Your submission should include your strategy
> explanation, risk limits, a log of trading decisions, trade fills and results, and a demo
> showing what worked, what failed, and why.

Deadline in UTC: **2026-11-30 15:59Z** (SGT = UTC+8). Timeline on the same page:
development and trading window **17–28 Nov 2026**, submission deadline **30 Nov**, top-10
finalist presentations **8 Dec**. "The top 10 entries will be shortlisted for final
judging."

Two statements that change how the rest of this file should be read:

- The page's own guidance asks for a **screen capture of the dashboard** as part of the
  entry ("record a short screen capture of the local dashboard in action … and submit it
  with your entry"), i.e. the dashboard is a scored artifact, not decoration.
- On version control: "**Never include PATs, OAuth tokens or other credentials.**"
  (`.gitignore` already excludes `.env`, `*.key`, `*.pem`; a secret scan of every file that
  would ship found only code that *reads* `QODER_PAT`, never a value.)

## Judging criteria — observed 2026-11-25, verbatim

| Weight | Criterion, as written | What carries it in this entry |
|---|---|---|
| 25% | **Risk-adjusted return** — "Trading performance evaluated relative to the risks taken." | `docs/submission/trading-journal.md` §1 equity table + the backtest in §4; net, max drawdown and per-trade R together, never NAV alone. |
| 30% | **Qoder & Qoder Cloud Agent usage** — "Effective use of Qoder and Qoder Cloud Agent for agent engineering, including multi-agent orchestration and automation, as well as developing dashboards, reports, and reusable skills." | Four Forward templates + 11 schedules (§2–§3), the dashboard (§9), five published skills. |
| 30% | **Strategy & risk design** — "A clear trading thesis and edge, defined conditions that invalidate the strategy, and robust risk controls, including position limits, drawdown responses, and kill switches." | Sleeves A/B/C and their invalidation rules (§4), `guard.py` gates, the state machine (`kill_switch`, `daily_halt`) in §5. |
| 15% | **Reusability & documentation** — "Reference-ready agent templates, reusable skills and scripts, plus presentation slides or a report clearly explaining how the agent works." | `AGENTS.md` (template snapshot), `docs/decisions/PORTABILITY.md`, the deck. |

Weights sum to 100%. Clarifications from the page's FAQ, also verbatim:

- "'Strategy and risk' focuses on trading strategy and financial risk management and
  accounts for 30% of the score. Judges also consider returns, trade execution, and your
  overall agent-based trading framework."
- "Strong returns do not guarantee a strong overall score. A high-risk approach may score
  lower on strategy and risk management, even if it is profitable."
- Terms & Conditions clause 2: "a participant will not be selected as a winner based solely
  on absolute investment returns, portfolio value or leaderboard position."
- "Can I stop trading and submit before the competition ends? Yes. Early submission is
  allowed." — so the 25–27 Nov sessions are upside, not an obligation.
- It is an **individual** competition.

This closes the gap that `docs/decisions/rules-source-of-truth-nov20.md` recorded on
2026-11-20 (it found "no judging, submission or deadline content at all" here and asked for
a `docs/judging-criteria.md` that was never written). The weights in that memo were a
handbook quotation; they are now page-verified and unchanged, so `docs/judging-criteria.md`
is still absent by choice — this file is the rules-of-record.

## Resolved: no minimum-trades or minimum-ticker rule

The "need 3+ tickers" idea came from the 40%-per-ticker exposure cap, not a
trading-activity requirement. No single stock/ETF position may exceed 40% of
total *initial* account assets — so to deploy 100% of capital you mechanically
need 3+ distinct tickers (e.g. 40/40/20, or 4 tickers at 25% each). Sitting
flat with zero trades carries **no penalty** under these terms — there is no
disqualification or scoring clause tied to trade count or ticker count.
(A separate, broader Moomoo "3rd Global Paper Trading Competition" — Oct 11–
Nov 20, different dates — does list "trading activity" as a scoring
*dimension*, but that's a different event from this one and doesn't apply
here as confirmed.)

## Important open design question this raises

**Margin trading and short selling are both natively available** on this
account — not something I'd confirmed before. Terms: long positions 50%
initial / 40% maintenance margin; short positions 60% initial / 50%
maintenance; margin financing interest 4.8%/yr, short-selling interest
6.0%/yr, both charged daily after market close.

Sleeve A/C were designed around buying inverse ETFs (SQQQ/SPXS/SOXS) for
bearish exposure, on the assumption direct shorting wasn't available/verified.
It is. Trade-off not yet resolved:
- Inverse ETF (current design): no margin bookkeeping, no short-interest
  accrual, but leveraged-ETF decay drag and an extra product's own fees.
- Direct short: avoids ETF decay, but adds daily short-interest cost (6%/yr)
  and margin-requirement tracking, and changes `portfolio_gate`'s "only ever
  BUYS to open" invariant — a short position would become a normal state,
  not an error state, if adopted.

**Action**: have QCA's 30-session backtest compare both and report which
nets better after all costs, before committing either way.

## Other rules worth having on record

- Eligibility floors, per instrument class as the page writes them: only US-listed stocks, ETFs
  and options may be traded; "Stocks priced below USD 1 are not eligible for trading"; "Stocks and
  options of companies with a market capitalisation below USD 500 million are not eligible". The
  $500M clause names *companies*, not funds, so applying it to an ETF's net assets is the desk's
  interpretation and not a quotation — that reading is what removed `SPXS` from SPY's bearish
  routing. Audit: `docs/decisions/rules-source-of-truth-nov20.md` §2.2, and the open question is
  kept on the record in `docs/decisions/spxs-eligibility-fix.md` §7 item 3. (This bullet was
  rewritten 26 Nov to the per-class wording drafted in `rules-source-of-truth-nov20.md` §9; the
  version the memos were audited against said "nothing priced under $1 or market cap under $500M
  is eligible", which folds two floors written for different instrument classes into one.)
- Trading hours: 4:00 AM–8:00 PM ET (pre-market + regular + after-hours).
- Max 200 executed orders/day (cancelled/amended don't count); max 100
  concurrent positions. Nowhere close to binding at our scale.
- Options are excluded from the 40% stock/ETF cap; capped separately at 1,000
  contracts per single contract (combined position + pending orders).
- Fills require real matching market volume: if order qty > 20x actual market
  volume, partial fill, remainder stays pending. Matters if lower-liquidity
  candidate tickers (GLD/TLT/XLE) ever get activated; not a concern for
  QQQ/SPY/SMH at our size.
- Stock fees: $0 commission, $0.99/order platform fee, $0.000166/share sold
  capped at $8.30/trade (sell-side only). Cross-check against whatever fee
  assumption the 30-session backtest uses — QCA's option fee formula
  (2*(1.99+0.30*contracts)) is for options and doesn't conflict with this.
- ITM options auto-exercised after close on expiry day; OTM expire worthless;
  index/stock options settle at closing price on expiry date.
- Reset Card / revival mechanism use is grounds for automatic disqualification.
  `guard.py`'s flow has no such mechanism anywhere — no exposure here.
- Final settlement uses regular-market closing prices on the final
  competition day; after-hours trades on the final day don't count. Weekly
  return figures use Friday 10:00 PM ET prices.
