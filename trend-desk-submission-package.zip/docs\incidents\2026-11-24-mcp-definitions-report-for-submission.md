# MCP tool definitions occasionally absent from the model's request (Forward / Cloud Agents)

**Type:** platform defect — model context assembly / MCP tool registration
**Severity:** high (silent, unrecoverable-by-config; cost one full trading day of an unattended desk)
**Reporter's product surface:** Qoder Cloud, Forward layer (`/api/v1/forward`)
**Status of reporter-side workaround:** mitigated in prompts, **not** fixed at source — the defect is still reachable.

## Summary

In Forward-mode sessions whose template declares an MCP server, that server's tool definitions are
occasionally missing from the model's context — including on the **first** model request of a freshly
created child thread — while the connector itself is healthy. The session's own registry still resolves
the tool, so the failure is recoverable by re-issuing the call, but nothing observable tells the client
which of the two states it is in. The result is that a wrong tool name and a dead connector are
indistinguishable from the event stream, and an agent will (correctly, by its own evidence rules) halt.

## Environment

- Forward API, identity `idn_a3c83d8b8fd13c3f158a12c7`, environment `env_00vqul91jtzi9aekyu8m`.
- MCP server `moomoomcp` → `https://mcp.moomoo.com/mcp`, declared on three templates:
  `tmpl_d7df3829ed5d73548bb5e9ed`, `tmpl_bf2c477c0fba1a3363833f91`, `tmpl_6c3c42cc4500efcbd6d60309`.
- All templates: toolset `agent_toolset_20260401`, `permission_policy: always_allow`, model `efficient`,
  `context_window: 200000`.
- Sessions are schedule-originated (`source_type: "schedule"`), each with a Managed twin sharing the
  `sess_` id. **This is not a Managed-mode run** — the mode hypothesis was tested and rejected.

## Deterministic reproducer

1. `POST /forward/sessions` with `{identity_id, template_id: tmpl_d7df3829ed5d73548bb5e9ed,
   budget: {type: "limit", max_credit_cost: "3.00"}}`.
2. Send one `user.message` instructing the agent to emit exactly the tool name
   `moomoomcp__quote_stock_quote` with the parameter `{"code_list":"[\"US.QQQ\"]"}`.
3. Observed: `agent.tool_use` with `evaluated_permission: "deny"` and the result
   `Tool 'moomoomcp__quote_stock_quote' does not exist in this session's tool set.`
4. In the **same session**, immediately afterwards:
   - `agent.mcp_tool_use` with `name: "quote_stock_quote"`, `mcp_server_name: "moomoomcp"`,
     `input: {"code_list":["US.QQQ"]}` → returns live data, `ret_code: 0`.
   - `agent.tool_use` with `name: "mcp__moomoomcp__quote_stock_quote"` → also resolves.

Executed: session `sess_00werfiurbklcuqzvys7`, thread `sthr_00werfjbomsxskmq4s4s`,
2026-11-23T23:42:11Z → 23:42:41Z. The registry form works, the flattened form does not, and the error
text names no server, so a client cannot tell "server not registered" from "tool name not registered".

## Production incident evidence (2026-11-23, non-deterministic)

Session `sess_00wdhbcisny0wq187gc0` (a scheduled SCAN): 8 denied calls of exactly the shape above across
3 of its threads, while the same event stream contains **188/188** successful correct-path
`agent.mcp_tool_use` calls that day — including three made by a **different role in the same session** at
15:38:28, 15:38:31 and 15:38:35, i.e. 6 and 13 seconds around a researcher failure at 15:38:22.

| population | tool name form | parameter typing |
|---|---|---|
| 188 successes | bare (`quote_stock_quote`, `quote_market_state`, `quote_cur_kline`) | native: `["US.QQQ"]`, `{"ktype":6,"num":12}` |
| 8 failures | server-prefixed (`moomoomcp__…`) | string-serialised: `"[\"US.QQQ\"]"`, `"6"`, `"14"` |

Per thread:

- `sthr_00wdhdf48gjr4sfsutac` — 0 correct, 2 wrong, on **model request #1**, `compactions = 0`.
- `sthr_00wdkaaiom7lsr49xk9k` — 0 correct, 2 wrong, on **model request #1**, `compactions = 0`.
- `sthr_00wdi7txaw8ao432gcxm` — 20 correct, then `agent.thread_context_compacted` at 15:29:58, then 4
  wrong 48 s later.

Two threads therefore failed before any model turn had completed, so compaction is one trigger, not the
cause. The string-typed parameters are the load-bearing evidence: a model that can see a JSON schema does
not serialise an array into a string — the **schema**, not merely the name, was absent.

## Corroboration on a native tool, same session

The coordinator called `create_agent` with the key `agent_name` four times and received
`create_agent requires a non-empty name.`, then retried with `name` and succeeded. Same signature —
identity known, schema reconstructed from memory — on a built-in tool, which rules out anything specific
to the MCP connector.

## Frequency, measured over 7 trading days

Rejections of the string `Tool 'X' does not exist in this session's tool set`, counted from
`agent.tool_result` bodies rather than from one name shape:

| date | connector-name rejections | correct-path MCP calls | recovered in the same session |
|---|---|---|---|
| 2026-11-17 | 0 | 1 | — |
| 2026-11-18 | 0 | 108 | — |
| 2026-11-19 | 2 (`moomoo__…`, wrong server alias) | 192 | **yes, 2/2** (+5, +9 calls afterwards) |
| 2026-11-20 | 0 | 112 | — |
| 2026-11-22 | 1 (`send_to_message` — an invented **non-MCP** tool name) | 0 | — |
| 2026-11-23 | 8 (`moomoomcp__…`, 3 threads) | 188 | **no, 0/3** |

≈10 connector-name rejections per ~610 correct-path calls, on 3 of 7 days. The 11-22 row matters: the
same failure mode produced a made-up *harness* tool name, so this is a general tool-definition-injection
issue, not an MCP-connector bug.

## Why this is expensive for schedule-driven agents

Nothing in the event stream reports the resolved tool set. No event type carries it —
`agent.thread_context_compacted` carries only `id`, `processed_at`, `session_id`, `type` — and
`GET /forward/sessions/{id}/resources` returns **405**. A client cannot distinguish "connector down" from
"definitions not in context" except by inferring it from the shape of the model's own output. On
2026-11-23 that cost a full trading day: 0 orders placed, the 10:00–11:00 ET entry window forfeited, and
39.6 credits burned by one scheduled run for zero verdicts. Worse, the misdiagnosis ("the namespace
dropped mid-run") was itself persisted into the desk's durable memory and propagated to later runs until
this analysis corrected it.

## Requests

1. **Guarantee, or make observable,** that every MCP server declared on the compiled template is present
   in the tool list of the **first** model request of every thread — including threads created by
   `create_agent`. Two of the three failing threads had no completed model turn before the first rejection.
2. **Re-inject tool definitions after `agent.thread_context_compacted`** rather than relying on the
   conversation summary; one thread lost them exactly there.
3. **Name the server in the unknown-tool error**, e.g.
   `tool "moomoomcp__quote_stock_quote" not found in server "moomoomcp"; did you mean the tool "quote_stock_quote"?`
   A wrong name would then be self-correcting and would not be mistaken for an outage.
4. **Document the accepted tool-name forms** — registry string `mcp__<server>__<tool>` versus
   `mcp_server_name` + bare name — and state whether both are stable API. The acceptance path had to
   discover the `mcp__` prefix by trial after two denials and a 20 s pause.
5. **Expose the resolved tool list per thread**, either as an event type or as a session resource (that
   route currently 405s). Without it, "definitions absent" is only inferable after it has already cost a turn.

## Field mitigation already deployed by the reporter (context, not a fix)

All four desk templates now carry an explicit dispatch contract (server + bare tool name + native JSON
types, plus the registry form) and an R1–R4 recovery ladder that forbids reporting a gap until a
bare-name attempt has failed with a connector-class error (`ret_code`, `Forbidden`, auth, timeout,
network). A regression gate counts rejections and per-thread recovery from the event stream daily. This
converts a lost run into one wasted tool call, but it is prompt-level: it depends on the model following
the instruction, and it cannot make the definitions appear. It does not remove the need for 1–5.

## Evidence available on request

Raw event-stream captures for both the reproducer session and the 2026-11-23 incident session, the
per-thread rejection tally, and the four template configurations (before / after mitigation).
