# Release sequence, Nov 20–22 2026 — three nights, three releases, one per ET-day change slot

**This file is the authoritative record of what was chosen and in what order.** A reader should not need
the three decision memos to know the sequence; where those memos still disagree with this file, this file
is the one the owner decided. Prepared by mailbox `20261120T034745Z-d20f3e` (Tier B: prep and docs only),
2026-11-20T04:5xZ. **Nothing below has been applied.** Every cloud call made while preparing it was a `GET`.

## 1. The decision

| # | night (ET-day slot) | release | what it changes | package |
|---|---|---|---|---|
| 1 | **2026-11-20**, opens `2026-11-20T05:00:00Z` (00:00 ET), closes `13:30:00Z` (08:30 ET) | **latency fix** (Proposal A, sleeve-A-scoped re-quote clause) | `researcher.system`, `coordinator.system` — prompt text only, no skill publish, no re-pin | `.scratch/proposal-a-1120/` |
| 2 | **2026-11-21** | **SPXS removal, Package A** | publishes `desk-risk-guard` + `trend-signal` + `vwap-chop` versions, re-pins `researcher`/`executor`/`risk_auditor` | `.scratch/changes/2026-11-20-spxs-eligibility/A-remove-spxs/` |
| 3 | **2026-11-22** at the earliest | **IWM long-only** | publishes `trend-signal` + `vwap-chop` versions, re-pins + re-prompts `researcher`/`executor`/`risk_auditor`/`coordinator` | `.scratch/changes/2026-11-20-release-sequence/` |

**Nights 2 and 3 are conditional on the night before them actually landing.** The dates are derived from the
change budget, not fixed in advance: if release 1 slips a night, everything after it slips with it, and the
gate will name the new instant for you. Do not "catch up" by putting two of these in one ET day — that is
exactly what §6.4 forbids and what the gates refuse.

Why this order, in one line each:

- **Latency fix first** because it is costing real signals every live session: the SCAN round trip is
  ~21m47s against the researcher's own 5-minute staleness rule, which voided the only two approvable
  signals the replay found. The bug is realised loss, recurring daily.
- **SPXS second** because the exposure it fixes is **potential, not realised** — SPXS has never actually
  been traded (that premise comes from `spxs-eligibility-fix.md` §0.5 and was **not** independently
  re-verified here; no local journal or log mentions an SPXS position, which is consistent but not proof).
  If that premise is wrong, the ordering argument weakens, though the A-over-B choice does not.
- **IWM third** because its before-bytes *are* SPXS-A's after-bytes. This is not a stylistic preference:
  `verify.py` C1/C1b shows this package's anchors fail to match at all on the pre-SPXS-A live files, and
  C2d/C2e shows a whole-field `system` POST built on pre-latency-fix text silently reverts release 1.
  The order is enforced by content at apply time, not by this table.

## 2. SPXS: A chosen, B rejected-for-now

`SH` (1x inverse) instead of removing SPXS would change the **risk character** of the desk, not just its
ticker list: roughly double the notional for the same bearish idea, about a third of the risk per ticket,
and it binds against the 35% `single_asset_target_pct` capital cap instead of against the risk budget the
sizing was designed around. That is a different strategy.

**B is rejected-for-now, not discarded.** If a bearish SPY instrument is wanted later, B is the shape to
revisit, and Package B's prepared bytes stay where they are.

## 3. The budget rule, settled — and three claims about it that are wrong

DRIVER.md §6.4 says only *"One change per template per day so effects can be attributed"*. **The word "day"
is not qualified anywhere in DRIVER.md** — that single missing word is what produced three mutually
incompatible statements tonight. Resolved to the **America/New_York calendar day**, for three reasons
recorded in `tools/slot.mjs`'s header: the same rule's change *window* is defined in ET; every schedule on
this desk is `America/New_York` and every prompt says so; and the stated purpose is attribution, whose unit
here is one US session.

Live observed at 04:21Z, `GET /templates/{id}`, verbatim strings:

| template | `updated_at` as returned | = UTC | ET calendar day | window containing it |
|---|---|---|---|---|
| researcher / executor / risk_auditor | `"2026-11-20T09:29:44+08:00"` | 2026-11-20T01:29:44Z | **2026-11-19** (20:29 ET) | the **current** one, 11-19 → SPENT |
| coordinator | `"2026-11-19T22:05:04+08:00"` | 2026-11-19T14:05:04Z | 2026-11-19 (09:05 ET) | **no window** — it sits in the daytime gap |
| executor-gating-rehearsal | `"2026-11-20T09:22:41+08:00"` | 2026-11-20T01:22:41Z | 2026-11-19 (20:22 ET) | the current one → SPENT |

The API returns a **`+08:00` offset, not Zulu**, so "which day" has three candidate answers and they do not
all agree. Computed with all three helpers (`.scratch/released20f3e/daydefs.cjs`, from `slot.mjs`'s
boundary definition and `budget.mjs`'s `windowFor`):

- For the 01:29:44Z / 01:22:41Z writes: ET day **11-19**, boundary day **11-19**, `budget.windowFor`
  **11-19** — all three agree, and UTC day would say **11-20**, which is the only reading that makes
  c25e91's claim look true.
- For the coordinator's 14:05:04Z write: ET day **11-19**, boundary **11-19**, `budget.windowFor` **11-18**.
  It disagrees because the question is ill-posed: 09:05 ET is outside every change window, so "which window
  contains it" has no answer and the two implementations attribute it to opposite sides. That is exactly the
  hazard §9.2 was worried about, and it is why release 1 must be re-gated at 05:00Z rather than reasoned
  about now.

This package uses the **ET calendar day**; `slot.mjs` prints the raw string, the UTC instant, the ET day, and
the same-window verdict on every run, so a disagreement is visible instead of buried in a helper.

Verdicts on the three claims:

1. **[correct] 7b19d4:** "next slot opens `2026-11-20T05:00:00Z` = 00:00 ET 20 Nov, usable to 13:30:00Z".
   Reproduced: `slot.mjs researcher,coordinator` exits 3 naming exactly that instant at 04:20Z, and exits
   4 (eligible) at 05:10Z. `proof/scenarios.txt` S1/S2.
2. **[wrong] c25e91:** "researcher, risk_auditor and executor were all written 2026-11-20T01:29:44Z
   (spent today); a coherent release cannot happen on 2026-11-20." Those writes are **ET 2026-11-19**. The
   claim compared UTC dates. Release 1 *is* eligible on the 20th; what is genuinely blocked is release 2 on
   the 20th — and only because release 1 will have spent `researcher`. Same scenarios, S3/S3b.
3. **[superseded, not disproved] §9.2 of this very memo** concludes the earliest eligible researcher write is
   `2026-11-20T21:45:00Z` (16:45 ET 20 Nov) rather than `05:00:00Z`. Read §9.2 before believing this
   sentence: it is not an arithmetic slip. It rests on a documented desk precedent
   (`researcher-write-once-nov20.md` §6) and on the observation that both the 01:29:44Z release and a 05:00Z
   release land **before the same 20 Nov BRIEF at `14:00:00Z`** — so the ET-day reading permits exactly the
   two-unattributable-changes-in-one-trading-day outcome §6.4 exists to prevent.
   The honest position is that **DRIVER §6.4's "per day" is ambiguous and the desk has produced two
   documented readings of it.** The owner's sequence decision settles it for these three releases — latency
   fix first, from 05:00Z, double-dip accepted — but the rule itself still says "day", and the next release
   will need the same judgement call. Do not re-derive it from the rule text; run `slot.mjs`, which prints
   both the ET-day and the same-window answer on every invocation. §9.2's safety argument about the
   coordinator (never write it alone, because the window reading makes it eligible while the researcher is
   spent) holds under **both** readings and is why `write-system.mjs` refuses half the pair.

**A real wrinkle none of the three framings mentions:** the window `16:45 ET → 08:30 ET` **crosses ET
midnight**. Two writes can therefore sit in one continuous window on two different ET days — legal per the
letter of §6.4, but the upcoming session still opens with two changes on the same template. Tonight is
exactly that case (the 01:29:44Z release plus release 1 at ~05:12Z). `slot.mjs` does not hide it: it prints
the WARN and returns **exit 4**, a third state meaning "eligible, but a human should decide". Only night 3's
`apply.sh` turns that into a hard requirement (`OWNER_SAME_WINDOW=1` in addition to `GO=1`); for nights 1
and 2 the exit code is the whole mechanism, so the decision has to be made and journalled by hand. The
double-dip fires **once**, on night 1 — nights 2 and 3 are clean (S4/S6).

### Two gate defects, found by opening the scripts rather than trusting their names

- **`A-remove-spxs/apply.sh` has no change-budget gate at all** — no date or timezone logic anywhere in it.
  Its gates are a `CONFIRM` string, an open-SPXS-position check, `show-pins.mjs`, then publish/repin/verify.
  The task's premise that "SPXS's apply.sh will itself detect Nov-20's researcher slot as spent and tell
  the owner to wait for Nov-21" is **false**. A human following it on the 20th would be permitted to write
  `researcher` twice in one ET day. Night 2 below supplies the missing gate from outside; nothing in that
  package needs to change.
- **`.scratch/proposal-a-1120/tools/budget.mjs` is over-strict.** It ANDs all four templates regardless of
  which ones a release touches. Demonstrated offline (`proof/scenarios.txt` S8): on a state where only
  `researcher` is spent, it prints the coordinator as `eligible now: YES` and still returns exit 3, while a
  correctly-scoped gate returns 0. For night 1 it happens to agree (all four are free), so it does not
  block anything tonight — but it is not a per-release gate and should not be trusted as one.

## 4. Night 1 — 2026-11-20: the latency fix

Writes `researcher` + `coordinator` prompts. No skill publish, no re-pin, no schedule change.
Account: no orders, no position calls, `5830104` untouched.

The window is verified clear of live runs, read live from `GET /schedules` at ~05:0xZ
(`.scratch/released20f3e/schedules.json`, all 7 schedules `active`, field path `trigger_policy`):
`BRIEF 0 9 * * 1-5` → `2026-11-20T14:00:00Z`, then SCAN-1005 15:05Z, SCAN-1100 16:00Z, SCAN-1230 17:30Z,
SCAN-1400 19:00Z, FLAT 20:30Z, REPORT 21:15Z. The change window closes 13:30:00Z, so **the desk is idle
across the entire Nov-20 window** and nothing needs to be paused.
(Caveat so the evidence isn't over-read: `tools/recon.mjs` prints `-` in its cron/next column — it reads
top-level `cron`/`next_run_at`, while the real fields are `trigger_policy.expression` and
`trigger_policy.upcoming_runs_at`. The times above come from the raw `schedules.json`, not that table.)

```bash
cd /c/Users/tteh/Documents/qoder-trend-desk-dashboard

# 4a. budget gate - run it at/after 2026-11-20T05:00:00Z. Exit 0 or 4 = go on; 3 = wait.
node --env-file=.env .scratch/changes/2026-11-20-release-sequence/tools/slot.mjs researcher,coordinator
#     exit 4 means: eligible for the ET day, but the 01:29:44Z release is in the same continuous window.
#     Read the WARN and decide - proposal-a's apply.sh does not consult this gate, so it will not stop you.

# 4b. its own preflight + dry run (both are read-only against production)
node --env-file=.env .scratch/proposal-a-1120/tools/preflight.mjs
bash .scratch/proposal-a-1120/apply.sh

# 4c. WRITE - the CONFIRM value is printed by step 4b, line "CONFIRM value for this build".
#     As prepared it was 573c2051551d,4246c3bfeca2; re-read it from the dry run, do not type this.
GO=1 CONFIRM=<from-4b> bash .scratch/proposal-a-1120/apply.sh
#     NOTE: that script checks only GO=1 + CONFIRM. It does not read slot.mjs and has no
#     OWNER_SAME_WINDOW branch, so the 4a double-dip warning is the only place it surfaces and there is no
#     flag to record your decision. Night 3's apply.sh does have one; night 1's does not. (Same class of
#     gap as §3 defect 1, and the reason night 2's gate is run from outside that package too.)

# 4d. rollback
GO=1 bash .scratch/proposal-a-1120/rollback.sh
```

Confirm on the first live run: the researcher's SCAN step 2 must re-quote and re-stamp before sending
numbers into `trend-signal`, and the coordinator's SCAN line must carry the same clause. If a SCAN signal
comes back `NONE` with a *stale* reason after this change, that is the bug not fixed, not new behaviour.

## 5. Night 2 — 2026-11-21: SPXS Package A

**Only after night 1 actually landed.** Publishes three skill versions and re-pins three templates.
`CONFIRM=REMOVE-SPXS-A` is mandatory (the script refuses without it) because SPY loses its bearish leg.

```bash
# 5a. budget gate - the gate SPXS's own apply.sh does not have
node --env-file=.env .scratch/changes/2026-11-20-release-sequence/tools/slot.mjs researcher,executor,risk_auditor
#     expected at 5:00Z Nov-21: exit 0 (clean). If it says Nov-22, night 1 slipped - wait, do not double-dip.

# 5b. live pins before the change, and the dry run (nothing sent)
node --env-file=.env .scratch/changes/2026-11-20-spxs-eligibility/tools/show-pins.mjs \
  skill_00vqwa9tq5szk3y13lg4 skill_00vqvkdtlzojk2xg1rku skill_00vz0dq461mv4e5iv1p3
CONFIRM=REMOVE-SPXS-A PORTFOLIO_JSON=<portfolio.json> \
  bash .scratch/changes/2026-11-20-spxs-eligibility/A-remove-spxs/apply.sh

# 5c. WRITE
CONFIRM=REMOVE-SPXS-A PORTFOLIO_JSON=<portfolio.json> GO=1 \
  bash .scratch/changes/2026-11-20-spxs-eligibility/A-remove-spxs/apply.sh

# 5d. rollback
CONFIRM=ROLLBACK-SPXS-A GO=1 \
  bash .scratch/changes/2026-11-20-spxs-eligibility/A-remove-spxs/rollback.sh
```

`PORTFOLIO_JSON` is required in **both** modes and must be a `portfolio.json` dumped from the live account
— not hand-written. Reason: removing SPXS from `universe.leverage` while an SPXS position is open makes
`guard.py` value it at 1x and **understate gross exposure**. Practical hazard, recorded because it has
bitten before: the moomoo `account_*` tools have historically returned no data on this account, so plan to
build the dump from `sim_trade_position_list` (with `market: 100`) plus the cash/NAV reads. If you cannot
produce a real `positions[]`, **do not set the variable to satisfy the gate** — the gate is the safety.

Confirm on the first live run: a SPY downside signal must now return `NONE` with reason
`SPY has no eligible bearish ETF configured - long entries only`, and Sleeve C the same for a SPY fade.
A SPY *long* must still work byte-identically.

## 6. Night 3 — 2026-11-22 at the earliest: IWM long-only

**Only after night 2 landed** — `base-check.mjs` proves it by content and refuses otherwise. Publishes two
skill versions (`trend-signal`, `vwap-chop`) and does **one POST per template** carrying `skills` + `system`
together for `researcher`, because two POSTs would spend the ET-day budget twice.

```bash
# 6a. budget gate
node --env-file=.env .scratch/changes/2026-11-20-release-sequence/tools/slot.mjs \
  researcher,executor,risk_auditor,coordinator

# 6b. everything: build + verify (69 checks) + live preconditions + gate + plan. DRY by default.
bash .scratch/changes/2026-11-20-release-sequence/apply.sh

# 6c. WRITE - CONFIRM is printed by 6b; as prepared it is 21772c46d616,376be5bb1a6b
GO=1 CONFIRM=<from-6b> bash .scratch/changes/2026-11-20-release-sequence/apply.sh

# 6d. rollback (argument = the records/pre-apply-<stamp>.json path 6c printed)
GO=1 bash .scratch/changes/2026-11-20-release-sequence/rollback.sh <records/pre-apply-*.json>
```

Rollback limits, stated because they are easy to get wrong: a published skill version **cannot be
withdrawn**. A rollback re-pins every template to the recorded version, so nothing *resolves* to the new
bytes, but they stay in the version list and `latest_version` stays advanced. **After a rollback the pins,
not `latest_version`, are the marker of what is live** — anyone reading `GET /skills/{id}` alone will read
it wrong.

Confirm on the first live run: IWM appears in the SCAN roster; an IWM long is sized at **1x** (not 3x);
an IWM downside returns `NONE` with `IWM has no eligible bearish ETF configured - long entries only`; and
QQQ/SMH/SPY verdicts are unchanged.

## 7. What this release does NOT include — kept visible, not silently dropped

- **The coordinator prompt still names SPXS** in "(SQQQ, SOXS, SPXS)". SPXS-A's own apply.sh says so at
  line 84 and leaves it out of scope. It is a one-sentence prompt edit; it is **not** urgent because
  `guard.py` refuses SPXS at the rule layer regardless of what the prompt says, so it is a
  prompt-vs-reality mismatch rather than a live risk. It needs its own ET-day slot (a coordinator-only
  write) — and note that is precisely the case `budget.mjs` would wrongly block (§3, defect 2).
- **Full bearish diversification.** Every candidate inverse fails the documented $500M floor
  (TZA $197.6M, SRTY $75.7M, FAZ $94.1M, ERY $50.3M, GLL $93.2M, TMV $200.2M). Direct short-selling of 1x
  ETFs is a separate, larger build — order support, margin, `guard.py` short handling. Deliberately not
  scoped into any night here.
- **The 21m47s SCAN round trip itself.** Release 1 changes what the prompts do with a stale quote; it does
  not make the round trip faster. If night 1's confirmation shows signals still voiding on staleness, the
  remaining fix is scheduling/latency, not text.
- **Nothing else was sequenced:** no schedule change, no `AUTONOMY_PHASE` change, no account or order
  action, no credit-budget change (and note the schedule API has no budget field to set).

## 8. Item (1) of the task: staged, NOT applied

The three decision memos were **not edited** — three live sessions hold them, and two child sessions
already clobbered shared work on this memo family tonight. The exact replacement text for each, with the
bytes and sha256 of the file as read, is in
`.scratch/changes/2026-11-20-release-sequence/doc-status/`:

| staged file | target | holder |
|---|---|---|
| `doc-status/vix-gate-proposal-a-nov20.md` | `docs/decisions/vix-gate-proposal-a-nov20.md` (43,808 B, `651e32e9…`) | session `20261120T023636Z-7b19d4`, still running |
| `doc-status/spxs-eligibility-fix.md` | `docs/decisions/spxs-eligibility-fix.md` (18,102 B, `e57e9543…`) | writer state unknown — the memo drifted after its own done-ack |
| `doc-status/ticker-diversification-nov20.md` | `docs/decisions/ticker-diversification-nov20.md` (38,999 B, `9fe5929a…`) | session `20261120T024106Z-c25e91`, wrote 03:40:54Z, still running |

## 9. Evidence index

| claim | where | result |
|---|---|---|
| the three-night budget verdicts, the double-dip, the abuse case, the over-block | `tools/scenarios.mjs` → `proof/scenarios.txt` | **10 passed, 0 failed**, driven against a loopback mock using the **real** live `updated_at` payloads |
| the IWM package is deterministic, compiles, and behaves (IWM long at 1x, IWM short → NONE, QQQ/SMH/SPY byte-identical) | `tools/verify.py` → `proof/verify.txt` | **69 passed, 0 failed** |
| dry run writes nothing; apply = 2 publishes + 4 single POSTs; rollback restores the world hash; the unreferenced-version residue | `tools/roundtrip.sh` → `proof/roundtrip.txt` | **11 passed, 0 failed** |
| what is live right now (templates, pins, skills, schedules) | `tools/recon.mjs` → `.scratch/released20f3e/recon.txt` | GET-only capture at 04:21Z |
| before-bytes provenance, per file: source path, sha256, byte count | `before/PROVENANCE.json`, re-checked by `tools/build.py` | build aborts if a source moved |
