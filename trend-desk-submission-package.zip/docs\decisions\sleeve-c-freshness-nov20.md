# Sleeve C has no freshness protection — evidence, 2026-11-20

Read-only answer to mailbox `20261120T014903Z-6b2f84`. It feeds the pending decision on the
researcher/coordinator SCAN re-quote-stamp clause (`e5f2a8` chain), which is **not applied**.
No template write, no publish, no order or account action was made to produce this note.

## Verdict

**Sleeve C has no mechanical freshness protection at all, and has never had any.** Its only defence
is one prompt-level sentence with no threshold. A C ticket can therefore be built from a bar series
that stopped updating, and nothing downstream notices.

## 1. live `chop.py` — no quote-age logic exists

Bytes: `vwap-chop` `1795095917868411`, `scripts/chop.py`, 173 lines, sha256 `43810bd7d2ad6e7e…`.
Downloaded from `/forward/skills/.../versions/1795095917868411/content` at 02:31Z and confirmed
byte-identical to the copy captured earlier by `20261120T013558Z-b4d721` under
`.scratch/changes/2026-11-20-spxs-eligibility/live/`.

That skill has exactly **one** published version (`GET .../versions` returns a single row,
created `2026-11-19T13:45:17Z`), and it is both `latest_version` and the explicit pin on
researcher / executor / risk_auditor — so "has not had it since published" is proven by the version
list, not inferred.

What `sleeve_c_signal` actually validates (`chop.py:77-92`):

- ticker is in `INVERSE`;
- `or_width_pct`, `now_min`, `flat_by_min` are numeric and not NaN;
- `or_width_pct > A_BAND_MAX_PCT` (the handoff from A);
- `start_min <= now_min <= flat_by_min - 90` — a **clock** window (10:30 ET to 90 min before flat);
- `len(bars) >= 9`;
- per bar: `high`, `low`, `close`, `volume` numeric.

`now_min` is passed in by the caller; it is never compared against anything in `bars`. The bar
objects are only ever read for the four OHLCV fields — **no timestamp field is inspected anywhere in
the file** (grepped for `stale|fresh|age|minute|elapsed|timestamp|datetime|time.`: the only hits are
the clock window above and `leverage`). Twenty bars that froze at 10:00 plus a `now_min` of 14:00
produce a valid SHORT.

## 2. researcher step 3 — a stale clause with no threshold

Live `researcher` (`tmpl_d7df3829ed5d73548bb5e9ed`, `updated_at 2026-11-20T09:29:44+08:00`, 3,776 chars),
SCAN step 3 verbatim, final sentence:

> Never adjust the width, the bars or the quote: a missing or stale input means NONE.

So step 3 *does* carry its own freshness instruction, separate from step 2 — but compare the two:

- step 2 (Sleeve A / trend-signal): "If any number is missing, **stale (older than 5 minutes)** or
  inconsistent, return NONE" — a number, attached to a named field.
- step 3 (Sleeve C): "a missing or stale input means NONE" — no threshold, and no instruction to
  compute the age of the `quote_history_kline` ktype=6 series it was just told to fetch. For a
  multi-bar series "older than 5 minutes" is not even well-defined without saying *which* bar.

Prompt-level, undefined, unenforced. It is weaker than the step-2 sentence that tonight's re-quote
clause exists to fix, not equal to it.

## 3. coordinator — routing is unconditional

Live `coordinator` (`tmpl_19f984c8f0fd516965b63998`, `updated_at 2026-11-19T22:05:04+08:00`, 3,274 chars):

> SCAN (10:05, 11:00, 12:30, 14:00): … then researcher returns signal JSON per ticker. For each LONG
> or SHORT, auditor runs desk-risk-guard check. Only approved tickets go to the executor, at most ONE
> new position per scan.

No step-3 or sleeve distinction, and no staleness test of its own. Its only freshness language is the
doctrine line: "Missing or stale evidence means HOLD." — again no threshold, and not addressed to any
stage that could compute one.

## 4. Consequence for "scope the clause to Sleeve A only"

Not as safe as it looks, for two reasons beyond the above:

1. `guard.py` (live `desk-risk-guard` `1795138181446404`, `check` path) has **no staleness gate either**:
   `--now` is used only for entry windows and flat timing (`guard.py:152`), and no proposal field
   carrying a quote time is read.
2. `sleeve` in `proposal.json` is documented as `trend | option | hedge` (`guard.py:120`) and the code
   only branches on `!= "hedge"` and `== "option"`. A Sleeve C ticket is submitted as `sleeve: "trend"`
   — **A and C are the same value inside the guard.** An A-only scope therefore cannot be expressed at
   the auditor at all; it would silently describe "the trend sleeve", which already includes C.

So an A-only re-quote-stamp clause leaves C exactly as exposed as it is tonight, and the label the
clause would be scoped by does not distinguish the two sleeves where it matters.

## Reproduce

```
node --env-file=.env -e "… GET /forward/skills/skill_00vz0dq461mv4e5iv1p3/versions …"   # one version
node --env-file=.env -e "… GET /forward/skills/…/versions/1795095917868411/content …"   # zip -> chop.py
sha256sum vwap-chop/scripts/chop.py    # 43810bd7d2ad6e7e9d7338fc74fc9d2e777cee1095f07e67e66a6648db5f72e9
# live prompts: GET /forward/templates/{tmpl_d7df3829ed5d73548bb5e9ed,tmpl_19f984c8f0fd516965b63998}
# live guard: .scratch/changes/2026-11-20-calendar-noentry/after/1795138181446404-tree/
```

Working copies kept under `.scratch/sleevec-fresh/`.
