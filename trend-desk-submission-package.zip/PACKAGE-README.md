# Qoder Trend Desk — submission package

Moomoo × Qoder AI Paper Trading Agent Challenge, 2026. Deadline 30 Nov 2026 23:59 SGT (15:59 UTC).
Competition paper account `5830104`, $100,000 starting NAV, trading window 17–28 Nov 2026.

This archive is the "runnable trading-agent package" that the rules ask for alongside the deck.
Everything in it was produced by the desk or by the build sessions that built it — no file here was
written to look like a result. Numbers quoted in the deck are traceable to the paths named below.

## Layout

| Path | What it is | Read it for |
|---|---|---|
| `deck/qoder-trend-desk-submission.pptx` | The presentation (8 pages), sha256 `66a72a401bf0ef909f1c5b64977778017523a5428cae5d93c08937aadff64c2e` — the file to check the hosted link against | the whole entry |
| `deck/qoder-trend-desk-submission.pdf` | The same 8 pages as a PDF, 577,416 B, exported from that .pptx by PowerPoint on 26 Nov — the readable report the rules ask for | the whole entry, without PowerPoint |
| `app/` | The dashboard server + UI, runnable | demo, decision visibility |
| `skills/` | The five skills exactly as the cloud mounts them (code, not description) | strategy + risk logic |
| `skills/SKILL-VERSIONS.json` | Per-file SHA-256 of each build, which template pins which version, whether the pin is the head | proving the backtest ran the live bytes |
| `backtest/` | The replay engine, its recorded outputs, and the fetch script | the risk/reward claim |
| `docs/submission/system-overview.md` | Full system design: agents, sleeves, gates, failure modes | agent design (30%) |
| `docs/submission/trading-journal.md` | Day-by-day journal; §4 is the backtest method and results | strategy + results (30%) |
| `docs/decisions/` | 33 dated decision memos (plus `PORTABILITY.md`) — what was tried, what failed, why it was kept or cut | what failed and why |
| `logs/` | fills / orders / decisions / equity as the desk recorded them | fills + decision log |
| `evidence/` | Dashboard capture (GIF + PNG) and a live read of the cloud configuration | demo + configuration |
| `AGENTS.md` | Dated snapshot of the Forward configuration this desk runs | reference-ready templates |
| `README.md` | Repo README: setup, run, capture method | how to run it |

## Run the dashboard

```bash
cd app
npm install
cp .env.example .env      # then paste your own PAT into .env — see credential policy
npm start                 # http://localhost:4173
```

`server.js` reads `GET /forward/sessions` and each session's event stream with your PAT
server-side only, and mines the structured records the desk's skills print during a run:
guard verdicts, sizing, signals, equity rows, orders and fills.

## Re-run the backtest

```bash
cd backtest/intraday
node build_store.mjs        # pulls 5-minute bars through the moomoo MCP into bars/
python3 build_regimes.py    # regime labels per session -> regimes.json
python3 replay.py           # -> replay_out.json (compare with the shipped copy)
```

`engine.py` and `desk_sleeves_v2.py` are unchanged from the contest-window §4 run; only two
adaptations exist and both are documented at the head of `replay.py` (the `INVERSE["SPY"]`
patch, and merging the contest window from `../contest-window/sim_out.json`). `backtest/mounted/`
holds copies of the same `trend_signal.py`, `guard.py` and `rules.json` whose hashes are recorded
in `skills/SKILL-VERSIONS.json`.

## Credential policy

- No token appears in this archive. `.env` is not shipped; `.env.example` carries an empty
  `QODER_PAT=`. The rules require this: credentials belong only in the token fields, never in
  prompts, source, dashboards, reports or unmasked screenshots.
- The `QODER_PAT` used during development was created at https://qoder.com/cloud/pat-keys and
  kept in `.env`, which is in `.gitignore`.
- `.scratch/` (working captures, ~550 MB) and `node_modules/` are excluded by design.

## What the numbers mean

| Figure in the deck | Source of truth in this package |
|---|---|
| NAV $99,825.82, cumulative −$172.29, peak-to-trough −0.172% | `logs/equity.csv` rows 20/23/24/25 Nov: `(99,998.11 − 99,825.82) ÷ 99,998.11` |
| 1 traded day of 7, one entry + one close | `logs/fills.csv` — of its four `FILL` rows, two are desk trades (24 Nov, SQQQ 119 @ 49.71 → 48.279); the other two are the probes below. The 7 sessions are the `by_day` keys of `evidence/credits-census.json` (17–20, 23, 24, 25 Nov) |
| That one close was a stop breach, not a target hit | `logs/fills.csv` order `3401916`, text `SCAN 12:30 close stop breach SQQQ`; `logs/closes.csv` `2026-11-24,trend,SQQQ,119,49.71,48.25,48.279,-170.29,2.00,-172.29` — fee $2.00 |
| 19 Nov AAPL fills are venue probes, not desk decisions | `logs/fills.csv` orders `3393381` / `3393382` (1 share buy 353.59 / sell 353.69, text `probe: premarket match test`), plus six `status 5` cancels on 18–19 Nov. They are excluded from every desk statistic |
| 25 Nov: 4 refusal records, all refusals, 0 orders | `logs/decisions.jsonl` — four records from session `sess_00wkm85i7er5si2l2j8r` (SCAN, 10:05 ET), each `"approved": false`: one `account '' is not the competition account`, and three that carry the *same* iron-fly `size rounds to zero … $1123 vs $1368` reason (the `tool_use` call, its `tool_result`, and the researcher `verdict`). So 25 Nov holds two distinct refusals recorded four times, not four decisions. Zero orders: `logs/fills.csv` has no 25 Nov row, and the 14 events dated 25 Nov in `logs/orders.jsonl` read back only order ids issued 18–24 Nov |
| 694.06 credits over 118 scheduled runs (779.96 across all 150 desk sessions) | `evidence/credits-census.json` — deduplicated `GET /sessions` read, 26 Nov |
| 106 sessions replayed (65 general + 41 contest) | `backtest/intraday/replay_out.json` (`sessions`, 65) + `backtest/contest-window/sim_out.json` (`sessions`, 41). 81 candidate sessions were offered to the engine and 16 were dropped: `engine.py:445-468` trades a day only when all six instruments share a contiguous five-minute timeline that starts at 09:35, and 14 of the 16 lack SPY's own opening bar (the 370-bar fetch truncates the oldest session in each page) while 2022-04-07 and 2022-04-14 lack SQQQ's and SOXS's. The count is in `backtest/intraday/store_summary.json` |
| 101 trades, +$1,137.91, avg R +0.015, t +0.17, fees $209.21 | 60 `as_run` trades in `backtest/intraday/replay_out.json` + 41 in `backtest/contest-window/sim_out.json` → `out["ladder/signal/next/etf"].trades`; both files carry a per-trade `R`, and every t below is `mean R ÷ (sd R ÷ √n)` on that column |
| Per-window: 2018-01 +$743.08 / 2016-08 −$568.53 / 2022-04 +$259.33 / 2020-03 0 trades | `replay_out.json` → `groups.W1_2016aug`, `W2_2018jan`, `W4_2022apr`; `groups` has no `W3` key because `as_run` contains no `202003*` day (18 such sessions were replayed). t on mean R: 2018-01 **+2.83** (n22, avg R +0.421), 2016-08 **−2.07** (n23, avg R −0.45), 2022-04 +0.13 (n15) |
| "QQQ averages −0.605 R" on the limitations slide | the 18 `as_run` trades with `instrument == "QQQ"` (all LONG, 2016–2022): avg R −0.605, t −2.37, net −$700.92, 5 winners. The QQQ-family shorts ran through SQQQ and made +$539.25, so the number is a statement about long QQQ exposure, not about the whole family (`groups.QQQ` counts 30 trades and −$329.49 across both samples) |
| Contest block t: deck +0.42, journal §4 +0.43 | same 41 trades; +0.42 is recomputed from the per-trade `R`, +0.43 is `avg_R 0.051 ÷ (sd_R 0.767 ÷ √41)` from the published `risk_stats.json` metrics, which carry no t field |
| 11 active schedules, 4 firing straight at the executor | `evidence/cloud-census-2026-11-26.json` → `schedules` |
| Pins: guard `…453332` (v11) on researcher/executor/risk_auditor, trend-signal / vwap-chop / option-adapter / journal at head | same file → `production_templates[].skill_pins`. Re-read live 26 Nov: coordinator carries no guard pin, the three `smoke-*-1122` clones pin guard `…200317` (v8) and `executor-gating-rehearsal` mounts no guard |
| Guard head `…544437` (v12, published 25 Nov 05:20:29Z, `guard.py` 92,283 B) is bound by no template | `GET /skills` head read beside the per-template pins — the template list alone cannot show this, which is why slide 8's fifth limitation says the desk runs the version before the head |

## Known limits, stated rather than hidden

- The live record is 7 sessions with one round trip. That is far too short to carry a performance
  claim, which is why the entry rests on the replay instead.
- The replay's pooled t-statistic is +0.17: no edge is demonstrated across the whole sample. Only
  2018-01 clears significance and 2016-08 is significantly negative. Both are on the slide.
- 2020-03 produced zero trades — 18 sessions replayed, no `as_run` row — because the VIX ladder
  and the opening-range width band (0.15–1.5%) between them refuse the day. The deck calls the
  crisis behaviour an inference from the ladder, not a measurement. The band's own refusal rate is
  measurable in the shipped census: 96 of 492 evaluations (19.5%) are
  `opening range … outside 0.15-1.5%` (`backtest/contest-window/signal_census.json`), and 279
  (56.7%) find no confirmed breakout. That is capital preservation and an expression blind spot at
  the same time.
- Eligibility is quoted per instrument class. The page's $500M floor attaches to "stocks and options
  **of companies**"; it does not name ETFs. Applying it to fund net assets is the desk's own
  interpretation, and that reading is what removed `SPXS` from SPY's bearish routing — so slide 8
  calls it a proxy rather than a rule. `docs/contest-rules-notes.md` now quotes both floors as
  written, and `docs/decisions/rules-source-of-truth-nov20.md` §2.2 audits the sentence they replaced.
- Eligibility is quoted per instrument class. The page's $500M floor attaches to "stocks and options
  **of companies**"; it does not name ETFs. Applying it to fund net assets is the desk's own
  interpretation, and that reading is what removed `SPXS` from SPY's bearish routing — so slide 8
  calls it a proxy rather than a rule. `docs/contest-rules-notes.md` now quotes both floors as
  written, and `docs/decisions/rules-source-of-truth-nov20.md` §2.2 audits the sentence they replaced.
- The shipped PDF is an export of the shipped .pptx (PowerPoint, 26 Nov). Both were verified at the
  file level — the .pptx by reading `ppt/slides/slide6/7/8.xml`, the PDF only by page count and byte
  size, because no PDF text extractor was available here. Nothing in the PDF was visually proofread.
- No stop order is possible on this account type, so a breached level is exited at the next
  scheduled check (12–22 minutes later), not at the level. The deck says so; `max_loss` is the
  backstop. The evidence is in `logs/fills.csv`: the take-profit ticket `3401719` (SELL 119 SQQQ
  limit 51.90) was cancelled 60 seconds after the entry was filled, and the exit actually taken
  was `3401916` at the 12:30 scan.
- The raw 5-minute bar store is **not** in this archive (`backtest/intraday/bars/` is absent by
  design, to spare broker quota); `replay.py` cannot be re-run without re-fetching it through
  `build_store.mjs`. The recorded outputs it produced are shipped unchanged.
- The market is closed on 26 Nov (Thanksgiving) and the cron has no holiday knowledge; the guard's
  `day` check inside the run is what stops new entries.
- The desk-risk-guard head is a newer build than the version pinned on the three desk roles. Every
  claim here is reproduced from the pinned build, not the head.
