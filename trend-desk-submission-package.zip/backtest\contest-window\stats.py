"""Risk and return statistics for the live-faithful Sleeve A replay.

Reads sim_out.json (engine.py output) plus the session bars, and prices the desk's own equity
curve. Nothing here re-decides a trade: it only measures the ledger the engine produced.

Two numbers are reported on purpose and they are not the same measurement:
  maxDD_realised  walks the curve at each session CLOSE (what the desk's equity ledger can see)
  excursions       walks each held position's worst and best 5-minute mark, per trade
                      into the curve -- it answers "how much pain did the flat rule absorb"
Daily returns are close-to-close on realised NAV, so Sharpe/Sortino exclude unrealised risk.
"""
import json
import math
import os
import statistics as st
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import mkdata  # noqa: E402  store reader, same one engine.py uses
SIM = json.load(open(os.path.join(HERE, "sim_out.json"), encoding="utf-8"))
BARS = json.load(open(os.path.join(HERE, "bars", "SPY.json"), encoding="utf-8"))
RULES = json.load(open(os.path.join(HERE, "mounted", "rules.json"), encoding="utf-8"))
NAV0 = float(RULES["competition"]["starting_nav"])
PY = 252.0  # trading days a year, rules.json structure.trading_days_year


def _spy_last_close():
    """BARS is keyed by stamp string, so index the session's last 5-minute close per date once."""
    out = {}
    for stamp, b in BARS.items():
        d = int(b["date"])
        if d not in out or stamp > out[d][0]:
            out[d] = (stamp, b["close"])
    return {d: c for d, (_, c) in out.items()}


SPY_CLOSE = _spy_last_close()


def spy_close(day):
    return SPY_CLOSE.get(int(day))


def daily_curve(trades, days):
    """Realised NAV at each session close, carrying flat days forward."""
    by_day = {}
    for t in trades:
        by_day[t["day"]] = t["nav_after"]
    nav, out = NAV0, []
    for d in days:
        nav = by_day.get(d, nav)
        out.append((d, nav))
    return out


def drawdown(curve):
    peak, dd, dd_days, cur_start = -1e18, 0.0, 0, 0
    worst_run, run = 0, 0
    for _, nav in curve:
        peak = max(peak, nav)
        if nav < peak:
            run += 1
            worst_run = max(worst_run, run)
        else:
            run = 0
        dd = min(dd, nav - peak)
    return dd, worst_run


def excursions(trades):
    """Per held trade: worst and best 5-minute mark against the fill, plus whether the levels the
    ticket carried were actually touched while the position was open.

    Bars are limited to [opened, closed_at] on the entry day. Using the whole session would count
    prints from before the fill and after the exit -- which is how an MAE gets inflated.
    Excursions are NOT folded into the curve: open positions overlap, so the same bar would be
    charged to NAV twice. They are read per trade. This measures marks, it is not a stop model.
    """
    allb = mkdata.load_all()
    out = []
    for t in trades:
        rows = allb.get(t["instrument"], {}).get(t["day"])
        if not rows:
            continue
        held = [r for r in rows if t["opened"] <= stamp_hm(r) <= t["closed_at"]]
        if not held:
            continue
        sgn = 1 if t["dir"] == "LONG" else -1
        stop_px, tp_px = min(t["stop"], t["tp"]), max(t["stop"], t["tp"])
        # exit THROUGH the stop: the next-check fill landed beyond the level the ticket carried.
        slip = round((stop_px - t["exit"]) * sgn * t["qty"], 2)
        lo = min(r["low"] for r in held)
        hi = max(r["high"] for r in held)
        mae = round((lo - t["fill"]) * sgn * t["qty"], 2)
        mfe = round((hi - t["fill"]) * sgn * t["qty"], 2)
        out.append({**{k: t[k] for k in ("day", "family", "instrument", "action", "why",
                                         "opened", "closed_at", "net", "R")},
                    "mae_usd": mae, "mfe_usd": mfe,
                    "mae_R": round(mae / (t["r_unit"] * t["qty"]), 2),
                    "mfe_R": round(mfe / (t["r_unit"] * t["qty"]), 2),
                    "bars": len(held), "stop_slip_usd": max(0.0, slip),
                    "giveback_usd": round(mfe - t["net"], 2),
                    "stop_touched": (lo <= stop_px) if sgn > 0 else (hi >= stop_px),
                    "tp_touched": (hi >= tp_px) if sgn > 0 else (lo <= tp_px)})
    return out


def stamp_hm(bar):
    return mkdata.hhmm(bar).strftime("%H:%M")


def excursion_line(trades, tag):
    pts = excursions(trades)
    if not pts:
        print("   %-22s no bars for held positions" % tag)
        return None
    worst = min(pts, key=lambda p: p["mae_usd"])
    slipped = [p for p in pts if p["stop_slip_usd"] > 0]
    gave_back = [p for p in pts if p["giveback_usd"] > 0]
    line = {
        "positions_with_bars": len(pts),
        "worst_mae_usd": worst["mae_usd"],
        "worst_mae_pct_nav": round(100.0 * worst["mae_usd"] / NAV0, 3),
        "worst_mae_R": worst["mae_R"], "worst_mae_day": worst["day"],
        "worst_mae_instrument": worst["instrument"],
        "median_mae_R": round(st.median([p["mae_R"] for p in pts]), 2),
        "median_mfe_R": round(st.median([p["mfe_R"] for p in pts]), 2),
        "stop_touched_but_closed_otherwise": sum(1 for p in pts if p["stop_touched"]
                                                 and not p["why"].startswith("stop")),
        "tp_touched_but_not_taken": sum(1 for p in pts if p["tp_touched"]
                                        and p["why"] != "take_profit"),
        "exits_through_the_stop": len(slipped),
        "stop_slippage_usd_total": round(sum(p["stop_slip_usd"] for p in slipped), 2),
        "stop_slippage_usd_worst": max([p["stop_slip_usd"] for p in slipped], default=0.0),
        "median_stop_slippage_usd": round(st.median([p["stop_slip_usd"] for p in slipped]), 2)
        if slipped else None,
        "mean_abs_giveback_R": round(st.mean([abs(p["mfe_R"] - p["R"]) for p in pts]), 2),
    }
    print("   %s worst mark %+.0f USD (%.2f%% NAV, %+.2fR) on %s %s | median MAE %+.2fR vs MFE %+.2fR"
          % (tag, line["worst_mae_usd"], line["worst_mae_pct_nav"], line["worst_mae_R"],
             line["worst_mae_day"], line["worst_mae_instrument"],
             line["median_mae_R"], line["median_mfe_R"]))
    print("   %s exits that printed through the stop: %d/%d, slippage %+.0f USD total / %+.0f worst"
          " | target touched but not taken: %d/%d | mean gap between best mark and realised: %.2fR"
          % (" " * len(tag), line["exits_through_the_stop"], len(pts),
             line["stop_slippage_usd_total"], line["stop_slippage_usd_worst"],
             line["tp_touched_but_not_taken"], len(pts),
             line["mean_abs_giveback_R"]))
    return line


def sharpe(returns, rf=0.0):
    if len(returns) < 2:
        return None
    ex = [r - rf for r in returns]
    sd = st.pstdev(ex)
    return (st.mean(ex) / sd) * math.sqrt(PY) if sd else None


def sortino(returns, target=0.0):
    if len(returns) < 2:
        return None
    downside = [r for r in returns if r < target]
    ds = math.sqrt(sum(r * r for r in downside) / len(returns)) if downside else 0.0
    return (st.mean([r - target for r in returns]) / ds) * math.sqrt(PY) if ds else None


def max_run(bits):
    best = run = 0
    for b in bits:
        run = run + 1 if b else 0
        best = max(best, run)
    return best


def mins(hhmm_str):
    h, m = hhmm_str.split(":")[:2]
    return int(h) * 60 + int(m)


def corr(a, b):
    if len(a) < 2 or len(a) != len(b):
        return None
    ma, mb = st.mean(a), st.mean(b)
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    da = math.sqrt(sum((x - ma) ** 2 for x in a))
    db = math.sqrt(sum((y - mb) ** 2 for y in b))
    return num / (da * db) if da and db else None


def beta(a, b):
    if len(a) < 2 or len(a) != len(b):
        return None
    ma, mb = st.mean(a), st.mean(b)
    num = sum((x - ma) * (y - mb) for x, y in zip(a, b))
    den = sum((y - mb) ** 2 for y in b)
    return num / den if den else None


def analyse(variant, days=None, label=""):
    v = SIM["out"][variant]
    trades = [t for t in v["trades"] if days is None or t["day"] in days]
    sess = [d for d in SIM["sessions"] if days is None or d in days]
    n = len(trades)
    m = {"variant": variant, "label": label, "sessions": len(sess), "trades": n}
    if not n:
        return m, [], []

    wins = [t["R"] for t in trades if t["net"] > 0]
    losses = [t["R"] for t in trades if t["net"] <= 0]
    Rs = [t["R"] for t in trades]
    nets = [t["net"] for t in trades]
    gross = sum(t["gross"] for t in trades)
    fees = sum(t["fees"] for t in trades)
    gw = sum(t["net"] for t in trades if t["net"] > 0)
    gl = -sum(t["net"] for t in trades if t["net"] < 0)

    m.update({
        "net_usd": round(sum(nets), 2),
        "return_pct": round(100.0 * sum(nets) / NAV0, 3),
        "win_pct": round(100.0 * len(wins) / n, 1),
        "avg_R": round(st.mean(Rs), 3), "med_R": round(st.median(Rs), 3),
        "sd_R": round(st.pstdev(Rs), 3),
        "avg_win_R": round(st.mean(wins), 3) if wins else None,
        "avg_loss_R": round(st.mean(losses), 3) if losses else None,
        "payoff": round(st.mean(wins) / -st.mean(losses), 2) if wins and losses and st.mean(losses) < 0 else None,
        "profit_factor": round(gw / gl, 2) if gl else None,
        "expectancy_usd": round(st.mean(nets), 2),
        "best_usd": round(max(nets), 2), "worst_usd": round(min(nets), 2),
        "best_R": round(max(Rs), 2), "worst_R": round(min(Rs), 2),
        "gross_usd": round(gross, 2), "fees_usd": round(fees, 2),
        "fees_pct_of_gross_profit": round(100.0 * fees / gw, 1) if gw else None,
        "sig_long": sum(1 for t in trades if t["action"] == "LONG"),
        "sig_short": sum(1 for t in trades if t["action"] == "SHORT"),
        "tp_exits": sum(1 for t in trades if t["why"] == "take_profit"),
        "stop_exits": sum(1 for t in trades if t["why"].startswith("stop")),
        "unmonitored_exits": sum(1 for t in trades if t["why"].startswith("unmonitored")),
        "flat_exits": sum(1 for t in trades if t["why"].startswith("flat")),
    })

    risk_days = {t["day"] for t in trades}
    curve = daily_curve(trades, sess)
    dd, dd_run = drawdown(curve)
    rets, bench, ret_days = [], [], []
    prev, prev_b = NAV0, None
    spy0 = spy_close(sess[0])
    for d, nav in curve:
        c = spy_close(d)
        if prev_b is not None and c:
            rets.append(nav / prev - 1.0)
            ret_days.append(d)
            bench.append(c / prev_b - 1.0)
        prev, prev_b = nav, c
    m.update({
        "maxDD_realised_usd": round(dd, 2),
        "maxDD_realised_pct": round(100.0 * dd / NAV0, 3),
        "maxDD_days": dd_run,
        "daily_mean_pct": round(100.0 * st.mean(rets), 4) if rets else None,
        "daily_sd_pct": round(100.0 * st.pstdev(rets), 4) if rets else None,
        "sharpe": round(sharpe(rets), 2) if rets and sharpe(rets) is not None else None,
        "sharpe_risk_days_only": round(sharpe([r for r, d in zip(rets, ret_days)
                                               if d in risk_days]), 2)
        if sum(1 for d in ret_days if d in risk_days) > 2 else None,
        "sortino": round(sortino(rets), 2) if rets and sortino(rets) is not None else None,
        "worst_day_pct": round(100.0 * min(rets), 3) if rets else None,
        "best_day_pct": round(100.0 * max(rets), 3) if rets else None,
        "pos_days": sum(1 for r in rets if r > 0), "neg_days": sum(1 for r in rets if r < 0),
        "days_with_trades": len({t["day"] for t in trades}),
        "exposure_pct_of_sessions": round(100.0 * len({t["day"] for t in trades}) / max(len(sess), 1), 1),
        "max_consecutive_losses": max_run([1 if t["net"] < 0 else 0 for t in trades]),
        "avg_hold_min": round(st.mean([mins(t["closed_at"]) - mins(t["opened"]) for t in trades]), 1),
        "avg_gross_win_usd": round(st.mean([t["gross"] for t in trades if t["net"] > 0]), 2) if wins else None,
        "avg_gross_loss_usd": round(st.mean([t["gross"] for t in trades if t["net"] <= 0]), 2) if losses else None,
        "spy_return_pct": round(100.0 * (spy_close(sess[-1]) / spy0 - 1.0), 3) if len(sess) > 1 else None,
        "corr_spy": round(corr(rets, bench), 3) if corr(rets, bench) is not None else None,
        "beta_spy": round(beta(rets, bench), 3) if beta(rets, bench) is not None else None,
    })
    if m["spy_return_pct"] is not None:
        m["excess_vs_spy_pct"] = round(m["return_pct"] - m["spy_return_pct"], 3)

    ann = (NAV0 + sum(nets)) / NAV0
    yrs = len(sess) / PY
    m["cagr_pct"] = round(100.0 * (ann ** (1.0 / yrs) - 1.0), 2) if yrs > 0 and ann > 0 else None

    def group(key):
        out = {}
        for t in trades:
            k = key(t)
            out.setdefault(k, {"n": 0, "net": 0.0, "R": 0.0})
            out[k]["n"] += 1
            out[k]["net"] = round(out[k]["net"] + t["net"], 2)
            out[k]["R"] = round(out[k]["R"] + t["R"], 2)
        return out

    attrib = {"by_family": group(lambda t: t["family"]),
              "by_action": group(lambda t: t["action"]),
              "by_exit": group(lambda t: t["why"].split(":")[0].split(" ")[0])}
    return m, attrib, trades


def main():
    AS = "ladder/signal/next/etf"
    DZ = "marketable/fill/mon/etf"
    window = [d for d in SIM["sessions"] if 20261117 <= d <= 20261130]
    res = {}
    for name, var, days, lab in (
            ("full", AS, None, "all sessions in the store"),
            ("window", AS, window, "eligible window, as-replayed"),
            ("full_design", DZ, None, "design-path variant, all sessions"),
            ("window_design", DZ, window, "design-path variant, window only")):
        print("=== %s (%s) ===" % (name, lab))
        m, attrib, trades = analyse(var, days, lab)
        res[name] = {"metrics": m, "attribution": attrib,
                     "sessions_covered": [d for d in SIM["sessions"]
                                          if days is None or d in days],
                     "excursions": excursion_line(trades, "excursion:")}
        for k in sorted(m):
            if k in ("variant", "label"):
                continue
            print("   %-26s %s" % (k, m[k]))
    json.dump(res, open(os.path.join(HERE, "risk_stats.json"), "w", encoding="utf-8"), indent=1)
    print("\nwrote risk_stats.json")
    print("sessions in the store:", SIM["sessions"][0], "->", SIM["sessions"][-1],
          "(%d); window cut covers %d" % (len(SIM["sessions"]), len(window)))

    v = SIM["out"][AS]
    why, rej = {}, {}
    for t in v["trades"]:
        k = t["why"].split(":")[0].split(" ")[0]
        why[k] = why.get(k, 0) + 1
    for t in v["rejected"]:
        k = t[-1].split(" - ")[0]
        rej[k] = rej.get(k, 0) + 1
    print("exit census (all sessions):", json.dumps(why))
    print("rejection census (all sessions):", json.dumps(rej))


if __name__ == "__main__":
    main()
