"""
desk_sleeves_v2.py - pure decision logic for Sleeve A execution, Sleeve B and Sleeve C.

Stdlib only. No tool calls. QCA's adapters supply normalized inputs (bars, positions,
working orders, option contracts) built from the real tool schemas, and carry out the
returned intents through guard.py check() -> risk_auditor -> executor, exactly like Sleeve A.

What changed from v1, and why
  * Sleeve A signal: untouched (trend_signal.signal()). Its EXECUTION now uses the shared
    helpers below: marketable-limit entry, resting take-profit, cancel-first exits, and a
    stop that can be rebuilt from broker state after the /data/desk reset.
  * Sleeve B: verticals dropped. Every non-hedge position is flattened by 15:45 ET, so a
    spread's benefits (lower net theta and IV exposure over a multi-day hold) never arrive,
    while its costs (two fees, legging risk, unverified MLEG placement) do. B is now a
    single-leg long call/put that overlays an ACCEPTED Sleeve A entry on SPY/QQQ when the
    prior session was a same-direction range expansion. Premium paid = maximum loss, so a
    gap between monitoring runs cannot cost more than the budget.
  * Sleeve C: fades only on days Sleeve A rejects as too wide AND the session has crossed
    VWAP (chop evidence). Volume-weighted VWAP bands replace stdev-of-closes. Desk sizing
    (rules.json trade risk, 0.35% today) replaces v1's 1%, which was about 3x the desk rule.
    Bearish fades buy the inverse ETF, like Sleeve A.
  * Tail hedge: dropped. The book is flat overnight, and a ~6% OTM put does not pay on the
    1-2% intraday moves that threaten open positions.

Invariant: the desk only ever BUYS to open (inverse ETFs and puts carry bearish views).
Any short position is therefore an error state and is closed first.
"""
from __future__ import annotations

import math

# Reward:risk for every equity entry (A and C). One shared value lets any monitoring run
# rebuild the stop from broker state alone: stop = cost - (tp_limit - cost) / RR.
RR = 1.5

# ticker -> (bearish vehicle, its leverage, correlation bucket).
# UNIVERSE must match Sleeve A's existing SHORT -> inverse-ETF map.
UNIVERSE = {
    "QQQ": ("SQQQ", 3, "US_EQUITY"),
    "SPY": ("SPXS", 3, "US_EQUITY"),
    "SMH": ("SOXS", 3, "US_EQUITY"),
}
# Off until the harness supports them and QCA confirms each pair is on the feed and liquid.
# The value of a candidate is how differently it moves from the live set, so the
# non-US_EQUITY buckets are the ones that add independent chances of a signal.
CANDIDATES = {
    "IWM": ("TZA", 3, "US_EQUITY"),
    "DIA": ("SDOW", 3, "US_EQUITY"),
    "XLF": ("FAZ", 3, "US_EQUITY"),
    "XLE": ("ERY", 2, "ENERGY"),
    "TLT": ("TMV", 3, "RATES"),
    "GLD": ("GLL", 2, "GOLD"),
}
INSTRUMENTS = {**UNIVERSE, **CANDIDATES}
INVERSE = {t: v[0] for t, v in INSTRUMENTS.items()}
LEVERAGE = {v[0]: v[1] for v in INSTRUMENTS.values()}
FAMILY = {**{t: t for t in INSTRUMENTS}, **{v[0]: t for t, v in INSTRUMENTS.items()}}
BUCKET = {t: v[2] for t, v in INSTRUMENTS.items()}
ACTIVE = set(UNIVERSE)                  # scanned live; add candidates only on harness evidence
OPTION_UNDERLYINGS = {"SPY", "QQQ"}     # Sleeve B only where chains are deepest


# ----------------------------------------------------------------------------------
# Session statistics
# ----------------------------------------------------------------------------------
def vwap_bands(bars):
    """Session VWAP and the volume-weighted standard deviation of typical price around it.
    bars: 5-min regular-session dicts (open/high/low/close/volume), oldest first."""
    vol = sum(b["volume"] for b in bars)
    if len(bars) < 2 or vol <= 0:
        return None, None
    tps = [(b["high"] + b["low"] + b["close"]) / 3.0 for b in bars]
    vwap = sum(tp * b["volume"] for tp, b in zip(tps, bars)) / vol
    var = sum(b["volume"] * (tp - vwap) ** 2 for tp, b in zip(tps, bars)) / vol
    return vwap, math.sqrt(var)


def running_vwap_crosses(bars, skip=6):
    """How often the close switched sides of the RUNNING session VWAP after the opening
    range (first `skip` bars). Two or more = the session is rotating, not trending."""
    cum_pv = cum_v = 0.0
    prev_side, crosses = None, 0
    for i, b in enumerate(bars):
        tp = (b["high"] + b["low"] + b["close"]) / 3.0
        cum_pv += tp * b["volume"]
        cum_v += b["volume"]
        if i < skip or cum_v <= 0:
            continue
        v = cum_pv / cum_v
        if b["close"] > v:
            side = 1
        elif b["close"] < v:
            side = -1
        else:
            side = prev_side
        if prev_side is not None and side is not None and side != prev_side:
            crosses += 1
        prev_side = side
    return crosses


# ----------------------------------------------------------------------------------
# Sleeve C - VWAP fade on days Sleeve A will not trade
# ----------------------------------------------------------------------------------
def sleeve_c_signal(ticker, bars, or_width_pct, a_band_max_pct, now_min, flat_by_min,
                    z_min=1.5, z_max=3.0, min_crosses=2, start_min=10 * 60 + 30):
    """
    or_width_pct, a_band_max_pct: taken from Sleeve A's own computation for this ticker
        today (never recomputed here), so C is exactly A's complement.
    now_min, flat_by_min: minutes after midnight ET. flat_by comes from calendar_rules,
        so half-days (12:45 flat) shrink the window automatically.
    Returns an intent in UNDERLYING prices; vehicle_levels() converts it after the fill.
    """
    def none(why):
        return {"sleeve": "C", "ticker": ticker, "action": "NONE", "reason": why}

    if ticker not in ACTIVE:
        return none("not in the active universe")
    if or_width_pct <= a_band_max_pct:
        return none(f"opening range {or_width_pct:.2f}% is inside A's band - Sleeve A's territory")
    if not (start_min <= now_min <= flat_by_min - 90):
        return none("outside the C window (needs data after 10:30 ET and 90 min to revert before flat)")
    if len(bars) < 9:
        return none("not enough bars")

    vwap, sigma = vwap_bands(bars)
    if not sigma:
        return none("VWAP bands unavailable")
    crosses = running_vwap_crosses(bars)
    if crosses < min_crosses:
        return none(f"{crosses} VWAP cross(es) - one-sided session, likely a trend day, no fade")

    px = bars[-1]["close"]
    z = (px - vwap) / sigma
    if not (z_min <= abs(z) <= z_max):
        return none(f"z={z:.2f} outside the fade zone [{z_min}, {z_max}]")

    prior = bars[-3:-1]
    if z > 0:   # stretched above VWAP -> bearish fade
        stalled = bars[-1]["high"] <= max(b["high"] for b in prior)
        side, extreme = "SHORT", max(b["high"] for b in bars)
    else:       # stretched below VWAP -> bullish fade
        stalled = bars[-1]["low"] >= min(b["low"] for b in prior)
        side, extreme = "LONG", min(b["low"] for b in bars)
    if not stalled:
        return none(f"z={z:.2f} but price is still extending - no stall yet")

    reward = abs(px - vwap)
    stop_dist = reward / RR
    stop = px + stop_dist if side == "SHORT" else px - stop_dist
    buffer = 0.1 * sigma
    if (side == "SHORT" and stop < extreme + buffer) or (side == "LONG" and stop > extreme - buffer):
        return none("a 1.5R stop would sit inside the session extreme - noise would tag it")

    return {
        "sleeve": "C", "ticker": ticker, "action": side,
        "family": FAMILY[ticker], "dir": -1 if side == "SHORT" else +1, "kind": "equity",
        "vehicle": INVERSE[ticker] if side == "SHORT" else ticker,
        "underlying_entry": px, "underlying_stop": stop, "underlying_target": vwap,
        "underlying_stop_dist": stop_dist,
        "reason": f"rotating session ({crosses} VWAP crosses), z={z:.2f}, stalled - fade toward VWAP {vwap:.2f}",
    }


# ----------------------------------------------------------------------------------
# Shared execution helpers (Sleeve A and Sleeve C equity entries)
# ----------------------------------------------------------------------------------
def vehicle_r(intent, vehicle_quote):
    """1R in the price of the instrument actually bought. Long-underlying entries use the
    underlying stop distance; inverse-ETF entries scale the underlying's % stop by that
    ETF's own leverage (3x or 2x)."""
    if intent["vehicle"] == intent["ticker"]:
        return intent["underlying_stop_dist"]
    pct = intent["underlying_stop_dist"] / intent["underlying_entry"]
    return LEVERAGE[intent["vehicle"]] * pct * vehicle_quote


def equity_qty(nav, trade_risk_pct, size_mult, r):
    """Desk rule (guard.py:161): floor(NAV x trade_risk_pct% x regime size_mult / R).
    trade_risk_pct comes from rules.json (0.35 today); never hard-code it here."""
    if r <= 0:
        return 0
    return int(math.floor(nav * trade_risk_pct / 100.0 * size_mult / r))


def marketable_buy_limit(ref_px, tol_pct):
    """A buy limit just through the market: fills now if price is within tolerance;
    otherwise it does not fill, gets cancelled, and the desk does not chase."""
    return round(ref_px * (1 + tol_pct / 100.0), 2)


def levels_from_fill(fill_px, r):
    """Anchor stop and take-profit on the actual fill so recover_stop() is exact."""
    return {"stop": round(fill_px - r, 2), "tp_limit": round(fill_px + RR * r, 2)}


def recover_stop(cost, tp_limit, rr=RR):
    """Every equity position is long with a resting take-profit at cost + rr*R, so R and the
    stop follow from broker state alone. Returns None when the stop cannot be recovered."""
    if cost is None or tp_limit is None or tp_limit <= cost:
        return None
    return cost - (tp_limit - cost) / rr


ENTRY_SEQUENCE = [
    "1. guard.py check() verdict approved by risk_auditor in the same run.",
    "2. Place a day BUY limit at marketable_buy_limit(ref, tol): 0.10% for equities, 5% for options.",
    "3. Poll sim_history_order_list until filled or N polls pass (count polls; do not compare to a local "
    "clock). Not filled -> cancel -> poll until cancelled -> done, no chase. Partial fill -> cancel the "
    "remainder and continue with the filled quantity.",
    "4. Equities: levels_from_fill(fill, r). Options: use the overlay's tp_limit.",
    "5. Place a day SELL limit at tp_limit for the filled quantity; poll until it shows working. If it "
    "cannot be placed after two tries, close the position now: without a resting take-profit an equity "
    "stop cannot be recovered after the reset.",
]

CLOSE_SEQUENCE = [
    "1. Cancel every working order on the symbol; poll until each shows cancelled or filled.",
    "2. Re-read the position (the take-profit may have filled in part or in full meanwhile).",
    "3. SELL the remaining quantity at MARKET; poll until filled; re-send once if needed.",
    "Used by stop exits, fail-safe exits, B orphan exits AND the 15:30 FLAT run. Cancel first, always: "
    "a take-profit left working after a close can fill later and open a position nobody intended.",
]


# ----------------------------------------------------------------------------------
# Monitoring (any scheduled run's first act)
# ----------------------------------------------------------------------------------
def monitor_actions(positions, working_tp, last_px):
    """
    positions: normalized rows [{symbol, qty, direction 'LONG'/'SHORT', cost, is_option,
               underlying (options only), mv (optional)}]
    working_tp: {symbol: limit price of the working day SELL limit (the take-profit)}
    last_px: {symbol: last price}; a missing price falls back to mv / qty.
    Returns (closes, unverifiable). Every close uses CLOSE_SEQUENCE. Error states come first.
    """
    errors, closes, unverifiable = [], [], []
    closing_families = set()
    equity = [p for p in positions if not p.get("is_option")]
    options = [p for p in positions if p.get("is_option")]

    for p in equity:
        sym = p["symbol"]
        if p["direction"] != "LONG" or p["qty"] <= 0:
            errors.append({"symbol": sym, "why": "ERROR STATE: short position - the desk only opens longs"})
            closing_families.add(FAMILY.get(sym))
            continue
        stop = recover_stop(p["cost"], working_tp.get(sym))
        if stop is None:
            closes.append({"symbol": sym, "why": "FAIL-SAFE: no working take-profit, stop unrecoverable - close"})
            closing_families.add(FAMILY.get(sym))
            continue
        px = last_px.get(sym)
        if px is None and p.get("mv") and p["qty"]:
            px = p["mv"] / p["qty"]
        if px is None:
            unverifiable.append({"symbol": sym, "why": "no price - retry next run; escalate to owner after two misses"})
            continue
        if px <= stop:
            closes.append({"symbol": sym, "why": f"STOP: {px:.2f} <= recovered stop {stop:.2f}"})
            closing_families.add(FAMILY.get(sym))

    open_families = {FAMILY.get(p["symbol"]) for p in equity} - closing_families
    for p in options:
        sym = p["symbol"]
        if p["direction"] != "LONG" or p["qty"] <= 0:
            errors.append({"symbol": sym, "why": "ERROR STATE: short option - the desk only buys options"})
        elif FAMILY.get(p.get("underlying")) not in open_families:
            closes.append({"symbol": sym, "why": "B overlay orphaned - parent equity position closed; exit with it"})
    return errors + closes, unverifiable


# ----------------------------------------------------------------------------------
# Cross-sleeve gate (runs before guard.py; guard.py still owns every risk cap)
# ----------------------------------------------------------------------------------
def portfolio_gate(intent, open_exposures, families_entered_today):
    """
    intent / open_exposures: {family, dir (+1/-1), kind 'equity'|'option'}
    Rules for all sleeves:
      1. One equity position per family at a time, and one equity entry per family per day.
         This is the assumption behind the realistic backtest (-$166), and it blocks the
         same-day re-entries that stopped out on Fri 11/13.
      2. No opposite-direction exposure inside one correlation bucket (all US equity index
         and sector ETFs are one bucket): paying fees and risk to be partly flat is not a position.
      3. A B overlay needs an open same-direction equity parent in the same family.
    When guard.py's open-risk cap binds, prefer intents from a bucket with no open exposure.
    """
    fam, d, kind = intent["family"], intent["dir"], intent["kind"]
    if kind == "equity":
        if any(e["family"] == fam and e["kind"] == "equity" for e in open_exposures):
            return False, "family already holds an equity position"
        if fam in families_entered_today:
            return False, "one equity entry per family per day - already used"
    if kind == "option" and not any(
            e["family"] == fam and e["kind"] == "equity" and e["dir"] == d for e in open_exposures):
        return False, "B overlay needs an open same-direction equity parent in this family"
    b = BUCKET.get(fam)
    if b and any(BUCKET.get(e["family"]) == b and e["dir"] == -d for e in open_exposures):
        return False, f"opposite-direction exposure already open in the {b} bucket"
    return True, "ok"


# ----------------------------------------------------------------------------------
# Sleeve B - single-leg option overlay on an accepted Sleeve A entry
# ----------------------------------------------------------------------------------
def prior_day_expansion(daily, ratio_min=1.5):
    """daily: at least 21 completed sessions, oldest first; daily[-1] is the prior session.
    1.5x, not v1's 2.0x: the 20-day average already contains this month's shock days, so
    2.0x would almost never fire inside the contest window."""
    if len(daily) < 21:
        return None, "need 21 completed daily bars"
    y = daily[-1]
    if y["high"] <= y["low"]:
        return None, "degenerate prior-session range"

    def rng(d):
        return (d["high"] - d["low"]) / d["open"]

    base = sum(rng(d) for d in daily[-21:-1]) / 20.0
    if base <= 0:
        return None, "no baseline range"
    ratio = rng(y) / base
    loc = (y["close"] - y["low"]) / (y["high"] - y["low"])
    if ratio >= ratio_min and loc >= 0.66:
        return +1, f"prior session {ratio:.2f}x range, closed at {loc:.0%} of it"
    if ratio >= ratio_min and loc <= 0.34:
        return -1, f"prior session {ratio:.2f}x range, closed at {loc:.0%} of it"
    return 0, f"no qualifying expansion ({ratio:.2f}x, close at {loc:.0%})"


def sleeve_b_overlay(a_intent, expansion_dir, contracts, budget_usd, fee_ok, dte_min, dte_max,
                     delta_lo=0.25, delta_hi=0.50, entry_tol_pct=5.0):
    """
    a_intent: the Sleeve A entry guard.py ALREADY approved: {underlying, dir, underlying_entry,
              underlying_target}.
    contracts: normalized [{symbol, right 'CALL'|'PUT', strike, dte, delta, premium}] for that
              underlying. premium is the contract's actual traded price -- the quote's last_price
              (or order-book bid/ask) -- NEVER option_ex_data.premium, which is not a price
              (observed 0.123 against a real last of 8.55). Only delta/IV/OI come from
              option_ex_data.*.
    budget_usd: option_trade_risk_pct x NAV x regime size_mult (rules.json). The premium paid
              is the maximum loss, so B needs no stop.
    fee_ok(premium, qty) -> bool: wraps guard.py's own fee gate (single source of truth).
    dte_min, dte_max: the option sleeve's DTE bounds, rules.json risk.dte_min / risk.dte_max.
              dte_min >= 1 keeps 0DTE out: the max-|delta| sort otherwise lands on today's
              expiry whenever an affordable contract exists there, which carries auto-exercise
              risk after 16:00 ET.
    """
    def none(why):
        return {"sleeve": "B", "action": "NONE", "reason": why}

    und = a_intent["underlying"]
    if und not in OPTION_UNDERLYINGS:
        return none(f"{und} has no B overlay (SPY/QQQ only)")
    if expansion_dir != a_intent["dir"]:
        return none("no confluence: prior-session expansion does not agree with today's breakout")

    right = "CALL" if a_intent["dir"] > 0 else "PUT"
    cands = [c for c in contracts
             if c["right"] == right and dte_min <= c["dte"] <= dte_max
             and c.get("premium") and c["premium"] > 0
             and c.get("delta") is not None and delta_lo <= abs(c["delta"]) <= delta_hi]
    # Most responsive contract the budget affords; shorter expiry breaks ties.
    for c in sorted(cands, key=lambda c: (-abs(c["delta"]), c["dte"])):
        limit = round(c["premium"] * (1 + entry_tol_pct / 100.0), 2)
        qty = int(budget_usd // (limit * 100))
        if qty < 1 or not fee_ok(c["premium"], qty):
            continue
        move = abs(a_intent["underlying_target"] - a_intent["underlying_entry"])
        tp = round(c["premium"] + abs(c["delta"]) * move, 2)   # first-order; gamma only helps a long
        return {
            "sleeve": "B", "action": "BUY_TO_OPEN", "contract": c["symbol"], "qty": qty,
            "family": FAMILY[und], "dir": a_intent["dir"], "kind": "option",
            "limit": limit, "tp_limit": tp, "max_loss_usd": round(limit * 100 * qty, 2),
            "exit": "resting take-profit; otherwise exits with its parent A position; FLAT at 15:30",
            "reason": f"{right} delta {c['delta']:.2f}, {c['dte']} DTE, confluence with prior-session expansion",
        }
    return none("no contract fits delta band, DTE bounds, budget and fee gate")


# ----------------------------------------------------------------------------------
# Credit planning
# ----------------------------------------------------------------------------------
def pick_monitor_cadence(budget_today, cost_scan, n_scans, cost_flat, cost_monitor_worst,
                         window_min=315, choices=(15, 30, 45, 60), reserve=0.2):
    """Finest monitoring cadence whose WORST case (a position open the whole window) fits the
    day's credits with a reserve. budget_today = free daily credits + the day's discretionary
    cap (100 + 300 now). window_min: 10:15 to the 15:30 FLAT run. Returns None when even
    hourly monitoring does not fit: tell the owner, and never cut the FLAT run."""
    usable = budget_today * (1 - reserve)
    fixed = n_scans * cost_scan + cost_flat
    for m in sorted(choices):
        if fixed + (window_min // m) * cost_monitor_worst <= usable:
            return m
    return None
