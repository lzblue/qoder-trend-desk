# Regime robustness of Sleeve A — what the 84-session replay says, and what to change before Fri 27 Nov

**Status: analysis and proposal only. Nothing here was applied.** No template write, no skill publish or
re-pin, no `rules.json` / `guard.py` / `calendar_rules.py` edit, no schedule change, no order, probe or
cancel on account 5830104, no change to live desk behaviour of any kind. Every cloud call made for this
memo was a `GET`; every moomoo call was a read-only `quote_history_kline`. The QODER_PAT was used only
inside an `Authorization` header and appears in no file and in no output.

- Task `20261119T235031Z-7c2a04` (mailbox wake) · written 2026-11-20 · replay runs 00:0x–01:20Z, live
  read-only pulls 09:2x local / ~01:3xZ (`date -u` read 01:36:28Z at the time of writing).
- Harness: `.scratch/bt-regime-1120/` — method, provenance and limits in
  [`.scratch/bt-regime-1120/README.md`](file:///C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/bt-regime-1120/README.md).
- Claim tags: **[observed]** = produced by a run I executed this task, or read from a live system;
  **[documented]** = written in a file in this repo or a published skill's bytes; **[undiscoverable]** =
  not knowable from what I can reach.
- Numbers are the *replay's*, not the desk's: no session in the extension window was ever traded live.

---

## 0. Bottom line

1. **Sleeve A is not robust across regimes.** Over 84 sessions (2026-03-26…11-18) the shipped as-run
   variant makes **+$67.06 on 108 trades**, and the entire profit and more comes from bearish tape:
   bear **+$1,055.37** (34 trades, 64.7 % win), sideways +$129.71 (22, 45.5 %), **bull −$1,118.02**
   (52, 44.2 %). **[observed]** The fill-anchored variant has the same shape (+$1,431.50 bear /
   −$1,155.14 bull).
2. **The published 38-session window is a bear sample wearing a general result.** It contains
   bull 13 / sideways 3 / **bear 22** sessions and 30 `normal` / 7 `caution` / 1 `bear_high_vol` /
   **0 `crisis`** desk labels, with VIX peaking at 28.18. Its two headline numbers reproduce to the
   cent in this harness (as-run +$572.83, anchor +$1,016.99, 46 trades each), so the replay is sound —
   the *coverage* is what is thin. **[observed]**
3. **The anchor fix is not a general improvement; it is a bear-regime fix, and its size is not
   separated from noise.** BASE38 +$444.16 splits bull +$69.09 / sideways +$0.00 / **bear +$375.07**
   (84 % in one bucket); in EXT the same per-bucket deltas are bull **−$37.12** / sideways +$3.77 /
   bear +$376.13. Paired per-trade bootstrap: BASE38 +$9.66 [−0.14, +26.34], EXT +$3.17
   [−1.46, +10.30] — **both bands straddle zero**. Ship it because the 1.5 R arithmetic should mean
   what it says, not because of P&L. **[observed]**
4. **The weakest regime's failure mode is one cell, and it is the desk's own vocabulary:** on sessions
   the live classifier labels `normal`, the short leg (buying SQQQ/SOXS/SPXS) lost **−$1,281.77 over
   33 trades, avg_R −0.159, 42.4 % win**, while the long leg on the same days made **+$882.26 over 58
   trades (+0.120 R)**. **[observed]** Nothing can veto that cell: `allow_bearish_etf` is `True` in all
   five computed branches *and* in the fail-closed branch of the live `regime()` bytes, and
   `guard.py` never reads the flag at all. **[documented]**
5. **Highest-value change: make `allow_bearish_etf` false when the prior-close tape is not bearish**
   (the enforcement path already exists at `trend_signal.py:177-178`; only the constant is wrong).
   Measured effect on the replay: EXT fill-anchored total **+$419.69 → +$1,847.92**, bull bucket
   **−$1,158.18 → +$522.43**, improving in *both* half-windows. Two honest caveats: the gate was chosen
   after seeing the split (in-sample), and its paired per-session bootstrap **straddles zero**
   (+$17.00/session, band [−15.15, +50.61]; it costs money on 11 of 84 sessions). Its value is the
   removal of a leg that has no evidence behind it, not a promised +$1.4 k. **[observed]**
6. **But size the expectation to what is left.** As of the settled 19 Nov close the classifier reads
   **`bear_high_vol` (VIX 28.44, 4 bear flags, NDX 26,517 vs 200-day 28,071) → `allow_long=False`,
   `size_mult=0.5`, shorts permitted**. **[observed]** In the replay, `bear_high_vol` sessions produced
   **1 ticket in 3 sessions** and `caution` 16 tickets in 15 sessions, so the remaining five sessions
   (20, 23, 24, 25 and a half-day 27) should generate a handful of tickets, not fifty. A change worth
   0.05 R is worth ~$20 here; only removing a catastrophic path or preventing a wrong label is worth a
   publish inside the window. **[observed]** for the counts, **[undiscoverable]** for how many tickets
   actually appear.

---

## 1. Coverage of the window the published numbers came from

The task's first requirement: state what the 38 sessions actually contain before claiming anything
about regime robustness. **[observed]** (`facts.py`, `out_facts.txt`)

| set | sessions | window | desk labels | derived buckets | VIX min/med/max | sessions with `allow_long=False` |
|---|---|---|---|---|---|---|
| BASE38 (the published window) | 38 | 2026-09-28 → 11-18 | normal 30, caution 7, bear_high_vol 1, **crisis 0** | bull 13, sideways 3, **bear 22** | 14.84 / 17.25 / 28.18 | 1 |
| EXT (this task's extension) | 84 | 2026-03-26 → 11-18 | normal 66, caution 15, bear_high_vol 3, **crisis 0** | bull 33, sideways 19, bear 32 | 14.25 / 17.98 / 31.05 | 3 |

- 22 of 38 published sessions are bear and only 3 are sideways: **the autumn window is a one-regime
  window**, which is exactly the risk the payload flagged.
- All 87 classifiable days came back `source: computed` — **zero fail-closed labels**, so nothing below
  depends on the fail-closed branch. **[observed]**
- The classifier is the desk's own, not an invention: `trend_signal.regime()` from the **live published
  bytes v `1795047415929677`** (sha-verified copy; `GET /forward/skills/skill_00vqvkdtlzojk2xg1rku`
  still reports that value as `latest_version` **[observed]**). Inputs: `US..SPX/NDX/VIX/VXN/SOX` daily
  closes with 200-day SMAs and the SOX 5-day return; branches crisis VIX ≥ 35 / bear_high_vol VIX ≥ 28
  or ≥ 4 flags / caution ≥ 2 flags / low_vol VIX < 13 / normal.
- `bull / sideways / bear` is **derived** (`mkregime_hist.py:57-72`), because the desk label has no bull
  bucket. Bear is tested first, bull needs both indices above their 200-day *and* NDX 20-session
  ≥ +2 %. Every conclusion below is reported against the desk label as well, so nothing rests on the
  derived definition alone.
- Labelling is point-in-time: day *D* from closes strictly before *D* — what the 09:00 BRIEF sees.
- Three sessions were excluded and the reason printed rather than discovered later: 2026-04-10 (5 of 6
  instruments missing), 2026-04-29 and 2026-08-19 (64 bars — the 1,000-bar fetch cap; below the
  `MIN_BARS = 70` gate there is no afternoon and no 15:30 close). **[observed]**

## 2. Re-verification of the two driver numbers

**[observed]** `run_regime.py`, on `engine.py` byte-identical to `.scratch/bt/engine.py`
(sha256 prefix `60e92b34aafab9d8`):

| variant (38 sessions) | net | trades | win | avg_R | maxDD | fees |
|---|---|---|---|---|---|---|
| as-run `ladder/signal/next/etf` | **+$572.83** | 46 | 47.8 % | +0.002 | −$1,379.98 | $96.36 |
| anchor-only `ladder/fill/next/etf` | **+$1,016.99** | 46 | 47.8 % | +0.059 | −$1,382.30 | $96.36 |

Both match the stored P1.6 metrics in `.scratch/bt/sim_out.json` to the cent, so the claim was true as
far as it goes. It is the *generalisation* that fails — see §4.

## 3. As-is vs anchor-only, split by regime

EXT, one continuous $100 k account, exit-at-next-check (the honest model of 5830104).
**[observed]** (`out_facts.txt`, `out_ext_v2.txt`)

| bucket | trades | as-run $ | anchor $ | anchor − as-run | anchor win % | anchor avg_R |
|---|---|---|---|---|---|---|
| bull | 52 | −1,118.02 | −1,155.14 | **−37.12** | 44.2 % | −0.012 |
| sideways | 22 | +129.71 | +133.48 | +3.77 | 45.5 % | −0.003 |
| bear | 34 | +1,055.37 | +1,431.50 | **+376.13** | 64.7 % | +0.160 |
| **ALL** | **108** | **+67.06** | **+409.84** | **+342.78** | 50.9 % | +0.044 |

BASE38, same axes: bull 20 trades +$69.09, sideways 3 +$0.00, bear 23 **+$375.07** (of +$444.16
total). So in both windows essentially all of the anchor benefit is bear-regime, and in the wider
sample the bull contribution is negative.

Same result in the desk's own vocabulary, EXT: **[observed]**

| desk label | sessions | trades | anchor $ | as-run $ | anchor avg_R |
|---|---|---|---|---|---|
| normal | 66 | 91 | −399.51 | −417.55 | +0.018 |
| caution | 15 | 16 | +662.08 | +337.34 | +0.138 |
| bear_high_vol | 3 | 1 | +147.27 | +147.27 | +0.839 |
| crisis | 0 | 0 | — | — | — |

**Everything positive in Sleeve A comes from `caution` sessions.** On the 66 `normal` sessions it is
a money-losing machine, and it has never seen a `crisis` session.

## 4. How much of this is 108 trades

Seeded bootstrap, 20,000 resamples (`sig.py`, `out_sig.txt`). Paired where the pairing is legal.
**[observed]**

| contrast | BASE38 point | 95 % band | EXT point | 95 % band | verdict |
|---|---|---|---|---|---|
| bear mean R − bull mean R | +0.422 | [−0.085, +0.920] | +0.172 | [−0.220, +0.553] | **not separated** |
| in bull: SHORT − LONG mean R | −0.323 | [−0.964, +0.412] | −0.448 | [−0.910, +0.027] | **not separated** (close) |
| anchor fix, per-trade USD | +9.66 | [−0.14, +26.34] | +3.17 | [−1.46, +10.30] | **not separated** |
| G2 gate, per-session USD (fill) | — | — | +17.00 | [−15.15, +50.61] | **not separated** |

This is the most important paragraph in the memo: **no single contrast in this sample reaches
separation at n = 108 trades.** What the numbers support is a *directional* claim repeated across
independent cuts — the short-on-normal cell is negative in EXT (−$1,281.77), in the bull bucket
(−$1,672.74), in both half-windows after gating (Mar-Aug −$605.43 → +$579.28 and Sep-Nov
+$1,025.12 → +$1,268.64), and on the desk's own label. Consistency across cuts is not the same as a
significant band, and the memo does not pretend otherwise. Conversely, the +$444.16 anchor figure
that has been quoted since P1.6 should stop being quoted as an expected gain: its own band crosses
zero.

## 5. Failure modes that only appear in the weakest regime (bull)

### 5.1 The bearish leg is ungateable, and it is where the bull losses are

EXT anchor variant, bull bucket: LONG 33 trades **+$517.60** (48.5 %, +0.151 R) vs SHORT 19 trades
**−$1,672.74** (36.8 %, −0.296 R). **[observed]** Removing only the shorts turns the bull bucket from
−$1,158.18 into **+$522.43** and its avg_R from −0.012 into +0.152.

Why nothing stops it — **[documented]**, live trend-signal bytes:
- `regime()` returns `shorts = True` on every branch (`:137-145`) and `FAIL_CLOSED` also carries
  `allow_bearish_etf: True` (`:43-44`);
- `signal()` already has the veto path (`:177-178`, `regime X: no bearish entries`) — the plumbing
  exists, the flag is simply never false;
- `guard.py` (v12 and v13 trees) contains **no reference to `allow_bearish_etf`**; it consumes
  `proposal.regime_mult` (`:167`) and checks only `stop must be below entry for a BUY` (`:208`). So
  the auditor cannot apply the gate either without an edit. **[documented]**

### 5.2 The risk asymmetry: dollars follow stop-distance, not the risk budget

Realised per-ticket dollar risk, EXT anchor variant: bull LONG **$123.74** vs bull SHORT **$258.74**
(2.1×), sideways LONG $212.83 vs SHORT $288.16, bear LONG $152.00 vs SHORT $263.84. **[observed]**

The mechanism is arithmetic, not a bug: `size_long()` (`engine.py:83-102`, guard.py:198-211 verbatim)
sizes off the stop distance and then clips by a 35 % single-asset notional cap. Mean stop distance as a
share of price is 0.36 % for the 1× ETFs (≈$659/share) and 0.98 % for the inverses (≈$43/share), so
**29 of 33** bull longs and 12 of 19 bull shorts bind on the cap, and once the cap binds, realised
dollar risk is `0.35 × NAV × dist/price` — roughly $126 for a long and $343 for a short at $100 k.
A sizer that is supposed to risk 0.35 % of NAV per ticket instead allocates dollars toward the volatile
leg, and in a bull tape the volatile leg is the one that loses. **[observed]** (recomputed from trade
rows in `out_capasym.txt`)

### 5.3 Protection: three-quarters of exits are "we looked again and closed"

Exit-reason mix, EXT anchor variant: `unmonitored` (no recorded stop level → close at next check) in
38 of 52 bull, 16 of 22 sideways, 24 of 34 bear trades — **78 of 108**. **[observed]**

Scoring the same 108 tickets as if a monitored stop existed gives as-run **+$1,912.23** and anchor
+$1,270.81. Those are **upper bounds the live account cannot produce** — no protective stop order is
possible on 5830104 **[documented]** (moomoo paper docs + tool schema) — and they are quoted only to
price the gap: on this replay, the difference between "a stop" as a recorded level and "a stop" as an
order is about +$1,845 of EXT as-run P&L. **[observed]**, with §4's warning about bands.

In a bull tape this is not academic: a 3× inverse bought at 10:16 that reverses has no exit until the
11:00 check plus latency, which is the window where the −0.296 R average lives.

### 5.4 Scarcity: what the desk refuses, and what the refusals cost

687 candidate-scan evaluations produced no ticket in the as-run path **[observed]** (`why_none.py`):
519 "no confirmed breakout beyond the opening range on the right side of VWAP", **156 by the
0.15–1.5 % opening-range width filter** (151 of them *wide*, concentrated in bear 77 / sideways 48 /
bull 26 — the filter is doing regime work the strategy then pays for), 11 "stop distance invalid or
wider than the opening range", 1 regime veto. Desk-level gates removed a further 61 one-new-position-
per-scan and 36 no-fill-ladder candidates. **[observed]**

And the frequency by regime: bull 31 of 33 sessions traded, sideways 15 of 19, **bear only 22 of 32**.
The strategy is not merely worse in bear tape at the ticket level — it is *rarely in the market* at
all, which is why the USD figures are so sensitive to a handful of outcomes.

## 6. What the data argues against changing

- **The long gate (`allow_long`) is not where the value is.** It fired on exactly **1** candidate in
  84 sessions, and forcing it open changed whole-window P&L by **+$0.00**. **[observed]** So the
  `a2c7f8` VIX-gate variant — which another session owns, is **pending**, and whose bytes I did not
  read this task — should be judged as crash insurance, not as expectancy. Today's tape is the first
  label in this whole exercise where it actually binds, which is a reasonable argument for keeping it;
  it is not an argument that it earns money. **[documented]** for pending status, **[observed]** for
  the $0.00.
- **Do not read the March–August half as an independent win.** EXT-only (46 sessions, 62 trades) has
  ΣR +2.03 but net **−$613.96**: positive per-R, negative in dollars, with `corr($risk, R) = −0.207`
  at n = 62 (~1.6σ, not significant — reported as "the two measures disagree", not as a sizing law).
  **[observed]**
- **Do not treat `crisis` as tested.** Zero sessions in 84; VIX peaked at 31.05 in-sample and sits at
  28.44 today. Anything the desk does at VIX ≥ 35 is extrapolation. **[observed]**

## 7. Ranked recommendation — what to change before Fri 27 Nov

Remaining sessions: **20 (size_mult 1.0, entry from 10:05), 23 (1.0), 24 (1.0), 25 (0.75,
10:00–14:00), 27 (0.5, half day, flat by 12:45)**; 26 Nov closed. **[documented]** —
`calendar_rules.py` in the published desk-risk-guard tree. Tier A = worth a publish inside the window;
Tier B = measure or prepare, do not ship mid-contest. Ranked by (evidence strength × in-window
relevance) ÷ ship cost.

### Tier A

**A1 — Get today's regime label from a settled close, not a same-day kline.** Zero cloud writes,
decisive. The 19 Nov VIX bar read *during* that session says **22.23**; the settled close says
**28.44** **[observed]** — that is `caution` (longs allowed, size_mult 0.75) versus `bear_high_vol`
(longs vetoed, size_mult 0.5, hedge_mult 1.5). One mid-session read can flip the entire entry set for
a session, and the researcher's BRIEF is the only thing standing between the two. Action: one sentence
in the researcher prompt — daily index closes must come from a *completed* session (never today's
partial bar), and if the newest close is not yesterday's, fail closed. Cost: one template write by the
owner; no publish, no credits.
*(This is the only recommendation here whose in-window value I would defend as large.)*

**A2 — Gate `allow_bearish_etf` on the prior-close tape.** Set it `True` only where the classifier
already says the tape is bearish (`caution` / `bear_high_vol` / `crisis`), i.e. make the flag agree
with its own name; three values in `regime()` plus one line in `FAIL_CLOSED`, published as a new
trend-signal version and pinned on `researcher`. Evidence: the −$1,281.77 / 33-trade
`normal`-day short cell, the −$1,672.74 bull short cell, and improvement in both half-windows and
under both anchors. In-window relevance: **none today** (20 Nov is `bear_high_vol`, where the gate
permits shorts) and it becomes relevant only if the tape reverts to `normal` mid-week — which is
precisely the scenario where the replay says the desk loses money. Ship-cost: one skill publish + one
re-pin + the standing byte-match verification. Counter-argument to weigh: bands do not separate (§4),
and the gate was chosen in-sample; if the owner prefers to keep this window untouched, A2 is exactly
the kind of change to make after 28 Nov, when it can be measured on a fresh tape.

**A3 — Do not chase tickets in the last five sessions.** Expected trade count from the replay's own
frequencies: `caution` 16 tickets / 15 sessions, `bear_high_vol` 1 / 3 → a couple of tickets per week
at the current size_mults. The positive cells are all small-n; the negative cell (shorts on `normal`)
is the only one with volume behind it. Holding the one-new-position-per-scan cap and the "missing or
stale evidence means HOLD" rule is the option this data supports. Cost: zero.

### Tier B

**B1 — Fill-anchored levels (the "anchor fix").** Correctness argument stands (a 1.5 R target measured
from a price that was not paid is not the design's trade — `trend_signal.py:182`), but the P&L case
does not survive the split: 84 % of the published +$444.16 is bear, EXT-bull is −$37.12, and the
paired band crosses zero. An exact fix is a **two-artifact change** (trend-signal `signal()` plus the
executor's `levels_from_fill` path), which is the wrong shape for the last week of a contest.
Re-measure after 28 Nov. **[observed]** + **[documented]** for the code locations.

**B2 — Dollar-risk parity across legs.** Once the notional cap binds, realised risk tracks
`dist/price`, so the 3× inverse leg carries ~2× the dollars of the 1× leg (§5.2). A per-ticket
realised-risk band in `guard.py` — approve only if `qty × dist` is inside the intended budget ± a
tolerance — makes the risk budget mean what it says across products. Needs a desk-risk-guard publish
and its own tests; do not bundle it with A2.

**B3 — Protection cadence.** 78 of 108 exits are "look again and close"; a monitored model prices the
gap at roughly +$1,845 of EXT as-run (§5.3), which is *not* available profit. Adding checks costs
~15–20 credits per extra scan **[observed]** (Nov-18 actuals: 100.54 cr/day, SCAN 14.97–20.54) and
schedules carry no budget field **[documented]**, so the only lever is fewer, wider-spaced runs. Do
the arithmetic against the remaining five sessions before spending it.

**B4 — The 1.5 % opening-range width ceiling.** It rejected 151 candidates, 77 of them in bear
sessions. Untested as a variant here; it may be suppressing the desk's best regime. Measure before
touching — this is a replay change, not a publish decision.

**Explicitly out of scope for these five sessions:** universe expansion, Sleeve B options plumbing and
Sleeve C. None has a production adapter, and the other memos already carry those arguments.

## 8. Reproducing this

```bash
cd C:/Users/tteh/Documents/qoder-trend-desk-dashboard/.scratch/bt-regime-1120
PY=/c/Users/tteh/AppData/Local/Programs/Python/Python312/python.exe
$PY run_regime.py both > out_ext_v2.txt 2>&1   # BASE38 + EXT, 8 variants, per-regime tables
$PY facts.py           > out_facts.txt   2>&1   # every figure quoted above, one place
$PY sig.py             > out_sig.txt     2>&1   # bootstrap bands (incl. paired gate effect)
$PY why_none.py        > out_why_none.txt 2>&1   # 687 NONEs attributed; long-gate counterfactual
$PY shortgate.py       > out_shortgate.txt 2>&1   # bearish-leg gates, half-window split
$PY label_today.py     > out_label_today.txt 2>&1 # live read: what the classifier says now
```

All offline except the last, which reads `closes_20261119.json` and the two `daily_*_205to1119.json`
payloads already in `pages/` (no network needed to re-run). The engine is `.scratch/bt/engine.py`
unmodified; the signal code is the live published bytes; BASE38 reproduces the P1.6 metrics to the
cent, and the two `mkdata.py` loader defects this task fixed leave that output byte-identical
(`README.md` §3).

## 9. What would change my mind

- A second window (2025 data) reproducing the `normal`-day short loss at similar magnitude — the
  single strongest argument that A2 is not in-sample selection.
- A live log from these five sessions showing whether the desk takes shorts on `normal`-labelled days
  at all; if the auditor's own judgement already refuses them, A2 changes nothing in practice and
  should be scored as documentation, not as P&L.
- One populated `bear_high_vol` session traded by the live desk (today may provide it): the replay has
  one ticket of evidence there, and it is the regime the remaining window is in.
