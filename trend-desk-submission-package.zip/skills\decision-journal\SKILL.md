---
name: decision-journal
description: Append-only decision log plus expectancy statistics, equity curve, drawdown, Sharpe-style ratio and the daily report for the trading desk. Use to record every signal, verdict, order, fill, close, rejection and skip, and to produce the 16:15 ET report.
---

# decision-journal

Plain Python (stdlib only). Files live in the session's working folder: `logs/decisions.jsonl`, `logs/equity.csv`.
Cloud sessions are new each run, so after writing, also save the files with the agent's file-saving tool, and read the previous versions at the start of each run.

## Record every decision, including the ones rejected
```
python scripts/journal.py log --file logs/decisions.jsonl --kind verdict --agent risk_auditor --json '{"ticker":"QQQ","approved":false,"reasons":["event blackout 13:45-14:30 ET"]}'
```
Kinds: `signal`, `verdict`, `order`, `fill`, `close`, `skip`, `error`, `note`.
A `close` record must carry `sleeve`, `ticker`, `realized_pnl` and `fees`. A submitted order is not a fill: log `fill` only after the order record shows it executed.

## Statistics (feed the result into desk-risk-guard's `closed_trades`)
```
python scripts/journal.py stats --file logs/decisions.jsonl
```
Reports win rate, average win and loss, expectancy per trade after costs, and profit factor per sleeve. A high win rate is not an edge: 90% wins with one large loser can be negative expectancy.

## Equity curve and daily report (16:15 ET)
```
python scripts/journal.py equity --csv logs/equity.csv --date 2026-11-18 --nav 100420.55 --bench 672.10
python scripts/journal.py report --file logs/decisions.jsonl --csv logs/equity.csv --date 2026-11-18
```
`--bench` is the SPY close, giving the buy-and-hold baseline the judges asked to see. `--date` may be left off both commands, and each then uses the current day in America/New_York; a malformed `--date` is refused with an error instead of matching no records. The report lists NAV, drawdown, Sharpe-style ratio, expectancy, every veto and skip, and a "what worked / what failed / why" section the auditor completes in three bullets.
