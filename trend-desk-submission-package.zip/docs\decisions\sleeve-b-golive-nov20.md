# Sleeve B go-live prep — 2026-11-20

> **SUPERSEDED as a plan of record on 2026-11-21** by
> [`sleeve-b-source-of-truth-nov21.md`](sleeve-b-source-of-truth-nov21.md). Read that first and do **not**
> run this document's `apply.sh` / `go-all.sh`: step (b) publishes a **v5 debit-hedge** adapter whose
> premium-basis sizing is wrong for the owner's new 0DTE credit structure, and binding v4 carries a DTE
> band that forbids it. The steps below stay valid as *measurement*; none of them is the next action.

Task `20261120T022735Z-e84a1f` (Tier B, prep only), extended by amendment `a371be`.

**Nothing in this document was applied.** No template binding, no skill publish, no re-pin, no
`rules.json` or `guard.py` change, no schedule change, no order on any account. Everything below
is either an offline proof or a script waiting for an owner decision.

| Piece | State | Blocked on |
|---|---|---|
| Probe package (step a) | built and verified offline, gated NO-GO | the owner flips the flag; the order itself is owner-attended |
| Premium-model fix (step b) | fixed in a v5 candidate, verified, **not published** | an owner decision to publish |
| Option budget (step c) | derived from real economics; **not applied** | same publish step as (b) |
| 3-template binding package (step d) | built, round-trip proven | owner runs `apply.sh` |
| This document (step e) | done | — |
| Readiness-doc item "B while A not live" | verified **stale**, flagged not resolved | owner wording |

---

## 1. The probe — what it is and when it may fire

**Purpose.** Two row shapes have never been seen: (i) a **filled option order row produced by a
probe**, (ii) a **populated `sim_trade_position_list` row for an option**. Everything else about
option rows is already OBSERVED on account 3732983's history (22 status-4 fills, 2026-01-26 …
2026-10-06) — see `.scratch/sleeveb/fills/2026-11-20-filled-option-rows.md`.

**Constraints folded in from amendment `a371be` (owner-confirmed).**

- The sim engine does **not fill outside the regular session** (09:30–16:00 ET, trading days),
  so a probe fired now (22:2x ET Nov 19) would rest or cancel and capture nothing.
- The probe runs on paper account **`3732983`** only, and **never on `5830104`** (the contest
  account the cloud desk trades). The plan script's `ACC_ID` was changed accordingly and now
  carries an explicit assertion that the account is not `5830104`.
- Nothing fires before **09:30 ET whatever the flag says**.

**The gate.** `flag` ships as `NO-GO`. `armed-check.mjs` decides *whether*, and it opens no
connection and places nothing. Verified matrix (simulated clock; a simulated run never writes a
`fired/` record):

| Clock (ET) | flag | verdict | exit |
|---|---|---|---|
| 09:25 | GO | `TOO_EARLY` | 1 |
| 09:30 | GO | `FIRE` | 0 |
| 16:00 | GO | `SESSION_OVER` | 5 |
| Sat 10:00 | GO | `WEEKEND` | 5 |
| Thanksgiving 10:00 | GO | `SESSION_CLOSED` | 5 |
| 09:31 | NO-GO | `NO-GO_AT_FIRE_TIME` | 4 |

The trading-day test deliberately does **not** trust `calendar_rules.py` alone: that file closes
only declared holidays (it has no weekend rule, because the live desk is driven by weekday cron).
The weekend test lives in the gate. An unreadable calendar fails closed (`CALENDAR_UNKNOWN`).

**Owner commands.**

```bash
CONFIRM=ARM-SLEEVEB-PROBE bash .scratch/sleeveb/probe/arm.sh     # flip to GO
node .scratch/sleeveb/probe/armed-check.mjs --status             # what the gate sees; never fires
bash .scratch/sleeveb/probe/watch-and-fire.sh                    # near 09:30 ET; exit 0 = FIRE
bash .scratch/sleeveb/probe/disarm.sh                            # back to NO-GO, no confirm needed
```

`watch-and-fire.sh` refuses to sit through more than 90 minutes of idle wait (`exit 7`); start it
inside the last 90 minutes before the open, or use the wake recipe below. If the flag is still
`NO-GO` at the open it reports **"NO-GO at fire time" (exit 4)** — armed but not triggered — and
waits for the owner.

**What "fire" does and does not mean.** A `FIRE` verdict writes `fired/<stamp>.json` and prints
the runbook. **It does not submit the order.** No local process holds a moomoo credential or an
MCP client (the vault secret is not exposed), so the submission is a human-attended MCP call —
CONTRACT rule 8. The exact calls, the re-quote step (quotes decay in minutes, and the 2026-11-19
chain expires 2026-11-20), and the close leg are in
`.scratch/sleeveb/probe/FIRE-RUNBOOK.md`.

**If the owner wants it unattended**, the only honest route is a one-shot desktop wake at 14:30Z
(09:30 ET) whose prompt runs `armed-check.mjs --check` and executes the runbook only on `FIRE`.
The wake prompt is written verbatim in FIRE-RUNBOOK.md §2. It was **not** created here: creating
a scheduled action that can submit an order is the owner's call, not a prep step.

**Planner verification (no network).** `build-probe-order.py` re-run against the saved 2026-11-19
chain: **32 checks, 0 failed**, now including the session-window check, the 3732983 target and the
"not 5830104" assertion. Pre-open fire time → exit 1. The pre-built ticket was
`US.SPY261120P720000`, quote $0.81, limit $0.85, debit $85 — but that contract expires 2026-11-20,
so at fire time it is 0DTE and the runbook requires a fresh chain and a fresh `plan` run (the
planner only accepts 1–3 DTE).

**Timing note.** 09:30–09:31 ET is 14:30–14:31Z, between BRIEF (14:00Z) and SCAN-1005 (15:05Z),
and the desk's earliest entry window is 10:00 ET. The probe is on a different account from the
desk, so there is no collision either way.

---

## 2. Premium model — the mismatch and the fix (step b)

**The mismatch.** `guard.py` sizes the ticket on **raw quote premium**:
`cost1 = o["premium"] * 100` then `qty = floor(budget / cost1)`
(`build/stage/guard/guard.py:237,248`). The adapter's `pick()` sizes on the **entry limit**,
`limit = round(premium × 1.05, 2)` (`option-adapter/scripts/sleeve_b.py:274`), and the ticket that
reaches the executor is priced at that limit.

**Consequence, measured on observed prices:**

- In the uncapped case the adapter's qty is the smaller of the two and `decide()` takes
  `min(guard.qty, adapter.qty)`, so no oversize happens — the mismatch is then a *recording* error
  (guard's `risk_usd` is the quote cost, not the debit).
- **When guard binds** — which is the normal case, because guard multiplies by its calendar
  `size_mult` (0.5 on 2026-11-17…19) while the adapter runs at 1.0 — the real debit can exceed the
  budget guard approved by up to `ENTRY_TOL_PCT = 5.0%`: budget $224 → qty 1 → debit $235 = 104.9%.
  Also proven: guard's echoed `order.limit_price` is the quote ($2.24) while the ticket says $2.35.

**The fix (v5 candidate, NOT published).** One field: `build_proposal()` sets `option.premium` to
the **limit actually being sent** and keeps the quote in `premium_quote`. Nothing else changes.
`verify-premium-fix.py` against live guard: qty unchanged, `risk_usd` == the true debit, guard's
echoed limit == the ticket limit, debit fits budget, every non-price field identical, and veto
verdicts identical. The adapter's 138/138 offline tests still pass on v5.

Why not a guard change: guard has no way to know the tolerance, and asking it to would put pricing
policy in the risk gate. The adapter already knows its limit; it just was not telling guard.

---

## 3. Option budget (step c)

Inputs: NAV $100,000, multiplier 100 (observed on every option row), fees $1.99/order + $0.30
/contract. OBSERVED in-band 1-DTE contracts in the saved 2026-11-19 capture cost **$233–$732**
per contract at the limit (n=8). INFERRED for 2–5 DTE at the observed IV 40.9%: **$355–$1,525**.

| budget | % NAV | priced points with qty ≥ 1 |
|---|---|---|
| $500 | 0.50% | 7/20 (35%) |
| $750 | 0.75% | 14/20 (70%) |
| **$1,000** | **1.00%** | **17/20 (85%)**, priciest affordable $954 |
| $1,500 | 1.50% | 19/20 (95%) |

**Recommendation:** `risk.option_trade_risk_pct = 1.0` (from 0.5) and leave
`risk.max_open_option_premium_pct = 1.5`. Guard multiplies the first by its calendar `size_mult`,
so the per-ticket budget is $500–$1,000, not a flat $1,000. Total open option premium 1.5% equals
the shares' `max_open_risk_pct` and sits 0.5 pt under the 2.0% daily-loss limit, so the sleeve
alone cannot trip `daily_halt`. Owner's suggested ceiling was 1% per ticket; 1.0% sits at it.

Applying this means editing `rules.json` **and publishing desk-risk-guard as a new version**, then
re-pinning on the three templates — a separate change with its own byte-match proof. It is not
part of the binding package below, and it was not done.

---

## 4. Binding package for option-adapter v4 (step d)

Location: `.scratch/changes/2026-11-20-sleeveb-golive/`.

- `before/` — live GET snapshots of the three templates, all skills, and the schedules
  (2026-11-20T03:0xZ).
- `template-skills.mjs` — writes **only** the `skills` array of one template; requires
  `CONFIRM=BIND-OPTION-ADAPTER` to apply or `CONFIRM=UNBIND-OPTION-ADAPTER` to roll back (an undo
  is never reachable with the enable token), `GO=1` to write, and refuses unless
  `skill.latest_version == 1795137189020914`. It re-reads after writing and fails if any field it
  does not own moved. `FORWARD_BASE` may only be a loopback URL.
- `apply.sh` / `rollback.sh` — three gates to apply; rollback restores `before/<id>.json` arrays.
- `tools/roundtrip-test.sh` — mock API on 127.0.0.1:4191 seeded from `before/`.

**Proof (run 2026-11-20T03:1xZ, mock only):**

```
0 PASS non-loopback FORWARD_BASE refused by name
1 PASS apply refuses without CONFIRM
2 PASS 3/3 dry runs, nothing written
3 PASS 3/3 written and read back; option-adapter bound to 3/3
4 PASS idempotent (3x NO CHANGE)
5 PASS rollback 3/3 restored
6 PASS rollback needs its own CONFIRM
7 tmpl_d7df… skills IDENTICAL (sha 0cd5e989ecea81fd -> 0cd5e989ecea81fd)  all-other-fields IDENTICAL
  tmpl_6c3c… skills IDENTICAL (sha ff825178cf0885fd -> ff825178cf0885fd)  all-other-fields IDENTICAL
  tmpl_bf2c… skills IDENTICAL (sha cc4afe6a647acf5c -> cc4afe6a647acf5c)  all-other-fields IDENTICAL
  ROUND TRIP: every target equals its before snapshot (clock aside)
```

What it does **not** prove: the server's own whitespace, auth, or rate limits. The real write path
was exercised on the rehearsal template on 2026-11-19 (readiness doc §1). `created_at` /
`updated_at` move on any write and cannot be restored — the arrays can.

**Owner commands.**

```bash
CONFIRM=BIND-OPTION-ADAPTER bash .scratch/changes/2026-11-20-sleeveb-golive/apply.sh        # dry run, GET only
CONFIRM=BIND-OPTION-ADAPTER GO=1 bash .scratch/changes/2026-11-20-sleeveb-golive/apply.sh   # bind
CONFIRM=UNBIND-OPTION-ADAPTER GO=1 bash .scratch/changes/2026-11-20-sleeveb-golive/rollback.sh
```

**Binding does not make Sleeve B trade.** No prompt on researcher, executor or risk_auditor calls
`option-adapter` yet; the wiring (new prompt steps + the executor's option ticket path) is a
separate change. Binding only makes the skill available.

---

## 5. Readiness item "whether B may act while Sleeve A is not live" — stale

Verified against live config at 03:0xZ:

- All **7 schedules are `active`** on the coordinator: BRIEF (`0 9 * * 1-5`), SCAN-1005, SCAN-1100,
  SCAN-1230, SCAN-1400, FLAT (`30 15 * * 1-5`), REPORT (`15 16 * * 1-5`); every one recorded a
  `last_run_at` on 2026-11-19.
- The coordinator template runs `AUTONOMY_PHASE=bounded` with `multiagent` wired to the other three.

But the desk account's **entire order history is 8 rows**: 6 cancelled, 2 AAPL probe fills. There
is no strategy entry in it. So "live" is true in the scheduling/autonomy sense and false in the
"has an approved entry for an overlay to attach to" sense. Those are different predicates, and the
readiness line mixes them. **Flagged, not resolved** — the owner should restate the condition as
"B may act on any entry A actually produces", which is true today, and drop the implication that
A is dormant.

---

## 6. Owner go/no-go checklist before 09:30 ET (14:30Z)

1. Decide the probe: leave `NO-GO` (nothing happens), or arm at least 10 minutes before 09:30.
2. If arming, be present (or create the wake) — submission is owner-attended by design.
3. Decide on the v5 premium fix and the 1.0% budget: these need a publish + re-pin, which this
   package does not do.
4. Decide whether to bind option-adapter v4 now (safe, no behaviour change) or wait for the
   prompt wiring.
