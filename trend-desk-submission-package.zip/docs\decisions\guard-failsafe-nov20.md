# guard.py fail-loud pass — desk-risk-guard magnitude fields (2026-11-20)

Task `20261120T030409Z-5e81ac`, Tier B: **prep / diff / rollback only**.
Status: **candidate built and tested offline. Nothing published, nothing pinned, nothing bound.** The three
templates that bind desk-risk-guard (researcher, risk_auditor, executor) are still pinned to v13
`1795138181446404`; coordinator binds no skills at all.

Package: `.scratch/changes/2026-11-20-guard-failsafe/`

---

## 1. The asymmetry being fixed

`guard.py` reads its inputs two ways, and the two ways fail differently:

- **presence-critical** fields are hard subscripts (`proposal["sleeve"]`, `proposal["ticker"]`). Absent → a
  `KeyError` → no verdict. Loud.
- **magnitude-critical** fields are `.get(key, default)`. Absent → the default *became the number* and
  `approved` stayed `true`. Silent.

The second group is the dangerous one, because the defaults are not neutral. Measured on the published bytes
(section 6): a dropped `regime_mult` **doubles** the size against a producer that asked for 0.5; a held row
without `open_risk` cuts the 1.5% open-risk cap from binding to nothing and sizes **6x** larger; a held option
row without `cost` makes room in the premium budget that was already spent; a missing `kind` routes an option
ticket through share sizing; a missing `account_mode` passes the SIMULATE guard against its own default.

This pass enumerates **every** `.get()` call site in the live file, classifies each one, and turns the unsafe
ones into a refusal that names the field.

## 2. Live baseline (read-only)

| item | value |
|---|---|
| skill | desk-risk-guard `skill_00vqwa9tq5szk3y13lg4` |
| published version | `1795138181446404` (v13), `updated_at 2026-11-20T01:29:41.464633Z` |
| `scripts/guard.py` | 16032 bytes, sha256 `8fe26118b2a8a3fd40329a0fc5f4fe70eec169d2f5704de42e2afa8756cb25d5`, 304 lines |
| templates binding it | 3 — researcher `tmpl_d7df3829ed5d73548bb5e9ed`, risk_auditor `tmpl_bf2c477c0fba1a3363833f91`, executor `tmpl_6c3c42cc4500efcbd6d60309`, each pinned `1795138181446404` |
| `.get()` call sites | 31, of which 23 carry a default argument and 8 do not |

The live bytes are the download of that exact version, unzipped under `live/unpacked/desk-risk-guard/`.
`AGENTS.md` was not used for any version or line number in this pass — it is a 2026-11-17 snapshot.

**GETs made for this package** (all HTTP 200, 17 calls, `2026-11-20T03:19:08.610Z` → `03:19:09.749Z`, logged
with byte counts in `before/get-log.json`): `GET /skills`, `GET /templates`, `GET /templates/{5 ids}`,
`GET /skills/{id}/versions` + `GET /skills/{id}/versions/{ver}/content` for desk-risk-guard@1795138181446404,
trend-signal@1795047415929677, decision-journal@1795137748003137, option-adapter@1795137189020914,
vwap-chop@1795095917868411.

Two further read-only runs while testing the scripts: `after/rollback-dry-run.json` (started
`2026-11-20T04:47:35Z`, finished `04:47:39Z`) and `after/apply-dry-run.log` (steps 0-2, `CAND_VERSION` set to
the current v13 so step 2 previews the plan). Both scripts without `GO=1` issue GETs only, never a POST.
No `account_*`, no `sim_trade_*`, nothing at all against account 5830104, no order, no web fetch.

## 3. Every `.get()` site, classified

Line numbers are **live v13 bytes** (the file in `live/unpacked/`), so they can be checked against the
download. `a` = unsafe: a missing or wrong value could silently over-expose the account. `b` = safe: the
default is neutral, strictly more conservative, or already produces a loud decline.

| # | line | read | default | class | why | action |
|--:|--:|---|---|:--:|---|---|
| 1 | 50 | `p.get(k, None)` for nav / peak_nav / day_start_nav | `None` | b | the sentinel *is* the detector: non-numeric → `state_unavailable` → loud decline | none |
| 2 | 99 | `portfolio.get("nav", None)` | `None` | b | non-numeric nav becomes NaN and every size rule declines | none |
| 3 | 106 | `portfolio.get("cash", None)` | `None` | b | the existing cash rule declines with a named reason; `--allow-unknown-cash` is an explicit opt-in | none |
| 4 | 122 | `proposal.get("kind", "share")` | `"share"` | **a** | an option ticket sized with share math: measured qty 546 shares of SPY at limit 2.26, approved | gated: must be `share` or `option` |
| 5 | 126 | `proposal.get("is_close")` | *(none)* | b | absent is falsy = treated as an entry, the stricter reading of a close | see §8 hazard 1 |
| 6 | 134 | `portfolio.get(k, None)` (unread-figure list) | `None` | b | renders the 0b reason | none |
| 7 | 139 | `portfolio.get("account_name", "")` | `""` | b | empty name fails `name_contains` → declines | none |
| 8 | 142 | `portfolio.get("account_id")` | *(none)* | b | `str(None)` ≠ configured id → declines | none |
| 9 | 144 | `portfolio.get("account_mode", "SIMULATE")` | `"SIMULATE"` | **a** | the SIMULATE guard passes against a field nobody filled in | gated: key must be present; read is now `portfolio["account_mode"]` |
| 10 | 167 | `proposal.get("regime_mult", 1.0)` | `1.0` | **a** | 1.0 is the regime table's **bull ceiling**; a request that asked for 0.5 traded at double (282 → 564, risk $89.49 → $177.01) | gated: required unless `sleeve=="hedge"`, numeric, `0 ≤ x ≤ REGIME_MULT_MAX`; multiplied via `float()` so a decimal string cannot concatenate |
| 11 | 170 | `portfolio.get("closed_trades", {})` | `{}` | b | absent / `{}` / `null` each leave the gate no average, so size is untouched | read made null-safe (§4) |
| 12 | 170 | `…{}.get(sleeve)` | *(none)* | **a** | `closed_trades: null` → `AttributeError`, **no verdict at all** (measured rc=1); a present row without numeric `n`/`expectancy` raises at the comparison | gated when the row is present; crash removed |
| 13 | 180 | `portfolio.get("orders_today", 0)` | `0` | **a** | the 150/day budget never binds on a request with no counter | gated: numeric ≥ 0; read is `float(portfolio["orders_today"])` |
| 14 | 182 | `portfolio.get("positions", [])` | `[]` | **a** | position count vs `max_positions` counted zero | gated: key present and a list |
| 15 | 190 | `proposal.get("entry", 0)` | `0` | **a** | `entry` divides every share cap and becomes the limit price; `$1.00 min` test read 0 | gated on share tickets: numeric > 0; read is `float(proposal["entry"])` |
| 16 | 193 | `proposal.get("underlying", ticker)` | `ticker` | b | falls back to a required field, and the option-underlyings rule then declines an ineligible fallback | none |
| 17 | 200 | `portfolio.get("positions", [])` | `[]` | **a** | the same absent list read a desk with holdings as flat for all four aggregate sums (measured 99 → 700) | gated; read is `portfolio["positions"]` |
| 18 | 201 | `p.get("kind", "share")` (held row) | `"share"` | **a** | a held option misfiled as a share leaves the option premium budget: measured qty 2 → 5 contracts | gated per row: `share` or `option`; read is `p["kind"]` |
| 19 | 202 | `uni["leverage"].get(ticker, 1)` | `1` | b | `universe.leverage` deliberately lists only the 5 levered names; requiring presence would false-reject SPY/QQQ/IWM/SMH — 1x is the config's own convention | untouched; comment added; §8 hazard 2 |
| 20 | 213 | `uni["leverage"].get(p["ticker"], 1)` (held row) | `1` | b | the same 1x convention; what is unsafe here is the **ticker** the lookup is keyed on, not this default | default untouched; the row's ticker is gated (note under the table) |
| 21 | 217 | `p.get("open_risk", 0)` (held row) | `0` | **a** | the 1.5% open-risk cap emptied: measured qty 99 → 600 (6x), `binding` moved off "open risk cap" | gated per row: numeric ≥ 0; summed with `float()` |
| 22 | 232 | `proposal.get("target")` | *(none)* | **a** | `order.take_profit` is the one exit that rests on a paper account; without it the ticket's only exit is the monitored stop | gated on share tickets: numeric > 0; read is `proposal["target"]` |
| 23 | 239 | `proposal.get("regime_hedge_mult", 1.0)` | `1.0` | **a** | a hedge that asked for 1.5x got 1.0x: measured 7 contracts → 4, both approved | gated when `sleeve=="hedge"`: positive number; read is `float(proposal["regime_hedge_mult"])` (values above `hedge_max_multiplier` are capped, as before) |
| 24 | 240 | `o.get("dte", 0)` (hedge window) | `0` | b | default 0 fails the 7-45 test → vetoes, never approves | gated anyway (a veto for the wrong reason hides what was asked); outcome unchanged |
| 25 | 242 | `p.get("cost", 0)` (held hedge premium) | `0` | **a** | premium already spent is subtracted from the hedge budget; absent made room that was used | gated on hedge/option rows: numeric ≥ 0; summed with `float()` |
| 26 | 242 | `p.get("sleeve")` (held row) | *(none)* | **a** | a hedge read as a trend holding spends the trend budget and is never subtracted from the hedge budget | gated on live option rows: one of `trend`/`option`/`hedge` |
| 27 | 246 | `p.get("cost", 0)` (option sleeve) | `0` | **a** | same subtraction for the option sleeve budget: measured qty 2 → 5 contracts | same as #25 |
| 28 | 246 | `p.get("kind")` (filter) | *(none)* | **a** | the filter decides which rows spend which budget; a row with no kind is read as a share, so 1300 of held option premium vanished from the cap | gated per row: `share` or `option` |
| 29 | 246 | `p.get("sleeve")` (filter) | *(none)* | **a** | the other half of the same filter: a non-hedge row is included in, or excluded from, the held-premium sum | #26 |
| 30 | 258 | `o.get("dte", 1)` (0DTE warning) | `1` | b | suppresses a warning only; the value is verified earlier now | reads the verified number |
| 31 | 261 | `proposal.get("stop")` (option stop_level) | *(none)* | b | informational for option tickets; no share size depends on it | untouched |

**17 sites classified (a), 14 classified (b).** The (a) sites are 13 distinct fields. The gate validates 19
fields in all — 9 on the proposal (`kind`, `regime_mult`, `regime_hedge_mult`, `entry`, `stop`, `target`,
`option`, `option.premium`, `option.dte`), 4 on the portfolio (`account_mode`, `orders_today`, `positions`,
`closed_trades` and its per-sleeve `n`/`expectancy`), 6 per held row (`market_value`, `ticker`, `kind`,
`open_risk`, `sleeve`, `cost`) — because three of them were worth gating even though their default was
classified b: `option.premium`/`option.dte` (a veto for the wrong reason hides what was asked) and a held
row's `ticker` (an unresolvable name reads 1x: measured `TQQQX` → qty 466, approved).

Two magnitude inputs that are **not** `.get()` sites but belong to the same family, because a missing one
raises and leaves no verdict, are validated by the same gate: `positions[i].market_value` (feeds the 35%
single-asset, 120% effective-gross and invested-percentage sums) and `positions[i].ticker` / `kind` when a
row is present. Rows with `market_value == 0` — a closed row the broker persists — are exempt from the
expensive checks (sleeve, cost, universe-resolvability) but still validated for ticker, kind, market_value
and open_risk, because the sums subscript them.

## 4. Mechanism: decline with a reason, not raise

The file's own doctrine at `check()` (`guard.py:130-132` live) is *"Decline with a reason rather than raising:
a traceback leaves the coordinator with no verdict to act on."* Raising would be a regression for the
coordinator, which parses one JSON object, and the crash paths are the very bug being fixed (row 12).

So the fix is **one gate, one refusal, machine-readable**:

- `magnitude_gaps(proposal, portfolio, kind, sleeve, rules)` returns a list of gap sentences.
- A new numbered block **0c** in `check()` calls it immediately after the existing `state_unavailable` (0b)
  decline and before any number is computed:

  ```python
  gaps = magnitude_gaps(proposal, portfolio, kind, sleeve, r)
  if gaps:
      return _verdict(False, ["magnitude_field_missing: " + "; ".join(gaps)], warnings, size_mult=0.0, **info)
  ```

- Every gap goes out in **one** verdict, so a ticket missing three fields is told about all three instead of
  being bounced three times.
- The reason starts with the fixed token `magnitude_field_missing:` so the auditor can grep it, and each
  sentence is `"<field> is missing|is not usable (<value>): <what it decides>. Expected <shape>."`, plus,
  only when no value could be read, the sentence naming the default the code substituted.
- **Closes are exempt**, and not by a special case inside the gate: `is_close` returns at step 0, before 0c
  is called, so FLAT and every closing ticket stay reachable when the account read is the thing that failed.
- Where the gate guarantees a usable value, the read site was hardened rather than left to re-default:
  `portfolio["account_mode"]`, `float(portfolio["orders_today"])`, `portfolio["positions"]`,
  `float(proposal["entry"])`, `float(proposal["stop"])`, `proposal["target"]`, `p["kind"]`,
  `float(p["market_value"])`, `float(p["open_risk"])`, `float(p["cost"])`, `float(o["premium"])`,
  `float(o["dte"])`, `float(proposal["regime_hedge_mult"])`, `float(...)` on the `regime_mult` factor, and
  numeric coercion of the expectancy `n` / `expectancy`. Decimal-string figures — the shape the account
  actually returns — now compute instead of raising; measured live vs candidate on such a ticket: live
  `TypeError: can't multiply sequence by non-int of type 'float'`, candidate returns a verdict.

## 5. The diff

`diff/scripts-guard.py.patch` — 239 lines added, 26 removed in `scripts/guard.py`; `diff/SKILL.md.patch` —
1 line added; `diff/manifest.json` — per-file sha256 and byte counts for all six files against the v13
download. The other **four** files are byte-identical to the v13 download and are not touched by this change:
`references/rules.json 49dbeaf4…`, `scripts/book.py 6b8071da…`, `scripts/calendar_rules.py 557c3cf2…`,
`scripts/levels.py 746a0151…`. `tools/publish.mjs` refuses to POST unless exactly those four match and exactly
these two differ.

| file | live v13 sha256 (12) | candidate sha256 (12) | bytes |
|---|---|---|--:|
| `scripts/guard.py` | `8fe26118b2a8` | `8b956e8d91fe` | 31894 |
| `SKILL.md` | `24c424d2d8ab` | `399ee235ee90` | 7566 |

Additions to `guard.py`: the module constant `REGIME_MULT_MAX = 1.0` (documented as the ceiling
trend_signal.py's REGIME table can emit — 0.25 / 0.50 / 0.75 / 1.00, fail_closed 0.50, so 1.0 is the bull
bucket, not a target), `field_gap()` and `magnitude_gaps()`, the 0c gate, the null-safe expectancy read, and
the coercions above. The docstring gained one paragraph naming `magnitude_field_missing` and the closes
exemption.

`SKILL.md` gained one bullet under "What the verdict means" telling the auditor what the token means and what
to do about it: re-read the account and rebuild the JSON, **do not invent a placeholder to get a verdict**.

## 6. Tests

Harness `tests/run.py` runs both trees side by side and writes `tests/result-live.json` /
`tests/result-candidate.json`. Python 3.12.10, absolute interpreter path, no network, no cloud.

```
PY=.../Python312/python.exe
$PY tests/run.py live        # reproduce each failure mode on the PUBLISHED bytes
$PY tests/run.py candidate   # same shapes must now fail loud + regression over 39 real shapes
$PY tools/assert-gates.py    # the gate apply.sh step 0 runs: both thresholds or exit 1
```

**Live: 12/12 silent failure modes reproduced** (this is the reachability proof — none was assumed):

| scenario | measured on published v13 bytes |
|---|---|
| `regime_mult_missing` | qty 282 → **564**, risk $89.49 → **$177.01**, both `approved:true reasons:['ok']` |
| `regime_mult_above_table` | `regime_mult 2.0` (no such bucket in trend_signal.py) → qty 282 → **578**, approved |
| `open_risk_missing` | open-risk cap defeated: qty 99 → **600 (6x)**, binding cap moved from `open risk cap` to `ok` |
| `positions_key_missing` | qty 99 → **700**, approved — every aggregate cap read zero exposure |
| `proposal_kind_missing` | option ticket sized as SHARES: **546 shares of SPY** at limit 2.26, mechanism `monitored` |
| `hedge_mult_missing` | hedge under-sized: 1.5x → 7 contracts, default 1.0 → **4**, both approved |
| `orders_today_missing` | approved with the order budget **never evaluated** |
| `account_mode_missing` | approved: the SIMULATE guard passes because the field is absent |
| `position_cost_missing` | premium cap defeated: qty 2 → **5 contracts** |
| `position_kind_missing` | row read as a share, **1300 of option premium vanished** from the cap: qty 2 → 5 |
| `held_ticker_unclassifiable` | `TQQQX` in neither universe list, valued 1x → qty 466, approved |
| `closed_trades_null` | **no verdict at all**: rc=1 `AttributeError: 'NoneType' object has no attribute 'get'` |

**Candidate: 12/12** — eleven scenarios now return `approved:false` whose first reason begins
`magnitude_field_missing:` and name the exact field; the twelfth (`closed_trades_null`) returns
`approved:true qty=282`, i.e. crash → verdict, which is the correct fix for that one (an absent history is
legitimately nothing to average, so it must not become a veto).

**Regression over 39 real shapes** (recorded Nov 17-19 proposals × recorded portfolios, plus the ladder /
window / cap fixtures): **35 byte-identical, 4 declared, 0 undeclared, 0 declared-that-stopped-differing.**

## 7. Behaviour change, stated honestly

Only one class of input changes outcome: a field that decides a size, budget or count is **absent or
unusable**.

The four declared differences, with what each was before:

1. **`2026-11-18 SPY probe WITHOUT regime_mult`** — `approved:true` on live → declined. **This is the headline
   change**, and it is exactly the case the pass exists for. It is not produced by the desk's own pipeline:
   `trend_signal.py signal()` emits `regime_mult` on every non-NONE result, so only a hand-composed or
   truncated ticket loses it.
2. **`2026-11-17 SOXS auditor proposal × UNVERIFIED portfolio`** — live `rc=1` (`AttributeError: 'str' object
   has no attribute 'get'` on the string sentinels) → candidate returns a verdict. Crash → verdict.
3. **`2026-11-19 QQQ FLAT probe × real 15:30 residual portfolio`** — live `rc=1` on `closed_trades: null` →
   candidate returns a verdict. Crash → verdict. (The crash is itself the proof that this ticket was not a
   close: closes return at step 0, long before the expectancy read.)
4. **`hedge fixture from the calendar-noentry package`** — declined for a missing `regime_hedge_mult`. That
   fixture omits a field `SKILL.md:43` documents as part of the hedge shape; no recorded **live** proposal has
   this shape, and the hedge path never ran in production this week.

Everything currently approving on real data keeps approving with byte-identical output, including: all four
`regime_mult` buckets, the SOXS/QQQ/SMH live shapes, the three ladder rungs, the 15:30 window, the 12:15 Cook
blackout, the expectancy gate at half-size and disabled, the position-count and order-budget caps, the wrong
account name, non-SIMULATE mode, stop above entry, off-universe ticker, sub-$1 price, absent
`closed_trades`, `--allow-unknown-cash`, size-rounds-to-zero, unread nav, and both real close probes.

**No new false rejections were added to good proposals.** The one that could have been — a warning on an
empty `closed_trades` — was built, measured as changing the verdict bytes of three currently-passing real
shapes, and removed; the null-safety stayed and the warning did not.

## 8. Residual hazards, deliberately not patched here

1. **A close ticket that omits `is_close` is judged as an entry.** `is_close` absent reads as falsy, which is
   the conservative reading for the *risk rules*, but sizing then treats it as a new BUY. Nothing inside
   `guard.py` can tell a close from an entry without the flag. Fix is at the contract level (the coordinator's
   FLAT/scan wording, or a separate `close` subcommand). **Owner decision.**
2. **A levered ticker added to `universe.shares` but missing from `universe.leverage` still reads 1x.** The
   gate refuses an *unresolvable* held ticker, but for the proposal's own ticker the 1x default is the
   config's convention and requiring presence would reject SPY/QQQ/IWM/SMH. The durable fix is an exhaustive
   leverage map in `rules.json` — a rules change, not a guard change. **Owner decision.**
3. **`risk.dte_min` / `dte_max` (v12 keys) are read by nothing in the skill**, and `option.delta` is documented
   at `SKILL.md:43` but never read. Dead config; a false comfort if anyone believes the DTE band is enforced
   outside the 7-45 hedge window. Removal or wiring is a separate change.
4. **`always_allow` is unchanged.** The gate this pass fixes is arithmetic, not permission: all four templates
   still grant the executor 13 tools with no `always_ask`, so `AUTONOMY_PHASE` remains prompt text.
5. **The auditor still hand-builds `portfolio.json`.** This pass makes a bad build refuse loudly instead of
   sizing wrong; it does not remove the manual step that produces it.

## 9. What the owner must decide

1. **Publish or not.** `GO=1 MEMO=read bash .scratch/changes/2026-11-20-guard-failsafe/apply.sh` publishes a
   new desk-risk-guard version and re-pins researcher, risk_auditor and executor to it. Irreversible in the
   publish half (a version can be superseded, never withdrawn); the pins roll back with `rollback.sh`.
2. **Timing against tonight's runs.** SCAN windows are scheduled; a version switch mid-session changes the
   verdict text the auditor journals for `magnitude_field_missing`. Publishing before the next BRIEF is the
   clean boundary, and nothing forces it — every template is pinned, so latest moving does not reach the desk.
3. **Whether `target` should be mandatory on share tickets** (§3 row 23). Every recorded real shape carries
   it, so this costs nothing today, but it is a stricter contract than the researcher prompt currently states.
4. **Whether an off-universe held ticker should be a veto or a warning** (§3 row 21). Built as a veto.
5. **Hazards 1 and 2** above, which are contract/config changes rather than guard changes.

## 10. Files produced

```
.scratch/changes/2026-11-20-guard-failsafe/
  before/    get-log.json (17 GETs, timestamps + bytes), live-read json, skills.json,
             versions per skill, one file per template (5)
  live/      desk-risk-guard-1795138181446404.zip (+ trend-signal, decision-journal,
             option-adapter, vwap-chop zips) and live/unpacked/desk-risk-guard/
  skill/     the candidate tree (guard.py + SKILL.md changed, four files identical)
  diff/      scripts-guard.py.patch, SKILL.md.patch, manifest.json
  tests/     run.py, real-objects-raw.json, result-live.json, result-candidate.json,
             live-run.log, candidate-run.log, apply-dryrun.log
  after/     rollback-dry-run.log + .json (timestamped), apply-dry-run.log
  tools/     assert-gates.py, make-diff.py, publish.mjs, repin.mjs, verify-after.mjs, show-pins.mjs
  read-live.mjs, apply.sh, rollback.sh
```

`publish.mjs` refuses to POST unless exactly the two intended files differ from the v13 bytes, the tree agrees
with `diff/manifest.json`, and `latest_version` is still `1795138181446404`. `apply.sh` refuses `GO=1` without
`MEMO=read` (measured: prints `REFUSED: GO=1 without MEMO=read.` and exits 2). Both scripts were run in dry-run
mode and their output is kept above; the dry-run path issues GETs only.

`docs/decisions/guard-failsafe-nov20.md` is this file.
