"""US market calendar and event rules for the 17-27 Nov 2026 competition window (stdlib only).

Sources, checked 17 Nov 2026: Moomoo strategy deck (timeline + 'Nov's must-know events'), earnings calendars
(Earnings Whispers, Investing.com), Fed/BLS release calendars. The researcher re-verifies the `verify` items
each morning; a wrong date here only makes the desk more cautious or less cautious on that day.
"""
from __future__ import annotations
from datetime import date

CLOSED = {date(2026, 11, 26): "Thanksgiving: US markets closed"}
HALF_DAYS = {date(2026, 11, 27): "Black Friday: regular session closes 13:00 ET"}

# The sleeve B fly: off on a day the desk must not carry risk into, plus a generic veto in guard.py for
# a major release that lands inside structure.release_window_et. Both are read by guard.py's iron_fly
# branch, so a date here changes behaviour instead of changing prose.
# Owner decision B7, 2026-11-22: the Wednesday-25 CONDITIONAL is withdrawn. Wed 25 is a fly day, full
# stop - it was never actually conditional, because the three releases below are all 08:30 ET and the
# holding window starts at 10:00, so the release veto could not fire for them. The veto itself stays:
# it is the desk-wide "no new 0DTE structure straddling a release" rule, not a Wed-25 rule, and deleting
# it would silently un-protect Mon 23/Tue 24 from a release nobody has scheduled yet. Only FLY_OFF is a
# per-day switch. Fri 27 stays off. Fly entry cut-off: rules.json structure.entry_window_et[1] = 11:00 ET.
FLY_OFF = {date(2026, 11, 27): "the contest final ranking is taken at the 13:00 ET close - no new 0DTE structure on the last trading day"}
MAJOR_RELEASES = {
    date(2026, 11, 25): [("PCE price index", "08:30"), ("GDP", "08:30"), ("jobless claims", "08:30")],
}

# size_mult scales every new trade that day. no_entry = list of (start, end) ET windows with no new entries.
DAYS = {
    date(2026, 11, 17): {
        "size_mult": 0.5,
        "notes": ["Retail sales 08:30 and industrial production 09:15 already out",
                  "NVDA reports after the close (~16:20 ET), first print without Huang: flat by 15:45, nothing overnight"],
    },
    date(2026, 11, 18): {
        "size_mult": 0.5,
        "no_entry": [("13:45", "14:30")],
        "notes": ["NVDA gap reaction at the open; TGT and LOW before the open",
                  "FOMC minutes 14:00 ET: no new entries 13:45-14:30; Williams speaks 13:30",
                  "Anthropic (ANT) IPO prices after the close"],
    },
    date(2026, 11, 19): {
        "size_mult": 0.5,
        "notes": ["Anthropic (ANT) first trade on Nasdaq", "WMT, INTU, ROST report before the open",
                  "Post-NVDA follow-through day"],
    },
    date(2026, 11, 20): {
        "size_mult": 1.0,
        "entry_start": "10:05",
        "no_entry": [("11:45", "12:30")],
        "notes": ["UMich sentiment 10:00 ET", "Monthly options expiration: pinning into the close",
                  "Cook speaks 12:15 ET: no new entries 11:45-12:30; Waller 08:25 is before entry_start 10:05"],
    },
    date(2026, 11, 23): {"size_mult": 1.0, "notes": ["Quiet session"]},
    date(2026, 11, 24): {"size_mult": 1.0, "notes": ["Quiet session, pre-holiday positioning"]},
    date(2026, 11, 25): {
        "size_mult": 0.75,
        "entry_start": "10:00",
        "entry_end": "14:00",
        "notes": ["PCE inflation and GDP 08:30 ET", "Day before Thanksgiving: volume thins in the afternoon"],
    },
    date(2026, 11, 27): {
        "size_mult": 0.5,
        "notes": ["Half day: flat by 12:45 ET, thin liquidity"],
    },
}

VERIFY = [
    "NVDA earnings date/time: multiple calendars say Tue 17 Nov after close; a few older pages said 18 Nov",
    "ANT pricing 18 Nov evening and Nasdaq listing 19 Nov can slip",
    "FOMC minutes 18 Nov 14:00 ET",
]


def day_rules(d: date, timing: dict) -> dict:
    """Normalised rules for one date. `timing` comes from rules.json."""
    if d in CLOSED:
        return {"status": "closed", "notes": [CLOSED[d]]}
    half = d in HALF_DAYS
    base = DAYS.get(d, {"size_mult": 1.0, "notes": []})
    entry_start = base.get("entry_start", timing["entry_start_et"])
    entry_end = base.get("entry_end", timing["half_day_entry_end_et"] if half else timing["entry_end_et"])
    flat_by = timing["half_day_flat_by_et"] if half else timing["flat_by_et"]
    notes = list(base.get("notes", []))
    if half:
        notes.append(HALF_DAYS[d])
    return {
        "status": "half_day" if half else "open",
        "fly_off": FLY_OFF.get(d),
        "releases": list(MAJOR_RELEASES.get(d, [])),
        "size_mult": base.get("size_mult", 1.0),
        "entry_start": entry_start,
        "entry_end": entry_end,
        "flat_by": flat_by,
        "no_entry": base.get("no_entry", []),
        "notes": notes,
    }
