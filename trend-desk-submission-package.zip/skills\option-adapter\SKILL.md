---
name: option-adapter
description: Sleeve B options overlay. Turns one already-approved Sleeve A entry plus a live option chain into a contract decision and an executor ticket (delta band 0.25-0.50, DTE band from rules.json, premium from last_price or the book ask only), or NONE, or STATE_UNAVAILABLE. Also classifies order rows and open option positions fail-closed. Proposes only; it has no order path.
---

# option-adapter

Sleeve B, in two shapes that share the plumbing and not the risk.

* **`select`** - a small long-premium debit call or put **on top of** an entry Sleeve A has already
  opened and desk-risk-guard has already approved, and only when the prior session's range expansion
  agrees with today's breakout direction. The premium paid is the whole risk, so this shape needs no
  stop.
* **`fly`** - a 0DTE legged iron fly (short both bodies at the money, long a put wing and a call wing
  one expected move away). This is a **credit** structure: the premium received is not the risk, the
  wing width is, so sizing is `floor(0.75 % of NAV / max_loss_per_lot)` and it **does** need an exit
  rule, which is what `mark` computes. Do not read the sentence above as applying to the fly.

Plain Python (stdlib only). No network, no MCP calls, no order placement. `select` and `fly` return a
structure plus the ticket fields an executor would submit; they never submit them. Every decision is
re-checked by desk-risk-guard - `select` through its existing `sleeve="option"` branch, `fly` through
the `iron_fly` branch that reads `structure` from `rules.json`.

Two rules this skill exists to enforce:

* **Price is `last_price`, never `option_ex_data.premium`.** That field is not a price: 0.123 was
  observed against a real last of 8.55. Sizing and the fee gate are computed from the number this
  skill calls `premium`, so a wrong source produces an unfillable limit order. Only
  delta / IV / open interest / multiplier come from `option_ex_data`, and `premium` is filtered
  out before anything else sees the row. If `last_price` is absent the ask from
  `quote_order_book` is used and `price_source` records which was taken.
* **A filled option row has never been observed on this sim.** `classify` and `reconcile` match
  states positively against the schema that has been observed and answer
  `STATE_UNAVAILABLE` for anything else. They never infer a field name or a state.

## Commands

```
python scripts/sleeve_b.py select    --input in.json --rules rules.json --guard-dir DIR [--phase bounded]
python scripts/sleeve_b.py fly       --input envelope.json --rules rules.json [--guard-dir DIR] [--no-guard] [--phase bounded]
python scripts/sleeve_b.py mark      --proposal entry.json --input quotes.json [--spot N] [--now ISO8601] [--rules path]
python scripts/sleeve_b.py reconcile --positions pos.json --orders ord.json --rules rules.json
python scripts/sleeve_b.py classify  --input rows.json [--option]
```

`fly` and `mark` live in `scripts/sleeve_b_fly.py` and are imported lazily, so the older three
commands still work if that file is ever absent. All five print one JSON line on stdout and exit 0;
an unreadable input file is reported as `{"action":"STATE_UNAVAILABLE", ...}`, not a traceback.

`--rules` is the live `references/rules.json` from desk-risk-guard. `--guard-dir` is the
directory holding its `scripts/guard.py`. Without `--guard-dir`, `select` returns
`STATE_UNAVAILABLE` rather than a ticket: guard.py is the sizing authority, not a nice to have.

## `select` input

```json
{"today":"2026-11-20","now":"2026-11-20T10:35:00-05:00",
 "a_intent":{"underlying":"SPY","dir":1,"underlying_entry":730.20,"underlying_target":734.15,
             "underlying_stop":727.57},
 "daily":[{"date":"..","open":..,"high":..,"low":..,"close":..}, ... 21+ sessions, oldest first],
 "quotes":  {"data":{"quote_list":[{"code":"US.SPY261123C740000","last_price":2.30,"volume":500,
              "option_ex_data":{"delta":0.42,"implied_volatility":37.5,"open_interest":2718,
              "contract_multiplier":100}}]}},
 "book":    [{"code":"US.SPY261123C740000","bid":2.25,"ask":2.35}],
 "portfolio": {"nav":"100000","peak_nav":"100000","day_start_nav":"100000","cash":"100000",
               "positions":[],"orders_today":0,"account_id":"5830104"},
 "size_mult": 1.0, "held_option_premium": 0}
```

| field | source |
|---|---|
| `a_intent` | the Sleeve A entry guard.py already approved this run. Sleeve B never originates a direction. `underlying_entry`/`underlying_target` set the take-profit; `dir` picks CALL (+1) or PUT (-1). |
| `daily` | 21+ completed daily bars of the underlying, oldest first, last row = the prior session (`quote_history_kline`). |
| `quotes` | `quote_stock_quote` called with option codes in `code_list` - see the live data path below. The envelope is accepted verbatim. **Not** `quote_option_chain`: that endpoint has no prices. |
| `book` | `quote_order_book` rows, only needed when a contract has no `last_price`. Option quote rows carry no top-level `bid`/`ask`, so the book is a separate call. Pass the reply through verbatim: the levels are inside `data[i].books[0]`, and the two `*_time_ms` fields in there are the only thing that dates the quote. |
| `portfolio` | built by the auditor from the live account, the same object guard.py takes. |
| `size_mult` | the regime multiplier from the 09:00 BRIEF. The option budget is `option_trade_risk_pct x nav x size_mult`, further capped by `max_open_option_premium_pct` minus what is already held. |

## Live data path

Four reads, in this order, then this skill. Each one is what the desk's moomoo MCP returns today;
the shapes below were read off real payloads, not inferred.

1. `quote_option_expiration_date` (`symbol=US.SPY`, `US.QQQ`) or `quote_option_chain` with
   `start`/`end` set to today + `risk.dte_min` .. today + `risk.dte_max`. The chain answers one
   record per CALL and per PUT with `code`, `strike_price`, `strike_time`, `option_type`,
   `lot_size`, `stock_owner` - and **no price, no greeks, no premium**. It is the list of
   candidates, nothing more. Feeding a chain payload in as `quotes` yields zero contracts, with a
   "no last_price and no usable ask - contract dropped" warning per row.
2. Take the `code` values, in OSI form already (`US.SPY261120C740000`), and put them in
   `quote_stock_quote` as `code_list`. That endpoint accepts option codes and returns one row per
   contract carrying both halves Sleeve B needs:
   `last_price` (the price) and `option_ex_data` = {`delta`, `implied_volatility`, `open_interest`,
   `contract_multiplier`, `premium`, `strike_price`, `expiry_date_distance`, ...18 keys}.
   Pass this response through as `quotes` unchanged - `data.quote_list` is the shape this skill
   already unwraps.
3. Price the selected contract off the book when `last_price` is 0 or absent: `quote_order_book`
   for that one code, passed as `book`. The `option_ex_data.premium` in the same row is **not** a
   price (0.123 against a real last of 8.55 in the 2026-11-19 capture) and this skill filters it
   out before any decision reads the row.
   The reply is NOT a flat row. OBSERVED 2026-11-21T12:36Z, captured verbatim in
   `c1/proof/live-moomoo-shapes-2026-11-21.json`: `data` is an ARRAY of per-symbol objects and the
   levels are nested one more level down -
   `{"ret_code":0,"data":[{"code":"US.SPY261123C691000","books":[{"bid_list":[{"price":9.39,"volume":8,
   "order_count":0}],"ask_list":[{"price":9.47,"volume":10}], "exchange":"US",
   "exchange_data_time_ms":1795209303054,"server_send_to_client_time_ms":1795264596025}]}]}`.
   US options are one level deep, so there is one bid and one ask, and passing the reply through
   verbatim is correct. Reading `bid_list` off the outer row instead finds nothing, which is how this
   skill used to answer `{"all_legs_two_sided": false}` on a day the market was quoting all four legs.

   **The book must be datable, and the skill refuses undated legs.** `exchange_data_time_ms` is the
   exchange stamp and `server_send_to_client_time_ms` the moment it left moomoo; the difference dates
   the quote without anyone's clock, which matters because out of hours the reply is indistinguishable
   from a live one except by that pair - a Saturday 12:36Z call returned a perfectly two-sided book
   stamped 15.4 h earlier (Fri 16:15 ET). Anything older than the 5-minute desk rule, or with no stamp
   at all and no offset-bearing `now` to compare against, declines as `stale`. It used to warn and
   build anyway, which is how a fly could be opened on evidence nobody could date.
4. `quote_history_kline` for the underlying's daily bars, remapped to this skill's field names:
   live rows arrive as `open_price` / `high_price` / `low_price` / `close_price` / `time_key` /
   `date`, and `daily` must be `open` / `high` / `low` / `close`. 21+ completed sessions, oldest
   first, last row = the prior session. A live-shaped row passed in unmapped reads as missing OHLC
   and returns `STATE_UNAVAILABLE`, which is the intended failure rather than a silent zero.

Then:

```
python scripts/sleeve_b.py select --input in.json --rules rules.json --guard-dir DIR --phase bounded
```

Index options: **the claim this file used to make - that `US..SPX` has no backend data and Sleeve B
is ETF-only - was wrong, and it cost a build day.** OBSERVED 2026-11-20/21: `quote_option_chain` with
`symbol: "US..SPX"` and `index_option_type: 1000` returns the SPXW list, and `US..SPX` also resolves
as the index itself (last 6910.39 on Fri 11-20, exactly 10x XSP's 691.04). What is actually rejected is
`index_option_type: 1002` - "must be equal to one of the allowed values" - and moomoo's own tool text
says 1002 "has no backend data and is removed", which is the sentence that was over-generalised here.
`US..NDX` is UNVERIFIED: nothing in this build calls it, so treat it as unknown rather than as data.
The plumbing consequence (D1): SPXW is the contract root in OSI codes - seven digits after the C/P
(`US.SPXW261123C6910000`) - while the chain must be requested under `US..SPX` with
`index_option_type: 1000`, so `parse_osi()` and the chain request deliberately disagree and
`chain_request()` is the only place that mapping is written down. Index options that do exist need
`index_option_type`; only `contract_multiplier` is checked: a value other than 100 drops the contract
rather than mis-sizing it.
`owner_lot_multiplier` is **not** read - live option quote rows carry `owner_lot_multiplier: 0`
even for contracts whose `contract_multiplier` is 100, so gating on it would drop everything.

### Choosing the strike window (this decides whether B has any candidate at all)

`select` cannot invent a contract: it only filters what `code_list` was given. Two facts combine to
make the window matter. First, with the live `risk.dte_min` of 1, a contract expiring today has
dte 0 and is unbuyable, so on 2026-11-20 the Nov 20 expiry - the one that was in band on Nov 19 -
dropped out entirely. Second, |delta| rises with how far an option is in the money, and a window of
strikes taken **at the last price and above** puts calls in the money and puts out of it.

What was measured on 2026-11-20. Both rows come from the SPY chain as it stood that evening (the
sandbox's ET clock read 2026-11-19), but they are **different strike selections**, not one set of
rows filtered twice:

| window | contracts in band (delta 0.25-0.50, dte 1-5, multiplier 100) |
|---|---|
| centred on last 715.87 (the rehearsal session's own selection) | 10, spread over dte 1, 4 and 5 |
| `start_near_price=715.87`, `end_near_price=717.87` (at spot and above) | 8, every one at dte 1 |

Replaying that second selection's saved rows with the clock moved to 2026-11-20 and then to
2026-11-22/23 gave `candidates_examined: 0` each time. The reason is now known exactly and it is not
the delta band: that capture contained **only the two nearest expiries** - 28 rows at `261119` and
27 at `261120`. Once the ET date reaches 2026-11-20, the Nov 19 contracts are in the past and the
Nov 20 contracts are dte 0, so every row fails `risk.dte_min` before anything looks at delta.

So the selection must cover **every** expiry in `[today + dte_min, today + dte_max]` - for SPY and
QQQ that is usually three or four distinct dates, not the nearest one - and within each expiry it
must take strikes on **both sides** of the underlying's live last price (about +/-3%, a width chosen
here rather than measured). A one-expiry or one-sided window does not make Sleeve B conservative; it
makes it unable to answer.

The inference is that the second window simply never contained an at-the-money strike for the later
expiries, so nothing could be in band there; it is an inference, the zero is the measurement.
Request strikes that straddle the underlying's live last price on both sides - about +/-3%, a width
chosen here rather than measured - for each expiry in `[today + dte_min, today + dte_max]`.

`option_ex_data.expiry_date_distance` is present on live rows and already carries the DTE. This
module does not read it - it recomputes DTE from the OSI expiry against `today` - so the number is
cross-checked rather than trusted, and a contract whose expiry string cannot be parsed is dropped.

## Gates, in order (any failure stops the pipeline)

1. `today` and `now`, `a_intent`, `portfolio.nav`/`cash`, `size_mult` and `rules.json` all present
   and numeric - else `STATE_UNAVAILABLE`. DTE is computed from `today`, never hardcoded.
2. `rules.json` carries `risk.dte_min` and `risk.dte_max` (live v12: 1 and 5). Missing or inverted
   - `STATE_UNAVAILABLE`. Nothing in this skill assumes a DTE band.
3. Confluence: `prior_day_expansion(daily)` must be +/-1 and equal to `a_intent.dir`. A qualifying
   expansion is a prior-session range at least 1.5x the 20-session average that closed in the top
   third (bullish) or bottom third (bearish) of itself. No qualifying expansion - `NONE`.
   Fewer than 21 usable bars - `STATE_UNAVAILABLE`, because missing evidence is not the same as a veto.
4. Band: `right` matches `dir`, `dte_min <= dte <= dte_max`, `0.25 <= |delta| <= 0.50`,
   `premium > 0`, `contract_multiplier` is 100. Candidates are ordered by highest |delta|,
   shortest DTE breaking ties.
5. Budget and fee: `qty = floor(budget / (limit x 100))` with `limit = premium x 1.05`, then
   guard.py's own round-trip fee gate.
6. guard.py `check` on the constructed `sleeve="option"` proposal, at the real `--now`. Its veto
   is final; its `qty` can only reduce this skill's size, never raise it.

## `select` output

`action` is `BUY_TO_OPEN`, `NONE`, or `STATE_UNAVAILABLE`.

On `BUY_TO_OPEN`, `ticket` carries exactly the field set the 2026-11-19 live pre-market probe
verified for an option buy on this sim:

```json
{"acc_id":"5830104","market":100,"order_type":1,"order_side":1,"order_trade_time_type":0,
 "symbol":"US.SPY261123C740000","qty":"1","price":"2.42"}
```

`symbol` is OSI `US.{TICKER}{YYMMDD}{C/P}{strike x 1000}`; `qty` and `price` are strings.
Also returned: `contract`, `premium` and `premium_source`, `dte`, `delta`, `limit`, `tp_limit`
(premium + |delta| x the Sleeve A move), `max_loss_usd`, `budget_usd`, `expansion`, the
`proposal` handed to guard.py and guard.py's full `guard_verdict`.

## `fly` - the 0DTE legged iron fly

Input is one envelope, all of it supplied by the caller (this skill makes no calls):

```json
{"today":"2026-11-23","now":"2026-11-23T10:12:00-05:00",
 "quotes":{"data":{"quote_list":[{"code":"US.SPY261123P691000","last_price":3.55,
                                 "data_date":"2026-11-23","data_time":1795446690000,
                                 "expiry_date_distance":0,"option_ex_data":{"implied_volatility":21.2,
                                 "contract_multiplier":100}}]}},
 "book":{"data":[{"code":"US.SPY261123P691000","name":"SPY 261123 691.00P",
                 "books":[{"exchange":"US","bid_list":[{"price":3.53,"volume":20,"order_count":0}],
                           "ask_list":[{"price":3.57,"volume":15,"order_count":0}],
                           "exchange_data_time_ms":1795446690000,
                           "server_send_to_client_time_ms":1795446691000}]}]},
 "combo":{"ret_code":0,"data":{"quote_list":[{"bid_price":-8.42,"ask_price":-8.08,"price":-8.05,
            "bid_volume":10,"ask_volume":5,"volume":4662,"turnover":1406985,
            "last_close_price":-9.7906,"rsp_code":0}]}},
 "bars5":[{"t":"09:35","o":690.65,"h":692.55,"l":688.66,"c":690.56}, ... six bars stamped 09:35-10:00
          ET, i.e. the 09:30-10:00 window under close-stamping],
 "spot":690.85, "iv":0.212,
 "venue_order":["SPXW","SPY"], "spot_by_venue":{"SPY":690.85,"SPXW":6908.5},
 "bars5_by_venue":{"SPY":[...], "SPXW":[...]},
 "portfolio":{"nav":"100000","account_id":"5830104",...}}
```

What it decides, in order:

1. **Geometry** - both shorts at `atm_strike`, wings at `atm +/- width`, legs emitted in the brief's
   1-2-3-4 order (long put wing, short put, short call, long call wing). This is the only geometry where
   `max_loss_per_lot = (width - credit) x 100` holds on both sides; a wing on one side only is a
   butterfly wearing a fly's name.
2. **Width from the expected move, never a fixed number**: `EM = S x IV_atm x sqrt(minutes_to_close /
   (390 x 252))`, rounded to that venue's strike grid ($5 SPX, $1 SPY). At 10:12 ET there are 348
   minutes to the close, so EM is not a daily move - it is what is left of one.
3. **Sizing on max loss, not premium**: `qty = floor(NAV x 0.75 % / max_loss_per_lot)`. `qty < 1` is
   `no_trade`, declined as `size`, and logged - not rounded up. **Lot convention (settled with C2, 12:03Z):
   `legs[].qty` is always 1 - the legs describe ONE lot - and the size of the trade is only the top-level
   `qty`.** The guard re-derives `max_loss_per_lot` as `(width - credit) x 100 x max(legs[].qty)`, so if the
   builder multiplied the legs too, its re-derivation carries an extra factor of `qty` and vetoes any trade
   of 2 lots or more as a mismatch - which is C2's CCR-8 finding, measured before the fix: every fly with
   `qty >= 2` was unapprovable while the arithmetic itself was right. Anything that needs contracts-per-leg
   (tickets, fees) multiplies by `qty`; `legs_per_lot` is emitted so a consumer never has to guess which
   field is which. C2 asked for the convention to be asserted rather than derived, so the emitter now
   **refuses** a leg array whose `qty` is not 1 (`legs %s do not carry qty 1 - the one-lot convention ... is
   broken at the source`) and writes `legs_per_lot: 1` as a constant instead of `max(legs[].qty)`: a shape
   the guard would veto is no longer producible here, and a future caller that builds legs by hand gets an
   error at the producer rather than a veto that reads like a market condition.
4. **D4 regime gate** on the 5-minute bars of `structure.regime_window_et` (09:30-10:00 ET), which is
   NOT the entry window: the window's move must be under `0.35 x EM` **and** its range under
   `1.00 x EM` - both are ceilings, so a wide open vetoes even when the direction is flat. Owner
   decision B6, confirmed 2026-11-22; loosened to 0.35/1.00 by owner ruling 2026-11-23 for Nov 23-24
   only, with the keep-or-revert decision due before Wed 25 08:30 ET. Before B6 the range leg was a floor
   (`range >= 0.39 x EM`), which
   asked for a wide open and then traded the breakout it had measured. Both fractions come from
   `rules.json structure` (`structure_source` says which rules.json was in force), and the refusal quotes
   the numbers. **A 5-minute bar's `t` is its CLOSE time**, verified 2026-11-22 on archived
   `quote_history_kline` captures whose regular sessions carry 78 rows stamped 09:35 through 16:00 and no
   09:30 row at all. So 09:30-10:00 ET is the six bars **stamped 09:35, 09:40, 09:45, 09:50, 09:55,
   10:00** - the 09:35 row is the 09:30-09:35 bar, and the row stamped 10:00 is the bar that ends the
   window. All six must be present: coverage is checked stamp by stamp and a missing one declines `stale`
   by name. Reading the stamps as opens measured 25 minutes and still printed a 30-minute window, which
   is the worse failure. A caller holding moomoo's native `open_price/high_price/.../time_key` rows must
   map them to `o/h/l/c/t` first: the builder declines bars it cannot read, it does not guess at field
   names.
5. **D1 venue rule**: SPXW only if its own book is two-sided on all four legs *and* it sizes to qty >= 1;
   otherwise SPY. Each attempt is recorded in `venue_trace` with the reason it failed, and the decline
   that reaches the coordinator is the **fallback venue's** reason - a stale chain must not be journalled
   as a sizing decision (it was, before this was fixed).
6. **Credit from the books**: `credit` is the smaller of (the sum of short bids minus the sum of long
   bids) and the combo bid, cross-checked against the legs; a combo that disagrees with the legs by more
   than 10 % loses and a warning says so, and so does a combo that is BETTER than they are (step 3's note
   explains why the better side cannot set the size). An empty book makes that instrument ineligible for
   the day - `last_price` is never used as a substitute for a two-sided market. Three marks are reported
   and they answer different
   questions: `credit` (bid-side, what the structure is worth if everything fills mid-market on the side
   you trade), `debit_at_ask` (both sides revalued at ask - a revaluation, not a fill), and
   `credit_crossed` = Σ short bids − Σ long asks, **the least the desk can actually receive** if every
   leg fills on the wrong side, which is the only one of the three that decides whether there is any
   credit to collect. `credit_crossed <= credit` always. A structure is refused as `no_trade` when
   `credit_crossed` is not positive, and a leg quoted `ask < bid` is refused as `book` (that is a broken
   quote, one side stale). A bid-side credit ABOVE `debit_at_ask` is *not* a broken book: it just means
   the two wings' combined spread is wider than the body's, which is ordinary for deep 0DTE strikes, so
   it warns instead of refusing - it used to refuse, which would have vetoed the trades this sleeve
   exists to take. Combo prices really arrive under `data.quote_list` (not `combo_list`) and NEGATIVE for
   a net-credit leg set - `bid_price -8.42 / ask_price -8.08 / price -8.05` on a real SPY fly, captured in
   `c1/proof/live-moomoo-shapes-2026-11-21.json`; `combo_credit` unscales with `abs()`, re-signs the pair
   and says so in `warnings`, so the marks above stay dollars. The combo may only move a mark the WORSE
   way: `credit` is the smaller of the combo bid and Σ leg bids, and `credit_basis` names which one was
   used. An undatable number cannot raise the credit that sets the size.
7. **One identity per structure** (`structure_key`): `"fly:"` + the sorted leg codes, each written
   `<OSI-without-US.-prefix>x<that leg's contracts-per-lot>` - which under the lot convention is always
   `x1`, e.g.
   `fly:SPY261123C691000x1|SPY261123C700000x1|SPY261123P682000x1|SPY261123P691000x1`. **The size is not
   in the key.** Lots travel as `qty`, contracts as `qty x legs_per_lot`, and C2's verdict keeps them in
   `order.contracts_per_leg_order`, so nothing downstream loses the number - and it has to be this way,
   because `guard.py:321` and `:666` both mirror the key from the legs alone: a builder that folded `qty`
   into the string was vetoed on every 2-lot fly with "a leg was amended" (measured against the staged
   guard at md5 `735d01bad729`, before this revision). It is a pure function of the legs - no prices, no
   seq order, no venue/expiry/qty arguments - so a re-quote keeps it and an amended wing or a rolled expiry
   breaks it. A malformed leg code yields `None` rather than a key that could collide. Consumers (guard
   verdict, tickets, the journal's one `close` record per structure, the dashboard's grouping) must use
   this and not re-derive an identity of their own: C5's CCR-3 is the reason it exists, and the
   dashboard's derived `legKey` is the fallback for rows that predate it.
8. **The proposal's own `book` block** (CCR-5): `{"all_legs_two_sided": true, "empty_legs": []}`, derived
   from the same two-sided test the pricing uses (`leg_two_sided`: both sides present and positive), not
   written as a constant. The risk guard refuses to size a fly without
   `proposal["book"]["all_legs_two_sided"] is True`, so a builder that omitted the field was vetoed every
   day with a reason that read like a market condition - which is exactly what C4 found by replaying a
   builder-shaped proposal through the staged guard. Note the collision: the **input** envelope's `book`
   is moomoo's order-book payload; the **output** `book` is this two-key summary. They are different
   documents and different shapes. A locked wing (`bid == ask`, both positive) counts as two-sided here -
   it is quoted on both sides, just with no width - and a leg with no `code` is labelled by its `seq` so
   the veto reason stays readable.

Freshness is enforced here too: any leg quote older than 300 s declines as `stale`, the same rule the
researcher applies to itself, and a leg that cannot be dated at all now declines the same way instead of
warning and building. The date comes from `exchange_data_time_ms` / `data_time` when present (with
`server_send_to_client_time_ms` giving the age at the server, which needs nobody's clock), else a
`time_key` / `update_time` stamp, compared against `now` - as a kline string or, which is what a
snapshot-shaped reply actually delivers, as an **epoch in ms** (CCR-13, from C3: their adapter feeds
`update_time` and nothing else, and the old strptime-only reader returned None for every numeric stamp, so a
quote 25 s old was declined as unverifiable on every single day). A `now` without an offset cannot be
compared to a UTC
epoch at all, so the age is reported as unverifiable rather than resolved in the caller's local zone. This box
is UTC+8 and has already been bitten once by a local `date.today()` that made a 0DTE read one day short.
`today` that disagrees with `now` is refused, because the DTE
in the codes would be a lie.

## `mark` - the exit test, from quotes only

`mark` exists because the account cannot answer "how is this position doing". OBSERVED 2026-11-20: an
option `sim_trade_position_list` row carried `unrealized_profit: NULL` **and** `realized_profit: NULL`,
the latter even after the structure was fully closed. So the loss test is recomputed from quotes, and
`reads_account_pnl: false` is in the output as a claim about what the function did not read.

`cost_to_close` is what leaves the account to go flat: the **ask** paid on the two shorts, minus the
**bid** received on the two long wings. Against the entry proposal's `exit_policy`:

| state | condition | action |
|---|---|---|
| `stop` | spot beyond a short strike by more than `width/2`, **or** cost >= `credit + 50 % of max loss` | CLOSE |
| `assignment_guard` | SPY only, after **15:00** ET, a short ITM by more than $0.50 | CLOSE |
| `expire_worthless` | session closed and every leg out of the money | HOLD, zero orders |
| `target` | cost <= 75 % of the credit received (25 % captured) | CLOSE |
| `time_exit` | at or after 15:30 ET and nothing above fired | CLOSE |
| `hold` | inside every band | HOLD |

Two ordering decisions that are easy to get backwards: the breach and stop tests precede the target test
(a structure that is halfway to max loss is also cheap to close), and `expire_worthless` precedes
`target` (after the close the wings print pennies, which would otherwise order four buy-backs to "capture"
credit that is already fully earned).

**Where the table's numbers come from.** Every threshold above is read from `rules.json structure.exit`, in
the spelling that file publishes - `target_credit_pct: 25.0` (per cent of the credit), `stop_credit_pct: 50.0`
(per cent of the max structural loss), `stop_on_strike_breach_beyond: 0.5`, `shorts_flat_by_et`,
`checks_every_min`, `first_check_et`/`last_check_et`, `assignment_guard_after_et`, `assignment_itm_min`,
`near_money_band`. Until now the builder looked up its own older names (`close_target_frac`,
`stop_loss_frac`, `check_cadence_min`), found neither in the published block and used module constants: the
guard echoed $138.75 per lot while the ticket carried 4.1625 per share, and editing rules.json moved nothing.
The proposal now emits both anchors and both spellings, plus `thresholds` (the rules block verbatim) and
`threshold_source`, so an owner edit is a live edit and a verdict can be compared to a ticket on one name.
The exit asymmetry on freshness is deliberate: `select` **declines** an undated or over-300 s quote, while
`mark` **warns** and still reports a state. An entry decision can be skipped; a close cannot be skipped
because the evidence is thin, and a position left open on a stale mark is the larger risk. The warning says
`asserted current, not shown current` so a reader is not told the mark was verified.

`mark` reports both `structure_key` (what the proposal claims) and `structure_key_now` (what the legs it
is actually marking add up to), and warns when they differ: a ticket whose wing was amended on the way is
not the structure that was approved, and that has to be visible at the exit rather than at the journal.

The two quantity fields in the output mean different things and are deliberately different numbers:
`legs[].qty` stays the one-lot mark (what a single leg of the structure is worth), while
`close_tickets[].qty` is contracts - `legs[].qty x lots` - because a ticket is an order the executor has to
size. Emitting the lot count there would have closed half of a 2-lot fly and reported the structure as flat.

The book is not automatically believed. `intrinsic_floor` is short-intrinsic minus long-intrinsic off
`spot`; if the computed cost is below it, the floor replaces the cost and a warning says the book looked
stale or a bad tick. A missing price on any leg is `STATE_UNAVAILABLE`, never a silent hold, and without
a `spot` the intrinsic, breach and ITM tests are unavailable - the output says so instead of claiming an
`expire_worthless` it cannot see.

## `classify` / `reconcile` - fail-closed fill handling

`sim_trade_history_order_list` rows carry **int** `status` and `side` with decimal-string numerics.
Observed sim statuses, which do **not** match Futu's public real-account docs:
`2` = resting, `4` = fully filled (only when `cum_qty == qty`), `5` = cancelled.
`avg_fill_price` and `cum_qty` are the authoritative fill record; there is no separate fills tool.
`today_*` fields stay null even on a same-day fill and are never read here.

Anything else is `STATE_UNAVAILABLE`, including: a status outside {2,4,5}; `status` as a string
or bool; a missing `status`/`qty`/`cum_qty`; `4` with `cum_qty != qty` or without a positive
`avg_fill_price`; `2` or `5` carrying a partial `cum_qty` (a resting or cancelled partial has
never been seen); a row that is not an OSI option when `--option`/`require_option` is set.

`reconcile` reads open option positions from `sim_trade_position_list` - filtering `qty == 0`,
because a closed position's row persists - and matches each one to its order rows. Any exposure
it cannot positively match sets `allow_new_entries: false`, which the auditor treats as: veto new
risk this run and flag it. A position whose order rows are all cancelled is reported `closed`,
not blocked. `--rules` is required, so the DTE band is guard's number rather than this skill's.

## What is still unproven

* **A filled option row HAS now been observed - on the other account.** The 2026-11-20 16:10-16:13Z
  probe on paper account `3732983` filled both legs of a two-leg option order (`avg_fill_price` 1.40
  against a 1.61 buy limit, 1.22 against a 1.19 sell limit), so `classify_fill`'s `filled` branch is no
  longer reachable only in tests, and the row shape it matches is real: `status: 4` with
  `cum_qty == qty`, `price` carrying the **limit** not the fill, `today_*` staying null. What is still
  unproven is **`5830104`, the competition account the desk trades** - no option fill has ever been seen
  there, and same-shape behaviour there is an inference, not a measurement.
* **Option fees are not measured.** `account_order_fees` failed three times with `-32603` during that
  probe, so the $2.29-per-side figure in the plan is moomoo's published schedule, not an observation.
  `fee_per_order()` implements `max(1.99, 0.65n) + 0.318n` per order for that reason.
* **The SPXW intraday book.** In the 2026-11-20 captures the SPXW and XSP books were empty while SPY's
  was two-sided, which is why `venue_trace` exists. A book can start filling, so check M1 on the morning
  of the first trade re-decides this - do not read the empty book as a property of index options.
* **`mark` has never run against a live open fly.** Its states are exercised against generated envelopes
  in `test_fly.py` group 13, and the enforcement lag it assumes - 12 to 22 minutes from a check firing to
  an order resting - is a measurement of *this desk's* schedule latency, not of the broker. Nothing here
  can shorten that lag; the width is chosen so the lag is affordable.
* **Combo quotes are corroborating, never authoritative.** OBSERVED 2026-11-21 on a real four-leg SPY
  fly (bytes in `c1/proof/live-moomoo-shapes-2026-11-21.json`): the reply nests under `data.quote_list`,
  is already divided by 1e9, and is NEGATIVE in every field for a net credit. Its bid 8.42 was ABOVE the
  8.25 the four leg bids sum to, so the builder takes `min(combo_bid, sum of leg bids)` - a number with
  no timestamp cannot raise the credit that sets the size. Its `volume` 4662 and `turnover` 1406985 are
  echoes of two *different* legs (the C691's volume, the P681's turnover) and its `bid_volume`/`ask_volume`
  10/5 match no leg book at all, so a combo says nothing about fillable size. A mixed-sign pair is
  refused rather than interpreted. Before this was read, the parse looked only under `data`, found nothing
  in `data.quote_list`, and every fixture run believed it was cross-checking a combo while it was silently
  pricing off the legs.

